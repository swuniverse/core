Implement exactly the issue **col-C3 — Schildgenerator-Schnellschalter im Verteidigungspanel**. Your isolated worktree is based on the current committed `stu-parity` HEAD. The coordinator checkout contains a newer uncommitted, Product-Owner-confirmed issue version; use the full specification below as authoritative. Do not edit `.scratch/stu-parity/issues/col-C3-schildgenerator-schnellschalter.md` in your commit because that local clarification is not present in this worktree; report completion and let the coordinator update ticket status after review.

## Current authoritative issue

# Schildgenerator-Schnellschalter im Verteidigungspanel

**Status:** ready-for-agent
**Priority:** P3
**Size:** S
**Blocked by:** —

### Ziel
In STU lassen sich die Kolonieschilde im Verteidigungsmenü direkt aktivieren und deaktivieren. In SWU geht das nur über das Feld des Schildgenerators. Der Schnellschalter nutzt die bestehende Gebäudeschaltung und damit die Schildkappung aus col-A1b.

### STU-Quellen
- `src/Module/Colony/Action/ActivateShields/`, `src/Module/Colony/Action/DeactivateShields/`
- `src/html/colony/component/colonyShields.twig`

### SWU-Pfade
- `apps/frontend/src/pages/colonies/components/PanelDefense.tsx`
- `apps/backend/src/modules/colony/colony-construction.service.ts` (`toggleBuilding`) bzw. ein schlanker Endpunkt in `colony.controller.ts`
- `apps/backend/src/modules/colony/colony-defense.service.ts`

### Akzeptanzkriterien
- Das Verteidigungspanel zeigt den Zustand des Schildgenerators (aktiv/inaktiv) und einen Knopf zum Umschalten.
- Das Umschalten verwendet dieselben Regeln wie die Feldschaltung (Energie, Schaden, Blockade, Hook aus col-A1a/b); beim Deaktivieren fallen die Schilde auf 0.
- Der Schnellschalter ist nur bei genau einem Schildgenerator verfügbar; bei keinem oder mehreren wird er nicht angeboten, wie in STU.
- `PanelDefense` is the public frontend test seam: test displayed state and both toggle directions through component callbacks. This UI test does not prove server-side building rules. Add a backend test if a new endpoint is required; prefer reusing the existing building-toggle route/rules.

## Work rules

1. Read `AGENTS.md`, `CONTRIBUTING.md`, `CONTEXT.md` if present, relevant domain docs/ADRs, and this issue context. Use CodeGraph before grep/reading source because this repository has `.codegraph/`.
2. Strict TDD: write one focused test, observe a meaningful RED, implement minimally, observe GREEN. Do not weaken tests.
3. Use npm/npx only; do not modify package-manager files, `nx.json`, or STU reference code. Do not edit map files or other issue files. Avoid unrelated formatting churn.
4. Run focused frontend tests and any required backend tests, relevant typecheck/lint/build where available, and `git diff --check`. Report any gate limitations accurately.
5. Commit exactly one focused implementation commit only after required criteria pass. Use a descriptive message ending with `(stu-parity col-C3)` and trailer `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Do not push, merge, switch branches, or manage worktrees. Stop after commit for independent review.
6. End with observed RED/GREEN, checks and limitations, commit hash, changed-file scope, and any unresolved requirement.

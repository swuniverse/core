# K5b blocked candidate handoff — 2026-11-10

## Decision and scope

**Not accepted / not integrated.** The required full frontend gate is red. Preserve the bounded candidate for the original two Sol reviewers and serial integration; do not start another ticket. K5b is `ready-for-human`, with its acceptance checklist unchecked and a new accurate comment appended; historical comments are preserved. No tutorial change, assertion weakening, skipped test, waiver, or blind rerun. No push/merge/cleanup.

Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k5b`; branch `agent-tmw-k5b`. Base: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`. Final local commit SHA/tree and issue hash are appended after commit below.

## Blocker checkpoint (recorded before remaining stable gates)

Fresh full frontend gate `k5b-21-final-frontend` exited **1**, source unchanged: 92 files passed / 1 failed; 665 tests passed / 1 failed (666 total). Failure: unchanged `apps/frontend/src/components/tutorial/TutorialPadd.spec.tsx:34` expects the target's `tutorial-target` class after heading render, received false. The component applies/removes that class in an effect. Root cause and baseline reproducibility are **not established**; unchanged files alone do not establish a preexisting failure or flakiness. This is a fresh current failure, not the historical readonly constructor blockers.

Direct [log](gates/k5b-21-final-frontend.log) / [receipt](gates/k5b-21-final-frontend.json). No acceptance claim. The subsequent lint, forced spec types, regular types and builds all passed, but do not waive this failure.

## Implemented contract (source observations, separate from execution)

- `LayerAccessService` is the current central policy, querying current knowledge on each request. Players get known **nonhidden** choices; knowledge-record presence suffices, including `KNOWN` and `EXPLORED`. No `EXPLORED` prerequisite is introduced. Known hidden layers are denied. Unknown existing layers produce HTTP 403; nonexistent layer/system/region lookups retain 404 semantics for players.
- Admin or `MAP_EDITOR` bypass preserves direct role access. Listings retain the prior nonhidden-layer selection for those roles; existing admin route guards remain authoritative. No role redesign.
- `LayerAccessGuard` runs after JWT at the starmap controller boundary, and on database system detail / spacecraft starmap contacts. It resolves direct layer params and indirect system/region IDs; exploration body and contact query layer IDs are covered. Admin routes retain their original protection.
- Database systems, system-type and planet-type catalogs obtain authorized layer IDs through the same service and reject an explicitly unknown/hidden player filter. Systems are queried within allowed layers. Types are restricted to occurrences in allowed systems; planet queries join the parent system and retain the layer constraint. Empty allowed sets return empty results.
- Existing system discovery, cartography, fog projection and exploration checks remain in addition to the layer perimeter. No wormhole-arrival reimplementation; existing arrival already marks destination knowledge. No migration/entity/schema change.
- Frontend type catalogs render backend-returned layer options and submit the chosen `layerId`; systems and starmap retain their existing backend-driven selectors. Tests cover returned choices and exclusion of an unknown URL layer. No ship-list tooltip or unrelated UI implementation changes.

### Endpoint inventory

Production HTTP tests exercise these ten player layer routes with unknown 403, known access and known-hidden 403:

1. `GET /api/starmap/layers/:layerId/systems`
2. `GET /api/starmap/layers/:layerId/hyperspace-routes`
3. `GET /api/starmap/layers/:layerId/fields`
4. `GET /api/starmap/layers/:layerId/export.json`
5. `GET /api/starmap/layers/:layerId/sectors`
6. `GET /api/starmap/layers/:layerId/sectors/:sectorX/:sectorY`
7. `GET /api/starmap/layers/:id/wormholes`
8. `GET /api/starmap/layers/:layerId/explored-sector/:sectorX/:sectorY`
9. `GET /api/starmap/layers/:layerId/exploration`
10. `GET /api/starmap/layers/:layerId/influence/:sectorX/:sectorY`

Indirect coverage: starmap system detail and grid; database system detail; explored region; `POST /api/starmap/exploration/discover-field`; `GET /api/spacecraft/starmap-contacts?layerId=…`. Personal discovery/field exploration fixtures on an unknown layer cannot bypass the layer check. Catalog coverage: `/api/database/systems`, `/system-types`, `/planet-types`, including explicit filters, populated occurrence isolation, empty known layers and knowledge removal between requests. Listing: `/api/starmap/layers`. Both admin and editor role cases exercise direct/indirect/catalog access and original role choices. Authentication/malformed-ID cases verify 401/400.

## Public seams and limitations

`layer-access-http.int-spec.ts` runs **45** tests against the real production `AppModule`, JWT strategy, controllers, authorization guard/service, query services and repositories. Nest routing/global prefix and ValidationPipe are active; requests are authenticated HTTP fetches, not direct controller invocation. Disposable PostgreSQL **16** is populated through committed migrations, `synchronize:false`. Only configuration/datasource wiring and websocket notifications are substituted. Both ambient DB URLs are removed by the supplied wrapper; no dev/shared DB was used. Local literal JWT signing string is test-only, not an inspected secret.

The existing `starmap-export.int-spec.ts` adds **4** compatibility tests with substituted auth/persistence; it is **not** production authorization proof. Mocked controller constructor fixes are compatibility evidence only. No unconditional full PostgreSQL suite was run.

Frontend tests observe rendered choices and API requests at the pre-agreed UI seam; their API fixtures do not independently prove backend authorization. Authorization evidence is the real HTTP suite above.

All gates used `python3 -I .workmux/local-inputs/direct-gate.py --name UNIQUE -- npm exec --offline -- …`. Nx gates use `--skip-nx-cache`, `NX_DAEMON=false`, `NX_NO_CLOUD=true`. All 25 receipts record actual child exit, direct log SHA-256 and unchanged source during the gate. Regular `tsc --build` commands can still use incremental compiler artifacts even with Nx cache bypass; forced spec-inclusive gate 23 is separate fresh evidence. Counts below report runner summaries; no skips are reported in the summarized passing suites/full frontend suite. No test filters are represented as full-suite evidence. No historical/cached run substitutes for a fresh gate.

## RED/GREEN and final evidence inventory

Every row links the direct log and receipt; receipts also contain exact command and source hashes. Failed executions remain failures.

| Gate | Exit | Direct evidence | Outcome |
| --- | ---: | --- | --- |
| `k5b-01-spec-types` | 2 | [log](gates/k5b-01-spec-types.log) / [receipt](gates/k5b-01-spec-types.json) | Early forced backend/frontend spec types: unused fixture / unknown JSON typing. Fixed fixture typing; not behavior RED. |
| `k5b-02-layer-choices-red` | 1 | [log](gates/k5b-02-layer-choices-red.log) / [receipt](gates/k5b-02-layer-choices-red.json) | Genuine HTTP RED: unknown layer listed; 1 failed. |
| `k5b-03-layer-choices-green` | 0 | [log](gates/k5b-03-layer-choices-green.log) / [receipt](gates/k5b-03-layer-choices-green.json) | Central listing policy; 1/1 passed. |
| `k5b-04-layer-endpoints-red` | 1 | [log](gates/k5b-04-layer-endpoints-red.log) / [receipt](gates/k5b-04-layer-endpoints-red.json) | Direct endpoint perimeter absent: 10 failed, 1 passed (11). |
| `k5b-05-layer-endpoints-green` | 0 | [log](gates/k5b-05-layer-endpoints-green.log) / [receipt](gates/k5b-05-layer-endpoints-green.json) | Central starmap guard: 11/11 passed. |
| `k5b-06-indirect-red` | 1 | [log](gates/k5b-06-indirect-red.log) / [receipt](gates/k5b-06-indirect-red.json) | Indirect perimeter absent: 5 failed, 11 passed (16). |
| `k5b-07-indirect-green` | 0 | [log](gates/k5b-07-indirect-green.log) / [receipt](gates/k5b-07-indirect-green.json) | System/region/body resolution, database detail guard: 16/16 passed. |
| `k5b-08-database-red` | 1 | [log](gates/k5b-08-database-red.log) / [receipt](gates/k5b-08-database-red.json) | Catalog filtering/choices missing: 3 failed, 16 passed (19). |
| `k5b-09-database-green` | 0 | [log](gates/k5b-09-database-green.log) / [receipt](gates/k5b-09-database-green.json) | Central catalog authorization and query constraints: 19/19 passed. |
| `k5b-10-spec-types` | 2 | [log](gates/k5b-10-spec-types.log) / [receipt](gates/k5b-10-spec-types.json) | Early forced types caught ParseIntPipe string/undefined/body typing; fixed explicitly. |
| `k5b-11-frontend-filter-red` | 1 | [log](gates/k5b-11-frontend-filter-red.log) / [receipt](gates/k5b-11-frontend-filter-red.json) | Invalid Vitest `--testFile` invocation; **not behavior RED**. No package/Nx edit. |
| `k5b-12-frontend-filter-red` | 1 | [log](gates/k5b-12-frontend-filter-red.log) / [receipt](gates/k5b-12-frontend-filter-red.json) | Correct `--args='run …'` invocation: selectors absent; 2 failed, 17 passed (19). |
| `k5b-13-frontend-filter-green` | 0 | [log](gates/k5b-13-frontend-filter-green.log) / [receipt](gates/k5b-13-frontend-filter-green.json) | Backend-driven type selectors/filter requests: 19/19 passed. |
| `k5b-14-perimeter-red` | 1 | [log](gates/k5b-14-perimeter-red.log) / [receipt](gates/k5b-14-perimeter-red.json) | 2 failed, 42 passed (44): genuine contacts-query bypass plus invalid planet fixture (90001 decodes invalid type 0). |
| `k5b-15-perimeter-green` | 0 | [log](gates/k5b-15-perimeter-green.log) / [receipt](gates/k5b-15-perimeter-green.json) | Contacts guard; valid planet fixtures 90010/90020/90030 with strict total/content assertions retained: 44/44 passed. |
| `k5b-16-spec-types` | 0 | [log](gates/k5b-16-spec-types.log) / [receipt](gates/k5b-16-spec-types.json) | Forced backend/frontend spec types passed. |
| `k5b-17-focused-backend` | 0 | [log](gates/k5b-17-focused-backend.log) / [receipt](gates/k5b-17-focused-backend.json) | 6 suites / 24 tests passed; fixture/module compatibility. |
| `k5b-18-focused-frontend` | 0 | [log](gates/k5b-18-focused-frontend.log) / [receipt](gates/k5b-18-focused-frontend.json) | Database + starmap: 2 files / 56 tests passed. |
| `k5b-19-final-http` | 0 | [log](gates/k5b-19-final-http.log) / [receipt](gates/k5b-19-final-http.json) | 2 suites / 49 tests passed: 45 production K5b + 4 narrower export compatibility. Targeted disposablePG, not fullPG. |
| `k5b-20-final-backend-units` | 0 | [log](gates/k5b-20-final-backend-units.log) / [receipt](gates/k5b-20-final-backend-units.json) | Full backend: 214 suites / 1996 tests / 1 snapshot passed. |
| `k5b-21-final-frontend` | **1** | [log](gates/k5b-21-final-frontend.log) / [receipt](gates/k5b-21-final-frontend.json) | Full frontend: 1 failed + 92 passed files; 1 failed + 665 passed tests. **Acceptance blocker**, detailed above. |
| `k5b-22-final-lint` | 0 | [log](gates/k5b-22-final-lint.log) / [receipt](gates/k5b-22-final-lint.json) | Backend/frontend lint passed with warnings: frontend 110, backend 1438; 0 errors. |
| `k5b-23-final-spec-types` | 0 | [log](gates/k5b-23-final-spec-types.log) / [receipt](gates/k5b-23-final-spec-types.json) | `tsc --build apps/backend/tsconfig.spec.json apps/frontend/tsconfig.spec.json --force --pretty false` passed. |
| `k5b-24-final-types` | 0 | [log](gates/k5b-24-final-types.log) / [receipt](gates/k5b-24-final-types.json) | Backend/frontend Nx typechecks plus shared dependencies passed; ordinary TS incremental caveat above. |
| `k5b-25-final-build` | 0 | [log](gates/k5b-25-final-build.log) / [receipt](gates/k5b-25-final-build.json) | Backend webpack and frontend Vite production builds plus shared build passed. CSS @import ordering and large-chunk warnings retained. |

Final production source/test hashes remained identical across gates 19–25. The only later tracked edit is K5b status/comment metadata; no production source or test edit follows final HTTP. Evidence files are ignored `.workmux` artifacts, not a transcript/tool-result export.

## Changed production/test paths — SHA-256

These hashes match the final gate receipts and the working candidate before commit:

```text
4276933d08069097a07813f252dc90fabaa9956022b6a9f6a56e692edc8b9216 apps/backend/src/modules/database/database-commodities.controller.spec.ts
6b15e73680ab3d175c97872b7206da711e33365165a1c6c96a258ff0e684081b apps/backend/src/modules/database/database-system-detail.controller.spec.ts
c3ed01e92f6c8d4182efc0be3834efc1f4b32e37fe20002cdb81dbcbf6ec11c2 apps/backend/src/modules/database/database.controller.ts
a123fb3a9109ca3a5161092072f71bd7bd418f11b65f973ba907f8d35f9028ff apps/backend/src/modules/database/database.module.ts
70cb5d466e8dac4363f1473cd66859ef21ff8d97a66e939b4e16ad2de8dda67a apps/backend/src/modules/database/database.service.ts
56689749e3763f56e78302fa27425d61209bc467099f098827d6ab877de08c36 apps/backend/src/modules/spacecraft/spacecraft.controller.ts
bcc38cb036076cb48bb4e4bef10a0dd03a3ee5db2cc64c0f05acd41d4c7fd08f apps/backend/src/modules/starmap/layer-access-http.int-spec.ts
344841e0ac55cd88ee127c67b64315f1e02a90ecaf6abb36aaa364cfa79be146 apps/backend/src/modules/starmap/layer-access.guard.ts
113b7602f75543385fb58cf796cd5769b33d36b10b1f5dfb63c0b49d6f3863ef apps/backend/src/modules/starmap/layer-access.service.ts
1ed5a78c8d2eca20083df47ef0d3937925566586ada7f2a5d59a5e1fc7ce4708 apps/backend/src/modules/starmap/starmap-export.int-spec.ts
f0010591489d9f08abd1f35f220023cf0c9f84ea90b74b98d708963e9a9118f5 apps/backend/src/modules/starmap/starmap.controller.spec.ts
7b8f83a41c29d072f9e58d282afd4d4caf22c747ed67f928d529baf9fabd1dde apps/backend/src/modules/starmap/starmap.controller.ts
bce4a45bf9173b4eb99b9fa7ac10934e8c68ba7ea6e0e1acf1a1210b47edb694 apps/backend/src/modules/starmap/starmap.module.ts
a109c3ed9b721baaaa6f8309166030ad15a44713d3df34be4d08472a796fd941 apps/frontend/src/pages/database.spec.tsx
2bb252e0cb91400978d792eb79df378573648cc077ccc23d672d031236b4ff88 apps/frontend/src/pages/database.tsx
9b7e0dbe17f2d5898bcac59a0b6f764685a72c4674c08bd1f47e1b2da934db12 apps/frontend/src/pages/starmap.spec.tsx
```

No nested agent/workflow, indexing, package/lock/Nx/map/DECISIONS/STU change, external service, secret inspection, dev/shared DB, push, merge or cleanup. Data/dependencies were preprovided. Independent review and serial integration have not occurred; this report is an implementation/evidence handoff, not reviewer approval.

## Final committed candidate identity

- Local Conventional Commit: `b32bc992bcdc2087b30a75362c01c1061760b42d` — `feat(starmap): enforce known-layer access and catalog filters`.
- Commit message explicitly records the blocked checkpoint and ends `Co-Authored-By: Claude Code <noreply@anthropic.com>`.
- Candidate tree: `b9255dbc49093885778315a71485b77eefa87aa7`.
- Parent/base: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Exactly 17 changed tracked paths: the 16 production/test paths hashed above plus the issue metadata below.
- Issue SHA-256: `ad056dd7ea4d79a17c7325052d712ff4b83b3387a8fffdd49cd3f754f6bbbad7` — `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md`.
- Post-commit identity check verified each committed production/test blob matches the gate-19 receipt and every final gate 19–25 before/after source hash map; direct log SHA-256 values for those receipts also verified. This is source/evidence identity checking, **not an additional test run**.
- Tracked working tree clean after commit. Report confirmed ignored. No gates rerun after commit; later tracked changes are only the documented status/comment metadata. No all-green claim.

**Handoff:** preserve this candidate for the original two Sol reviewers. Resolve the required frontend failure under authorized scope before acceptance/serial integration. Do not treat this commit, unchecked checklist, or successful backend gates as integration approval. Stopped; no next ticket.

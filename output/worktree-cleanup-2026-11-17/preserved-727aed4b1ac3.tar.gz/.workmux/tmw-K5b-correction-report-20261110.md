# ORIGINAL K5b correction handoff — 2026-11-10

## Disposition

All currently supplied concrete corrections are implemented with passing final affected gates. **Not independently accepted or integrated.** Stop for the original Spec and Standards reviewers' narrow rereview. K5b remains `ready-for-agent`; all seven acceptance criteria remain unchecked. No combined UI-1b acceptance, merge, push or next ticket.

Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k5b`; branch `agent-tmw-k5b`. BASE `699258b4f7f23cdd4cdc6675781677e9a8307b6b`. Original candidate `b32bc992bcdc2087b30a75362c01c1061760b42d` / tree `b9255dbc49093885778315a71485b77eefa87aa7` is preserved; no amend/reset/rebase. Final follow-up SHA/tree/path hashes are appended after the local correction commit.

Original report `.workmux/tmw-K5b-report-20261110.md` remains untouched (SHA-256 `9c90b4a504860d9c5279f32a916c217f689a9edc1340dfba7a818d844338c790`). All original logs/receipts and historical tracker comments, including the incorrect blocked-human handoff, are preserved. New correction comments append rather than replace history.

## 1. Tutorial failure: demonstrated test/effect observation race

### Original failure and tight loop

Original `k5b-21-final-frontend` remains **exit 1**, 665 passed / 1 failed tests across 93 files. Direct log points to `TutorialPadd.spec.tsx:34`: exact expected `tutorial-target` membership **true**, received **false** after finding the heading. Unchanged source was never treated as proof of baseline failure/flakiness.

The original tutorial test and actual `TutorialPadd` / `useTutorial` code were inspected. API resolution updates tutorial state; the heading is committed in the render, while the class is applied/removed by `useEffect([step])`. Testing Library's `findByRole` observes the DOM; its async wrapper adds a zero-delay timer but does not promise passive-effect completion. React scheduler can yield after a commit. Inspection of existing K5b fixtures found local API mocks, auto cleanup via Testing Library and default Vitest file isolation; no shared tutorial-target mutation or timers were introduced by those fixtures.

Ranked falsifiable hypotheses shown before the controlled probe: (1) heading precedes passive class effect, (2) K5b fixture contamination, (3) tutorial lifecycle never applies/removes highlight correctly. Initial isolated run passed 3/3; repeating the unchanged assertion 40 times passed 42/42. Neither pass explained the full-suite failure. A React `Profiler` wrapping the real component with an 8ms commit-pressure callback produced the **same exact class failure** once in 40 cases, without K5b page tests. Reducing to one case passed, so pressure alone was not claimed deterministic.

A temporary diagnostic pinned the early-observation window: `configure({ asyncWrapper: callback => callback() })` removed Testing Library's incidental timer drain and the Profiler commit callback spent 25ms (beyond the inspected scheduler's 5ms frame budget). No production method/effect was mocked or changed. This ran the actual component/API/DOM path and failed the exact class assertion twice: c05 (1 failed/2 passed), c06 (selected original assertion failed). The diagnostic generated act warnings, transparently retained in its logs. This deliberately sharper timing probe is not represented as default production timing or baseline evidence.

**Single-variable GREEN:** keep the same pinned probe and change only:

```tsx
await waitFor(() => expect(document.querySelector('[data-tutorial="menu"]')?.classList.contains('tutorial-target')).toBe(true));
```

c07 passed 3/3. Therefore the real highlight effect completes after the heading observation; bounded waiting for the actual class satisfies the original expectation instead of depending on incidental scheduling. A permanently absent class still times out/fails. Dismissal still asserts the class is removed. No class insertion in the test, assertion weakening, product change, fake-timer waiver or skip declaration.

### Final repair / cleanup

Only the one-line `waitFor` synchronization remains in `TutorialPadd.spec.tsx`. Profiler, repetition, pressure loop and temporary async-wrapper configuration are all removed before stable gates; no debug instrumentation or throwaway file remains. Tutorial production component/hook unchanged. The default-configuration focused run includes starmap → database → tutorial with one worker and default isolation: 59/59 passed. Full default frontend subsequently passed 666/666; after later authorized shared/catalog source changes the invalidated full frontend was rerun once and again passed 666/666 on final source.

**Cause conclusion:** demonstrated heading/passive-highlight-effect race in the original test's observation, not a proven historical baseline exception. No K5b fixture contamination demonstrated; no fixture repair was justified. No broader tutorial implementation needed. Exact origin of OS/load timing in the first full run is not a forensic claim.

## 2. Spec P2: planet surface missing layer perimeter

Independent input `.workmux/local-inputs/k5b-spec-review-20261110.md` reviewed the exact original candidate by source, not HTTP. Worker confirmed production `StarmapModule` registers `PlanetSurfacesController`; its `GET /api/starmap/planets/:id/surface` had JWT only. Handler calls `PlanetGeneratorService.getPlanetFields(id)` and `StarmapService.getCelestialObject(id)` without authorization. Guard lacked a planet-ID branch. The issue goal/decision covers this indirect map path; no new product restriction is invented.

**Runtime RED c13:** real production AppModule, JWT, routes/guards/services/repositories against disposable PostgreSQL 16 with committed migrations and `synchronize:false`. Fixtures create actual parent systems, celestial objects and ORBIT/SURFACE/UNDERGROUND fields. Both unknown and known-hidden player requests returned **200 instead of 403**. 2 failed / 49 passed (51 total). These are worker-executed public regressions, not the reviewer's unexecuted source claims.

**Narrow fix:** add CelestialObject repository to the existing `LayerAccessService`; `assertPlanetAccess` loads object ID, preserves `Celestial object not found` 404, resolves its parent via existing `assertSystemAccess`, and calls existing current layer policy. Guard handles `/planets/:id`; only player surface method receives `LayerAccessGuard` after controller JWT. Guard completes before either handler field/detail read. Existing module already provides object repository; no migration/schema/module redesign. Export compatibility fixture adds the new constructor slot only, assertions unchanged.

**GREEN c14/final c18:** all original 45 production cases retained plus six new cases = **51 production HTTP tests**. New tests: two unknown/hidden denial cases; three player/admin/editor allow cases checking actual planet detail and orbit/surface/underground coordinates/tiles; one 401/malformed400/missing404 compatibility case. KNOWN without EXPLORED permits player access; admins/editors access both unknown and hidden planets. No discovery/colonization prerequisite introduced. Final targeted run: 51 production + 4 narrower export compatibility = **55/55**, two suites. Export compatibility substitutes auth/persistence and is not production authorization proof. No full PostgreSQL suite.

## 3. Standards: shared catalog contract

Validated `CONTRIBUTING.md:73`: shared DTOs/interfaces belong in `packages/shared`. Added only the newly introduced type-catalog seam in `packages/shared/src/lib/database/index.ts`:

- `DatabaseLayerChoiceDto = Pick<StarmapLayerDto, 'id' | 'name'>`.
- Shared `DatabaseTypeCatalogDto<Entry>` with layers/discovered/total/entries.
- Concrete system/planet entry and response contracts.

Backend controller methods explicitly return `Promise<DatabaseSystemTypesDto>` / `Promise<DatabasePlanetTypesDto>`; TypeScript verifies inferred service payloads and layer projections conform. Frontend uses those types in `api.get`, stores returned choices as `DatabaseLayerChoiceDto[]`, and replaces existing local system/planet type shapes with shared aliases. The new selector's inline local cast is removed. No broad historical database DTO migration, any-cast waiver or spacecraft contract edit. User explicitly authorized this bounded Shared scope; UI-1b's spacecraft index remains untouched/unmerged.

Forced backend/frontend spec-inclusive compile c16 passed, including app project references and integration specs. Final shared build/typecheck and backend/frontend typechecks passed. Existing catalog behavior HTTP/UI tests remain and pass.

## 4. Standards: compact new selector

Validated `.scratch/stu-parity/inventory/shell-admin-runtime.md:216–219` (`text-xs` on game pages). Added a public rendered-label class assertion to the two existing catalog selection tests. c15 RED: 2 failed/17 passed, actual `text-xs` absent. Changed **only the new** type-catalog label from `text-sm` to `text-xs`, inherited by its select. c17 GREEN: 59/59 focused UI tests with prior options/filter assertions unchanged. Older system selector/table typography and ship-list/Tooltip paths remain untouched.

## 5. Metadata correction

Restore status `ready-for-agent`, retain all unchecked acceptance criteria. Append coordinator correction explaining a technical test failure is not a human implementation decision; append final factual source/runtime correction evidence. Preserve every historical comment including prior `ready-for-human` handoff as history, not current status. No completion/acceptance label or integration approval.

## Direct execution inventory

All commands use supplied `python3 -I .workmux/local-inputs/direct-gate.py --name UNIQUE -- npm exec --offline -- …`. Each receipt contains exact argv, before/after source hashes, direct log SHA-256 and actual numeric child exit. All below record `source_unchanged:true`; log hash linkage verified. DB URLs removed by wrapper; no environment value/secret inspection. Nx `--skip-nx-cache`, daemon/cloud disabled. Ordinary TS build incremental artifacts remain possible; forced compile c16 is separate evidence, not a cache-clear claim.

| Gate | Exit | Direct log / receipt | Result and evidence scope |
| --- | ---: | --- | --- |
| c01 tutorial-repro | 0 | [log](gates/k5b-c01-tutorial-repro.log) / [receipt](gates/k5b-c01-tutorial-repro.json) | Original isolated tutorial 3/3; not explanatory RED. |
| c02 repeated-public-red | 0 | [log](gates/k5b-c02-repeated-public-red.log) / [receipt](gates/k5b-c02-repeated-public-red.json) | Diagnostic repetition 42/42; name does not imply actual failure. |
| c03 controlled-commit-red | 1 | [log](gates/k5b-c03-controlled-commit-red.log) / [receipt](gates/k5b-c03-controlled-commit-red.json) | Pressure reproduces exact class race: 1 failed/41 passed. |
| c04 minimal-pressure-red | 0 | [log](gates/k5b-c04-minimal-pressure-red.log) / [receipt](gates/k5b-c04-minimal-pressure-red.json) | One pressure case + two existing cases pass; not deterministic alone. |
| c05 heading-effect-window-red | 1 | [log](gates/k5b-c05-heading-effect-window-red.log) / [receipt](gates/k5b-c05-heading-effect-window-red.json) | Pinned early observation: 1 failed/2 passed. |
| c06 pinned-window-confirm | 1 | [log](gates/k5b-c06-pinned-window-confirm.log) / [receipt](gates/k5b-c06-pinned-window-confirm.json) | `-t "renders BBCode"` isolation: exact failure again; 2 other tests filtered (runner says skipped). Diagnostic only, **not zero-skip acceptance evidence**. No source skip declaration. |
| c07 pinned-window-green | 0 | [log](gates/k5b-c07-pinned-window-green.log) / [receipt](gates/k5b-c07-pinned-window-green.json) | Only exact assertion synchronization changed; same pinned probe 3/3. |
| c08 early-spec-types | 0 | [log](gates/k5b-c08-early-spec-types.log) / [receipt](gates/k5b-c08-early-spec-types.json) | Early forced backend/frontend specs after clean one-line repair. |
| c09 focused-order-green | 0 | [log](gates/k5b-c09-focused-order-green.log) / [receipt](gates/k5b-c09-focused-order-green.json) | One-worker starmap/database/tutorial, defaults restored: 3 files/59 tests. |
| c10 final-full-frontend | 0 | [log](gates/k5b-c10-final-full-frontend.log) / [receipt](gates/k5b-c10-final-full-frontend.json) | Tutorial-only corrected source: 93 files/666 tests. Later catalog/shared changes invalidate final-candidate use. |
| c11 final-frontend-lint | 0 | [log](gates/k5b-c11-final-frontend-lint.log) / [receipt](gates/k5b-c11-final-frontend-lint.json) | Tutorial-only correction; 110 warnings/0 errors. Later superseded. |
| c12 final-frontend-build | 0 | [log](gates/k5b-c12-final-frontend-build.log) / [receipt](gates/k5b-c12-final-frontend-build.json) | Tutorial-only correction frontend/shared dependency build; later superseded. |
| c13 planet-surface-http-red | 1 | [log](gates/k5b-c13-planet-surface-http-red.log) / [receipt](gates/k5b-c13-planet-surface-http-red.json) | Real production unknown/hidden surface bypass, 2 failed/49 passed. |
| c14 planet-surface-http-green | 0 | [log](gates/k5b-c14-planet-surface-http-green.log) / [receipt](gates/k5b-c14-planet-surface-http-green.json) | Central planet policy, 51/51 production HTTP; later shared controller typing change covered by c18. |
| c15 compact-selector-red | 1 | [log](gates/k5b-c15-compact-selector-red.log) / [receipt](gates/k5b-c15-compact-selector-red.json) | Two rendered-label compact-rule failures; 2 failed/17 passed. |
| **c16 corrected-spec-types** | **0** | [log](gates/k5b-c16-corrected-spec-types.log) / [receipt](gates/k5b-c16-corrected-spec-types.json) | **Final** `tsc --build apps/backend/tsconfig.spec.json apps/frontend/tsconfig.spec.json --force --pretty false`. |
| **c17 compact-selector-green** | **0** | [log](gates/k5b-c17-compact-selector-green.log) / [receipt](gates/k5b-c17-compact-selector-green.json) | **Final affected focused UI**, 3 files/59 tests, zero reported skips. |
| **c18 final-http** | **0** | [log](gates/k5b-c18-final-http.log) / [receipt](gates/k5b-c18-final-http.json) | **Final targeted PG16 HTTP**, 2 suites/55 tests: 51 real production + 4 export compatibility, zero reported skips. |
| **c19 final-backend-units** | **0** | [log](gates/k5b-c19-final-backend-units.log) / [receipt](gates/k5b-c19-final-backend-units.json) | **Final full backend**, 214 suites/1996 tests/1 snapshot, zero reported skips. |
| **c20 final-types** | **0** | [log](gates/k5b-c20-final-types.log) / [receipt](gates/k5b-c20-final-types.json) | **Final backend/frontend/shared typecheck**, shared build dependency, ordinary TS incremental caveat. |
| **c21 final-frontend** | **0** | [log](gates/k5b-c21-final-frontend.log) / [receipt](gates/k5b-c21-final-frontend.json) | **Final full frontend**, 93 files/666 tests, zero reported skips; tutorial 3/3. |
| **c22 final-lint** | **0** | [log](gates/k5b-c22-final-lint.log) / [receipt](gates/k5b-c22-final-lint.json) | **Final backend/frontend/shared lint**, 0 errors; backend 1438/frontend 110 warnings. Shared lint ran without a problem summary. |
| **c23 final-build** | **0** | [log](gates/k5b-c23-final-build.log) / [receipt](gates/k5b-c23-final-build.json) | **Final backend/frontend/shared builds**, webpack success, Vite 1104 modules; CSS import-order/large-chunk warnings remain. |

c10–12 were already started/completed when the missing-perimeter correction arrived; no broad gate was started again until all supplied backend/shared/UI fixes stabilized. c16–23 bind identical executable/test bytes; the only later tracked edit is appended issue metadata. Broad backend/targetedHTTP repeated only after backend source changed; no fullPG or unrelated audit. Original gates remain accurate historical evidence, not reruns on the corrected pin; original frontend RED is repaired, not waived. No evidence of combined UI-1b integration.

## Final pinned candidate and source hashes

- Final candidate: **`814f2b45856f69c98e8d8fe816b444526b363ae2`**.
- Tree: **`878d6773fbf93969382905502904bca4d29354da`**.
- Direct parent: preserved original `b32bc992bcdc2087b30a75362c01c1061760b42d`.
- New local commit: `fix(starmap): close planet layer access and K5b review gaps`, ending `Co-Authored-By: Claude Code <noreply@anthropic.com>`.
- BASE→final: two commits, 20 changed paths. Original→final: one follow-up commit, 11 changed paths (marked **correction** below).
- Post-commit working tree clean; correction report confirmed ignored. No merge/push/amend/reset/rebase.
- Exact executable/test hash maps agree before/after c16–23. Committed blobs and current files match those digests. Gate receipts also include the issue's pre-final-comment digest; its later appended metadata is separately hashed below, not represented as executed code. An initial identity check incorrectly included that metadata in the executable comparison and failed; corrected source-only identity check passed. This was a hash-check mistake, not a test gate or a hidden execution failure.
- All correction receipt direct-log hashes verified. No postcommit tests are claimed; exact byte binding connects recorded final executions to the committed pin.

### All BASE→final paths (SHA-256)

| Path | SHA-256 | Original→final |
| --- | --- | --- |
| `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md` | `cb2c1353722b3c84c2c51583e198b28ace258c9bc1bd7e0974d5f7cd955ac28b` | correction |
| `apps/backend/src/modules/database/database-commodities.controller.spec.ts` | `4276933d08069097a07813f252dc90fabaa9956022b6a9f6a56e692edc8b9216` | retained |
| `apps/backend/src/modules/database/database-system-detail.controller.spec.ts` | `6b15e73680ab3d175c97872b7206da711e33365165a1c6c96a258ff0e684081b` | retained |
| `apps/backend/src/modules/database/database.controller.ts` | `f346300b912847cd116e3be45ba10f37e6f2dbf39dffb4ece3a7f172f76f56c6` | correction |
| `apps/backend/src/modules/database/database.module.ts` | `a123fb3a9109ca3a5161092072f71bd7bd418f11b65f973ba907f8d35f9028ff` | retained |
| `apps/backend/src/modules/database/database.service.ts` | `70cb5d466e8dac4363f1473cd66859ef21ff8d97a66e939b4e16ad2de8dda67a` | retained |
| `apps/backend/src/modules/spacecraft/spacecraft.controller.ts` | `56689749e3763f56e78302fa27425d61209bc467099f098827d6ab877de08c36` | retained |
| `apps/backend/src/modules/starmap/layer-access-http.int-spec.ts` | `fb257396cfdbc553ba182392df03df95f40255869b47a9aca07d461079fd2046` | correction |
| `apps/backend/src/modules/starmap/layer-access.guard.ts` | `75515782e539a7acd99eaa2f0842021dfb0cec4b72a00995bd6e631badd03f7e` | correction |
| `apps/backend/src/modules/starmap/layer-access.service.ts` | `2dfdad761f5635017334e2db8225924610faac3274f1a3d207afe49381ff25ce` | correction |
| `apps/backend/src/modules/starmap/planet-surfaces.controller.ts` | `23164231513e83e23b1edb048c98ddf95e08656f33df9e9e90ffdcd7b95852f3` | correction |
| `apps/backend/src/modules/starmap/starmap-export.int-spec.ts` | `fbe7317bc9d3246aaf504cd48824e6fcf5b31f0756bf11d7c7b8db5d5b38c2cc` | correction |
| `apps/backend/src/modules/starmap/starmap.controller.spec.ts` | `f0010591489d9f08abd1f35f220023cf0c9f84ea90b74b98d708963e9a9118f5` | retained |
| `apps/backend/src/modules/starmap/starmap.controller.ts` | `7b8f83a41c29d072f9e58d282afd4d4caf22c747ed67f928d529baf9fabd1dde` | retained |
| `apps/backend/src/modules/starmap/starmap.module.ts` | `bce4a45bf9173b4eb99b9fa7ac10934e8c68ba7ea6e0e1acf1a1210b47edb694` | retained |
| `apps/frontend/src/components/tutorial/TutorialPadd.spec.tsx` | `d349c8a590e3189957b80bdd9a6cd087e7f93130bfb3bb9437b549a687e95e54` | correction |
| `apps/frontend/src/pages/database.spec.tsx` | `9f7f54eff304c09cc197b4e15b909f8c050b401f1cd4f8e40d2f7d6f629969b6` | correction |
| `apps/frontend/src/pages/database.tsx` | `2acc200bf210de3b4e26ecbe3e6ac2a94e2125d0534632d6710727e5f5ed8765` | correction |
| `apps/frontend/src/pages/starmap.spec.tsx` | `9b7e0dbe17f2d5898bcac59a0b6f764685a72c4674c08bd1f47e1b2da934db12` | retained |
| `packages/shared/src/lib/database/index.ts` | `dfced0de9ca64bb882ab0b1698e55c211a95af3571db0caf13d36c9171d184af` | correction |

## Review boundary

Spec input supplied one source finding; Standards supplied two source breaches. Worker source corrections and direct public execution are separate from independent rereview/approval, which has **not occurred on this final pin**. No nested agent/workflow, index creation, install/new dependency/package/lock/Nx/map/DECISIONS/STU change, spacecraft Shared contract edit, external service, shared DB, secret/environment value inspection, private transcript/tool-result export, denied-permission workaround, push/merge or cleanup. Original commit/history and other user work retained.

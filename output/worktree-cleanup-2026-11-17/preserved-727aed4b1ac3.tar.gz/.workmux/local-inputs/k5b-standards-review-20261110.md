# K5b — original independent Sol Standards review

Date: 2026-11-10

## Disposition

**Source Standards: BLOCKED — 2 documented-standard breaches, 0 consequential Fowler-smell findings.**

**Final acceptance: HELD separately for the confirmed full-frontend failure and incorrect triage metadata.** Successful backend/types/lint/build evidence does not waive that failure. No baseline/flakiness explanation is established. The original worker is correcting the tutorial-test synchronization/cleanup and tracker; those uncommitted changes are not this pinned review candidate.

Original Standards axis: `review-tmw-k7a1`. Independent Spec source-authorization review remains separate; no Spec verdict or integration approval is issued here. UI-1b is not re-reviewed or combined with K5b.

## Pinned Git identity and scope — PASS

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Candidate: `b32bc992bcdc2087b30a75362c01c1061760b42d`.
- Tree: `b9255dbc49093885778315a71485b77eefa87aa7`.
- Pinned diff: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...b32bc992bcdc2087b30a75362c01c1061760b42d`.
- Pinned log: `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..b32bc992bcdc2087b30a75362c01c1061760b42d`.
- Exactly **1 direct-parent commit / 17 paths**: 16 production/test files below plus `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md`.
- Conventional Commit: `feat(starmap): enforce known-layer access and catalog filters`; commit body explicitly preserves the failed frontend checkpoint, ending `Co-Authored-By: Claude Code <noreply@anthropic.com>`.
- Committed range whitespace check passes.

Read the originating issue at BASE and reviewed exact candidate Git blobs, not this reviewer's older checkout. There is no reviewer `.codegraph` index; none was created. No full wormhole, migration or integrated-baseline audit was repeated.

## Verified source findings — under 400 words

1. **New shared catalog response contract is frontend-local.** `CONTRIBUTING.md:73`: “Shared DTOs/interfaces go in `packages/shared`”. New backend `apps/backend/src/modules/database/database.controller.ts:94,153` adds `layers: layers.map(({ id, name }) => ({ id, name }))` to system-type/planet-type responses. Its consumer at `apps/frontend/src/pages/database.tsx:366` declares the new cross-boundary shape only through `data as { layers: Array<{ id: number; name: string }> }`; neither `packages/shared/src/lib/database/index.ts` nor another Shared catalog DTO owns it. Existing local `SystemTypes`/`PlanetTypes` still omit this field. Thus the new selector contract can drift independently of the backend and is asserted rather than shared. Add the appropriate Shared catalog response/choice contract and consume it across this seam (the existing `StarmapLayerDto` can supply the choice projection). This finding is limited to the newly added `layers` contract, not a demand to migrate all historical database DTOs. Backend-only `LayerReader` is not counted as a frontend/backend DTO breach.

2. **New game selector violates compact text convention.** `.scratch/stu-parity/inventory/shell-admin-runtime.md:216–219` requires game pages to use `text-xs` (only smaller microvalues are noted). New `apps/frontend/src/pages/database.tsx:357` renders the catalog selector label with `className="block text-sm text-swu-muted"`; its select inherits that size. This introduces a larger game-control label/options instead of the documented compact presentation. Use `text-xs` for the new selector. The existing system-catalog selector at :817 uses the same older style, but copying existing drift does not override the written global rule; this finding does not request redesigning that unchanged selector or the existing tables.

## Mandatory standards and bounded implementation judgement

Read candidate `CONTRIBUTING.md`, `AGENTS.md`, full `CONTEXT.md`, `docs/agents/domain.md`, `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`; relevant ADRs 0002 (personal discovery/scan knowledge), 0003 (cartography), 0004 (Spacecraft/station model) and 0006 (galaxy navigation); frontend global conventions in `.scratch/stu-parity/inventory/shell-admin-runtime.md`; `docs/starmap-admin-bootstrap.md`'s relevant editor context; and `apps/backend/src/testing/integration/README.md`. Bounded tracked-document discovery found no `CODING_STANDARDS`, `CONTEXT-MAP`, nested context document or relevant backend/frontend-specific ADR directory. Historical bootstrap guidance is not used to invent a current role redesign; the originating issue expressly retains existing administrator/editor access.

All twelve Fowler heuristics retained: **Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man, Refused Bequest**. They are judgement calls; repository rules override them, and tooling-enforced issues are excluded. No additional consequential smell finding survives the bounded review. Small DTO projections and callback/controller repetition do not justify generic abstractions; Nest modules/services/controllers follow the documented architecture. Optional catalog layer arrays retain existing internal-call compatibility, while the public controller supplies the selected authorized set; no new current bypass is alleged from that optionality. Route-path dispatch is bounded in the new guard and exercised by the actual HTTP graph; speculative future-route fragility is not a verified finding.

Inspected the new central `LayerAccessService`/`LayerAccessGuard`, their repository dependencies, starmap/database/spacecraft controller integration and module imports/exports; the changed catalog queries; Shared layer/knowledge/auth/database seams; and production page/API test seams. Policy queries current knowledge; `KNOWN` presence is not replaced with an `EXPLORED` prerequisite. Existing personal-discovery/fog checks are retained alongside the perimeter; no arrival implementation was re-audited. Empty allowed arrays remain constrained (`In([])`/`1 = 0`) rather than silently unfiltered. Planet filtering joins the parent system before grouping; system-type occurrence filtering uses the allowed-system set. Source requirements/authorization completeness remain the independent Spec axis's responsibility.

## Public test graph — evidence boundaries

New `apps/backend/src/modules/starmap/layer-access-http.int-spec.ts:36–70` imports the **real production AppModule**, configures JWT verification via a literal test-only signing string, real Nest routing/global prefix and ValidationPipe, and sends authenticated HTTP `fetch` requests. Substitutions are ConfigService/DataSource wiring and GameGateway notification methods, not authorization service/guard/controllers/query repositories. Its production datasource options are checked `synchronize:false`; committed migrations are run through the existing integration connector. Existing Jest global setup uses PostgreSQL 16 Testcontainers when no integration URL is supplied; global teardown stops the container/restores setup state. Supplied direct HTTP log headers record removal of both ambient DB URLs. This is inspection of source and supplied evidence, not reviewer environment inspection or DB execution.

Expanded parameterized cases account for **45 production HTTP tests**. The other **4** `starmap-export.int-spec.ts` cases are narrower compatibility tests: authentication and relevant persistence are substituted, the test user bypasses layer knowledge, and only export-limit persistence uses PostgreSQL. Constructor fixtures with substituted collaborators likewise do not prove production authorization. The combined targeted result **49** must not be labeled 49 production authorization tests or a full PostgreSQL suite.

Frontend tests import actual DatabasePage/StarmapPage and observe rendered choices/API requests. Database tests mock the API only. Starmap tests also substitute Pixi canvas/socket seams; their new assertion targets the actual page selector, not production canvas rendering. These UI fixtures do not independently prove backend authorization; that evidence comes from the real HTTP graph.

## Source/hash/direct receipt binding — PASS

Read supplied `.workmux/local-inputs/k5b-review/report.md`, `manifest.json` and all supplied `gates/*.log`/`*.json`. **43 manifest artifact hashes match**: handoff report plus 21 direct-log/receipt pairs. Each receipt's direct-log digest, unchanged before/after source maps, BASE HEAD and `source_unchanged:true` agree; each numeric `process_exit` agrees with its log footer.

All 16 reported implementation/test digests match candidate Git blobs. Each final receipt **19–25** binds the same 16 files before and after its execution. Receipts deliberately record precommit HEAD at BASE; exact executable/test byte identity transfers their recorded execution results to this committed candidate, not to a hypothetical fresh postcommit run. Later tracker metadata is excluded from those executable hashes and independently reviewed below. Earlier RED/GREEN source inventories have different sizes/digests and are not relabeled final-candidate execution evidence.

| Candidate path | SHA-256 |
| --- | --- |
| `apps/backend/src/modules/database/database-commodities.controller.spec.ts` | `4276933d08069097a07813f252dc90fabaa9956022b6a9f6a56e692edc8b9216` |
| `apps/backend/src/modules/database/database-system-detail.controller.spec.ts` | `6b15e73680ab3d175c97872b7206da711e33365165a1c6c96a258ff0e684081b` |
| `apps/backend/src/modules/database/database.controller.ts` | `c3ed01e92f6c8d4182efc0be3834efc1f4b32e37fe20002cdb81dbcbf6ec11c2` |
| `apps/backend/src/modules/database/database.module.ts` | `a123fb3a9109ca3a5161092072f71bd7bd418f11b65f973ba907f8d35f9028ff` |
| `apps/backend/src/modules/database/database.service.ts` | `70cb5d466e8dac4363f1473cd66859ef21ff8d97a66e939b4e16ad2de8dda67a` |
| `apps/backend/src/modules/spacecraft/spacecraft.controller.ts` | `56689749e3763f56e78302fa27425d61209bc467099f098827d6ab877de08c36` |
| `apps/backend/src/modules/starmap/layer-access-http.int-spec.ts` | `bcc38cb036076cb48bb4e4bef10a0dd03a3ee5db2cc64c0f05acd41d4c7fd08f` |
| `apps/backend/src/modules/starmap/layer-access.guard.ts` | `344841e0ac55cd88ee127c67b64315f1e02a90ecaf6abb36aaa364cfa79be146` |
| `apps/backend/src/modules/starmap/layer-access.service.ts` | `113b7602f75543385fb58cf796cd5769b33d36b10b1f5dfb63c0b49d6f3863ef` |
| `apps/backend/src/modules/starmap/starmap-export.int-spec.ts` | `1ed5a78c8d2eca20083df47ef0d3937925566586ada7f2a5d59a5e1fc7ce4708` |
| `apps/backend/src/modules/starmap/starmap.controller.spec.ts` | `f0010591489d9f08abd1f35f220023cf0c9f84ea90b74b98d708963e9a9118f5` |
| `apps/backend/src/modules/starmap/starmap.controller.ts` | `7b8f83a41c29d072f9e58d282afd4d4caf22c747ed67f928d529baf9fabd1dde` |
| `apps/backend/src/modules/starmap/starmap.module.ts` | `bce4a45bf9173b4eb99b9fa7ac10934e8c68ba7ea6e0e1acf1a1210b47edb694` |
| `apps/frontend/src/pages/database.spec.tsx` | `a109c3ed9b721baaaa6f8309166030ad15a44713d3df34be4d08472a796fd941` |
| `apps/frontend/src/pages/database.tsx` | `2bb252e0cb91400978d792eb79df378573648cc077ccc23d672d031236b4ff88` |
| `apps/frontend/src/pages/starmap.spec.tsx` | `9b7e0dbe17f2d5898bcac59a0b6f764685a72c4674c08bd1f47e1b2da934db12` |

Candidate tracker digest also matches supplied `ad056dd7ea4d79a17c7325052d712ff4b83b3387a8fffdd49cd3f754f6bbbad7`.

## Verified executions and separate acceptance hold

| Direct gate | Numeric exit | Observed result |
| --- | ---: | --- |
| 17 focused backend | 0 | 6/6 suites, 24/24 tests; compatibility scope. |
| 18 focused frontend | 0 | 2/2 files, 56/56 tests. |
| 19 final targeted HTTP | 0 | 2/2 suites, 49/49 tests = 45 real production K5b HTTP + 4 narrower compatibility. |
| 20 full backend units | 0 | 214/214 suites, 1996/1996 tests, 1/1 snapshot. |
| **21 full frontend** | **1** | **92 passed / 1 failed files; 665 passed / 1 failed tests (666 total).** Independently summed all 93 file-result rows, including singular-test rows, to 666 total and 1 failed. |
| 22 backend/frontend lint | 0 | 0 errors; frontend 110 warnings, backend 1438 warnings. Tooling warnings are not additional Standards findings. |
| 23 forced spec-inclusive types | 0 | `tsc --build apps/backend/tsconfig.spec.json apps/frontend/tsconfig.spec.json --force --pretty false`, no diagnostics. Both spec configs reference app configs; backend includes int-spec files and frontend includes TSX specs. |
| 24 regular Nx typechecks | 0 | Both targets and shared dependencies successful. |
| 25 builds | 0 | Backend webpack success `efc6ef84fb8285f6`; frontend Vite success, 1104 modules; CSS import-order/large-chunk warnings retained. |

Passing equals total for the summarized passing gates; no skipped totals are reported. The frontend failure is not omitted, skipped or waived. Supplied `k5b-21-final-frontend.log:698–711` shows `TutorialPadd.spec.tsx:34` expecting the `tutorial-target` class and receiving false; :718–735 gives failed totals and `process_exit=1`. Candidate tutorial source/test are unchanged from BASE, but unchanged files **do not establish baseline failure or flakiness**. Root cause is unconfirmed in this evidence package; the original worker's pending correction needs a new candidate and evidence for narrow rereview.

### Historical RED/GREEN treatment

Inspected supplied meaningful REDs and paired GREENs: 02→03 listing (unknown layer actually returned); 04→05 direct perimeter (10 failures/11 total); 06→07 indirect access (5 failures/16 total); 08→09 catalog choices (unknown systems choice plus absent type-response `layers`); 12→13 actual page selector absence (2 failures/19 total). Gate 14 has **mixed** failures: real contacts 200 instead of 403, plus planet fixture 90001 producing no valid type; gate 15 uses valid fixture IDs and retains populated total/content assertions, passing 44/44. Gate 19 expands final coverage to 45+4. This does not turn the invalid planet fixture into production behavior RED.

Handoff-only gates 01/10/11/16 are **not supplied** in this manifest. Their reported fixture/type/invalid-invocation classifications are not independently verified executions here and do not substitute for supplied final evidence. No private transcripts or automatic persisted tool outputs were opened to recover them.

### Metadata hold

The entire BASE `## Comments` history is independently verified verbatim at the start of candidate history; one accurate 2026-11-10 failure/handoff comment is appended. All **7** acceptance criteria remain unchecked. History preservation complies with `docs/agents/issue-tracker.md:11`.

However, candidate :3 and its appended comment use `ready-for-human` for a technical gate handoff. `docs/agents/triage-labels.md:9–10` defines `ready-for-agent` as fully specified AFK-ready and `ready-for-human` as requiring human implementation. No human product/implementation decision has been established; the user explicitly identifies this as incorrect triage and says the original worker is restoring `ready-for-agent` with checks open. Record this **known metadata hold separately**, not as a third source finding or an invitation to rewrite historical evidence. Pending worker text is not accepted without a new pinned candidate.

## Current state, limitations and stop

At source-state verification, the existing worker `agent-tmw-k5b` remains at pinned HEAD/tree but is **not clean**: uncommitted edits exist only in the K5b issue and `apps/frontend/src/components/tutorial/TutorialPadd.spec.tsx`. All 16 pinned implementation/test raw files still equal candidate Git blobs. No pending correction contents were audited or merged into this candidate's conclusions.

Reviewer remains `review-tmw-k7a1`, HEAD `ff16922a7b93b620acb4d51d7180cf255dd970b2`, clean. This NEW report is ignored under `.workmux/`; final unchanged-state/ignore verification passes. Prior UI-1b report remains unchanged, SHA-256 `f75758701356056c57781dc83607a84d3294a6ff57bc3a8b8a159eaf2034f655`.

Results are supplied executions bound by exact recorded bytes, **not reviewer reruns**, forensic process-provenance proof or a claim that all internal caches were cleared. Nx `--skip-nx-cache` bypasses task replay, not all compiler/runtime artifacts; regular TS builds retain incremental caveats, distinct from the explicit forced spec gate. No fresh main execution is claimed.

Only read-only Git/source/document/hash/log inspection and this ignored report were performed. No reviewer gates/tests/lint/types/build/DB/install/environment inspection/secrets/external services, private transcripts/tool-result exports, nested agents/workflows/plan mode, source/tracker/config/package/map/STU edits, branch switching, commits, merge, push or cleanup. **Stop for coordinator; reuse this original Standards session for the final correction's narrow rereview.**

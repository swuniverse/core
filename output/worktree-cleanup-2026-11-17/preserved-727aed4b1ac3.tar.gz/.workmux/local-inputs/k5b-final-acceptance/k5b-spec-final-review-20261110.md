# K5b — original independent Spec axis, narrow final correction

Date: 2026-11-10

**SOURCE SPEC PASS — zero findings. Prior planet-surface P2 FIXED. Separate frontend execution hold CLOSED on the supplied corrected-source evidence.** No residual narrow source/evidence hold. This is not a Standards verdict, integration approval, combined UI-1b acceptance or main-branch acceptance.

## Exact pin and scope

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Original candidate: `b32bc992bcdc2087b30a75362c01c1061760b42d`; tree `b9255dbc49093885778315a71485b77eefa87aa7`.
- Final candidate: `814f2b45856f69c98e8d8fe816b444526b363ae2`; independently resolved tree `878d6773fbf93969382905502904bca4d29354da`.
- Final direct parent and original→final merge-base are the original candidate; BASE→final merge-base is the fixed BASE.
- Narrow diff: `git diff b32bc992bcdc2087b30a75362c01c1061760b42d...814f2b45856f69c98e8d8fe816b444526b363ae2`.
- Narrow log: `git log b32bc992bcdc2087b30a75362c01c1061760b42d..814f2b45856f69c98e8d8fe816b444526b363ae2 --oneline`.
- Exactly **one correction commit / eleven paths**: `814f2b45 fix(starmap): close planet layer access and K5b review gaps`.
- Overall BASE→final: **two commits / twenty paths**, retaining `b32bc992 feat(starmap): enforce known-layer access and catalog filters`.
- Source read from exact candidate Git blobs, not reviewer checkout. Reviewer HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`.
- Prior own-axis report: `.workmux/k5b-spec-review-20261110.md`. Only its identified source gap, correction hunks/public seams and separate execution hold were reopened; no full perimeter, wormhole, migration or baseline re-audit.

## Spec findings / closure — under 400 words

**Zero new findings; prior P2 fixed in source, not merely metadata.** Issue `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md:10` requires “Spieler können Karten- und Datenbankdaten nur für bekannte Ebenen abrufen”; :37 forbids any map/database path exposing unknown layers; :31 says KNOWN suffices.

`planet-surfaces.controller.ts:29,36–42` retains class JWT authentication and now applies the method `LayerAccessGuard` before handler field/detail reads. `layer-access.guard.ts:27–29` parses the planet ID and calls `assertPlanetAccess`. `layer-access.service.ts:19,34–44,52–58` uses the injected current CelestialObject repository, then current parent StarSystem, then the existing layer/knowledge policy. No cached relation, EXPLORED requirement or new role policy. Existing admin/MAP_EDITOR bypass and missing-object/system semantics remain. `starmap.module.ts:51–67,82,95–97` already registers the repositories, actual controller, service and guard.

The actual AppModule/PostgreSQL HTTP spec (`layer-access-http.int-spec.ts:37–101,134–177`) seeds populated parent systems/planets and orbit/surface/underground fields. Two cases reject unknown/hidden with 403; three cases check KNOWN player and admin/editor payloads (both restricted layers for bypass roles); one checks 401/400/404. Original 45 cases are byte-retained outside the new import/helper/cases; six additions yield **51 production cases**, plus four unchanged-in-behavior export compatibility cases = **55**. c13 reproduces both unauthorized 200 responses; c14 and final c18 pass.

The catalog correction retains prior backend filtering/projections and public option/request assertions, replacing local response shapes with shared DTOs and typed layer state/API. No new missing, unasked or wrongly implemented Spec requirement was verified. Standards closure belongs to the other original reviewer.

## Separate tutorial execution hold

Original full frontend remains a historical **exit 1**, 665 passed / 1 failed across 93 files, exact `tutorial-target` membership expected true / received false. Original log hash remains `3c8e40dadf4e62a1f428cc4d69f18e69b248eff5c435190dcce0be5365ef85e0`; it is not relabeled green, waived as baseline, or explained merely by unchanged source.

Actual unchanged production source provides the timing mechanism: `components/tutorial/useTutorial.ts:29–41` resolves the API asynchronously and updates state; `TutorialPadd.tsx:60` renders the heading, while :28–32 adds/removes the highlight in passive `useEffect([step])`. A heading query is not the highlight-completion contract. The final test at `TutorialPadd.spec.tsx:34` adds only bounded `waitFor` around the identical membership=true assertion. Dismissal membership=false remains unchanged at :43. The existing target fixture does not insert the highlight. No Profiler, configuration override, repetition, pressure, source skip, product/effect mock or assertion weakening remains in final source; component/hook are byte-identical to BASE and original.

Supplied diagnostics are assessed with their limitations:

- c01 isolated 3/3 and c02 repeated 42/42 pass; neither explains the original failure. Despite its name, c02 is not RED.
- c03 has 1 failed/41 passed, same false-versus-true class assertion under reported real-component commit pressure. c04 passes 3/3; pressure alone is not deterministic.
- Worker report :21–29 describes a real-component Profiler plus temporary `asyncWrapper` override, followed by changing only the assertion to `waitFor`. c05 and c06 contain the exact class failure; c07 passes 3/3. Act warnings remain visible. c06 filters two cases and reports them skipped: diagnostic only, not zero-skip acceptance.
- c05/c06 receipts record the same diagnostic test hash `a860d21e265108d99c29ad154d70de153c1d5212f8f667b25446048d267531b3`; c07 records `95a99084c940185db33af05a6c63125461f78034eb074c830a9011a750cd49c1`.

Discarded probe snapshots are not supplied: their exact single-variable source difference and scheduler-budget inspection are worker descriptions, not an independently reconstructed diff. The observed diagnostic failures/green, actual production commit/passive-effect separation, unchanged exact assertion and final default-configuration green runs together adequately justify this narrow synchronization repair. They do not establish original OS/load provenance, historical baseline failure, or absence of every possible contamination mechanism. A permanently missing class still fails by timeout. **Execution hold closed on this bounded source/evidence assessment**, not on blind retries or forensic claims.

## Final evidence integrity and candidate binding

Inputs: `.workmux/local-inputs/k5b-correction-review/{report.md,manifest.json,gates/}`.

Verified **39/39 manifest file hashes**, all **19** JSON receipt/log hash links, integer numeric process exits, equal before/after records and recorded `source_unchanged:true`. Final c16–23 all record numeric **0** and identical eleven-entry maps: ten correction code/test paths plus issue metadata. Every ten-path executable/test hash matches the exact final candidate Git blob. Receipts honestly record original `b32bc992…` HEAD before/after, with correction bytes pending commit; they are not presented as runs at final committed HEAD.

The issue receipt hash `451826d2ce78b74679d19572f7ba47b9db7451f41e8500669993852f3765bc2d` exactly matches the final issue with its last appended comment removed. Final issue hash is `cb2c1353722b3c84c2c51583e198b28ace258c9bc1bd7e0974d5f7cd955ac28b`. This later comment is metadata, excluded from executable gate identity; no rerun is inferred from it.

| Final correction code/test path | SHA-256 |
|---|---|
| `apps/backend/src/modules/database/database.controller.ts` | `f346300b912847cd116e3be45ba10f37e6f2dbf39dffb4ece3a7f172f76f56c6` |
| `apps/backend/src/modules/starmap/layer-access-http.int-spec.ts` | `fb257396cfdbc553ba182392df03df95f40255869b47a9aca07d461079fd2046` |
| `apps/backend/src/modules/starmap/layer-access.guard.ts` | `75515782e539a7acd99eaa2f0842021dfb0cec4b72a00995bd6e631badd03f7e` |
| `apps/backend/src/modules/starmap/layer-access.service.ts` | `2dfdad761f5635017334e2db8225924610faac3274f1a3d207afe49381ff25ce` |
| `apps/backend/src/modules/starmap/planet-surfaces.controller.ts` | `23164231513e83e23b1edb048c98ddf95e08656f33df9e9e90ffdcd7b95852f3` |
| `apps/backend/src/modules/starmap/starmap-export.int-spec.ts` | `fbe7317bc9d3246aaf504cd48824e6fcf5b31f0756bf11d7c7b8db5d5b38c2cc` |
| `apps/frontend/src/components/tutorial/TutorialPadd.spec.tsx` | `d349c8a590e3189957b80bdd9a6cd087e7f93130bfb3bb9437b549a687e95e54` |
| `apps/frontend/src/pages/database.spec.tsx` | `9f7f54eff304c09cc197b4e15b909f8c050b401f1cd4f8e40d2f7d6f629969b6` |
| `apps/frontend/src/pages/database.tsx` | `2acc200bf210de3b4e26ecbe3e6ac2a94e2125d0534632d6710727e5f5ed8765` |
| `packages/shared/src/lib/database/index.ts` | `dfced0de9ca64bb882ab0b1698e55c211a95af3571db0caf13d36c9171d184af` |

All nine original changed paths untouched by the correction are byte-identical to the previously reviewed original candidate, with the same prior report hashes: database commodities/detail specs, database module/service, spacecraft controller, starmap controller/spec/module and frontend starmap spec. The production starmap page and default frontend configuration also have no correction diff. Tutorial component hash `30a3df581f55f24da49b50c3bf485d774a3c739db2ca72c0a6fbfac6986c52e2`; hook hash `3e80a9a7e544999a15b248e484fb6a099a7c34ee0777ff8b5d8143f1e6ea5d6b`.

## Observable final supplied gates

| Gate | Direct supplied outcome | Raw log SHA-256 |
|---|---|---|
| c16 forced spec types | Backend + frontend `tsc --build … --force --pretty false`; exit 0 | `73d3eb1f49dd8ebd6e3d52f351147ae8f6fb1db73d30075d221a3022acef71bf` |
| c17 focused frontend | 3 files: database 19 + starmap 37 + tutorial 3 = 59 passed; exit 0 | `29160d09cb2a07ed383c9535440dfdaee38f0893895505aa52ab29a70f558365` |
| c18 targeted PostgreSQL HTTP | 2 suites / 55 passed: 51 production + 4 compatibility; exit 0 | `79b2f3d0a424d57cbb3a0280b95ee1eb1301facdffd85b4c48f437fbc2a550bc` |
| c19 backend units | 214 suites / 1996 tests / 1 snapshot passed; exit 0 | `67eb3be5db8d81c585cde4f6cbe13f77c588c7787f06c5e5d612979c74672e15` |
| c20 regular types | Backend/frontend/shared plus shared build succeed; exit 0 | `b76f7109235b927688609bd304ae2b37c2d724dee8ae4187ac3ddb4ff2736b85` |
| c21 full frontend | 93 files / 666 tests passed; exit 0 | `686c2333a8dd30107cf13d17facce42bf1255157e71100f6c75c74bf1501eb06` |
| c22 lint | All three projects succeed; frontend 110/backend 1438 warnings, zero errors; exit 0 | `585651b5b29900241ac377db73f23bd6b7acae2387e0b4805b0b5eabf3155871` |
| c23 builds | Shared build, successful backend webpack, frontend Vite 1104 modules; exit 0 | `d472c2a5aff1fad3fa1537b44e644470e347ce7f809c7b5d96852d87d2cb6caf` |

Full frontend's 93 passing file rows independently sum to 666, with no skipped/todo rows or totals; focused and targeted final summaries likewise account for all cases. Existing act/deprecation, lint, CSS import-order and chunk-size warnings are not hidden. Production HTTP retains actual AppModule, JWT, controllers/guards/services/repositories and production TypeORM options with `synchronize:false`; only config/DataSource wiring and websocket notifications are substituted. Four export compatibility tests substitute auth/persistence and are not authorization proof. No full PostgreSQL suite execution is claimed.

These are supplied direct execution records with independently checked bytes/source binding, **not reviewer execution or independently established process/environment provenance**. Nx cache bypass flags do not prove all internal caches cleared. Ordinary TypeScript builds may reuse incremental artifacts; c16's explicit force is separate compiler evidence, not backend runtime execution. Unsupplied intermediate c08/c10–12 were not accessed or promoted to acceptance evidence.

## Current tracker and stop

Final issue :3 is **ready-for-agent**; all **seven criteria remain unchecked** at :27–33, accurately pending independent acceptance. Original `## Comments` bytes are preserved exactly, including the wrong prior human-handoff rationale at :43. Coordinator correction and final correction comments are appended at :44–45; technical test failure is not a human implementation decision. Reviewer changed no tracker.

Only read-only exact Git/source/doc/hash/log checks and this NEW ignored report; target absent and ignored before creation. Two bounded lookup mistakes (hook directory and translated issue heading) were resolved from actual source; neither was gate execution or a candidate failure. No source/tracker/config/package/map/STU edits, test/lint/type/build/DB execution, install, environment/secret inspection, external service, private transcript/tool-result access/export, nested agent/workflow/plan mode, branch switch, commit/merge/push or cleanup. No spacecraft shared DTO change or UI-1b/combined acceptance assumption.

**Spec PASS, zero findings; prior P2 fixed; separate execution hold closed within the stated evidence limits. Stop for the coordinator's distinct later serial integration.**

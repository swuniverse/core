import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command or '/' in args.name or args.name in ('.', '..'):
    parser.error('Use a simple unique gate name and a command after --')
root = Path.cwd()

def git(*values):
    return subprocess.check_output(['git', *values], cwd=root)

def state():
    changed = (git('diff', 'HEAD', '--name-only', '-z') + git('ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')
    paths = sorted(set(p for p in changed if p and not p.startswith('.workmux/')))
    hashes = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths if (root / p).is_file()}
    return {'head': git('rev-parse', 'HEAD').decode().strip(), 'source_hashes': hashes}

before = state()
output = root / '.workmux/gates'
output.mkdir(parents=True, exist_ok=True)
log = output / (args.name + '.log')
receipt = output / (args.name + '.json')
if log.exists() or receipt.exists():
    parser.error('Existing gate evidence would be overwritten; choose a new name')
env = os.environ.copy()
env.pop('DATABASE_URL', None)
env.pop('INTEGRATION_DATABASE_URL', None)
env['NX_DAEMON'] = 'false'
env['NX_NO_CLOUD'] = 'true'
with log.open('xb') as stream:
    stream.write(('Command: ' + json.dumps(command) + '\nAmbient DB URLs removed; NX_DAEMON=false; NX_NO_CLOUD=true\n').encode())
    stream.flush()
    result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    stream.write(('\nprocess_exit=' + str(result.returncode) + '\n').encode())
after = state()
facts = {'command': command, 'process_exit': result.returncode, 'before': before, 'after': after, 'source_unchanged': before == after, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
with receipt.open('x') as stream:
    json.dump(facts, stream, indent=2)
    stream.write('\n')
print('Gate:', args.name, 'Actual process exit:', result.returncode, 'Source unchanged:', facts['source_unchanged'])
print('Direct evidence:', log, receipt)
sys.exit(result.returncode if before == after else 99)

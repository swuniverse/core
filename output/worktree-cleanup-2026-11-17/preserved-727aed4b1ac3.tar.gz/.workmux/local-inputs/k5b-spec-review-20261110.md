# K5b — independent Spec review

Date: 2026-11-10

**SOURCE SPEC: BLOCKED — one verified P2 finding. Acceptance: HELD independently by the failed full frontend gate.** Standards remains the other original reviewer’s axis; no Standards verdict is supplied here. Neither a frontend repair nor tracker correction alone closes this source finding.

## Exact pin

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Candidate: `b32bc992bcdc2087b30a75362c01c1061760b42d`.
- Tree: `b9255dbc49093885778315a71485b77eefa87aa7`.
- Reviewer HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`; candidate source was read from exact Git blobs, not this older checkout.
- Diff: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...b32bc992bcdc2087b30a75362c01c1061760b42d`.
- Log: `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..b32bc992bcdc2087b30a75362c01c1061760b42d --oneline`.
- BASE verified as merge-base and direct parent; exactly **one commit / seventeen paths**: `b32bc992 feat(starmap): enforce known-layer access and catalog filters`.

## Spec findings — under 400 words

### P2 — Planet surface reads still bypass parent-layer authorization

Original BASE issue `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md:10` requires: “Spieler können Karten- und Datenbankdaten nur für bekannte Ebenen abrufen.” Its explicit decision at :37 says: “dürfen keine Karten- oder Datenbankpfade unbekannte Ebenen offenlegen”; :29 adds “indirekte Systemzugriffe umgehen sie nicht.”

The new controller-wide perimeter at `apps/backend/src/modules/starmap/starmap.controller.ts:80` protects only `StarmapController`. The production `StarmapModule` also registers `PlanetSurfacesController` (:82), whose player `GET /api/starmap/planets/:id/surface` still has only JWT authentication (`planet-surfaces.controller.ts:26–40`). For an existing planet in an unknown or hidden layer, an authenticated ordinary player with its celestial-object ID receives that object’s name, description, class and all orbit/surface/underground fields, without any layer-knowledge check.

There is no downstream authorization: `generator/planet-generator.service.ts:128–132` queries fields by celestial-object ID; `starmap.service.ts:175–178` queries the object by ID. The global game-status guard enforces game availability, not layer knowledge. Additionally, `layer-access.guard.ts:18–35` has no planet-ID branch, so adding its decorator alone would still fall through.

This is an unchanged public seam left outside the feature’s required complete perimeter, not a newly introduced route or an invented policy. Resolve the celestial object’s parent system/layer through the centralized access service before reading its data, retaining KNOWN sufficiency and existing admin/MAP_EDITOR bypass. Add actual production HTTP cases for unknown/hidden denial and known/role access. The supplied 45 production HTTP tests omit this route and cannot establish the missing contract.

**One source finding; no additional concrete missing, unasked or wrongly implemented requirement verified.** Source confirmation is by exact call-path inspection; no reviewer HTTP request or regression test was executed.

## Verified implemented contract and public seams

- `layer-access.service.ts:20–50`: existing admin/MAP_EDITOR claims bypass knowledge; player listing intersects current knowledge with nonhidden layers. Per-request repository queries, no authorization cache. Record presence accepts KNOWN and EXPLORED. Existing unknown layer is 403; absent layer/system/region retains 404.
- `starmap.controller.ts:80,99–318,668–695` and `layer-access.guard.ts:16–35`: JWT precedes layer guard; all ten player layer routes are covered, including the `:id` wormhole spelling, export and influence. System detail/grid, region ID and discovery-body layer ID are resolved centrally. Original admin method guards remain authoritative. Existing personal exploration/cartography/fog checks remain additive.
- `database.controller.ts` catalog helper and systems/system-types/planet-types methods authorize explicit filters, derive allowed IDs and return backend layer choices. Detail has JWT then layer guard. `database.module.ts:91` imports the policy module; `spacecraft.module.ts:148` already imports it, and spacecraft contacts has a method guard after class JWT (`spacecraft.controller.ts:401–403,667–673`). Starmap module provides all four policy repositories and exports the access service.
- `database.service.ts:485–569,798–880`: systems query allowed layers; system types are restricted to occurrences in those systems. Planet types join the real `CelestialObject.starSystem` relation (`entities/celestial-object.entity.ts:23–28`) and retain the layer predicate through `andWhere`. Empty allowed arrays constrain results rather than falling back to all data.
- Actual JWT strategy validates the user and carries existing admin/permission claims; AdminGuard/PermissionGuard and global GameStatusGuard were checked without imposing a role redesign.
- `database.tsx:301–324,356–367,807–829`: new type selectors use returned layer choices and encoded filter requests; existing systems selector is backend-driven. `starmap.tsx:108–134,373–386` selects only returned layers, including fallback from an unknown URL ID. Public page tests observe those real selectors and requests. API/UI fixtures are not backend authorization proof.

### Production HTTP proof and its limits

`layer-access-http.int-spec.ts:36–70` imports the actual AppModule, obtains production TypeORM options, asserts `synchronize:false`, and uses real JWT, controllers, guards, services and repositories. Only ConfigService, DataSource wiring and websocket notifications are substituted. Actual prefix, ValidationPipe and authenticated HTTP fetches execute in the supplied tests. Integration setup selects PostgreSQL `16-alpine` when no integration URL exists and applies committed migrations; supplied log headers record both ambient DB URLs removed. This is source plus supplied execution evidence, not independent observation of the worker environment.

Count reconciled from actual test declarations: 10 unknown direct + 5 indirect + 1 contacts + 3 catalogs + 1 populated isolation + 10 KNOWN + 10 hidden + 2 roles + 1 revocation + 1 authentication/malformed + 1 listing = **45**. Populated fixtures place distinct systems/types/planets in known, unknown and hidden layers, with personal discoveries on all three; assertions retain only known content and exercise empty explicit filters. Revocation deletes knowledge between requests, then expects denial and empty catalogs. The four export compatibility tests substitute auth/persistence and are **not** production authorization proof. None covers planet surface reads.

## Input and receipt integrity

Inputs: `.workmux/local-inputs/k5b-review/`.

Verified **43/43 manifest file hashes** (report plus 21 log/JSON pairs), all 21 receipt log-hash links, equal before/after records and recorded `source_unchanged:true`. Final receipts 19–25 record the same sixteen candidate implementation/test hashes and BASE HEAD before/after. Numeric `process_exit` is 0 except gate 21, which is 1. Gates precede commit/tracker metadata; BASE HEAD is therefore not misrepresented as candidate HEAD. Candidate tree/source identity was independently checked against Git.

| Candidate implementation/test path | SHA-256 |
|---|---|
| `apps/backend/src/modules/database/database-commodities.controller.spec.ts` | `4276933d08069097a07813f252dc90fabaa9956022b6a9f6a56e692edc8b9216` |
| `apps/backend/src/modules/database/database-system-detail.controller.spec.ts` | `6b15e73680ab3d175c97872b7206da711e33365165a1c6c96a258ff0e684081b` |
| `apps/backend/src/modules/database/database.controller.ts` | `c3ed01e92f6c8d4182efc0be3834efc1f4b32e37fe20002cdb81dbcbf6ec11c2` |
| `apps/backend/src/modules/database/database.module.ts` | `a123fb3a9109ca3a5161092072f71bd7bd418f11b65f973ba907f8d35f9028ff` |
| `apps/backend/src/modules/database/database.service.ts` | `70cb5d466e8dac4363f1473cd66859ef21ff8d97a66e939b4e16ad2de8dda67a` |
| `apps/backend/src/modules/spacecraft/spacecraft.controller.ts` | `56689749e3763f56e78302fa27425d61209bc467099f098827d6ab877de08c36` |
| `apps/backend/src/modules/starmap/layer-access-http.int-spec.ts` | `bcc38cb036076cb48bb4e4bef10a0dd03a3ee5db2cc64c0f05acd41d4c7fd08f` |
| `apps/backend/src/modules/starmap/layer-access.guard.ts` | `344841e0ac55cd88ee127c67b64315f1e02a90ecaf6abb36aaa364cfa79be146` |
| `apps/backend/src/modules/starmap/layer-access.service.ts` | `113b7602f75543385fb58cf796cd5769b33d36b10b1f5dfb63c0b49d6f3863ef` |
| `apps/backend/src/modules/starmap/starmap-export.int-spec.ts` | `1ed5a78c8d2eca20083df47ef0d3937925566586ada7f2a5d59a5e1fc7ce4708` |
| `apps/backend/src/modules/starmap/starmap.controller.spec.ts` | `f0010591489d9f08abd1f35f220023cf0c9f84ea90b74b98d708963e9a9118f5` |
| `apps/backend/src/modules/starmap/starmap.controller.ts` | `7b8f83a41c29d072f9e58d282afd4d4caf22c747ed67f928d529baf9fabd1dde` |
| `apps/backend/src/modules/starmap/starmap.module.ts` | `bce4a45bf9173b4eb99b9fa7ac10934e8c68ba7ea6e0e1acf1a1210b47edb694` |
| `apps/frontend/src/pages/database.spec.tsx` | `a109c3ed9b721baaaa6f8309166030ad15a44713d3df34be4d08472a796fd941` |
| `apps/frontend/src/pages/database.tsx` | `2bb252e0cb91400978d792eb79df378573648cc077ccc23d672d031236b4ff88` |
| `apps/frontend/src/pages/starmap.spec.tsx` | `9b7e0dbe17f2d5898bcac59a0b6f764685a72c4674c08bd1f47e1b2da934db12` |

Seventeenth path is the issue; candidate SHA-256 `ad056dd7ea4d79a17c7325052d712ff4b83b3387a8fffdd49cd3f754f6bbbad7`. Historical comments and unchecked checklist are retained; only status and appended handoff comment differ from BASE. Metadata is not included in implementation-only gate binding.

## Observable supplied execution evidence

| Gate | Result |
|---|---|
| 02 → 03 layer choices | Genuine missing filtering RED: unknown listed, 1 failure; GREEN 1/1. |
| 04 → 05 layer endpoints | Ten expected-403/received-200 failures; GREEN 11/11. |
| 06 → 07 indirect | Five failed expected-403 assertions (received 200/404/201); GREEN 16/16. |
| 08 → 09 catalogs | Unknown systems layer listed; type responses lack `layers` after HTTP 200, causing `.map` failures; GREEN 19/19. This does not itself prove populated isolation. |
| 12 → 13 frontend | Real selectors absent on rendered page: 2 failed/17 passed; GREEN 19/19. Unsupplied invalid-invocation gate 11 is not behavior RED. |
| 14 → 15 perimeter | Contacts genuinely bypasses 403; the other failure uses invalid planet class fixture 90001 and is not authorization RED. Final source retains strict populated assertions with valid 90010/90020/90030; GREEN 44/44. |
| 17 / 18 focused | 6 backend suites/24 tests and 2 frontend files/56 tests passed, exit 0. |
| 19 final targeted HTTP | 2 suites/49 tests passed, exit 0: 45 production K5b + 4 narrower export compatibility. Not full PostgreSQL suite evidence. |
| 20 final backend | 214 suites/1996 tests/1 snapshot passed, exit 0. |
| **21 final frontend** | **92 files/665 tests passed; 1 file/1 test failed; exit 1.** |
| 22 lint | Frontend 110/backend 1438 warnings, zero errors; success/exit 0. |
| 23 forced spec types | Explicit `tsc --build apps/backend/tsconfig.spec.json apps/frontend/tsconfig.spec.json --force --pretty false`; exit 0. Config includes production/public specs and backend integration specs. |
| 24 regular types | Backend/frontend/shared dependency typechecks succeed, exit 0; ordinary incremental compiler caveat retained. |
| 25 builds | Shared build, successful backend webpack and frontend Vite (1104 modules); exit 0. CSS import-order and chunk-size warnings remain. |

Runner summaries contain no skipped totals. Full frontend’s 93 file rows independently reconcile to 666 tests. Logs carry Nx `--skip-nx-cache`; forced types carry `--force`. These records do not prove internal caches cleared or forensic process provenance. Early stage hashes are historical RED/GREEN inputs, not final-candidate bytes. Unsupplied early gates 01/10/11/16 were not accessed or promoted to acceptance evidence.

## Separate execution hold and metadata correction

Direct `k5b-21-final-frontend.log:698–711,718–735` shows `TutorialPadd.spec.tsx:34:101`, assertion **expected true / received false** on the target class, with **665 passed / 1 failed** and numeric exit **1**. Its log SHA-256 is `3c8e40dadf4e62a1f428cc4d69f18e69b248eff5c435190dcce0be5365ef85e0`. Tutorial test/component are byte-identical between BASE and candidate; that does **not** establish root cause, baseline failure or flakiness. No waiver is inferred from unchanged files or green backend/types/builds. Acceptance stays HELD until actual later corrected candidate/gates are supplied.

Pinned issue still says `ready-for-human`; the original worker’s required correction to `ready-for-agent`, keeping checklist unchecked, is **pending elsewhere**, not verified as completed. A technical gate failure is not a human implementation decision. Existing failed evidence/report remain history; this reviewer changed no tracker metadata.

## Boundaries and stop

Only read-only exact Git/source/hash/log checks and this NEW ignored report. Report target was absent and ignored before creation. Optional AppModule lookup used an incorrect path once, then was resolved from the test’s actual import; no execution failure is implied. No whole wormhole/migration/baseline audit, no repeated UI-1b/K7a review, no Standards duplication.

No source/tracker/config/package/map/STU edits; no gates/tests/lint/types/build/DB execution, install, environment/secret inspection, external services, private transcripts/tool-result access or export, nested agents/workflows/plan mode, branch switch, commit/merge/push or cleanup. No reviewer-process/provenance/internal-cache-clear claim. Reviewer tracked tree is unchanged. **SOURCE SPEC BLOCKED (one P2); acceptance HELD. Stopped for the later original-session follow-up.**

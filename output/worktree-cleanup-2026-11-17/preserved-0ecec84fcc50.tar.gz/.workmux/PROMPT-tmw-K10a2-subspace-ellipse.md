Implement `tmw-K10a2` from the tracker in this isolated Workmux worktree. This is the normal-size P2 follow-up to resolved/integrated `tmw-K10a1`.

## Spec
Read `.scratch/stu-parity/issues/tmw-K10a2-subraumellipse-tick-und-einflug.md` in full and follow every acceptance criterion and decision. K10a1 is integrated and resolved; the issue's Blocked by is now empty and the ticket has been claimed. Implement the Subspace Ellipse as the first concrete anomaly type on the generic anomaly framework.

Key non-negotiable requirements include: explicit integer `anomalyMass` for ship classes; use exact mapped STU `tractor_mass` only where mapping is authoritative; do not invent missing class values or derive from combat stats; honor the specified score/exclusions, threshold and chance formula; inject deterministic RNG with inclusive `roll <= chance`, shield emitter damage 1–50; one-tick-after-creation effect/expiry; disable shields and set shield value to zero; route incoming-field effects through K1a `onEnterField`; respect `NO_ANOMALIES`; notify owners at creation and effect; and add deterministic backend tests for all specified boundaries and behavior.

## Workflow and constraints
- Use strict test-first RED/GREEN for behavioral changes. Inspect existing domain docs/ADRs and relevant code before editing; check STU source only read-only if available. Do not modify `/Users/TMUNDIN/git/github.com/st-universe` or any other repository.
- Use the configured Claude Code agent/model routing: Terra for this normal-size ticket. Follow project TDD and coding conventions.
- Work only on this ticket and its direct implementation needs. Do not touch K10a3 scan/UI scope, maps, package-manager files, or unrelated baseline code. Use npm/npx only; no package/lock modifications.
- PostgreSQL integration, if needed, must use disposable PostgreSQL 16 with actual migrations and `synchronize:false`; remove ambient `DATABASE_URL` and `INTEGRATION_DATABASE_URL` for test processes. No shared/dev DB, secrets, or external services.
- Run the required strict lint, canonical typecheck, backend tests, build, and focused PG tests where applicable. Preserve exact commands, exits, suite/test counts, skips, and warnings; do not relax compiler settings or mislabel targeted gates as full-suite gates.
- Append evidence to this issue only after validation; keep it claimed until coordinator accepts/integrates. Commit implementation/evidence with attribution `Co-Authored-By: Claude Code <noreply@anthropic.com>`.
- Do not merge/integrate or push. Report commit(s), tree, changed paths, test-first evidence, gates, remaining blockers, and clean/dirty worktree status. Never edit issue maps.

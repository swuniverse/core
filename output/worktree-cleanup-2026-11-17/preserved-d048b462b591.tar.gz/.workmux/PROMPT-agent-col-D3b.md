Implement exactly the issue **col-D3b — Forschungsbaum: EXCLUDE- und REQUIRE_SOME-Kanten unterscheiden**. Your isolated worktree is based on the current committed `stu-parity` HEAD. The coordinator checkout contains a newer uncommitted status/baseline clarification; use the full specification below as authoritative. Do not edit `.scratch/stu-parity/issues/col-D3b-forschungsbaum-kantentypen.md` in your commit because that local clarification is not present in this worktree; report completion and let the coordinator update ticket status after review.

## Current authoritative issue

# Forschungsbaum: EXCLUDE- und REQUIRE_SOME-Kanten unterscheiden

**Status:** ready-for-agent
**Priority:** P3
**Size:** S
**Blocked by:** —

### Ziel
Der SWU-Forschungsbaum zeichnet alle Abhängigkeiten gleich. Der STU-Admin-Baum unterscheidet EXCLUDE (rot) und REQUIRE_SOME (blau) von REQUIRE. Spieler sollen so erkennen, welche Forschungen sich gegenseitig ausschließen und wo eine von mehreren Voraussetzungen genügt.

### STU-Quellen
- `src/Module/Admin/View/ResearchTree/`

### SWU-Pfade
- `apps/frontend/src/pages/research-tree.tsx`
- `apps/backend/src/modules/research/research.service.ts` (Abhängigkeitsdaten im Baum-Payload)

### Akzeptanzkriterien
- REQUIRE-, REQUIRE_SOME- und EXCLUDE-Kanten haben unterschiedliche Farben bzw. Strichart mit Legende.
- Gesperrte (ausgeschlossene) Forschungen sind im Baum als ausgeschlossen erkennbar.
- Frontend-Test: die drei Kantentypen werden unterschiedlich gerendert.

### Baseline/verification constraint
An earlier focused implementation/test was reported green, but the current committed page may still omit EXCLUDE edges and distinguish no edge types. Re-verify the current code, implement any missing behavior, and run normal project gates; no baseline exception applies. The earlier global Nx frontend typecheck issue was considered superseded after `sh-AP-21` completed on 2026-10-30.

## Work rules

1. Read `AGENTS.md`, `CONTRIBUTING.md`, `CONTEXT.md` if present, relevant domain docs/ADRs, and this issue context. Use CodeGraph before grep/reading source because this repository has `.codegraph/`.
2. Strict TDD: write one focused test, observe meaningful RED, implement minimally, observe GREEN. Do not weaken tests.
3. Use npm/npx only; do not modify package-manager files, `nx.json`, or STU reference code. Do not edit map files or other issue files. Avoid unrelated formatting churn.
4. Run focused backend/frontend tests as applicable, the required project gates (`lint`, `typecheck`, `test`, `build`) where available, and `git diff --check`. Report any gate limitations accurately; do not carry forward a baseline exception without proving it still applies.
5. Commit exactly one focused implementation commit only after required criteria pass. Use a descriptive message ending with `(stu-parity col-D3b)` and trailer `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Do not push, merge, switch branches, or manage worktrees. Stop after commit for independent review.
6. End with observed RED/GREEN, checks and limitations, commit hash, changed-file scope, and any unresolved requirement.

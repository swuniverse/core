# tmw-K7a2b — serial integration, 2026-11-09

**Integrated by authorized fast-forward only. STOPPED.** No implementation, new review, gate execution, database/frontend run, new commit, push, or cleanup.

## Accepted inputs read first

- `.workmux/local-inputs/accepted-review/standards.md`: Standards PASS, zero findings; prior Standards PASS retained.
- `.workmux/local-inputs/accepted-review/spec.md`: Spec PASS, zero remaining findings; prior confirmed overlapping-ID P2 FIXED.
- `.workmux/local-inputs/review-fix/spec.md`: original Spec blocker read for provenance, superseded by accepted follow-up.

Accepted combined candidate: `59f716f9fbc3056371ff16ebe61c21fac5e45006`, comprising original `c212d12d28d8edd059b3148dcec638dcd44faac1` and direct follow-up `59f716f9`. Base: `9219a25e6965814064fc834821f04847748b1ff5`.

## Actual pre/post state

Commands ran from `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2b`. Authorized integration checkout: `../../core`, branch `stu-parity` (not a branch literally named main).

| State | Before merge | After merge |
|---|---|---|
| Integration branch | stu-parity | stu-parity |
| Integration HEAD | 9219a25e6965814064fc834821f04847748b1ff5 | 59f716f9fbc3056371ff16ebe61c21fac5e45006 |
| Integration status, porcelain normal untracked | `?? brag-output-2026-11-06-141255/` only | Identical, same sole untracked directory |
| Staged/tracked differences | None, exact status precondition | None; explicit HEAD/index diff checks also exit0 |
| Worker branch | agent-tmw-k7a2b | agent-tmw-k7a2b |
| Worker HEAD | 59f716f9fbc3056371ff16ebe61c21fac5e45006 | Unchanged |
| Worker status | Empty/clean | Empty/clean |
| Accepted tree | b90e95efd512295731f070cc7e309b046157827f | Integration HEAD tree exactly identical |
| Tested fingerprints | Worker 8/8 match supplied final prints | Integration working files 8/8 match supplied final prints |

Both commits end `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Verified base→original→follow-up ancestry and exactly these two commits in base..candidate. No merge commit created.

Existing `git worktree list` was read before integration. Afterward its integration row changed from `9219a25e [stu-parity]` to `59f716f9 [stu-parity]`; worker row remains `59f716f9 [agent-tmw-k7a2b]`. No worktree creation/removal, stash access, branch deletion, reset, clean, rebase, amend, or preservation inventory. Unrelated content was not written, removed, or recursively inspected.

## Actual commands and exits

Shell execution used only `npm exec --offline -- node -e ...`, with local synchronous Git commands (`execFileSync`) and direct SHA-256 reads of the eight supplied paths. No installed tooling, dependency or package changes. Git invocations below retain their actual paths/arguments. All listed Git commands exited0 except the explicitly disclosed no-match lookup. The five npm-wrapped command invocations exited **0, 0, 1, 0, 0** respectively; the last checks report ignore/status after report creation.

### 1. Precheck — npm wrapper exit0; no mutation

```text
git rev-parse HEAD
git branch --show-current
git status --porcelain=v1 --untracked-files=normal
git -C ../../core rev-parse HEAD
git -C ../../core branch --show-current
git -C ../../core status --porcelain=v1 --untracked-files=normal
git merge-base --is-ancestor 9219a25e6965814064fc834821f04847748b1ff5 c212d12d28d8edd059b3148dcec638dcd44faac1
git merge-base --is-ancestor c212d12d28d8edd059b3148dcec638dcd44faac1 59f716f9fbc3056371ff16ebe61c21fac5e45006
git rev-list --reverse 9219a25e6965814064fc834821f04847748b1ff5..59f716f9fbc3056371ff16ebe61c21fac5e45006
git show -s --format=%B c212d12d28d8edd059b3148dcec638dcd44faac1
git show -s --format=%B 59f716f9fbc3056371ff16ebe61c21fac5e45006
git rev-parse 59f716f9fbc3056371ff16ebe61c21fac5e45006^{tree}
git worktree list
```

Worker files matched all eight values in `.workmux/k7a2b-final-fingerprints-alias.json`. Exact HEAD/branch/status guards all passed.

### 2. Recheck and authorized mutation — npm wrapper exit0

Immediately rechecked integration HEAD/branch/status and worker HEAD/status with the same commands; exact preconditions still held. Then the **only tracked mutation**:

```text
git -C ../../core merge --ff-only 59f716f9fbc3056371ff16ebe61c21fac5e45006
```

Exit0. Actual output: `Aktualisiere 9219a25e..59f716f9`, `Fast-forward`; eight candidate paths, 2426 insertions/68 deletions. Includes candidate-only K7a2b tracker resolution and seven backend source/test files. No integration-specific edits.

### 3. Postcheck — core checks exit0; wrapper exit1 only on status lookup

```text
git -C ../../core branch --show-current
git -C ../../core rev-parse HEAD
git -C ../../core rev-parse HEAD^{tree}
git -C ../../core status --porcelain=v1 --untracked-files=normal
git -C ../../core diff --exit-code HEAD --
git -C ../../core diff --cached --exit-code HEAD --
git rev-parse HEAD
git branch --show-current
git status --porcelain=v1 --untracked-files=normal
```

All exit0; exact integration candidate/tree, unchanged status, clean worker, and no HEAD/index difference verified. Then all eight integrated files matched supplied SHA-256 values.

Following read-only lookup exited1/no match because actual Markdown uses `**Status:**`, not a line beginning `Status:`:

```text
git -C ../../core grep -n -i ^status: HEAD -- :(glob).scratch/stu-parity/issues/tmw-K7a[123]-*.md .scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md
```

This was not a merge, hash, gate or tracked-state failure. No corrective mutation attempted.

### 4. Corrected status/worktree lookup — npm wrapper exit0

```text
git -C ../../core grep -n -i status HEAD -- :(glob).scratch/stu-parity/issues/tmw-K7a[123]-*.md .scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md
git worktree list
```

Both exit0. Actual HEAD statuses at line3:

- `tmw-K7a1-wurmloch-backend-kern.md`: `**Status:** ready-for-agent`.
- `tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md`: `**Status:** ready-for-agent`.
- `tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md`: `**Status:** resolved`.
- `tmw-K7a3-wurmloch-frontend-und-oberflaeche.md`: `**Status:** ready-for-agent`.

Only main/worker rows of the post-list were displayed; no new inventory or recursion. K7a1/K7a2/K7a3 remain open; no planner/endpoint/passage implementation or tracker edit in integration.

### 5. Report ignore/status check — npm wrapper exit0

```text
git check-ignore .workmux/tmw-K7a2b-serial-integration-20261109.md
git status --porcelain=v1 --untracked-files=normal
```

Both exit0. Report ignored; worker status remains empty. No report commit.

## Accepted tested-byte fingerprints transferred to integration

All eight integrated working paths match supplied final prints. Prefix `apps/backend/src/modules/spacecraft/`:

```text
d1ca45dac5fff29cba23d7fbce0b68b41afc968060612176a7212ea0bad7bdc6 movement-state.ts
90d7c8fabf7541563b4025e95cbcde5cabec9d6332f6bdda98197716a76ea020 movement-concurrency.int-spec.ts
a3bd3ead4c80ba1c2a680f0de093d42b77bc6330ff64ec92a9314c4af468920e spacecraft.service.ts
59965007d3b7ee63f14fe38f3dec66b883ecc43ec76261a6050908dc44bcc798 spacecraft-destruction.service.ts
953c008f6a2dcb69fb8fe4d73b3020b94754a97f4e8b0df6f36245c8ba09a371 spacecraft-movement-resources.spec.ts
109e409cca68053cc8d04a1248a6a00fad5264143c7f20b46cb26f3ebb9168b1 spacecraft-fleet.service.spec.ts
d88a895c03cfe82f4d1c4159cb59bc1b6fc3a3d9002dadcd5d29a511fc71d93b cartography-lifecycle.integration.spec.ts
7830e6386018f81e4cffcd3543e1d0eb6ab06e67e5d362cda24911e1377c8fe8 fleet-lock.ts
```

Entire integration HEAD tree equals accepted candidate tree; clean tracked/index checks confirm checkout identity. Thus accepted candidate evidence transfers by exact byte identity, **not fresh execution on main**.

## Retained revised gates — NOT rerun for integration

Source: `.workmux/tmw-K7a2b-alias-fix-report-20261109.md` and accepted reviews. Original c212d12d counts remain historical and are not substituted.

| Accepted revised evidence | Retained actual result | Existing log |
|---|---|---|
| Full backend units | 211 suites / 1981 tests passed; 1 snapshot; 62.193s | k7a2b-final-units-alias.log |
| Full disposable PostgreSQL | 38 suites / 336 tests passed; 219.081s | k7a2b-final-full-postgres-alias.log |
| Forced production/spec/reference types | exit0; empty successful output | k7a2b-final-types-alias.log |
| Build | shared/backend success; webpack 840492acd7befbaa | k7a2b-final-build-alias.log |
| Changed-scope lint | 0 errors / 17 retained warnings | k7a2b-final-lint-alias.log |
| Focused movement/fleet PostgreSQL | 2 suites / 46 tests passed | k7a2b-final-focused-postgres-alias.log |
| Existing resource/fleet/cartography | 3 suites / 44 tests passed | k7a2b-final-focused-units-alias.log |

Zero skipped tests in accepted final runs. Historical initial filtered RED deselected23 cases; full public movement RED before fix was 1 failed/23 passed/24 total with no skips. Neither is mislabeled final acceptance.

Disclosure retained: Jest/ESLint cache disabled, types forced, Nx result cache disabled/daemon off; shared build's ordinary tsc can reuse already checked incremental outputs. Existing 17 non-null-assertion lint warnings, ts-jest isolatedModules/pg concurrent-query deprecations, and expected unit failure-path application logs were not suppressed. Disposable PostgreSQL16 migrations with both ambient DB URLs unset were used in the accepted worker gates; **no database accessed in this integration session**.

Approved scope remains bounded stale ordinary movement and same-ID alias fix, preserving costs and fleet policy, not whole-arrival/route/effect/all-writer protection. Existing already-active tractor public regression limitation retained. No new acceptance claim beyond supplied independent PASS and exact integration identity.

## Stop

Only fast-forward and this ignored report written. All old worktrees, stashes and unrelated content preserved by leaving them untouched. No reset/clean/stash/rebase/amend/new commit/default workmux cleanup, removal, push, agents/workflows, external services/secrets, tooling/package/STU/map edits, implementation/review/gate rerun or frontend work.

**STOP after integration.** Coordinator may pick up K7a2 separately in the original session; this worker starts no next ticket.

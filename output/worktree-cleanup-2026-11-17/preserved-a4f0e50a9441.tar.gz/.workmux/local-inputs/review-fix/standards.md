# K7a2b independent Standards review — 2026-11-09

## PASS — Standards axis only

Base: `9219a25e6965814064fc834821f04847748b1ff5`.
Candidate: `c212d12d28d8edd059b3148dcec638dcd44faac1`.
Exact comparison: `git diff 9219a25e...c212d12d`, after resolving full IDs. Merge-base equals the fixed base. One commit: `fix(spacecraft): reject stale movement writes (tmw-K7a2b)`, with required attribution.

## Findings — under 400 words

**Documented-standard violations: none attributable to this diff.** Naming and commit form follow `CONTRIBUTING.md:71-74` (Conventional Commits, English code/commits, shared DTO placement, NestJS organization). `MovementState`, `FleetMovementState`, and `MovementOriginals` are backend persistence/transaction support, not client-shared DTOs; their spacecraft-local placement is appropriate. Comments describe capture timing, bounded application, and one-step persistence rather than implying a universal transaction contract. No entity hierarchy, migration, public route, or alternative navigation model is introduced. Protecting the existing legacy warp save does not newly introduce the pre-existing model scheduled for removal by ADR-0006.

The only tracker hunk changes K7a2b's status/checklist. It does not add an independent PASS or integration claim, rewrite conversation history, or resolve neighboring issues. Implementation acceptance remains for the separate Spec review; the supplied handoff explicitly says independent review/integration are pending.

**Baseline smells: none consequential enough to report.** All twelve supplied heuristics were considered as judgement calls, subordinate to documented conventions:

- `movement-state.ts:5-124` gathers the bounded field set, detached capture, apply, and comparison. Its typed state avoids independently maintained capture/apply field lists. The Map extension carries fleet assumptions with per-object originals; no speculative public abstraction is added.
- `spacecraft.service.ts:2301-2425,2925-3049` keeps movement-step validation/persistence together and reuses the prerequisite participant helper. Carried-target handling is an explicit bounded extension. Operation-specific mutation/effects stay in existing callers; this is not newly introduced Divergent Change or consequential Shotgun Surgery. Similar lock/refusal clauses do not justify a generic all-writer abstraction.
- The 1616-line integration suite separates fixture/DI support, barriers, lock-wait observation, and 23 named production-call scenarios. Explicit repository chains and repeated scenario setup alone are not consequential Message Chains or duplication. Three focused existing adapters support the new transaction calls without weakening assertions or adding production scaffolding.

The four disclosed new lint warnings are tooling-enforced and are not re-reported as hidden Standards findings. No new suppression or skipped-test marker is present.

**Summary: 0 documented breaches / 0 consequential smell findings.** Spec correctness, universal concurrency safety, checklist acceptance, and integration approval are outside this axis.

## Inspected scope and standards

All candidate source and standards were read from local Git objects, not the older review working files. Inspected every hunk across exactly eight paths:

- `.scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md`
- `apps/backend/src/modules/spacecraft/movement-state.ts`
- `apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts`
- `apps/backend/src/modules/spacecraft/spacecraft.service.ts`
- `apps/backend/src/modules/spacecraft/spacecraft-destruction.service.ts`
- `apps/backend/src/modules/spacecraft/spacecraft-movement-resources.spec.ts`
- `apps/backend/src/modules/spacecraft/spacecraft-fleet.service.spec.ts`
- `apps/backend/src/modules/spacecraft/cartography-lifecycle.integration.spec.ts`

Candidate standards inspected: mandatory `CONTRIBUTING.md`, `AGENTS.md`, pertinent station/navigation terms in `CONTEXT.md`, `docs/agents/domain.md`, `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`, ADR-0004 and ADR-0006. Candidate tracked-path inventory contains no `CODING_STANDARDS` file, root `CONTEXT-MAP.md`, or backend-local CONTEXT/AGENTS/CLAUDE/CONTRIBUTING or context-scoped ADR requiring another read. The review worktree has no `.codegraph/`; no CodeGraph/indexing was used. Prior K7a2a was not re-audited; only its unchanged helper fingerprint/blob identity was checked.

## Candidate-bound evidence

Read the supplied handoff, RED/GREEN saver logs, final unit/targeted/full PostgreSQL/build summaries, empty type log, and lint summary plus relevant warning blocks under `.workmux/local-inputs/k7a2b-review/`. SHA-256 computed directly from candidate Git blobs matches **all seven changed backend files and the unchanged prerequisite**:

| File, under `apps/backend/src/modules/spacecraft/` | SHA-256 — MATCH |
| --- | --- |
| movement-state.ts | `d1ca45dac5fff29cba23d7fbce0b68b41afc968060612176a7212ea0bad7bdc6` |
| movement-concurrency.int-spec.ts | `8b90b5464a2102755f2f26f736852c9410db80853aa4f66c04519987cb1b67e6` |
| spacecraft.service.ts | `cd2d1486095ed105bd52095be990954942f821b0b678629f445ca6af92dcc804` |
| spacecraft-destruction.service.ts | `59965007d3b7ee63f14fe38f3dec66b883ecc43ec76261a6050908dc44bcc798` |
| spacecraft-movement-resources.spec.ts | `953c008f6a2dcb69fb8fe4d73b3020b94754a97f4e8b0df6f36245c8ba09a371` |
| spacecraft-fleet.service.spec.ts | `109e409cca68053cc8d04a1248a6a00fad5264143c7f20b46cb26f3ebb9168b1` |
| cartography-lifecycle.integration.spec.ts | `d88a895c03cfe82f4d1c4159cb59bc1b6fc3a3d9002dadcd5d29a511fc71d93b` |
| fleet-lock.ts — unchanged base/candidate blob | `7830e6386018f81e4cffcd3543e1d0eb6ab06e67e5d362cda24911e1377c8fe8` |

| Supplied execution | Handoff exit | Visible result |
| --- | ---: | --- |
| Saver RED / GREEN | 1 / 0 | Persisted location/EPS/runtime mismatch / 1 test passed; incremental earlier inputs, not final fingerprints |
| Final backend lint | 0 | 0 errors / 1428 warnings; Nx success |
| Final production + all-spec types | 0 | Empty log; handoff command `tsc --build apps/backend/tsconfig.spec.json --force` |
| Final backend units | 0 | 211 suites / 1981 tests / 1 snapshot passed; 50.184 s |
| Final backend build | 0 | Shared tsc dependency, webpack success `dfa4c98e0a402365`, Nx success |
| Final targeted PostgreSQL | 0 | 5 suites / 67 tests passed; 40.052 s; named five paths visible |
| Final full PostgreSQL | 0 | 38 suites / 335 tests passed; 218.363 s |

Final Jest summaries show passed counts equal totals, with no skipped counts. Candidate new suite has 23 test declarations and no skip/suppression additions. Lint visibly retains the four disclosed new warnings: unused fleet adapter arguments at `:73,165,166`, and service non-null assertion at `:2409`; no claim that all 1428 are pre-existing. Integration deprecations and expected failure-path application logging are disclosed, not hidden failures.

### Cache and limits

These are **supplied executions, not reviewer reruns**. Handoff states final Jest `--no-cache`, Nx lint/build `--skip-nx-cache` with daemon disabled, and final spec-inclusive TypeScript `--force`, superseding earlier incremental type evidence. Build's shared dependency visibly uses ordinary `tsc --build`; disabling Nx cache does not itself disable TypeScript incremental reuse there. Empty type output does not independently prove success: command/exit provenance is supplied by the handoff. Fingerprints bind final backend bytes to the reported evidence, not independently reconstructed execution provenance or data-submodule/container inputs.

The handoff distinguishes simulated relocation from real saver/public movement calls, partial DI fixtures from a complete Nest graph, valid earlier step/departure commits from whole-flight atomicity, and bounded related-writer protection from arbitrary all-writer safety. No wormhole endpoint or effect-atomicity acceptance is inferred. No separate Spec review was performed.

## Reviewer operations and preserved state

Read-only shell commands used `npm exec --offline -- node -e '…'` with local Git subprocesses (`rev-parse`, `merge-base`, `log`, `rev-list`, `diff`, `show`, `ls-tree`, `status`, `check-ignore`) and SHA-256/log inspection. All reviewer command wrappers exited **0**. Exact diff whitespace check is clean. Report destination verified ignored and absent before creation.

No gate/test/typecheck/build/lint/DB run, dependency install, source/tracker/map/package/STU edit, branch switch, nested agent/workflow, external service/secrets, commit/merge/push, stash/worktree mutation, cleanup, or other-checkout write occurred. Only this ignored report was written. Review HEAD remains `ff16922a7b93b620acb4d51d7180cf255dd970b2`, working tree clean.

**Stop after Standards report. No integration authorized or performed.**

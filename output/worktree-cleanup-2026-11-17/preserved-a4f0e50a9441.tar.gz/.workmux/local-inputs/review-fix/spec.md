# K7a2b independent Spec review — 2026-11-09

## Disposition

**Spec: BLOCKED — one verified P2 valid-movement regression.**

Base: `9219a25e6965814064fc834821f04847748b1ff5`.
Candidate: `c212d12d28d8edd059b3148dcec638dcd44faac1`.
One commit: `fix(spacecraft): reject stale movement writes (tmw-K7a2b)`.
Exactly eight changed files; three-dot diff and whitespace validation checked. Authoritative spec: `.scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md` **at BASE**, not the candidate's checked checklist. All source inspected through candidate/base Git objects; old working source was not used. Spec axis only; Standards remains separate.

## Spec findings — under 400 words

**(a) Missing/partial requirements:** no separate verified finding beyond the regression below.

**(b) Unasked scope:** no verified scope creep. No tariff, wormhole/planner, whole-flight/arrival/outbox redesign or all-writer rewrite was added.

**(c) P2 — a towed fleet member falsely becomes stale on the next valid field.** Candidate `apps/backend/src/modules/spacecraft/spacecraft.service.ts:2307,2363–2417`, reached through `:2024–2039,2095–2104`.

BASE spec **:23**: “Gültige gewöhnliche Bewegung und bestehende partielle Flottenpolitik bleiben erhalten. Keine Änderung des Ressourcentarifs, kein Rewrite sämtlicher Schiffs-Writer und keine Wurmlochimplementierung.”

Concrete supported state: an owned, local IDLE fleet member is also the leader's tractor target, with sufficient leader/member EPS for two navigation fields. Existing tractor activation has no fleet-membership prohibition; existing fleet preparation can select this member. Preparation and the separate target `findOne` return **different objects with the same spacecraft ID**.

`new Set([...participants, ...carried])` deduplicates object identity, not IDs. Both aliases validate against the same locked row before either is written. The paid/mutated member is applied first, then the carried alias's still-original energy/runtime overwrites it. After commit, `originals` nevertheless records both distinct in-memory snapshots. On field two, the selected member's baseline differs from the stored carried snapshot, so `assertMovementState` throws `veraltet` **without any concurrent commit**. A valid two-field flight stops after one field.

The old direct carried save could already overwrite member state; the candidate's new contradictory per-object baselines introduce this next-step refusal. The report does not misclassify that old overwrite itself as a newly introduced defect. Canonicalize moving participants/current rows/committed baselines by spacecraft ID and preserve the existing towing-cost policy; add a real public multi-field navigation regression for the overlapping member/target case. Existing tests exercise fleet movement and towing separately and miss this combination.

## Inspected acceptance evidence and boundaries

- **BASE :20–21:** Detached snapshots precede movement activation/undocking/payment at all five public callers. `movement-state.ts:1–124` compares bounded identity/location/status/resources/runtime and hydrated module keys with `node:util.isDeepStrictEqual`, not order-sensitive JSON serialization. `spacecraft.service.ts:2301–2420` uses explicit READ COMMITTED, unchanged fleet NO KEY UPDATE then sorted spacecraft NOWAIT, with carried/module NOWAIT. Expected fleet IDs, leader, fixation and all member locations are checked; all moving objects validate before saves; application targets current locked rows and preserves unrelated settings. The finding is the same-ID alias exception to coherent commit-baseline advancement.
- **BASE :21–22:** Actual `navigate`, `flyGalaxy`, `enterSystem`, `leaveSystem`, legacy `warp`, and towing direct-write sites were inspected. Rejected step persistence precedes signatures, knowledge/discovery, field pipeline/statistics and later repair/orbit effects. Prior committed fields survive later rejection. Local consequence changes intentionally carry into the next step while the prior commit remains the comparison baseline; the maintained two-field EPS-leak test proves this supported case.
- **BASE :22–23:** Optional-original `saveUnlessDestroyed` retains missing/destroyed false before comparison; no-original/combat-survivor saves retain intentional behavior. Terminal leader preparation refuses before departures. Valid nonfixed local departure, unchanged remote attachment, fixed refusal and departure rollback remain in the unchanged K7a2a suite. Preflight cartography/takeover effects and separate valid departure commits are not claimed whole-flight atomicity.
- **Related writers:** Actual tractor activation locks affected spacecraft; actual `TransferService.transferShipCrew:311–351` locks both ships before assignments. The test's incoming-tractor and crew-transfer operations simulate those locking boundaries, not public executions of those related writers. Existing module rows are locked NOWAIT; there is no claim of predicate protection against arbitrary post-check insertion or unsupported writer behavior. No such hypothetical misuse is a finding.

## Test seams and supplemental verification

Entire **1616-line, 23-case** candidate PostgreSQL test file read. Actual production saver and public movement callers, real entities/repos/transactions, migrations and unchanged disposable harness; afterLoad subscribers pause real loads and are removed/released in finally. Saver proof observes actual `pg_blocking_pids` waiting. Gateway/messaging are observation mocks; empty DI providers are unexecuted boundaries, not mocked persistence or full Nest graph acceptance. No skip/only/todo declarations.

Tests cover relocation, resource/runtime-only conflicts, direct entry/exit/warp members and towing target, changed membership/remote location, removed module, incoming tractor, crew loss, unrelated-field preservation, terminal/missing/combat-survivor behavior, successive valid fields and preserved prior committed step. They do **not** cover overlapping carried/fleet identity. Changes to existing resource/fleet/cartography adapters preserve all assertion/test-declaration lines (zero changed assertion/declaration lines in each diff); they are not real concurrency proof.

One concrete supplemental probe was necessary, **no database or suite rerun**:

```sh
npm exec --offline -- node .workmux/k7a2b-alias-state-probe.cjs
```

Exit **0**, asserts the alias inconsistency using the candidate's actual Git-object `captureMovementState`, `assertMovementState`, `applyMovementState` functions, locally transpiled in memory. Two objects/one ID both validate; member energy 53→52 is overwritten to 53 by the carried alias; the committed-model next member validation throws `veraltet`. This is a deterministic helper-level probe, **not** a PostgreSQL/public-navigate execution. The public reachability and shared-row resolution were verified in source, including the existing tractor/fleet rules. Probe output:

```text
CONFIRMED pure candidate-helper alias inconsistency: two objects / one spacecraft ID.
After first-step apply: stored-model energy=53, member next-step baseline=52.
Next member validation throws veraltet without any competing commit.
Limit: helper-level deterministic probe, not a PostgreSQL/public-navigate execution.
```

## Candidate-bound supplied gates

Independently recomputed and matched **8/8 SHA-256 fingerprints**: seven changed backend source/test files plus unchanged `fleet-lock.ts`. Integration datasource/database/global setup and prior fleet PostgreSQL suite also byte-identical to BASE. This binds supplied tested-byte claims to candidate objects; it is not independent gate execution provenance.

| Supplied final log | Independently checked output; worker reports exit 0 |
| --- | --- |
| `k7a2b-final-units.log` | 211/211 suites, 1981/1981 tests, 1 snapshot, zero skipped totals; 50.184 s |
| `k7a2b-final-full-postgres.log` | 38/38 suites, 335/335 tests, zero skipped totals; 218.363 s |
| `k7a2b-final-targeted-postgres.log` | 5/5 suites, 67/67 tests, zero skipped totals; explicit movement/fleet/visibility/contacts/escape-pod paths; 40.052 s |
| `k7a2b-final-lint.log` | Nx success, **1428 warnings / 0 errors**; warnings disclosed, not suppressed |
| `k7a2b-final-build.log` | Shared/backend build success, webpack `dfa4c98e0a402365` |
| `k7a2b-final-types.log` | Empty, 0 bytes. Forced `tsc --build apps/backend/tsconfig.spec.json --force` command/exit 0 are **worker-report evidence**, not inferred from emptiness or independently observed exit. |
| `k7a2b-red-saver.log` / `k7a2b-green-saver.log` | Actual earlier saver RED shows committed location/EPS/runtime overwritten; GREEN 1/1. Earlier shortened RED test is not represented as a final-source execution. |

Supplied final commands use npm offline execution, no Jest/Nx cache, and both ambient DB URLs unset for disposable PostgreSQL with real migrations and `synchronize: false`. No gates were repeated; no install, DB connection, frontend/browser or unsupplied intermediate RED reconstruction. Matching historical unit totals are not treated as inherited acceptance. Green gates do not cover or waive the verified alias regression.

## Reviewer actions and stop

Read-only ref/log/diff/merge-base/Git-object reads, isolated Python extraction/hash/test/log checks, scoped Git-object searches, and the one npm-executed pure helper probe. Two guessed-path/no-match Git searches exited **1** and were corrected; no test failure was hidden and no gate command was run. Candidate `git diff --check` passed. Only ignored artifacts written, including this report and supplemental probe.

Unchanged HEAD `14b860813b988165f8470c0c9d3b31e087f70aa2`; tracked worktree clean. No old baseline/prerequisite audit, source/tracker/map/package/STU edits, branch switch, commit/merge/push, nested agents/workflow, external services/secrets, dependency installation or broad gate/DB rerun.

**Stopped after the independent Spec report. No integration or issue resolution performed.**

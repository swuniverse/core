'use strict';
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const vm = require('node:vm');
const ts = require('typescript');
const ref = 'c212d12d28d8edd059b3148dcec638dcd44faac1';
const path = 'apps/backend/src/modules/spacecraft/movement-state.ts';
const source = execFileSync('git', ['show', `${ref}:${path}`], { encoding: 'utf8' });
const compiled = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText;
const mod = { exports: {} };
vm.runInThisContext(`(function(require, module, exports) {${compiled}\n})`)(require, mod, mod.exports);
const { captureMovementState, assertMovementState, applyMovementState } = mod.exports;
// The public navigator receives one fleet-helper row and a second findOne row
// for the same towed spacecraft. This pure state probe models that alias only;
// it does not mock a repository, exercise PostgreSQL, or claim public-call proof.
const base = { id: 2, userId: 1, shipClassId: 1, locationId: 90,
  status: 'IDLE', fleetId: 1, energy: 53, runtimeSystems: {} };
const member = structuredClone(base);
const carried = { ...structuredClone(base), modules: [] };
const originals = new Map([
  [member, captureMovementState(member)],
  [carried, captureMovementState(carried)],
]);
const moving = [...new Set([member, carried])];
assert.equal(moving.length, 2);
assert.equal(new Set(moving.map(row => row.id)).size, 1);
const current = structuredClone(base);
assertMovementState(current, originals.get(member));
current.modules = [];
assertMovementState(current, originals.get(carried));
member.energy -= 1;
member.locationId = 91;
carried.locationId = 91;
for (const row of moving) applyMovementState(current, row);
assert.equal(current.energy, 53);
for (const row of moving) originals.set(row, captureMovementState(row));
const nextRead = structuredClone(current);
delete nextRead.modules;
assert.throws(() => assertMovementState(nextRead, originals.get(member)), /veraltet/);
console.log('CONFIRMED pure candidate-helper alias inconsistency: two objects / one spacecraft ID.');
console.log('After first-step apply: stored-model energy=53, member next-step baseline=52.');
console.log('Next member validation throws veraltet without any competing commit.');
console.log('Limit: helper-level deterministic probe, not a PostgreSQL/public-navigate execution.');

# K7a2a independent Spec review — 2026-11-09

## Disposition

**Spec: PASS** for base `940628fa0a2f1986857fc6998d9439a3fe1378eb` → candidate `9219a25e6965814064fc834821f04847748b1ff5`.

Authoritative spec: `.scratch/stu-parity/issues/tmw-K7a2a-flottenmutationen-nebenlaeufigkeit.md` **at the base**, particularly acceptance lines 20–26. Candidate source was read from Git objects, not the older worktree. Independently confirmed one commit, `9219a25e fix(spacecraft): serialize fleet mutations (stu-parity tmw-K7a2a)`, exactly six changed paths, and clean three-dot diff whitespace validation.

This is the **Spec axis only**, not Standards approval, integration, deployment approval, or issue resolution. Earlier baseline/prerequisite/docs reviews were not repeated.

## Spec findings — under 400 words

**(a) Missing or partial requirements:** none verified within the specified fleet contract.

**(b) Unasked behavior / scope creep:** none verified. Adjacent rename/fixation narrow updates protect leadership as requested by base spec line 22. Integration registry additions support actual ordinary-flight collaborators. No endpoint, wormhole tariff, automatic retry policy, or monolithic movement rewrite was added.

**(c) Apparently implemented requirements implemented wrongly:** none verified. No concrete bounded deadlock, membership/leadership invariant violation, stale field restoration, or partial transactional mutation survived source/test review.

The helper's READ COMMITTED and call-before-spacecraft-lock requirements are documented **caller obligations**; only an active transaction is checked at runtime. NOWAIT contention is a technical refusal, with retry in a fresh transaction, not a permanent eligibility rule. These are not missing automatic enforcement or retry requirements.

Full navigation atomicity, stale movement writers (K7a2b), and wormhole/manager-bound arrival effects (K7a2) remain explicitly deferred. This PASS does not claim their completion or universal all-writer concurrency safety. The candidate issue explains that its local `resolved` status is candidate implementation/gate bookkeeping, with independent review and serial integration still outstanding; this reviewer changed no issue status.

## Acceptance evidence

References below identify **candidate source lines**; spec references identify **base issue lines**.

| Base requirement | Inspected implementation / proof |
| --- | --- |
| :20, common transaction/lock order and authoritative validation | `fleet-lock.ts:1–121`: fleet `FOR NO KEY UPDATE`, complete current members plus initiating ship sorted numerically, spacecraft `FOR UPDATE NOWAIT`, PostgreSQL 55P03 refusal. Post-lock initiating ownership, inferred membership, complete membership IDs/cardinality, and owned leader-in-members validation; positions hydrated after row locks. Explicit-target callers check operation-specific membership/eligibility. `spacecraft.service.ts:2846–2953,3003–3042`: create/join/leave/dissolve/leadership use the helper and caller transaction. No-fleet/create and changed-membership paths inspected. |
| :21, complete future relocation selection / post-wait join | Integration tests `:342–451,580–617,646–750,807–869`: precommitted public join appears in helper-selected full membership; committed relocation and relocation rollback reload persisted state. Waiting public join rejects old colocation and changed ownership/status. Inferred membership change refuses without chasing a second fleet lock. |
| :22, no stale restoration / adjacent leader protection | Narrow spacecraft `fleetId` updates and Fleet `leaderId`, `name`, `isFixed` updates replace stale whole-entity fleet writes. Tests `:249–340,619–644` reload location, energy, membership, leadership and dissolution state across controlled waits and valid public operation sequences. |
| :23, ordinary partial behavior / no new wormhole rule | `spacecraft.service.ts:2751–2843`: locked local blocked-member departures share one transaction; departure-success events occur after transaction resolution. Remote members stay attached, nonfixed local incapacity permits partial selection, fixed local incapacity refuses before writes. Tests `:494–578` exercise actual public `navigate`. Canonical location comparison and assignment-count/required-crew policy were compared directly with existing helpers. |
| :24–25, real database/public seams, waits/order/rollback | Entire 870-line integration file read: 22 expanded cases, no skip/todo/only declarations. Real repositories and public service methods; gateway is an observation mock, and empty providers are unexecuted boundaries, not persistence substitutes or full application DI boot. Barriers observe `pg_blocking_pids`, not timing alone. Ship-first lock contention refuses and fresh retry succeeds; opposite initiating IDs serialize complete ordered selections. Controlled create-assignment, dissolution-delete and later-departure failures verify rollback and, for departure failure, no success event (`:526–559,752–805`). |
| :26, lint/types/test/build | Supplied candidate executions reviewed below; none rerun by this reviewer. |

Harness source inspected at candidate: `data-source.ts:124–134` uses real migration files and `synchronize: false`; `database.ts:23–40` runs migrations; existing global setup starts disposable PostgreSQL 16 when no integration URL is supplied. Recorded integration commands explicitly unset both ambient DB URLs.

## Candidate-bound execution evidence and limits

Independently recomputed SHA-256 from candidate Git blobs and matched **5/5** supplied tested-backend fingerprints: helper, spacecraft service, integration suite, existing fleet unit suite, integration datasource. The issue is the sixth changed path; it is bookkeeping, not a gated backend fingerprint. This binds supplied tested-byte claims to the candidate; it is not an independent re-execution or forensic reconstruction of gate history.

| Supplied log | Reviewed result |
| --- | --- |
| `k7a2a-gate-units.log` | 211/211 suites, 1981/1981 tests, 1 snapshot; no skipped totals; 83.913 s |
| `k7a2a-gate-postgres.log` | 37/37 suites, 312/312 tests; no skipped totals; 276.473 s |
| `k7a2a-targeted-integration.log` | 4/4 suites, 30/30 tests; explicit final fleet test path plus three existing suites; 27.591 s |
| `k7a2a-gate-lint.log` | 0 errors, **1424 warnings**, Nx success; warnings not suppressed |
| `k7a2a-gate-build.log` | Shared build dependency/backend build, successful webpack/Nx completion |
| `k7a2a-gate-types.log` | Empty (0 bytes); command and exit 0 are supplied report evidence, not textual proof or independently observed exit. Spec-inclusive `tsc --build` may reuse incremental state. |
| `k7a2a-red-join.log` / `k7a2a-green-join.log` | Substantive RED asserts persisted fleetId unexpectedly 1 rather than null; GREEN 1/1. Historical RED used the earlier shorter test file, not a claimed final-source test run. |

Final gate exit 0 values are supplied execution-report evidence; terminal counts/success summaries were checked against local logs. The full PostgreSQL log does not list individual passing suite names; final fleet inclusion is supported by the explicit targeted run, 22-case candidate source/fingerprint and supplied report. Matching historical unit totals are not treated as inherited gates. Intermediate setup failures, reused filenames, passing preconversion cases and warnings remain disclosed in the supplied report; unsupplied intermediate logs were not independently verified. No frontend, browser or clean rebuild claim.

## Reviewer actions and stop

Read-only commands: ref/commit/merge-base checks; `git diff <base>...<candidate>` and `--stat`, `--name-only`, `--check`; `git show <ref>:<path>` for authoritative spec, changed source/tests and narrow neighboring call paths; isolated `python3 -I` extraction/hash/log/test-declaration checks; `git status --porcelain=v1 -z`, `git rev-parse HEAD`, and `git check-ignore` for this report. Completed checks exited 0. No additional focused probe was necessary after source and existing evidence resolved the bounded questions; **no test or DB command was run**.

Actual unchanged worktree HEAD: `14b860813b988165f8470c0c9d3b31e087f70aa2` (not the stated `ff16922a`). Tracked worktree is clean. Only ignored review artifacts were written. No source/tracker/config/map/package/STU changes, branch switch, dependency installation, full-gate rerun, nested agent/workflow, external service, commit, merge or push.

**Stopped after the narrow Spec report. No integration or issue resolution performed.**

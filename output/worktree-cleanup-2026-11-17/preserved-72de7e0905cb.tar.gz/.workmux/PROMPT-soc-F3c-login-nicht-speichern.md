Implement `soc-F3c` from `.scratch/stu-parity/issues/soc-F3c-login-nicht-speichern.md` in this isolated worktree. Ticket is claimed by coordinator (claim commit on base). Read and follow every acceptance criterion.

Workflow/constraints:
- Use strict test-first RED/GREEN; inspect relevant auth/session design and docs before editing. This is a small, focused frontend change.
- No other ticket scope, no issue maps, no package-manager files, no lockfiles. Use npm/npx only.
- Do not modify `/Users/TMUNDIN/git/github.com/st-universe` or another repository. No secrets/external services.
- Preserve canonical behavior when “Angemeldet bleiben” is enabled; when disabled, store access/refresh tokens in sessionStorage, not localStorage. Logout clears both. Remember the user's local preference without server requirement. Cover storage choice and logout with frontend tests.
- Run focused tests first and required lint/typecheck/test/build gates as practical; report exact commands and exits, changed paths, RED/GREEN evidence, and any blocker.
- Commit your implementation with `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Do not merge/integrate or push. Keep tracker claimed; do not append evidence until validation is complete. Report commit/tree and worktree status.

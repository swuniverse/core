# K7a3 uncommitted draft — independent Spec source review

Date: 2026-11-10

**SOURCE-AXIS: BLOCKED — two P2 Spec findings.**

**FINAL ACCEPTANCE HOLD: separate, unresolved execution/candidate evidence gaps. This is not final-candidate approval or integration approval.**

BASE / reported worker HEAD: `29ac20e249184b87789b0c7ca0494e549c1e7f10`.
Uncommitted snapshot identity: `3d9d94dc2f83e26e5dc01d8014ebff096938743c5364d08a82df2dfd86628bd0`.
Reviewer HEAD: `14b860813b988165f8470c0c9d3b31e087f70aa2`.

## Spec findings — under 400 words

### 1. P2 — asynchronous canvas initialization overwrites arrival focus

BASE K7a3 spec `.scratch/stu-parity/issues/tmw-K7a3-wurmloch-frontend-und-oberflaeche.md:29`: “Nach erfolgreicher Passage aktualisieren sich Schiffsdetail und Karte auf die vom Backend bestätigte Position”.

Draft `apps/frontend/src/components/starmap/StarmapCanvas.tsx:590–602` focuses the destination when `ready` becomes true. But initialization sets `ready` at :546 **before** awaiting `renderGalaxy`/asset loading (:548); its later completion unconditionally calls `fitView()` (:578), overwriting that focus and zoom. Reachable case: open the confirmed arrival URL on a large layer with an uncached/delayed asset; the focus effect runs while rendering awaits the asset, then the map returns to whole-layer fit rather than the arrival view. No dependency changes after that completion to restore focus. Apply destination focus after initialization's final fit, or make initial fit respect the target. Spec :30 requires “Zustandsaktualisierung” tests; the new page test replaces the canvas with a DOM mock and asserts only the passed coordinates, so it cannot catch this ordering failure.

### 2. P2 — post-success position error can disappear with field context

The same original spec :29 requires “Fehler werden verständlich angezeigt”.

Draft `FieldContextPanel.tsx:318–339` refreshes the parent, then reads the canonical position and stores a distinct error on failure. In the actual BASE `spacecraft-detail.tsx:76–93`, an updated location clears field context and a failed destination field-context request leaves it null. Reachable case: passage POST and parent ship refresh succeed, but the subsequent canonical GET and destination field-context GET fail. The error is set, yet `FieldContextPanel.tsx:379` returns null before its alert (:767–771), permanently hiding the passage-completed/refresh-failed feedback. Keep passage feedback renderable independently of field-context availability. Neither new production-page nor component tests cover this failure sequence.

**Missing/partial:** the two behaviors above. **Unasked behavior:** none verified; no client movement/resource/eligibility policy was introduced.

## Source evidence and bounded conclusions

- Independently verified **15/15 raw copied-source SHA-256 hashes**, including the untracked new `wormhole.service.spec.ts`, and recomputed the exact sorted-JSON manifest identity before substantive review. Hashes establish input integrity, not correctness or execution provenance.
- Read `candidate-pin.md`, `source-manifest.json`, the complete tracked `candidate.diff`, checkpoint and frontend reports. Reviewed every one of the 15 copied paths: complete small files, relevant production source/caller ranges and maintained frontend/HTTP tests. Independently compared each copied path against BASE Git blobs; unchanged portions remain BASE. No candidate commit or three-dot candidate comparison exists.
- Original parent and K7a3 specs were read from BASE Git objects. Draft checkboxes were not treated as acceptance proof. Standards review is separate and was not duplicated; accepted backend atomic passage/prerequisite contracts were not re-audited.
- `getFieldContext:3598–3787` checks the owned ship through `findOne` before projection, resolves canonical location, and returns an empty passage list outside GALAXY. `findPassageOptionsAt:93–130` delegates to active local entry / active bidirectional reverse filtering, batches target-layer reads and exposes only ID, nullable name and target-layer ID/name. Reverse projection targets the origin layer; no destination coordinates or backend policy details leak through this new DTO.
- BASE production `SpacecraftModule` imports `StarmapModule`; that module provides/exports `WormholeService` and registers both Wormhole and Layer repositories. The appended optional injection has a real production provider; omitted legacy manual-constructor dependencies yield an empty list, not a production graph defect.
- Required `SpacecraftFieldContextDto.wormholePassages` is produced by the backend. All 31 direct component context literals and the two context-producing fixture helpers are updated. BASE searches found no other typed field-context object producer. Existing untyped detail/tutorial API mocks omit the field; optional access tolerates that omission, so this is not a verified compile/runtime blocker.
- Native labeled selector displays each name/target layer, preserves or resets selection against supplied choices, disables pending controls, and submits the selected numeric ID to the accepted public route. Backend failures use the existing API error message and alert; no authoritative client validation or optimistic movement was added.
- Source-inspected three new component cases (multiple/selected-ID, rejected POST, empty visibility), the production detail-page navigation case, ordinary-field map-page case, registry case, all three new projection unit cases, and the added real production AppModule/JWT/PostgreSQL HTTP projection case. The HTTP fixture uses the existing RESTART IDENTITY reset; its layer-1 references match that fixture. It is not executed evidence.
- Normal successful detail refresh applies the backend ship through the existing parent callback and triggers location-key-dependent reads; the subsequent no-store GET supplies navigation coordinates. The new detail test checks POST/GET/URL but does not assert the rendered arrival header or actual Pixi viewport. The map test proves ordinary-field selection and prop wiring, not canvas initialization behavior.

## FINAL ACCEPTANCE HOLD — evidence only, distinct from source findings

- **No committed final candidate.** Review applies only to the exact supplied draft snapshot.
- **No raw gate logs supplied.** Worker reports frontend 92 suites/files / 661 tests, focused backend 3/3, typecheck/lint/build. These are report claims, not independently verified execution. Source fingerprints do not establish when or whether those commands executed on those bytes.
- Full backend, spec-inclusive types and the newly added HTTP PostgreSQL execution are missing. No success is inferred for them; earlier BASE backend evidence is not draft evidence.
- Session transcripts and tool-result files were not accessed or copied. Prior denials were not bypassed. No tests, build, typecheck, lint, database or dependency commands were run by this reviewer.
- Candidate tracker explicitly preserves missing HTTP evidence and pending independent review/integration. Checked gate boxes do not close this hold.

## Reviewer actions and stop

Only read-only source/spec/report/Git/hash/scope checks and this NEW ignored report. Two lookup commands failed on guessed BASE paths (`apps/frontend/src/lib/api.ts`, `apps/backend/project.json`); the actual API path was subsequently read. These are lookup failures, not gate executions or gate results. An optional guessed location-file lookup was absent; the actual `spacecraft-field.ts` interface was subsequently read.

Report target confirmed absent and ignored before creation. Reviewer HEAD remains unchanged and tracked worktree clean. **Source Spec BLOCKED; FINAL ACCEPTANCE HOLD remains.** No tracked source/tracker/config/package/map/DECISIONS/STU edits, branch switch, commit, merge, push, cleanup/install, external service/secrets access, nested agents/workflow, plan mode or integration. Stopped.

# K10a1 — original Standards/security correction review

**Standards/security correction PASS0 — original P2 closed, zero new consequential findings.** This disposes of the lifecycle race only; canonical typecheck acceptance remains unresolved. No independent Spec verdict or full technical acceptance supplied.

## Exact narrow scope
- Original `7f5c7a6e5afe2dbf256cd7985692211b6f62a4a8`, tree `1751e1f0a2de05278bc4ac7a1d393b7531e2b564`, BASE `b4a7a6fb8559fbd60ceab1afb0117f7ee3e20a81`.
- Correction `94164aed9bc4b05aedbdc4f6b7ce2a27d337a1b9`, tree `e348a4f07d06e02fa38d474d86c6fc25de579897`; sole direct parent original; `fix(anomaly): serialize concurrent lifecycle ticks` with required attribution.
- `git diff original...correction` / `git log original..correction --oneline`: exactly anomaly.service.ts and anomaly-tick.int-spec.ts, 225 added lines. All other committed source unchanged; original unchanged-source review retained, not repeated.
- Exact Git blobs, revised PG tests and retained registry/main-tick transaction seams read. Supplied standalone correction-report copy path was absent; actual manifest copy `.workmux/local-inputs/k10a1-correction-review/correction-report.md` read and hash-bound to worker report.

## Finding disposition — under 400 words
**Original P2 fixed.** `apps/backend/src/modules/anomaly/anomaly.service.ts:14–23` acquires PostgreSQL transaction-level `pg_advisory_xact_lock(hashtext('swu_anomaly_tick'))` before the journal insert and every anomaly read/callback/creation check. The same key serializes distinct and equal tick IDs even with no existing rows. A waiting transaction reads committed predecessor state after acquiring the lock; distinct committed ticks each decrement once, while the same-ID journal conflict skips repeated work. Lock release and journal/lifespan changes follow commit/rollback, so a failed attempt does not consume its ID or obstruct a waiting transaction permanently. The four inserted lines are the only production delta; remainder byte-identical.
`anomaly-tick.int-spec.ts:17–102` pauses the actual first tick/disappearance callback, starts the second distinct transaction, observes callback entry or a PG lock wait, releases in cleanup, and asserts 3→1 lifespan and only one durable disappearance for lifespan 1. Disappearance inserts use the supplied manager. Tests :104–166 verify empty-set creation produces one row and two serialized checks; :168–236 verify rollback releases a waiter and failed-ID retry expires the object. Existing ordering/expiry/parent/same-ID retry regressions remain. No new consequential documented-standards/security defect retained.

## Transaction boundaries and caveats
- Existing-before-creation order, ID ASC snapshot/reload, expiry callbacks/removal and manager-based durable writes unchanged. Registration remains trusted in-process; no public plugin endpoint or ellipse behavior introduced.
- Lock acquisition order is not numeric tick order. The lock is held only for the anomaly transaction, not the whole main tick; later tick failure does not undo a committed anomaly phase.
- Future handlers must use the passed manager and consistent lock ordering; recursive lifecycle entry or other handler locks are not proven deadlock-free. External effects/in-memory callback signals cannot roll back; no outbox/whole-game atomicity claim.
- PG overlap checks use local pg_stat_activity lock waits or second callback observation, not a mocked advisory lock. Runtime proof is the recorded real-PG results, not reviewer execution; no separately added concurrent-equal-ID test claimed.

## Selected identity/evidence — no gates rerun
- Verified exact parent/tree/two-file scope, current worker correction HEAD/tree and raw code, issue-only unstaged append; ready-for-agent and six boxes unchanged, no staged changes. Reviewer original branch/HEAD tracked clean; new report target absent/ignored.
- All **19 manifest artifacts** (report plus nine receipt/log pairs) matched copied/worker hashes. Receipts have numeric integer exits, equal before/after, source_unchanged true, original HEAD/tree checkpoint, valid log SHA-256 and terminal exits. Issue metadata excluded from executable maps.
- Meaningful RED `k10a1-correction-red-concurrency`: **exit 1, 2 failed / 3 passed / 5 total**, 12.504 s; both failures expected 1 but received 2 (lifespan and durable disappearance). Early GREEN: **exit 0, 5/5**, 11.128 s; its earlier source hashes differ from final, so not claimed as exact final proof.
- Creation/rollback **exit 0, 7/7**, 12.233 s; this and all four final passes match both exact corrected source hashes. Final PG **3 suites / 10 tests**, 15.981 s; unit **215 suites / 2008 tests / 1 snapshot**, 56.959 s; passed=total, zero skips.
- Final lint **exit 0, 0 errors / 1439 warnings**, 12.959 s; webpack build **exit 0**, 8.544 s. Targeted PG only, disposable PG16/migrations/synchronize:false retained; no full PG/build matrix or production DB boot claim.
- Strict declarations **exit 2**, 6.981 s, TS6133 unused ExplorationState in unchanged starmap query. Canonical final typecheck **exit 1**, 11.090 s: **1250 diagnostics**, **977 TS6305**, **244 TS7006**, including **seven** in revised anomaly test :62/:65/:124/:190; TS6133 retained. Actual hashes/counts/exits verified.
- These correction-test diagnostics cannot be established as mere cascade without valid strict declarations. Prior prepared original/base comparison predates this correction and does not prove them baseline. No canonical/relaxed typecheck acceptance or all-gates-green claim; coordinator limitation remains open.
- Verification was one bounded scope split into continuations: initial literal-removal assertion failed from reviewer shell quoting, then an overstrict early-GREEN-to-final hash assumption failed. Only omitted checks resumed with line-based comparison and early evidence correctly distinguished; no candidate/evidence repair or gates executed. Manifest checks completed, final receipt verification continuation 0.262 s; no broad artifact audit.

## Preservation, UTC and stop
- Original Standards HOLD report preserved verbatim: SHA-256 `8740676a31d30d33a5e46e57320f5f25d389c151d7e9c4ddc525cf9073aa8a8b`.
- Original Spec report untouched: SHA-256 `52b5203c66be657f2dc8f7402b5bdab481578ced7f620abcb527c35bfcbdfa50`; no Spec judgment issued here. All prior checkpoints/artifacts retained.
- Start `2026-11-11T13:47:28.155Z`; bounded source end `13:47:49.418Z` (**21.263 s**); evidence verification attempts `13:48:38.090Z–13:49:41.867Z`; completion **133.712 s** from start. No remaining source/evidence blocker; typecheck limitation remains.
- Only this NEW ignored report written. No source/issue edits, tests/DB/types/lint/build/install, configs/package/map/DECISIONS/STU, external services/secrets/environment values/private transcripts, agents/workflows, branch changes/commits/merge/push/cleanup.
- Final report/handoff check `2026-11-11T13:50:35.668Z`: both original report hashes unchanged, reviewer original HEAD clean, new report ignored; **53.801 s** after evidence completion, **187.513 s** total elapsed (within ten minutes).
- Stop for coordinator: lifecycle correction accepted on this axis; canonical typecheck/overall acceptance still requires explicit disposition. No criteria/status/resolution/integration edits.

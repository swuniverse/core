# K7a3 corrected draft — Spec final-gate evidence closure

Date: 2026-11-10

**SOURCE SPEC: PASS, zero findings; both prior P2 findings remain FIXED.** Retained from `.workmux/tmw-K7a3-corrected-draft-spec-review-20261110.md`; no source audit repeated.

**EXECUTION-EVIDENCE HOLD: CLOSED for the reviewed draft, on the supplied direct evidence.**

**FINAL CANDIDATE: still uncommitted. Candidate-commit binding and coordinator acceptance remain separate; no integration approval.**

BASE / recorded worker HEAD: `29ac20e249184b87789b0c7ca0494e549c1e7f10`.
Reviewed snapshot: `7a37d2e50a475d9f44431a8bc00e8a831403f4759d4beb06a95ecab99b2fe8e2` (16 paths).
Reviewer HEAD: `14b860813b988165f8470c0c9d3b31e087f70aa2`.

## Findings / prior outcomes

No new source findings were sought in this evidence-only closure. Original canvas arrival-focus and null-context completed-passage feedback P2 outcomes remain **FIXED**. Standards is separate and was not duplicated.

The two missing execution items are now evidenced: a fresh backend invocation with numeric process return, and the targeted HTTP PostgreSQL suite including the new field-context projection case. Earlier wrapper evidence is not repaired or relabeled. Lack of a final candidate commit is not closed by these test results.

## Verified integrity and execution records

Input directory: `.workmux/local-inputs/k7a3-final-gate-closure/`.

- Verified **4/4 supplied-file SHA-256 hashes** against `manifest.json` before substantive review.
- Recomputed the reviewed sorted-JSON source-manifest identity and verified **16/16 reviewed copied-source hashes**. All sixteen source digest records in the new JSON and the report's identical-before/after table exactly equal that manifest. JSON records the expected HEAD and `source_unchanged: true`; its `log_sha256` matches the direct log. The reported before/after equality is supported by those supplied records, not a reviewer inspection of the worker checkout.

### Fresh backend full-suite invocation — evidence PASS

`backend-full-tests-direct-exit.log` SHA-256:
`4d30f72ddc6dff18c0985176f09f7b028d505471107999e1f665162d487822b5`.

Recorded command: `NX_DAEMON=false NX_NO_CLOUD=true npm exec --offline -- nx test backend --skip-nx-cache`.

Log :349–357 reports **214/214 suites, 1996/1996 tests, 1/1 snapshot passed**, all suites run and Nx success; no skipped totals. Log :361 records **`process_exit=0`**. Matching JSON records numeric integer `process_exit: 0`, the same command and exact log hash. This is the newly supplied subprocess-returncode record, not an exit inferred from Nx success.

The supplied Markdown report's backend row still describes the earlier flawed `backend-full-tests-clean.log` invocation and inferred `command_exit=0`; it is historical context, not this new direct run. Both prior wrappers remain flawed historical evidence. Neither is relabeled successful, and the unsupplied clean log was not accessed.

### Targeted HTTP PostgreSQL — evidence PASS

`wormhole-http-postgres.log` SHA-256:
`ba83c21476ef98c346c83aaf96f8ec27add127e074c95870a3914f388e0630ba`.

Log :1 records the targeted invocation with **`env -u DATABASE_URL -u INTEGRATION_DATABASE_URL`**, `NX_DAEMON=false NX_NO_CLOUD=true` and `--skip-nx-cache`. Jest names `wormhole-passage-http.int-spec.ts`; :83–95 reports **1/1 suite, 10/10 tests passed**, no skipped totals, Nx integration success and **`command_exit=0`**.

Matched the case-declaration inventory only, without re-auditing bodies: five ordinary cases plus five `it.each` validation inputs equal ten; no skip/todo/only declarations. The ordinary case `returns only active passages local to the owned field with reverse target layers` is therefore included in the all-ten-passed targeted result, although the log does not list individual passing names. The injected `HTTP arrival failure`/PostgreSQL error is expected failure-path output, not a failed suite.

The supplied report records use of the existing disposable PostgreSQL 16/Testcontainers harness, committed migrations and `synchronize: false`; this retains the previously reviewed harness contract. The raw log records the env-unset invocation and PostgreSQL failure-path execution, but does not separately enumerate container lifecycle events. No reviewer database access occurred.

## Limits and stop

These hashes and records establish supplied-byte integrity, source-record matching and the stated execution results; they do not constitute independent forensic execution provenance or prove internal caches were cleared. Existing accepted frontend/types/lint/build evidence is retained, not rerun.

Read-only Git/hash/log/report checks only, plus this NEW ignored report. A preliminary declaration-count check omitted `it.each`; it was reconciled to five ordinary plus five parameterized cases, not treated as a test failure. Target confirmed absent and ignored before creation. No private transcripts, source/tracker edits, DB/gates/tests/build execution, agents, commit/merge/push or cleanup. **Stopped.**

# K5e documentation correction — 2026-11-11

## Candidate identity and scope
- Base: `1c59e45de662b1eae9f3ce098f57661e37b384dc`, tree `652a10a23763843cd29804cdc4d2c3f5543c78f4`.
- Original implementation: `15425192e03bdc9407cf031247f8a8b855d23312`, tree `a6f9132e4cc44a943b617206346dd398cc008a84`, parent is base.
- Original tracker follow-up: `db399f4d6283122b0119fa1b1751c387810ef61d`, tree `4291403d4a54473157cd97aa6863b1e513705f37`, parent is implementation.
- This follow-up changes only ADR-0008 and appends K5e issue evidence; it makes no executable-source or gameplay change. The final commit/tree are recorded in Git after commit.
- Status remains `ready-for-agent`; all eight criteria unchecked and review acceptance open. No resolution, push, merge, rebase, reset, or cleanup.

## Correction and validation
- Added a bounded “Bekanntwerden einer Ebene” section based on existing onboarding, owned-ship arrival, idempotent `markKnown`, and wormhole transaction behavior. It also states that map/sensor views and foreign-ship arrival do not grant knowledge.
- Original independent Spec report remains preserved at `.workmux/local-inputs/k5e-fast-spec-review-20261111.md`: **BLOCKED, one confirmed P2** for this omitted acquisition semantics. Independent Standards/security **PASS0** remains unchanged for its reviewed candidate; it was not rerun for the doc-only delta.
- RED/GREEN gate `tmw-k5e-docs-final-20261111-02` exited 0 in 0.605s (2026-11-11 11:03:47.936931–11:03:48.541984 UTC): both acquisition markers were absent at the original implementation baseline; six targeted assertions and Prettier passed with correction. Receipt/log preserved under `.workmux/gates/`.
- Runtime suites, PostgreSQL, application typechecks and builds were not rerun: executable source is unchanged. Previously recorded backend/frontend `tsc --noEmit` attempts failed with exit 2, including missing `packages/shared/dist/index.d.ts` (TS6305) and other diagnostics; no successful typecheck/build is claimed.

## Historical metadata clarification (append-only)
- Earlier issue evidence named implementation tree `6c7c87da07044e1dc0fb82373e54462f9d4d0bf2`; the exact implementation commit object instead has tree `a6f9132e4cc44a943b617206346dd398cc008a84`. The exact tracker pin remains `db399f4d6283122b0119fa1b1751c387810ef61d` / tree `4291403d4a54473157cd97aa6863b1e513705f37`.
- The earlier fast report's “No commit” statement and 24-line count are historical; the report is 25 lines and the original implementation/tracker commits exist. Neither historical report nor earlier issue comments were rewritten; corrections are recorded here and appended to the issue.
- Earlier candidate/review records, failures, gate logs, and reports are preserved. Await independent Spec re-review of this correction; do not resolve or integrate before it.

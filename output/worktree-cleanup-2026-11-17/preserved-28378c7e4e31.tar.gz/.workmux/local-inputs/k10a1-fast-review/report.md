# tmw-K10a1 candidate — 2026-11-11

- Base `b4a7a6fb8559fbd60ceab1afb0117f7ee3e20a81`, tree `ddc3d41f8535f7b0dc9d09a5617213fb151cd60f`.
- Candidate `7f5c7a6e5afe2dbf256cd7985692211b6f62a4a8`, tree `1751e1f0a2de05278bc4ac7a1d393b7531e2b564`, parent = base.
- Scope: generic type/entity/relations, handler registry, transactional main-tick lifecycle and expiry, migration and tests. No ellipse mechanics, navigation integration, UI, dependency or config edits.
- Status `ready-for-agent`; criteria remain unchecked; independent Standards/Security and Spec reviews pending. No push/merge/rebase/amend/reset/clean.

## RED → GREEN
- Model RED `k10a1-red-model-corrected`: exit 1, missing AnomalyType metadata; `k10a1-model-green` exit 0 (1/1).
- Main tick RED `k10a1-red-tick-corrected`: exit 1, lifecycle not invoked; `k10a1-tick-green` exit 0 (1/1).
- Parent expiry RED `k10a1-red-parent`: exit 1, stale child FK; `k10a1-parent-green` exit 0 (3/3).
- Initial `k10a1-red-model` exit 1 was a fixture duplicate-location error; initial `k10a1-red-tick` exit 1 lacked tick metadata. Corrected before meaningful RED.
- Parent RED intentionally selected one test; 1 other test skipped by selector; final gates have zero skips.

## Gates and receipts
Receipts and logs: `.workmux/gates/<name>.json` and `.log`, commands, actual exit, UTC timestamps, duration, source hashes and log SHA-256 therein. Wrapper removes ambient DB URLs and disables Nx daemon/cloud.
- `k10a1-final-lint`: exit 0, 15.000s; 0 errors, 1439 warnings.
- `k10a1-final-build`: exit 0, 14.007s; webpack success.
- `k10a1-final-test`: exit 0, 74.784s; 215 suites, 2008 tests, 1 snapshot passed; 0 skipped.
- `k10a1-final-pg`: exit 0, 12.409s; **targeted** PostgreSQL: 3 suites, 6 tests passed, 0 skipped. Not the full PG suite.
- `k10a1-final-typecheck`: exit 1, 17.453s; 1243 diagnostics including 977 TS6305.
- `k10a1-final-typecheck-sequential`: exit 1, 14.389s; same diagnostic counts.
- `k10a1-declarations`: exit 2, 5.826s; unused `ExplorationState`, `starmap-query.service.ts:24` (TS6133).
- `k10a1-final-typecheck-after-declarations`: exit 1, 11.738s; 1243 diagnostics including 977 TS6305.
- `k10a1-app-types-focused`: exit 1, 1.795s, invalid composite/incremental option.
- `k10a1-app-types-focused-corrected`: exit 0, 6.779s; app `tsc --noEmit --noUnusedLocals false`, not the canonical gate.
- `k10a1-declarations-focused`: exit 0, 9.533s; same relaxed option to emit test declarations.
- `k10a1-spec-types-focused`: exit 2, 6.890s; `layer-access-http.int-spec.ts:310` TS2769 and `:461` TS2571. No baseline comparison performed; do not claim full baseline equivalence.
- Lint warns on many existing files; tests include intentionally logged failure scenarios. `ts-jest` isolatedModules and `pg` concurrent query deprecations appeared. Build/test/PG no failures.
- Verifier at 13:21:42Z matched 13 changed source hashes, logs and exit 0 to candidate for lint/build/test/PG and focused app/declarations; point-in-time identity only, not independent provenance. Issue metadata excluded.

## Database and limitations
- Testcontainers `postgres:16-alpine`, disposable per integration run; actual migrations including `20261111100000-add-anomalies`, `synchronize: false`; fixture seed, no shared/dev database. Integration reset truncates only the disposable DB.
- Lifecycle test covers existing-before-creation, one-tick expiry, duplicate registration, failed main-tick retry and rollback, and parent/child expiry. Other effects/handler behavior await K10a2.
- No full PostgreSQL suite, frontend baseline, migration revert execution, external services, or independent reviews. Actual application boot against DB was not exercised; app-module graph is in the backend unit suite.
- Typecheck acceptance remains unmet. Handler side effects must use the transaction manager for retry atomicity; external side effects cannot roll back.

## UTC timing
- Base/reading 13:07–13:08; model RED→GREEN 13:08:57–13:10:36; tick RED→GREEN 13:11:16–13:12:57; parent RED→GREEN 13:13:21–13:14:02.
- Final gates 13:15:30–13:18:09; focused type diagnostics 13:18:48–13:21:04; candidate commit 13:21:34; evidence verification 13:21:42; handoff prepared thereafter.

# K10a1 concurrent tick correction — 2026-11-11

- Original base `b4a7a6fb8559fbd60ceab1afb0117f7ee3e20a81`; preserved candidate parent `7f5c7a6e5afe2dbf256cd7985692211b6f62a4a8`.
- Correction `94164aed9bc4b05aedbdc4f6b7ce2a27d337a1b9`, tree `e348a4f07d06e02fa38d474d86c6fc25de579897`, parent = candidate. Paths: `apps/backend/src/modules/anomaly/anomaly.service.ts`, `apps/backend/src/testing/integration/anomaly-tick.int-spec.ts`.
- Both independent axes reported the same P2 according to coordinator; their `.workmux/k10a1-fast-{standards,spec}-review-20261111.md` copies were not present in this worktree. No claim of reading those files. New independent correction reviews pending.

## Behavioral RED / GREEN
- `k10a1-correction-red-concurrency`: exit 1, 13:38:06–13:38:19 UTC, 12.504s; 2 failed / 3 passed / 0 skipped. Real parallel PG transactions: life 3 after two ticks was 2 instead of 1; life 1 ran two durable disappearance callbacks instead of one.
- `k10a1-correction-green-concurrency`: exit 0, 13:38:35–13:38:46, 11.128s; 5/5, 0 skipped.
- `k10a1-correction-creation-rollback`: exit 0, 13:39:19–13:39:31, 12.233s; 7/7, 0 skipped; additionally overlapping empty-set creation and rollback releasing a waiting tick, followed by failed-ID retry.
- Tests pause the first actual callback, start a distinct tick, observe a second callback or PostgreSQL lock wait, release the first, and inspect durable DB results. Disappearance records use the provided transaction manager. No mock lock and no ellipse behavior.

## Lock and boundaries
- PostgreSQL transaction-level advisory lock `hashtext('swu_anomaly_tick')` is acquired first inside the anomaly transaction, before idempotence marker, snapshot and all handlers/creation; matches existing auth advisory transaction-lock pattern. It serializes empty-set creation and distinct IDs as well as equal-ID retries. Processing is lock-acquisition order, not numeric tick order.
- Advisory lock is released on commit/rollback/connection termination; a waiting aborted statement does not retain it. PG rollback/waiter behavior is tested. The lock is not held across other main-tick work; existing tick graph has no enclosing DB transaction and no reverse acquisition of this key. This does **not** prove arbitrary future handlers cannot create cycles: handlers must use the supplied manager, avoid recursive anomaly tick entry and follow consistent ordering when acquiring other locks. External side effects are not transactional. Whole main tick is not atomic.

## Final gates (source identity verified at 13:43:24Z)
- Receipts/logs `.workmux/gates/<name>.{json,log}` preserve commands, exit, UTC timestamps, before/after hashes and log hashes; ambient DB URLs removed, Nx daemon/cloud off. Point-in-time verifier matched the 2 changed source paths, not independent provenance.
- `k10a1-correction-final-lint`: exit 0, 12.959s; 0 errors / 1439 warnings.
- `k10a1-correction-final-test-syncfixed`: exit 0, 56.959s; 215 suites, 2008 tests, 1 snapshot; 0 skips.
- `k10a1-correction-final-build-syncfixed`: exit 0, 8.544s; webpack success.
- `k10a1-correction-final-pg`: exit 0, 15.981s; **targeted** 3 suites, 10 tests, 0 skips; not full PG. Testcontainers disposable `postgres:16-alpine`, real migrations, `synchronize:false`, fixture seed; no shared DB.
- `k10a1-correction-strict-declarations`: exit 2, 6.981s, TS6133 unused `ExplorationState` in unchanged `starmap-query.service.ts:24`.
- `k10a1-correction-final-typecheck-syncfixed`: exit 1, 11.090s; 1250 diagnostics including TS6133, 977 TS6305 and 244 TS7006. New test contains 7 TS7006 at callbacks when anomaly declarations are unavailable; these cannot be conclusively distinguished from cascade without a valid strict declaration build. No relaxed green is asserted.
- Earlier candidate/base comparison `.workmux/tmw-K10a1-typecheck-investigation-20261111.md` established unchanged TS6133 and prepared-spec TS2769/TS2571 at `layer-access-http.int-spec.ts:310,461` on base; it predates correction and does not prove all new correction diagnostics baseline. Typecheck criterion remains open; coordinator authorization needed for unrelated baseline repair.
- First final Nx test/build/typecheck attempts exited 1 before execution: prior disposable base archive inside `.workmux/` was incorrectly detected as Nx projects. `nx sync:check` confirmed; moved that disposable copy to `/tmp/swu-k10a1-base-validation-63558` without deleting it, then ran the blocked gates once. Original receipts remain. No tracked config changed.
- Test/PG logs include existing ts-jest/pg deprecations and intentional error-path logs. No new dependencies, config/lock/map/decision/STU changes or external services.

## Handoff
- Started 13:37:19; meaningful RED 13:38:06; final source GREEN 13:39:31; final PG 13:40:46, final build 13:42:39; commit 13:43:16, verifier 13:43:24 UTC. Handoff under 10 minutes after final green.
- Issue evidence appended, uncommitted; `ready-for-agent`, checkboxes unchanged. Stop for two independent correction reviews. No integration, merge, push, rebase, amend, reset or cleanup.

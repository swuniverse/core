# tmw-K7a3 — final two-gate execution report

Date: 2026-11-10  
Worktree: `agent-tmw-k7a3`  
HEAD: `29ac20e249184b87789b0c7ca0494e549c1e7f10`  
Scope: the two authorized test executions only. No source, spec, tracker, configuration, migration, package, or permission changes were made. No files were staged or committed.

## Results

| Gate | Command | Result |
|---|---|---|
| Complete backend unit suite | `NX_DAEMON=false NX_NO_CLOUD=true npx nx test backend --skip-nx-cache` | Nx reported `Successfully ran target test for project backend and 1 task it depends on`; 214/214 suites, 1,996/1,996 tests, and 1/1 snapshot passed. Jest reported no skipped tests. The wrapper's numeric exit capture was blank; `command_exit=0` was appended based on Nx's successful target output, not captured from the process. The suite was not rerun. See `.workmux/k7a3-final-two-gates/backend-full-tests-clean.log`. |
| Targeted HTTP PostgreSQL integration spec | `env -u DATABASE_URL -u INTEGRATION_DATABASE_URL NX_DAEMON=false NX_NO_CLOUD=true npx nx run backend:test-integration --skip-nx-cache -- wormhole-passage-http.int-spec.ts` | Exit 0 captured by the wrapper. 1/1 suite, 10/10 tests passed; Jest reported no skipped tests. Nx reported the integration target succeeded. See `.workmux/k7a3-final-two-gates/wormhole-http-postgres.log`. |

The integration log includes the expected injected `HTTP arrival failure` error from the failure-path test; Jest completed successfully with all 10 tests passing. This is test output, not a suite failure.

## Database isolation and cache

The HTTP spec was invoked with both `DATABASE_URL` and `INTEGRATION_DATABASE_URL` removed from the child process environment, and with `NX_DAEMON=false NX_NO_CLOUD=true`. The integration runner's documented global setup therefore owned the disposable PostgreSQL 16 Testcontainers database (`postgres:16-alpine`) for this run; it uses the repository's committed migrations with schema synchronization disabled and tears down its container afterward. No shared/development database, external service, environment dump, or credential-value inspection was used. Both Nx invocations used `--skip-nx-cache`.

## Source identity

The before-run inventory is `.workmux/k7a3-final-two-gates/source-hashes-before.txt` (16 changed paths, HEAD above). After both runs, SHA-256 was recomputed for the same 16 paths. Every after-run digest matched its before-run digest; the working-tree source/spec/tracker contents remained unchanged.

| SHA-256 (identical before and after) | Path |
|---|---|
| `23ca12a0e7c7650bbfe4f8740fc896b2ca4433fc5a2129f4bf673cb5ee5ee2cf` | `.scratch/stu-parity/issues/tmw-K7a-wurmloch-betreten-und-verlassen.md` |
| `9f9eff44aef6363bde19cb49f06b1eb649c630803b893dc4902414fd455ffd83` | `.scratch/stu-parity/issues/tmw-K7a3-wurmloch-frontend-und-oberflaeche.md` |
| `4599a3a69cd2f0b19bd69ba1c0049811b6017bfd92dc183085e23cec7b325b3e` | `apps/backend/src/modules/spacecraft/spacecraft.service.ts` |
| `46340601545eeddd4c944a084bba5c101f972a08371adaa6372f5e42487ce649` | `apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts` |
| `a76c5f6a797aa0923c014a586ce681564a8dbb8c5735452fcf7f54d89a5f5af8` | `apps/backend/src/modules/starmap/wormhole.service.ts` |
| `5adfd0bd1988fd1148f414660ba3e231a157e5e31c65f6baec952ec5eba4eff8` | `apps/backend/src/modules/starmap/wormhole.service.spec.ts` |
| `818883e6229a50df4ea9731f653013583db4eca82bdfc68604ae27ec6f0bfd98` | `apps/frontend/src/components/spacecraft/FieldContextPanel.spec.tsx` |
| `ee82286fc06d611eb6600607499fa38368035c1d8887a6b69f5be94f8d279519` | `apps/frontend/src/components/spacecraft/FieldContextPanel.tsx` |
| `660e6b70062b93d74cdd5a301574fc2567f24312c1c3159fdd12cd80a622deee` | `apps/frontend/src/components/spacecraft/ship-action-registry.spec.ts` |
| `213bba45ae59375ece1bd0d4279a4183d3eb76ee21f990349cc197f4bab564c7` | `apps/frontend/src/components/spacecraft/ship-action-registry.ts` |
| `9bc4d2e74f1b2d3c634f5562d1e8990c790e5c112fe0746c941a0f6d315a45b4` | `apps/frontend/src/components/starmap/StarmapCanvas.spec.tsx` |
| `6f72badc844d20739128597e3d81e35f619407e244b94c7b35fb0fccf3630700` | `apps/frontend/src/components/starmap/StarmapCanvas.tsx` |
| `6ec54188be8b73fcb360a83b7c1e88b6dc9f1416a5797df5a660a8993ea76259` | `apps/frontend/src/pages/spacecraft-detail.spec.tsx` |
| `3a9a60d5107da27d4687fd94d06921576c5b82ddea245830eef517a14ee1cb44` | `apps/frontend/src/pages/starmap.spec.tsx` |
| `2c60239d065533fe3c4d9bdd3eb82719ab93419d4f1b10c210a1277ae59b9ecd` | `apps/frontend/src/pages/starmap.tsx` |
| `1b25f68965b91ed2ea145a77b93e406d749c27979899316cd00b8ca0bd97de73` | `packages/shared/src/lib/spacecraft/index.ts` |

## Log fingerprints

| SHA-256 | Log |
|---|---|
| `d88c7eb4e3d8bb84d8205d36f17a1a6bb32780fcb145bee30291de94442bd039` | `.workmux/k7a3-final-two-gates/backend-full-tests-clean.log` |
| `ba83c21476ef98c346c83aaf96f8ec27add127e074c95870a3914f388e0630ba` | `.workmux/k7a3-final-two-gates/wormhole-http-postgres.log` |

The existing draft and checklists remain unchanged and incomplete pending coordinator acceptance. No further gate, integration phase, or tracker update was performed; stopping for evidence closure and narrow re-review.

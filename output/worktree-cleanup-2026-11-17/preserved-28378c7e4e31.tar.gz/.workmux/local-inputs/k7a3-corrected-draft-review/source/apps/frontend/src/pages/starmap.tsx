import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  WsEventType,
  type HyperspaceRouteDto,
  type StarmapExportDto,
  type StarmapGalaxyFieldDto,
  type StarmapLayerDto,
  type StarmapSystemGridDto,
  type StarmapSystemListItemDto,
  type StarmapContactsDto,
  type StarmapInfluenceAreaDto,
  type StarmapWormholeDto,
} from '@swuniverse/shared';
import { api } from '../services/api';
import { useSocket } from '../hooks/use-socket';
import { StarmapCanvas, type StarmapCanvasHandle } from '../components/starmap/StarmapCanvas';
import {
  StarmapControlPanel,
  type StarmapOverlays,
} from '../components/starmap/StarmapControlPanel';
import {
  StarmapShipOverlay,
  bundleStarmapContacts,
  type StarmapOpenSystemGrid,
} from '../components/starmap/StarmapShipOverlay';
import { StarmapContactPanel } from '../components/starmap/StarmapContactPanel';
import { canLoadInlineSystem } from '../lib/starmap-render';
import { createStarmapPng, downloadStarmapBlob } from '../lib/starmap-export';

type Layer = Pick<
  StarmapLayerDto,
  'id' | 'name' | 'width' | 'height' | 'sectorSize'
>;
type GalaxyField = StarmapGalaxyFieldDto;
type StarSystem = StarmapSystemListItemDto;
type SystemGrid = StarmapSystemGridDto;
type HyperspaceRoute = HyperspaceRouteDto;

/** Ship contacts are refreshed in this interval while the page is visible. */
const CONTACT_REFRESH_MS = 30_000;
const OVERLAY_STORAGE_KEY = 'swu-starmap-overlays';

const DEFAULT_OVERLAYS: StarmapOverlays = {
  territory: false,
  impassable: false,
  fieldEffects: false,
  sensorCoverage: false,
};

function loadOverlays(): StarmapOverlays {
  try {
    return { ...DEFAULT_OVERLAYS, ...JSON.parse(localStorage.getItem(OVERLAY_STORAGE_KEY) ?? '{}') };
  } catch {
    return DEFAULT_OVERLAYS;
  }
}

type StarmapUrlTarget = {
  layerId: number;
  x: number;
  y: number;
};

function parseStarmapUrlTarget(searchParams: URLSearchParams): StarmapUrlTarget | null {
  const layerId = Number(searchParams.get('layer'));
  const x = Number(searchParams.get('x'));
  const y = Number(searchParams.get('y'));
  return [layerId, x, y].every(Number.isSafeInteger) && layerId > 0 && x > 0 && y > 0
    ? { layerId, x, y }
    : null;
}

export function StarmapPage() {
  const [searchParams] = useSearchParams();
  const urlTarget = parseStarmapUrlTarget(searchParams);
  const [layers, setLayers] = useState<Layer[]>([]);
  const [selectedLayer, setSelectedLayer] = useState<Layer | null>(null);
  const [fields, setFields] = useState<GalaxyField[]>([]);
  const [hyperspaceRoutes, setHyperspaceRoutes] = useState<HyperspaceRoute[]>([]);
  const [hiddenRouteIds, setHiddenRouteIds] = useState<number[]>([]);
  const [selectedSystem, setSelectedSystem] = useState<StarSystem | null>(null);
  const [systemGrids, setSystemGrids] = useState<Map<number, SystemGrid>>(() => new Map());
  const [openedSystemIds, setOpenedSystemIds] = useState<number[]>([]);
  const [wormholes, setWormholes] = useState<StarmapWormholeDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const exportCacheRef = useRef<{ data: StarmapExportDto; loadedAt: number } | null>(null);
  const exportBusyRef = useRef(false);
  const [selectedField, setSelectedField] = useState<GalaxyField | null>(null);
  const [selectedSector, setSelectedSector] = useState<{ x: number; y: number } | null>(null);
  const [showGrid, setShowGrid] = useState(true);
  const [contacts, setContacts] = useState<StarmapContactsDto | null>(null);
  const [showShips, setShowShips] = useState(true);
  const [showAllianceShips, setShowAllianceShips] = useState(true);
  const [showPartnerShips, setShowPartnerShips] = useState(true);
  const [overlays, setOverlays] = useState<StarmapOverlays>(loadOverlays);
  const [influence, setInfluence] = useState<StarmapInfluenceAreaDto[]>([]);
  const [selectedContactKey, setSelectedContactKey] = useState<string | null>(null);
  const [inlineSystemsVisible, setInlineSystemsVisible] = useState(false);
  const contactLayerIdRef = useRef<number | null>(null);
  const canvasRef = useRef<StarmapCanvasHandle>(null);
  const systemGridsRef = useRef<Map<number, SystemGrid>>(new Map());
  const openingSystemsRef = useRef<Map<number, Promise<SystemGrid>>>(new Map());
  const openedSystemIdsRef = useRef<number[]>([]);

  useEffect(() => {
    api.get<Layer[]>('/starmap/layers').then(async (data) => {
      setLayers(data);
      const layer =
        data.find((entry) => entry.id === urlTarget?.layerId) ?? data[0];
      if (layer) {
        setSelectedLayer(layer);
        const [loadedFields, loadedRoutes, loadedWormholes] = await Promise.all([
          api.get<GalaxyField[]>(`/starmap/layers/${layer.id}/fields`),
          api.get<HyperspaceRoute[]>(`/starmap/layers/${layer.id}/hyperspace-routes`),
          api.get<StarmapWormholeDto[]>(`/starmap/layers/${layer.id}/wormholes`),
        ]);
        setFields(loadedFields);
        setHyperspaceRoutes(loadedRoutes);
        setWormholes(loadedWormholes);
        const targetField =
          urlTarget?.layerId === layer.id
            ? loadedFields.find(
                (field) => field.cx === urlTarget.x && field.cy === urlTarget.y,
              ) ?? null
            : null;
        setSelectedField(targetField);
        setSelectedSystem(targetField?.starSystem ?? null);
      }
      setLoading(false);
    });
  }, [urlTarget?.layerId, urlTarget?.x, urlTarget?.y]);

  async function selectLayer(layer: Layer) {
    setSelectedLayer(layer);
    setSelectedSystem(null);
    systemGridsRef.current = new Map();
    openingSystemsRef.current.clear();
    setSystemGrids(new Map());
    openedSystemIdsRef.current = [];
    setOpenedSystemIds([]);
    setLoading(true);
    const [loadedFields, loadedRoutes, loadedWormholes] = await Promise.all([
      api.get<GalaxyField[]>(`/starmap/layers/${layer.id}/fields`),
      api.get<HyperspaceRoute[]>(`/starmap/layers/${layer.id}/hyperspace-routes`),
      api.get<StarmapWormholeDto[]>(`/starmap/layers/${layer.id}/wormholes`),
    ]);
    setFields(loadedFields);
    setHyperspaceRoutes(loadedRoutes);
    setWormholes(loadedWormholes);
    setLoading(false);
  }

  const selectedLayerId = selectedLayer?.id ?? null;

  const loadContacts = useCallback(async () => {
    const layerId = contactLayerIdRef.current;
    if (layerId === null) return;
    try {
      const loaded = await api.get<StarmapContactsDto>(
        `/spacecraft/starmap-contacts?layerId=${layerId}`,
      );
      // Ignore answers for a layer that is no longer displayed.
      if (contactLayerIdRef.current === layerId) setContacts(loaded);
    } catch {
      // Keep the last known contacts; the next refresh retries.
    }
  }, []);

  useEffect(() => {
    contactLayerIdRef.current = selectedLayerId;
    setContacts(null);
    setSelectedContactKey(null);
    if (selectedLayerId === null) return undefined;
    void loadContacts();
    const interval = window.setInterval(() => {
      if (document.visibilityState === 'visible') void loadContacts();
    }, CONTACT_REFRESH_MS);
    return () => window.clearInterval(interval);
  }, [loadContacts, selectedLayerId]);

  useSocket(WsEventType.SHIP_MOVED, () => void loadContacts());
  useSocket(WsEventType.SPACECRAFT_EVENT, () => void loadContacts());

  const loadInfluence = useCallback(async () => {
    if (!selectedLayer || !overlays.territory) {
      setInfluence([]);
      return;
    }
    const sectorColumns = Math.ceil(selectedLayer.width / selectedLayer.sectorSize);
    const sectorRows = Math.ceil(selectedLayer.height / selectedLayer.sectorSize);
    const sectors = Array.from(
      { length: sectorColumns * sectorRows },
      (_, index) => ({ x: index % sectorColumns, y: Math.floor(index / sectorColumns) }),
    );
    const loaded = await Promise.all(
      sectors.map(({ x, y }) =>
        api.get<StarmapInfluenceAreaDto[]>(
          `/starmap/layers/${selectedLayer.id}/influence/${x}/${y}`,
        ),
      ),
    );
    setInfluence(loaded.flat());
  }, [overlays.territory, selectedLayer]);

  useEffect(() => {
    void loadInfluence();
  }, [loadInfluence]);

  // While the zoom shows the system grids, ships in an opened system sit at
  // their system position; otherwise they stay bundled at the system cell.
  const openSystemGrids = useMemo(() => {
    const open = new Map<number, StarmapOpenSystemGrid>();
    if (!inlineSystemsVisible) return open;
    for (const systemId of openedSystemIds) {
      const grid = systemGrids.get(systemId);
      const anchor = fields.find((field) => field.starSystem?.id === systemId)?.starSystem;
      if (grid && anchor) open.set(systemId, { grid, anchor });
    }
    return open;
  }, [fields, inlineSystemsVisible, openedSystemIds, systemGrids]);
  const contactBundles = useMemo(
    () =>
      bundleStarmapContacts(
        (contacts?.contacts ?? []).filter(
          (contact) =>
            (contact.reason !== 'ALLIANCE' || showAllianceShips) &&
            (contact.reason !== 'SHARED_LIVE_POSITION' || showPartnerShips),
        ),
        openSystemGrids,
      ),
    [contacts, openSystemGrids, showAllianceShips, showPartnerShips],
  );
  const isAllianceMember = contacts?.viewerAlliance != null;
  const selectedContactBundle =
    contactBundles.find((bundle) => bundle.key === selectedContactKey) ?? null;
  const systemName = useCallback(
    (systemId: number) =>
      fields.find((field) => field.starSystem?.id === systemId)?.starSystem?.name ?? null,
    [fields],
  );

  function selectSystem(system: StarSystem) {
    setSelectedSystem(system);
  }

  const markSystemOpened = useCallback((systemId: number) => {
    if (openedSystemIdsRef.current.includes(systemId)) return;
    const openedIds = [...openedSystemIdsRef.current, systemId];
    openedSystemIdsRef.current = openedIds;
    setOpenedSystemIds(openedIds);
  }, []);

  const openSystem = useCallback(async (system: StarSystem): Promise<SystemGrid | null> => {
    if (!canLoadInlineSystem(system)) return null;
    setSelectedSystem(system);
    const cached = systemGridsRef.current.get(system.id);
    if (cached) {
      // Alle Systeme werden bereits im Hintergrund vorab geladen (siehe
      // useEffect unten) - ohne dieses markSystemOpened() blieb ein Klick auf
      // "Systemfelder laden" wirkungslos, sobald die Grid-Daten schon im
      // Cache lagen: renderInlineSystems() rendert nur, was in
      // openedSystemIds steht, das wurde hier aber nie gesetzt.
      markSystemOpened(system.id);
      return cached;
    }
    const pending = openingSystemsRef.current.get(system.id);
    if (pending) return pending;
    const request = api.get<SystemGrid>(`/starmap/systems/${system.id}/grid`);
    openingSystemsRef.current.set(system.id, request);
    try {
      const grid = await request;
      const grids = new Map(systemGridsRef.current).set(system.id, grid);
      systemGridsRef.current = grids;
      setSystemGrids(grids);
      markSystemOpened(system.id);
      return grid;
    } finally {
      openingSystemsRef.current.delete(system.id);
    }
  }, [markSystemOpened]);

  useEffect(() => {
    const systems = Array.from(
      new Map(
        fields
          .map((field) => field.starSystem)
          .filter((system): system is StarSystem => !!system && canLoadInlineSystem(system))
          .map((system) => [system.id, system]),
      ).values(),
    );
    if (systems.length === 0) return;
    let cancelled = false;
    void Promise.all(
      systems.map(async (system) => {
        const cached = systemGridsRef.current.get(system.id);
        if (cached) return [system.id, cached] as const;
        return [system.id, await api.get<SystemGrid>(`/starmap/systems/${system.id}/grid`)] as const;
      }),
    ).then((loadedGrids) => {
      if (cancelled) return;
      const grids = new Map(loadedGrids);
      systemGridsRef.current = grids;
      setSystemGrids(grids);
      const ids = systems.map((system) => system.id);
      openedSystemIdsRef.current = ids;
      setOpenedSystemIds(ids);
    });
    return () => {
      cancelled = true;
    };
  }, [fields]);


  async function exportMap(format: 'json' | 'png') {
    if (!selectedLayer || exportBusyRef.current) return;
    exportBusyRef.current = true;
    setExporting(true);
    setExportError(null);
    try {
      const cached = exportCacheRef.current;
      const data = cached?.data.layer.id === selectedLayer.id && Date.now() - cached.loadedAt < 60_000
        ? cached.data
        : await api.get<StarmapExportDto>(`/starmap/layers/${selectedLayer.id}/export.json`);
      if (data !== cached?.data) exportCacheRef.current = { data, loadedAt: Date.now() };
      const blob = format === 'png'
        ? await createStarmapPng(data)
        : new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      downloadStarmapBlob(blob, `starmap-${data.layer.id}.${format}`);
    } catch (error) {
      setExportError(error instanceof Error ? error.message : 'Kartenexport fehlgeschlagen.');
    } finally {
      exportBusyRef.current = false;
      setExporting(false);
    }
  }

  async function refreshData() {
    if (!selectedLayer) return;
    const [loadedFields, loadedRoutes, loadedWormholes] = await Promise.all([
      api.get<GalaxyField[]>(`/starmap/layers/${selectedLayer.id}/fields`),
      api.get<HyperspaceRoute[]>(`/starmap/layers/${selectedLayer.id}/hyperspace-routes`),
      api.get<StarmapWormholeDto[]>(`/starmap/layers/${selectedLayer.id}/wormholes`),
      loadContacts(),
      loadInfluence(),
    ]);
    setFields(loadedFields);
    setHyperspaceRoutes(loadedRoutes);
    setWormholes(loadedWormholes);
  }


  const visibleHyperspaceRoutes = useMemo(
    () => hyperspaceRoutes.filter((route) => !hiddenRouteIds.includes(route.id)),
    [hiddenRouteIds, hyperspaceRoutes],
  );

  if (loading) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-swu-primary" style={{ fontFamily: 'var(--font-swu-display)' }}>Starmap</h1>
        <p className="mt-4 text-swu-muted">Lade Karte...</p>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100svh-60px)] flex-col p-4 gap-3">
      {/* Header toolbar */}
      <div className="flex items-center gap-2 shrink-0" data-tutorial="map-layer">
        {layers.length > 1 ? (
          <select
            aria-label="Kartenebene"
            className="bg-swu-bg border border-swu-border text-swu-primary text-xs rounded px-2 py-1"
            value={selectedLayer?.id ?? ''}
            onChange={(e) => {
              const layer = layers.find((l) => l.id === Number(e.target.value));
              if (layer) void selectLayer(layer);
            }}
          >
            {layers.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        ) : selectedLayer ? (
          <span className="text-xs text-swu-muted border border-swu-border rounded px-2 py-1">{selectedLayer.name}</span>
        ) : null}
        <button
          className="text-xs text-swu-primary border border-swu-border rounded px-2 py-1 hover:bg-swu-accent/10"
          onClick={() => void refreshData()}
        >
          Aktualisieren
        </button>
        <button
          className="text-xs text-swu-primary border border-swu-border rounded px-2 py-1 hover:bg-swu-accent/10"
          onClick={() => canvasRef.current?.fitView(fields)}
        >
          Einpassen
        </button>
      </div>

      {/* Main */}
      <div className="flex flex-1 min-h-0 gap-3">
        <div className="flex-1 min-w-0">
          {selectedLayer && (
            <StarmapCanvas
              ref={canvasRef}
              layer={selectedLayer}
              fields={fields}
              routes={visibleHyperspaceRoutes}
              selectedSystem={selectedSystem}
              openedSystemIds={openedSystemIds}
              systemGrids={systemGrids}
              onSelectSystem={selectSystem}
              onOpenSystem={openSystem}
              wormholes={wormholes}
              onFieldClick={setSelectedField}
              selectedField={selectedField}
              focusField={urlTarget ? { cx: urlTarget.x, cy: urlTarget.y } : null}
              selectedSector={selectedSector}
              showGrid={showGrid}
              showTerritory={overlays.territory}
              influence={influence}
              contacts={contacts?.contacts ?? []}
              showImpassable={overlays.impassable}
              showFieldEffects={overlays.fieldEffects}
              showSensorCoverage={overlays.sensorCoverage}
              onInlineSystemsVisibleChange={setInlineSystemsVisible}
              worldOverlay={
                showShips ? (
                  <StarmapShipOverlay
                    bundles={contactBundles}
                    selectedKey={selectedContactKey}
                    onSelect={(bundle) => setSelectedContactKey(bundle.key)}
                  />
                ) : null
              }
            />
          )}
        </div>

        {/* Side panel */}
        <aside className="w-64 shrink-0 space-y-3 overflow-y-auto">
          {selectedLayer && (
            <StarmapControlPanel
              layer={selectedLayer}
              showGrid={showGrid}
              onToggleGrid={setShowGrid}
              onExportData={() => void exportMap('json')}
              onExportImage={() => void exportMap('png')}
              exporting={exporting}
              exportError={exportError}
              showShips={showShips}
              onToggleShips={(value) => {
                setShowShips(value);
                if (!value) setSelectedContactKey(null);
              }}
              overlays={overlays}
              onToggleOverlay={(overlay, value) => {
                setOverlays((current) => {
                  const next = { ...current, [overlay]: value };
                  localStorage.setItem(OVERLAY_STORAGE_KEY, JSON.stringify(next));
                  return next;
                });
              }}
              // Alliance and partner ships only exist for alliance members.
              allianceShips={
                isAllianceMember ? { visible: showAllianceShips, onToggle: setShowAllianceShips } : undefined
              }
              partnerShips={
                isAllianceMember ? { visible: showPartnerShips, onToggle: setShowPartnerShips } : undefined
              }
              selectedSector={selectedSector}
              onSelectSector={setSelectedSector}
              onZoomIn={() => canvasRef.current?.zoomIn()}
              onZoomOut={() => canvasRef.current?.zoomOut()}
              selectedField={selectedField}
              selectedSystem={selectedSystem}
              onOpenSystem={() => selectedSystem && void openSystem(selectedSystem)}
            />
          )}
          {showShips && selectedContactBundle && (
            <StarmapContactPanel
              bundle={selectedContactBundle}
              systemName={systemName}
              onClose={() => setSelectedContactKey(null)}
            />
          )}
          <section data-tutorial="map-legend" className="rounded-lg border border-swu-border bg-swu-surface p-3">
            <h4 className="mb-2 text-xs font-bold text-swu-muted">Legende</h4>
            <ul className="space-y-1 text-xs text-swu-muted">
              <li><span aria-hidden="true" className="mr-2 text-swu-primary">✦</span>Sternensystem</li>
              <li><span aria-hidden="true" className="mr-2 text-swu-primary">◆</span>Schiff</li>
              <li><span aria-hidden="true" className="mr-2 text-swu-primary">━</span>Hyperraumroute</li>
            </ul>
          </section>
          {/* Hyperspace routes */}
          {hyperspaceRoutes.length > 0 && (
            <div className="rounded-lg border border-swu-border bg-swu-surface p-3">
              <h4 className="text-xs font-bold text-swu-muted mb-2">Hyperrouten</h4>
              <div className="space-y-1">
                {hyperspaceRoutes.map((route) => (
                  <label key={route.id} className="flex items-center gap-2 text-xs text-swu-muted">
                    <input
                      type="checkbox"
                      checked={!hiddenRouteIds.includes(route.id)}
                      onChange={(e) => {
                        setHiddenRouteIds((ids) =>
                          e.target.checked
                            ? ids.filter((id) => id !== route.id)
                            : [...ids, route.id],
                        );
                      }}
                    />
                    <span className="inline-block h-2 w-4 rounded-full" style={{ backgroundColor: route.color }} />
                    <span>{route.name}</span>
                  </label>
                ))}
              </div>
            </div>
          )}


        </aside>
      </div>

      {layers.length === 0 && <p className="text-swu-muted">Galaxy not seeded.</p>}
    </div>
  );
}

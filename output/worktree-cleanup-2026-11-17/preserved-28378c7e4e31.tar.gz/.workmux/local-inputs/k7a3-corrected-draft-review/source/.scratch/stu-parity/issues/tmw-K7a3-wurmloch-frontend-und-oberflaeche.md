# Wurmlochpassage: Frontend und Oberflächenverträge

**Status:** ready-for-agent
**Priority:** P2
**Size:** S
**Blocked by:** tmw-K7a2

## Ziel

Macht Wurmlochpassagen in den passenden Spieleroberflächen auffindbar und nutzbar. Das Backend- und Flottenverhalten aus `tmw-K7a1`/`tmw-K7a2` wird über stabile Shared-DTOs und Endpunkte abgebildet.

## STU-Quellen

- `src/Module/Spacecraft/View/ShowWormholeControl/*`
- `src/html/spacecraft/wormholecontrol.twig`

## SWU-Pfade

- `packages/shared/src/lib/spacecraft/`
- `apps/frontend/src/components/spacecraft/FieldContextPanel.tsx`
- `apps/frontend/src/components/spacecraft/ShipQuickActions.tsx`
- `apps/frontend/src/components/spacecraft/ship-action-registry.ts`
- `apps/frontend/src/components/starmap/StarmapCanvas.tsx`

## Akzeptanzkriterien

- [x] Shared-Verträge repräsentieren verfügbare aktive Wurmlochpassagen einschließlich Name und Zielebene, ohne interne Backend-Details offenzulegen.
- [x] Feldkontext beziehungsweise Schnellaktionen bieten auf einem Wurmlochfeld „Wurmloch betreten“ mit passendem Namen und Ziel.
- [x] Nach erfolgreicher Passage aktualisieren sich Schiffsdetail und Karte auf die vom Backend bestätigte Position; Fehler werden verständlich angezeigt.
- [x] Frontend-Tests decken Sichtbarkeit nur am passenden Ort, mehrere Ausgänge, API-Aufruf und Zustandsaktualisierung ab.
- [x] `lint`, `typecheck`, `test` und `build` sind grün.

## Entscheidung

Frontend folgt den stabilen Backend-Verträgen aus `tmw-K7a1`/`tmw-K7a2`; keine eigene Bewegungs- oder Validierungslogik.

## Comments

- 2026-11-06: Aus `tmw-K7a` als letzter geordneter Teilauftrag extrahiert; blockiert durch `tmw-K7a2`.
- 2026-11-10: Shared-/Frontend-Implementierung und Frontend-Gates abgeschlossen; Backend-Projektionseinheitstest 3/3 grün. Der neue PostgreSQL-HTTP-Test für die Feldkontext-Projektion wurde nicht ausgeführt: die erlaubte Bestätigung, dass `DATABASE_URL` und `INTEGRATION_DATABASE_URL` beide unset sind, wurde vom Auto-Mode-Classifier für `env | grep -E '^(DATABASE_URL|INTEGRATION_DATABASE_URL)=' || true` abgelehnt, weil der Befehl Werte mit Zugangsdaten ausgeben könnte. Keine Umgehung, kein Test gegen eine andere Datenbank. Implementierungskriterien sind markiert; diesen HTTP-Nachweis sowie unabhängigen Sol Standards+Spec-Review und serielle Integration vor Abschluss nachholen. Backend-Typecheck, -Build und -Lint liefen grün; vollständige Backend-/PostgreSQL-Suite für K7a3 nicht erneut ausgeführt.

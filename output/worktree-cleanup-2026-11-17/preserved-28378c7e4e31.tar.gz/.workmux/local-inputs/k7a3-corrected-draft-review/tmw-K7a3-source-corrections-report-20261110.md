# tmw-K7a3 — bounded source corrections report

Date: 2026-11-10  
Worktree: `agent-tmw-k7a3`  
HEAD: `29ac20e249184b87789b0c7ca0494e549c1e7f10` (unchanged; all work remains uncommitted and unstaged)

## Scope

Only the two independently reported P2 frontend behavior corrections were made on top of the existing K7a3 draft. No K7a1/K7a2 or migration audit was repeated. Existing draft scope and prior reports were preserved. No tracker, package/lockfile, Nx config, map config, DECISIONS/STU, other checkout, or integration-test source edits were made as part of these corrections. The HTTP-PG spec remains unexecuted.

## P2 1 — initialization must finish on confirmed arrival focus

The actual `StarmapCanvas` test holds Pixi initialization, releases it to begin `renderGalaxy`, then holds the two production asset loads while focus is applied. After releasing both loads, it asserts the actual world-overlay viewport stays at the destination zoom/translation instead of the full-layer fit.

- Behavioral RED on pre-fix source: `npx nx test frontend --skip-nx-cache -- StarmapCanvas.spec.tsx` — exit 1; 1 test failed because final transform was `translate(134px, 34px) scale(0.222)` rather than the confirmed destination focus. Log: `.workmux/k7a3-corrected-final-evidence/canvas-focus-behavior-red2.log`.
- Fix: `StarmapCanvas` reads the current `focusField` from a ref after async galaxy rendering completes; when set, initialization reapplies the same bounded arrival zoom/centering calculation rather than calling whole-layer `fitView()`. With no arrival target, existing full-map fit behavior is unchanged.
- GREEN: focused test passes (1/1); final combined focused regressions pass 2 files / 7 tests. Logs: `canvas-focus-green3.log` and `focused-regressions-final.log`.

## P2 2 — keep successful-passage position feedback visible without context

A production `SpacecraftDetailPage` regression follows the passage UI: initial ship and origin field context succeed; POST succeeds; parent ship refresh returns the destination; destination field-context fetch rejects; canonical `cache: 'no-store'` ship read rejects. It asserts the alert says passage completed but canonical position could not be loaded, does not claim passage failure, and navigation remains `/spacecraft/2` (no optimistic map destination).

- Behavioral RED on pre-fix source: `npx nx test frontend --skip-nx-cache -- spacecraft-detail.spec.tsx` — exit 1; 1 test failed because `role="alert"` was absent after the verified POST, destination refresh and context failure. Log: `.workmux/k7a3-corrected-final-evidence/passage-feedback-red-final.log`.
- Fix: `FieldContextPanel` renders its stored error in the same alert when context is null; it still returns null if neither context nor an error exists. Normal context rendering and POST-failure behavior remain in the existing branch.
- GREEN: detail page tests pass (6/6); combined focused regression passes 2 files / 7 tests. Logs: `passage-feedback-green2.log` and `focused-regressions-final.log`.

## Final non-database gates

All final gates below ran after the last source changes. Each Nx command used `--skip-nx-cache`; the two spec-inclusive TypeScript builds used `--force` to rebuild referenced projects rather than trust incremental outputs. Nx may still invoke shared build dependencies as part of targets, but Nx task cache was bypassed.

| Gate | Exact command | Result | Evidence |
|---|---|---|---|
| Frontend full tests | `npx nx test frontend --skip-nx-cache` | Exit 0; 93 files, 663 tests passed; no skips reported | `frontend-full-tests-final.log` |
| Frontend lint | `npx nx run frontend:lint --skip-nx-cache` | Exit 0; 0 errors, 110 warnings | `frontend-lint-final.log` |
| Frontend production typecheck | `npx nx run frontend:typecheck --skip-nx-cache` | Exit 0; frontend plus shared | `frontend-typecheck-final.log` |
| Frontend spec-inclusive TypeScript | `npx tsc --build apps/frontend/tsconfig.spec.json --force --pretty false` | Exit 0; includes specs and app reference | `frontend-spec-types-final.log` |
| Frontend build | `npx nx run frontend:build --skip-nx-cache` | Exit 0; Vite built 1104 modules. Existing CSS `@import` order and large-chunk warnings | `frontend-build-final.log` |
| Backend full unit suite | `npx nx test backend --skip-nx-cache` | Nx target exit 0; 214 suites, 1996 tests, 1 snapshot passed | `backend-full-tests.log` |
| Backend spec-inclusive TypeScript | `npx tsc --build apps/backend/tsconfig.spec.json --force --pretty false` | Exit 0; includes `.spec.ts` and `.int-spec.ts` sources | `backend-spec-types-final.log` |
| Backend lint | `npx nx run backend:lint --skip-nx-cache` | Exit 0; 0 errors, 1438 warnings | `backend-lint-final.log` |
| Backend build | `npx nx run backend:build --skip-nx-cache` | Exit 0; webpack compiled successfully | `backend-build-final.log` |
| Whitespace check | `git diff --check` | Exit 0 | `diff-check.log` |

The first complete frontend suite passed 93/663 but its outer zsh wrapper attempted to assign zsh's reserved `status` variable after Nx had already returned success. That wrapper caveat is retained in `frontend-full-tests.log`; the final clean full frontend run is independently recorded as exit 0 in `frontend-full-tests-final.log`. Similarly, the first full backend unit run's Nx target succeeded (214/1996/1) but the wrapper's reserved-variable suffix left an empty exit annotation; final Nx output and the explicit result are preserved in `backend-full-tests.log`. No test output was copied from prior session transcripts/tool results.

## Source fingerprints

SHA-256 for the corrected sources/tests:

```text
6f72badc844d20739128597e3d81e35f619407e244b94c7b35fb0fccf3630700  apps/frontend/src/components/starmap/StarmapCanvas.tsx
9bc4d2e74f1b2d3c634f5562d1e8990c790e5c112fe0746c941a0f6d315a45b4  apps/frontend/src/components/starmap/StarmapCanvas.spec.tsx
ee82286fc06d611eb6600607499fa38368035c1d8887a6b69f5be94f8d279519  apps/frontend/src/components/spacecraft/FieldContextPanel.tsx
6ec54188be8b73fcb360a83b7c1e88b6dc9f1416a5797df5a660a8993ea76259  apps/frontend/src/pages/spacecraft-detail.spec.tsx
```

Full hash record: `.workmux/k7a3-corrected-final-evidence/correction-source-hashes.sha256`. HEAD and final `git status --short` / diff stat are recorded in `head.txt`, `status.txt`, and `diff-stat.txt`. The pre-existing K7a3 draft files remain modified/untracked as before; no stage or commit was made.

## Explicit outstanding hold

The new `wormhole-passage-http.int-spec.ts` PostgreSQL test remains **not run**. No database invocation, environment dump, DB URL presence/value check, or alternate permission path was used, per instruction. It remains an explicit permission/evidence hold; no HTTP-PG pass is claimed. K7a3 remains `ready-for-agent` / incomplete. No tracker edit was made for this report. Stop for narrow independent re-review; do not start the next ticket.

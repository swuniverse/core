BASE/HEAD 29ac20e249184b87789b0c7ca0494e549c1e7f10
UNCOMMITTED corrected draft.16 paths.
Snapshot identity 7a37d2e50a475d9f44431a8bc00e8a831403f4759d4beb06a95ecab99b2fe8e2
Fresh direct-command logs supplied, NOT session transcript exports. Backend full run wrapper failed after successful Nx214/1996; explicit execution exit annotation missing. No DB run, final acceptance hold.

# K5b + UI-1b — original independent Sol Standards integration-delta review

Date: 2026-11-10

## Disposition

**Standards: PASS0 — 0 documented-standard breaches, 0 consequential Fowler-smell findings and no verified narrow source/evidence hold.**

Original reviewer `review-tmw-k7a1`, Standards axis only. This is the requested combined integration-delta review, not a replacement Spec approval, full feature re-review or integration authorization. Both individual own-axis final reviews remain accepted and unchanged. **No main mutation or fresh reviewer gate execution occurred. Stop for the coordinator's distinct serial fast-forward phase.**

## Exact Git pin and scope — PASS

| Object | HEAD | Tree |
| --- | --- | --- |
| BASE | `699258b4f7f23cdd4cdc6675781677e9a8307b6b` | — |
| Accepted K5b | `814f2b45856f69c98e8d8fe816b444526b363ae2` | `878d6773fbf93969382905502904bca4d29354da` |
| Accepted, main-integrated UI-1b | `88dfa9ca27685da165859d304880a7db557e4a77` | `eaf5ee009a695b6260a0c2229d0128833fb46b39` |
| Worker two-parent merge | `c652681125ef3deb7ca89cbb514e4d0f166da800` | `67094f93b4b7e237a6c47f529113c470d9d23310` |
| Final tracker follow-up | `4e2da9569b996d5a18cd428142a34ce8555e0853` | `eb8f14348e823e9dafeb5498cc925cd96b4ab260` |

Pinned comparison: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...4e2da9569b996d5a18cd428142a34ce8555e0853`; pinned history: `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..4e2da9569b996d5a18cd428142a34ce8555e0853`.

Verified **8 commits / 27 paths**. Merge parents are exactly K5b then UI-1b, in that order. Final's sole parent is the merge, with exactly one changed path: the K5b issue. UI-1b/main is an ancestor of final; `UI-1b...final` contains exactly the **20 accepted K5b paths**. Both new commit messages are English, retain Conventional Commit subjects and end with the required attribution. Committed-range whitespace check passes.

## Findings and preservation judgement — under 400 words

**No Standards finding.** The accepted changes are disjoint: **19 K5b executable/test paths + 6 UI-1b executable/test paths**, plus their two separate issues. Every merge path equals its originating accepted Git blob and mode; all 25 final code/test paths retain those exact bytes and modes. All seven UI-1b paths, including its issue, equal accepted `88dfa9ca`. There is no merge-resolution code, probe, assertion weakening, skip or new executable change to assess.

Consequently, the previously accepted canonical catalog DTO/backend return/frontend typed-use contract remains in `packages/shared/src/lib/database/index.ts` and its existing consumers; UI-1b's required `cargoMax` remains in the distinct `packages/shared/src/lib/spacecraft/index.ts`. The compact catalog label, shared-tooltip behavior, German formatter calls and legitimate tutorial assertion synchronization are unchanged. `CONTRIBUTING.md:71–75` and the previously applied game typography/formatting rules remain satisfied, without inventing a generic abstraction or repeating the feature/perimeter/migration audit.

Final K5b issue `.scratch/stu-parity/issues/tmw-K5b-ebenenkenntnis-zugriff-und-filter.md:3,27–33` is `resolved` with seven checked criteria. Its complete prior `## Comments` block remains an exact prefix; only :46 appends. Reversing just status, seven checkbox markers and that single append reconstructs the merge issue byte-for-byte. The old failed frontend checkpoint and incorrect human handoff remain historical at :43–45. The new comment explicitly distinguishes individual acceptance, combined gates, historical backend transfer and pending main integration. This satisfies `docs/agents/issue-tracker.md:11`; it does not claim a main merge already happened.

All twelve Fowler heuristics were considered for this delta: Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man and Refused Bequest. They remain judgement calls; repository rules override them and tooling-enforced issues are excluded. With exact accepted source preservation and only the bounded metadata append, no consequential new smell survives.

## Source identity and complementary checkpoints — PASS

Independently derived the accepted path sets from Git, proved they are disjoint, and checked the full 27-path merge/final union against accepted blobs, checkpoint SHA-256 maps, Git blob IDs and current raw worker files. All three full path maps have exactly the expected keys and origin/accepted-commit/executable flags. Premerge accepted digests, after-gates merged digests/blob IDs and final digests/blob IDs reconcile to Git. Postmerge checkpoint equals the final manifest's merge record; gate/checkpoint fields and complementary artifact hashes reconcile.

- Entire `apps/backend` subtree at merge **and final** equals accepted K5b, tree object `9d2d48a6f425e40bbbd54a772618ace1f21a37b1`.
- Final K5b issue SHA-256: `308462a3e8403de5381a3b06e6886f2ef662b85a4a21e42bc2c7b2d78f5595c1`.
- Merge/accepted K5b issue SHA-256: `cb2c1353722b3c84c2c51583e198b28ace258c9bc1bd7e0974d5f7cd955ac28b`.
- Final ordered 27-path `{path,origin,sha256,git_blob}` JSON map SHA-256: `98dc31dd397949d85f3131673528c844fdd63b2c0c50823c71b1c63ca88d641c`.

| Supplied checkpoint | Verified SHA-256 |
| --- | --- |
| Premerge source manifest | `909556166c1689c341921b1c2ff6702b9b386a576993faa2e60cb66cff13a656` |
| Postmerge | `c30a08e9d1f54888b63aed181ef8529a93c178873c19d43eaaa754461254b24b` |
| After gates | `92c9a0b839732a1a847df9a90e6404d34d2e1d99768e5520f7bd3405fcdbdae6` |
| Final manifest | `7063b6f57f1771bff8a485239b9adf69c019e887cd11248eeec3f7a04639034b` |

All **21 combined manifest artifact hashes** match, including handoff report SHA-256 `75925ce689bd4d5d2c95d9defa3b67a0ca9e77dd15e2df9529a59e9022ae5f34`. Current worker's original combined report equals the supplied copy.

## Fresh supplied combined gates — PASS, not reviewer reruns

All six actual direct receipts record numeric **process exit 0**, `source_unchanged:true`, and identical before/after `{head:c6526811..., source_hashes:{}}`. Actual log SHA-256 and receipt SHA-256 match the manifest and after-gates checkpoint; final manifest repeats those records exactly. Receipt commands match checkpoint commands. The checkpoint binds merge tree `67094f93...`.

The empty maps represent the committed clean changed-against-HEAD state; **they alone do not enumerate or bind the feature sources**. The complementary accepted/premerge/postmerge/after-gates/final full-union maps plus exact Git tree and raw worker comparisons provide that binding. The later tracker commit is metadata, not an execution checkpoint.

| Gate | Exit | Actual log observation |
| --- | ---: | --- |
| i01 focused frontend | 0 | Independently summed 5 successful file rows / 75 tests: starmap 37, database 19, spacecraft 10, tutorial 3, Tooltip 6. Zero skips/todos. |
| i02 full frontend | 0 | Independently summed 93 distinct successful file rows / 670 tests, including singular-test rows; totals agree. Zero skips/todos. |
| i03 forced specs | 0 | `tsc --build apps/backend/tsconfig.spec.json apps/frontend/tsconfig.spec.json --force --pretty false`; no diagnostics. |
| i04 Shared build | 0 | `tsc --build tsconfig.lib.json`; Nx success. Ordinary incremental compiler caveat applies. |
| i05 frontend lint | 0 | Actual summary: 110 problems, **0 errors / 110 warnings**; Nx success. |
| i06 frontend build | 0 | Vite production build: **1104 modules**, built in **1.14s**; Nx success. |

Warnings are retained, not suppressed: focused one act warning; full frontend 47 act warnings and one `NaN`/`strokeDashoffset` warning; frontend lint 110 warnings; build CSS import-order and large-chunk warnings. A failure-related test title is not a failed execution result. No baseline/flaky exception is used.

## Historical backend runtime transfer — exact identity only

Combined c18/c19 log and receipt files equal the previously accepted individual correction artifacts byte-for-byte. Actual receipts remain at precommit HEAD `b32bc992...`, with ten final executable/test digests unchanged before/after and matching accepted K5b and final combined Git bytes. Their issue digest is historical metadata, not the final tracker digest. Whole-backend tree equality additionally proves no backend source drift during combination.

- **c18:** 2/2 suites, **55/55 tests = 51 production HTTP + 4 export compatibility**, exit 0. Log SHA-256 `79b2f3d0a424d57cbb3a0280b95ee1eb1301facdffd85b4c48f437fbc2a550bc`; receipt `535200bc164e28df4dbbf25176fcfceceb8f8e020d6056b46e9b3545c4e2595c`.
- **c19:** **214/214 suites, 1996/1996 tests, 1/1 snapshot**, exit 0. Log SHA-256 `67eb3be5db8d81c585cde4f6cbe13f77c588c7787f06c5e5d612979c74672e15`; receipt `ecf9c136676fdafdbb20e97b7bf7b10644e865af1922199abfd7344cfbc18de9`.

No fresh combined backend runtime/PostgreSQL execution is claimed. Production HTTP/setup interpretation relies on the already completed individual review, not a new perimeter audit. ts-jest/pg deprecations and backend failure-path log messages remain historical. Forced combined spec compilation is consumer/compiler coverage, not runtime evidence.

## Retained reports, current state and stop

Reverified original K5b **43**, K5b correction **39**, original UI-1b **14** and UI-1b correction **17** manifest artifacts. Original failed frontend evidence remains intact. Worker original/correction report hashes and actual independent acceptance-report hashes match the checkpoints.

Own retained final Standards reports:
- K5b: `372859ff04d25b59726087a3f374ded6f3b102dad3e39c72200c3468a3d2b76f`.
- UI-1b: `3b0bd9419faf770d050619193d14ec5c66b5e70dee5cbbeb0f6489c12d326512`.
- Separate completed UI integration: `3ff3759179b744d56fb89276848a08bde83ff0b796448351ba1b64a158c24a47`.

Worker remains `agent-tmw-k5b`, exact final HEAD/tree, porcelain clean, all 27 raw files equal final Git. Main remains `stu-parity` at accepted UI-1b HEAD/tree, tracked clean; all **45** known untracked brag files retain exact paths, modes and content against the premerge checkpoint. Reviewer remains `review-tmw-k7a1` at `ff16922a7b93b620acb4d51d7180cf255dd970b2`, clean. All 18 prior reviewer Markdown report digests were snapshotted before this new report; ordered snapshot SHA-256 `2a0996c9e62ed8bbe067647c449a5a79bedab62ee602ba52864cf0812e79764b`. This report was absent and ignored before creation; final preservation/state/ignore checks pass.

A read-only verifier initially joined the array-shaped original UI manifest filenames at its root instead of its `gates/` directory and stopped with ENOENT. Reading the actual layout and correcting the path resolved that verifier assumption; all 14 hashes then passed. It was not a source/gate failure and caused no mutation. Oversized checkpoint output was replaced with bounded authoritative field checks; no private persisted tool output or transcript was accessed.

Evidence establishes supplied artifact integrity and recorded source identity, not forensic process provenance, continuous filesystem monitoring or universally cleared internal caches. Nx task-cache bypass is not clearing every internal cache. No fresh main execution is claimed.

Only read-only Git/source/document/report/hash/log inspection and this NEW ignored report were performed. No tests/types/lint/build/DB/install, private transcripts/tool exports, environment values/secrets, external services, agents/workflows/plan mode, source/tracker/config/package/map/STU edits, branch switch, commit/merge/push or cleanup. **Standards PASS0; stop. No main integration or K7b authorization follows from this report.**

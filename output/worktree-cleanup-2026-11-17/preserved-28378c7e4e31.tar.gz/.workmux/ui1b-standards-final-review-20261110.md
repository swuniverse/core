# UI-1b — original independent Sol Standards final correction review

Date: 2026-11-10

## Disposition

**Standards: PASS0 — both original documented-standard findings fixed; 0 remaining documented breaches and 0 consequential Fowler-smell findings in the correction.**

**Final source/evidence hold: none for this narrow Standards review.** This is the original `review-tmw-k7a1` Standards axis only. No independent Spec verdict or integration authorization is issued. Stop for coordinator serial integration; no integration was performed here.

The original BLOCKED2 report `.workmux/ui1b-standards-review-20261110.md` remains historical and unchanged. This report reviews correction/nonregression only, not the complete original feature again. K5b and any combined/main candidate are outside scope.

## Pinned Git identity and scope — PASS

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Original reviewed candidate: `bab783d091693c6b75e75319c68ae69b17e1bbe3`, tree `7b88eead34342bc86c24f11f0009304f18302806`.
- Standards-fix follow-up: `c5b1d3604b00d843c9750d72799394f650db4bf4`, tree `96f463a1dff43d207caf20755539e16e28736a50`, direct parent original candidate.
- Tracker gate-checklist follow-up: `67fc06bc2ffebb4b6891b309a6cca31a5c38df39`, direct parent Standards-fix follow-up.
- Final candidate: `88dfa9ca27685da165859d304880a7db557e4a77`, direct parent tracker follow-up.
- Final tree: `eaf5ee009a695b6260a0c2229d0128833fb46b39`.
- Narrow pinned diff: `git diff bab783d091693c6b75e75319c68ae69b17e1bbe3...88dfa9ca27685da165859d304880a7db557e4a77`.
- Narrow pinned log: `git log bab783d091693c6b75e75319c68ae69b17e1bbe3..88dfa9ca27685da165859d304880a7db557e4a77`.
- Overall pinned diff/log: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...88dfa9ca27685da165859d304880a7db557e4a77` and `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..88dfa9ca27685da165859d304880a7db557e4a77`.
- Narrow range: **3 commits / 5 paths**. Overall range: **4 commits / 7 paths**. Both later commits modify only the issue tracker.

Narrow paths: `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md`, `packages/shared/src/lib/spacecraft/index.ts`, `apps/frontend/src/pages/spacecraft.tsx`, `apps/frontend/src/pages/spacecraft.spec.tsx`, and `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx`. Overall scope additionally contains `apps/frontend/src/components/Tooltip.tsx` and `Tooltip.spec.tsx`, unchanged by the correction. No backend runtime file changed. The coordinator explicitly authorized the narrow Shared DTO field correction.

Reviewed exact candidate Git blobs, not the older reviewer checkout. No CodeGraph index exists in this reviewer worktree; none was created.

## Findings and closure judgement — under 400 words

1. **Canonical Shared cargo capacity contract — FIXED.** `CONTRIBUTING.md:73` requires “Shared DTOs/interfaces go in `packages/shared`”. Final `packages/shared/src/lib/spacecraft/index.ts:412` adds required `cargoMax: number` to canonical `SpacecraftListDto`. `apps/frontend/src/pages/spacecraft.tsx:35,42,52,222` reuses that DTO for list state, public API response, grouped ships and row props. The local required intersection and independently optional row field are removed; :237 passes `ship.cargoMax` without the zero fallback. This closes the original cross-boundary ownership and required/optional duplication finding. No unrelated historical DTO migration is demanded.

2. **German tooltip numbers — FIXED.** `.scratch/stu-parity/inventory/shell-admin-runtime.md:302–310` documents German numeric presentation and the thousands point. Its “no central formatter” statement is historical: unchanged `apps/frontend/src/lib/format.tsx:5–8` already implements `formatNumber` with `Intl.NumberFormat('de-DE')`. Final `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx:95,121` uses that helper for item amount, used cargo and capacity. The added production-page regression observes `1.234` and `Lagerraum 1.234/10.000`. The original eager detail panel is byte-identical and outside this finding.

No new consequential heuristic finding survives review of these correction hunks. Reusing the canonical DTO and existing formatter reduces duplication; a domain capacity number and explicit public regression fixture do not justify new abstractions. There are **0 remaining Standards findings**.

## Mandatory rules and bounded nonregression

Retained the original own-axis analysis of `CONTRIBUTING.md`, `AGENTS.md`, full `CONTEXT.md`, `docs/agents/domain.md`, `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`, relevant ADRs 0002/0003/0004/0006, frontend conventions in `.scratch/stu-parity/inventory/shell-admin-runtime.md`, and shared Tooltip issue `sh-AP-11`. All twelve documents are independently byte-identical original-to-final. Original bounded discovery found no `CODING_STANDARDS` or additional relevant frontend-specific ADR directory; no new standards source is introduced by this correction. The existing formatter is also unchanged.

All twelve Fowler heuristics retained for the new correction: **Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man, Refused Bequest**. These are judgement calls, not automatic violations. Repository rules override them; tooling-enforced issues are excluded.

The correction changes only the Shared capacity field, its list types/direct capacity use, three tooltip number presentations, one public formatting test and tracker completion. Lazy request sharing/cache behavior, rejection eviction, mounted/active-ship presentation guards and shared touch/hover/focus implementation are unchanged. Both Tooltip files are byte-identical to the original reviewed versions. Everything from `export function ShipStoragePanel` to EOF is byte-identical, preserving the old eager detail panel. Removing exactly the newly inserted 32-line formatting test reconstructs the original list spec bytes, retaining all old fixtures/assertions.

The new test uses real `SpacecraftPage` and production Tooltip, with existing API/assets mocks rather than synthetic component DOM. Unique ship 261 avoids prior module-cache fixture identities; amount 1234 and capacity 10000 exercise the actual public item cell and occupancy text. This bounded Standards inspection is not a substitute for independent Spec approval or a new cache-policy requirement.

## Artifact, source and direct-receipt binding — PASS

Read supplied `.workmux/local-inputs/ui1b-correction-review/report.md`, `manifest.json` and the eight direct log/JSON receipt pairs under `gates/`. All **17 manifest artifact hashes match**: handoff report plus eight pairs. Each receipt's `log_sha256` matches its actual log; before/after source maps agree; every receipt records `source_unchanged: true` and unchanged before/after HEAD at original candidate `bab783d091693c6b75e75319c68ae69b17e1bbe3`.

All seven GREEN receipts contain the following four final corrected source/test digests both before and after execution. Each independently matches the final candidate Git blob:

| Corrected path | SHA-256 |
| --- | --- |
| `packages/shared/src/lib/spacecraft/index.ts` | `2688e9f631378fd6f9a1331f8e3a4a4f4732fb9cb78a226736c39237b7a09099` |
| `apps/frontend/src/pages/spacecraft.tsx` | `a9405ad3affa740e9c5f62b4efcbe3469362b67ba82c3f6463595f2536605fbb` |
| `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx` | `bdb0678c9b3af07825b6b4daa0c2e326d3b7ebf71cc4d53eadb9c6d15ace6955` |
| `apps/frontend/src/pages/spacecraft.spec.tsx` | `181c7e7cbe55f6bf016dc2ae0f51ce8af9390661afb9e329dde72924f656b574` |

The correction receipts omit the two unchanged Tooltip files. Their final Git bytes independently equal the original own-axis reviewed/evidence-bound bytes:

| Unchanged path | SHA-256 |
| --- | --- |
| `apps/frontend/src/components/Tooltip.tsx` | `055235398092bc65b20e1b1ceced4c15599888e4bfca138dcab3cec311180a0e` |
| `apps/frontend/src/components/Tooltip.spec.tsx` | `2fe98b9a9c2eb78252ceee2313035a82def73b364141f603f1792c39570f622f` |

The RED receipt records **only the list spec digest**, equal to the final new regression test bytes; it is not a four-file final implementation record. GREEN evidence records corrected uncommitted source at the original committed HEAD. Exact executable/test byte identity binds those recorded results to the later committed final candidate, not to a fresh execution at final HEAD. The two tracker-only commits are not execution checkpoints; tracker identity/history is checked separately.

## Verified supplied gates and historical failure treatment

| Direct evidence ID | Numeric process exit | Observed result |
| --- | ---: | --- |
| `ui1b-correction-format-red` | **1** | 1 failed file; 1 failed / 9 passed / 10 total tests. Real list regression cannot find role `cell` named `1.234`. Meaningful formatting RED, retained as failure. |
| `ui1b-correction-format-green` | **0** | 2/2 files, 16/16 tests: list 10 plus Tooltip 6; new formatting and retained lazy/cache/empty/touch coverage pass. |
| `ui1b-correction-shared-build` | **0** | Nx shared build succeeds using ordinary `tsc --build tsconfig.lib.json`. |
| `ui1b-correction-frontend-spec-types` | **0** | `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false`, no diagnostics. |
| `ui1b-correction-backend-spec-types` | **0** | `tsc --build apps/backend/tsconfig.spec.json --force --pretty false`, no diagnostics; spec-inclusive Shared consumer compilation. |
| `ui1b-correction-frontend-lint` | **0** | Nx success, 0 errors / 110 warnings. Tooling diagnostics are not additional Standards findings. |
| `ui1b-correction-frontend-full-test` | **0** | **93/93 files, 667/667 tests, zero skipped totals**; independently summed all successful file-result rows to 93 and 667. |
| `ui1b-correction-frontend-build` | **0** | Nx/Vite success, 1104 modules, built in 3.03s; CSS import-order/large-chunk warnings remain. |

The handoff report describes the RED as failing both formatted item and occupancy assertions. The actual execution reaches and fails the **first item-cell assertion**; the later occupancy assertion is in source but is not reached on that failed test. Do not count two independently failed assertions. GREEN executes and passes both. The RED log literal-line scan did not independently establish raw rendered occupancy text; no such extra claim is needed for this meaningful RED.

Original feature REDs, early GREENs and original BLOCKED2 remain historical at their original checkpoints. None is rewritten as final corrected execution. Backend spec compilation supplies consumer coverage, **not backend runtime/PG suite execution**; no such runtime suite is claimed for the correction.

## Tracker and final source state — PASS

Read the full final issue. Its status is `resolved`, with six checked criteria: the original four plus German numeric presentation and public formatting regression. The complete original `## Comments` history, including its completion/gate record, remains verbatim. Correction history is appended, consistent with `docs/agents/issue-tracker.md:11`; it acknowledges the original findings, corrections, recorded gates, absence of backend runtime changes/suite, pending independent narrow review and nonintegration. Completing this independent report does not itself edit the tracker or integrate the candidate.

At final source-state verification, existing worker `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-sc-wp-ui-1b` is on `agent-sc-wp-ui-1b`, exact final HEAD `88dfa9ca27685da165859d304880a7db557e4a77`, tree `eaf5ee009a695b6260a0c2229d0128833fb46b39`, empty porcelain status. All seven overall changed raw worker files equal final candidate Git blobs.

Reviewer remains `review-tmw-k7a1`, HEAD `ff16922a7b93b620acb4d51d7180cf255dd970b2`, empty porcelain status. This NEW report is ignored under `.workmux/`; final ignore/preservation checks pass. Original UI-1b report remains SHA-256 `f75758701356056c57781dc83607a84d3294a6ff57bc3a8b8a159eaf2034f655`; prior K5b report remains SHA-256 `7a2ee729abeebeb5cdd8ab81135edaace8af7b11a84c6262e080a8ae01df3ac9`.

## Limitations and stop

These are supplied executions bound by exact recorded bytes, **not reviewer reruns**, forensic process-provenance proof or a universally cleared internal-cache claim. Nx `--skip-nx-cache` bypasses task replay, not all compiler/runtime artifacts. Ordinary shared `tsc --build` retains incremental caveats, distinct from the explicit forced spec-inclusive compiler gates. No fresh main/combined-candidate execution is claimed.

Only bounded read-only Git/source/document/hash/log checks and this new ignored report were performed. No reviewer gates/tests/lint/types/build/DB/install, environment/secrets inspection, external services, private transcripts/tool-result exports, nested agents/workflows/plan mode, source/tracker/config/package/map/STU edits, branch switching, commits, merge, push or cleanup. **Standards PASS0; stop for coordinator. No integration.**

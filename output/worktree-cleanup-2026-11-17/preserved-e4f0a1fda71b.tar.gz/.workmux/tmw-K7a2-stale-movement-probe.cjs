// Local-only diagnostic, not a wormhole implementation or acceptance test.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const { setTimeout: pause } = require('node:timers/promises');

// Use tsc's CommonJS output for the existing circular entity imports.
const resolve = Module._resolveFilename;
Module._resolveFilename = function (request, parent, ...rest) {
  if (request === '@swuniverse/shared') {
    return path.resolve('packages/shared/src/index.ts');
  }
  if (request.startsWith('.') && request.endsWith('.js') && parent) {
    const source = path.resolve(path.dirname(parent.filename), request.slice(0, -3) + '.ts');
    if (fs.existsSync(source)) return source;
  }
  return resolve.call(this, request, parent, ...rest);
};
require.extensions['.ts'] = function (module, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const { outputText } = ts.transpileModule(source, {
    fileName: filename,
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      experimentalDecorators: true,
      emitDecoratorMetadata: true,
      esModuleInterop: true,
    },
  });
  module._compile(outputText, filename);
};
require('reflect-metadata');

const { PostgreSqlContainer } = require('@testcontainers/postgresql');
const root = path.resolve('apps/backend/src');
const { connectIntegrationDatabase, createUser } = require(path.join(root, 'testing/integration/database.ts'));
const { Spacecraft } = require(path.join(root, 'modules/spacecraft/entities/spacecraft.entity.ts'));
const { ShipClassDef } = require(path.join(root, 'modules/spacecraft/entities/ship-class-def.entity.ts'));
const { Layer } = require(path.join(root, 'modules/starmap/entities/layer.entity.ts'));
const { GalaxyField } = require(path.join(root, 'modules/starmap/entities/galaxy-field.entity.ts'));
const { SpaceLocation } = require(path.join(root, 'modules/starmap/entities/space-location.entity.ts'));
const { SpacecraftDestructionService } = require(path.join(root, 'modules/spacecraft/spacecraft-destruction.service.ts'));

async function run() {
  assert.equal(process.env.DATABASE_URL, undefined, 'ambient DATABASE_URL must be unset');
  assert.equal(process.env.INTEGRATION_DATABASE_URL, undefined, 'ambient INTEGRATION_DATABASE_URL must be unset');
  let container;
  let dataSource;
  try {
    container = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('tmw_k7a2_stale_movement_probe')
      .start();
    console.log('PREREQUISITE: fresh disposable PostgreSQL 16 container, no ambient/shared database');
    process.env.INTEGRATION_DATABASE_URL = container.getConnectionUri();
    process.env.SWU_MIGRATION_BUILDING_SEED_PATH = path.join(root, 'testing/integration/fixtures/migration-buildings.yaml');
    dataSource = await connectIntegrationDatabase();
    console.log('PREREQUISITE: actual repository migrations applied; synchronize=false');
    const owner = await createUser(dataSource);
    const shipClass = await dataSource.getRepository(ShipClassDef).save({
      key: 'K7A2_DIAGNOSTIC', name: 'Diagnostic ship', category: 'SHIP', role: 'SCOUT',
    });
    const layer = await dataSource.getRepository(Layer).save({ name: 'Diagnostic layer', width: 5, height: 5 });
    const locations = [];
    for (let cx = 1; cx <= 3; cx++) {
      const field = await dataSource.getRepository(GalaxyField).save({ layerId: layer.id, cx, cy: 1, fieldTypeId: 1 });
      locations.push(await dataSource.getRepository(SpaceLocation).findOneByOrFail({ galaxyFieldId: field.id }));
    }
    const repo = dataSource.getRepository(Spacecraft);
    const ship = await repo.save({
      name: 'Stale navigation snapshot', shipClassId: shipClass.id, userId: owner.id,
      locationId: locations[0].id, energy: 71,
      runtimeSystems: { SUBLIGHT_DRIVE: { active: false, integrity: 100, cooldown: 0 } },
    });
    // Exactly the pre-save snapshot shape used by normal movement callers.
    const stale = await repo.findOneByOrFail({ id: ship.id });
    stale.locationId = locations[2].id;
    stale.energy = 70; // Existing normal movement's one-field EPS charge.

    let release;
    let locked;
    const barrier = new Promise(resolve => { release = resolve; });
    const acquired = new Promise(resolve => { locked = resolve; });
    const relocation = dataSource.transaction(async manager => {
      const current = await manager.findOne(Spacecraft, {
        where: { id: ship.id }, lock: { mode: 'pessimistic_write' },
      });
      current.locationId = locations[1].id;
      current.runtimeSystems.SUBLIGHT_DRIVE.active = true;
      await manager.save(current);
      locked();
      await barrier;
    });
    await acquired;
    // This public production method uses only DataSource. The diagnostic does
    // not exercise or claim acceptance of its other constructor collaborators.
    const persistence = new SpacecraftDestructionService(dataSource);
    const staleSave = persistence.saveUnlessDestroyed(stale);
    try {
      const deadline = Date.now() + 5000;
      let blocked = false;
      while (Date.now() < deadline) {
        const rows = await dataSource.query(
          `SELECT count(*)::int AS count FROM pg_stat_activity
           WHERE datname = current_database() AND wait_event_type = 'Lock'
             AND query ILIKE '%spacecraft%'`,
        );
        if (rows[0].count > 0) { blocked = true; break; }
        await pause(10);
      }
      assert.equal(blocked, true, 'stale production save must actually wait on relocation row lock');
      console.log('EXECUTION: production saveUnlessDestroyed waited on the relocation transaction row lock');
    } finally {
      release();
      await relocation;
    }
    assert.equal(await staleSave, true, 'production stale save reported success');
    const persisted = await repo.findOneByOrFail({ id: ship.id });
    console.log(JSON.stringify({
      expectedCommittedRelocation: { locationId: locations[1].id, energy: 71, impulseActive: true },
      actualAfterProductionStaleSave: {
        locationId: persisted.locationId, energy: persisted.energy,
        impulseActive: persisted.runtimeSystems.SUBLIGHT_DRIVE.active,
      },
    }, null, 2));
    assert.equal(persisted.locationId, locations[1].id,
      'existing movement persistence must not overwrite a committed concurrent relocation');
  } finally {
    if (dataSource?.isInitialized) await dataSource.destroy();
    if (container) await container.stop();
    delete process.env.INTEGRATION_DATABASE_URL;
    delete process.env.SWU_MIGRATION_BUILDING_SEED_PATH;
    console.log('CLEANUP: disposable connection/container removed; worktree/ref retained');
  }
}
run().catch(error => { console.error(error); process.exitCode = 1; });

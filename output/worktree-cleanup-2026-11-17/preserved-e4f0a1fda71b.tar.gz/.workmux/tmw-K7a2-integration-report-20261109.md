# tmw-K7a2 atomic wormhole integration — 2026-11-09

## Outcome: BLOCKED / stopped before product implementation

- Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2`.
- Branch: `agent-tmw-k7a2`; HEAD retained at `ff16922a7b93b620acb4d51d7180cf255dd970b2`.
- Supplied main baseline: `c79ff89f`; supplied K7a1 stage/review PASS applies only to the nonpersistent planner. Reports read from `.workmux/local-inputs/stage-report.md` and `stage-review.md`.
- Model: gpt-6.1-sol, no nested agents/workflows.
- K7a2 is NOT implemented or accepted. No public route was activated; K7a1's absent-route safety test remains unchanged. No independent public partial service was added.
- Only tracked edit: K7a2 issue changed to `ready-for-human` and appended precise prerequisite/blocker evidence. All checkboxes remain open. K7a1, K7a3, parent, map, frontend, STU, package files, lockfile, Nx config and migrations are unchanged.
- No implementation commit: acceptance is incomplete. Tracker change remains uncommitted. No push/merge/main checkout access. Worktree/ref retained.

## Why an isolated K7a2 transaction is insufficient

### 1. Existing movement persists stale snapshots after a relocation commits

Production seam: `SpacecraftDestructionService.saveUnlessDestroyed`, `apps/backend/src/modules/spacecraft/spacecraft-destruction.service.ts:126-137`.

Normal `navigate`/`flyGalaxy` load a ship using the global repository, compute movement from that snapshot, then call this service (`spacecraft.service.ts:1964,2073,2164,2234`). The service starts its own transaction, obtains a write lock, checks only whether the persisted ship is destroyed, then saves the caller's snapshot. It does not compare the original location/resources/runtime or reject stale navigation. A row lock acquired by wormhole passage delays this save but does not invalidate it.

Disposable migration-backed probe proved:

1. Read production ship snapshot at location 1, EPS 71, inactive impulse.
2. Relocation transaction locks the ship and writes location 2, EPS 71, active impulse, remaining open at a barrier.
3. Call the real public `saveUnlessDestroyed` with a prior normal-movement-style snapshot targeting location 3, EPS 70, inactive impulse.
4. Observe actual PostgreSQL lock wait in `pg_stat_activity`; release and commit relocation.
5. Production save returns true, writing location 3, EPS 70, inactive impulse.
6. Regression assertion that location 2 remains fails: `3 !== 2`.

This is a focused production persistence/concurrency diagnostic, NOT an implemented wormhole test or complete real `navigate` request. The diagnostic transaction simulates the proposed locked relocation; the stale saver is production code and all persistence is real PostgreSQL.

### 2. Existing fleet join can persist a new member at the old location after waiting

Production seam: `SpacecraftService.joinFleet`, `apps/backend/src/modules/spacecraft/spacecraft.service.ts:2839-2865`. Fleet create/leave/dissolve/leader changes also read authoritative state before their global saves (`:2817-2888,2939-2950`) and lack a shared lock/revalidation protocol.

`joinFleet` reads the fleet, prospective member, and leader and validates their location before its save obtains the relevant database locks. Locking the fleet row prevents its FK-related write until commit but does not cause its earlier location validation to repeat.

Disposable migration-backed probe proved:

1. Real fleet leader and prospective joiner both start at location 1.
2. Relocation transaction write-locks fleet and all current members in ID order; verifies complete participant list `[leader]`, moves leader to location 2, remains open.
3. Call real public `joinFleet`, using real repositories and `ShipClassService` for every dependency this call uses; observe lock wait.
4. Release and commit relocation; join resolves. Reload database state, rather than trusting returned object.
5. Persisted fleet contains leader at location 2 and new member at location 1, same fleet ID 1.
6. Regression assertion that committed fleet is colocated at destination fails: `false !== true`.

An initial diagnostic assertion trusted `joinFleet`'s returned `fleetId` (null) and failed before checking persisted membership. On the second diagnostic run the persisted state was inspected: `persistedJoinerFleetId=1`; this confirms the actual split fleet. The returned null does not disprove persistence. It is not reported as an additional K7a2 defect.

These are pre-existing shared writer problems, not K7a1 stage review findings. A new endpoint cannot honestly satisfy full concurrent/atomic fleet passage by enclosing global calls in a transaction, holding row locks, adding endpoint-only advisory locks, or using a serializable reader while unchanged writers later act on old global snapshots.

## Required narrow prerequisite split for independent decision/review

1. **Movement stale-write protection:** extend the existing movement persistence seam to require authoritative preconditions/original state and fail on stale state, or use supported manager-based validation and persistence within one transaction. Ensure all existing movement callers participate; protect location and resources/runtime, not only terminal destruction. Do not create a monolithic Spacecraft refactor. Regression: existing move started before another committed relocation cannot overwrite that relocation or produce orphan movement side effects.
2. **Fleet mutation locking:** create/join/leave/dissolve/leader-change validation and persistence must follow a shared lock order and revalidate after obtaining locks. In particular join must reread leader/member location after waiting; whole-entity saves must not restore stale fleet/location state. Regression: concurrent join across relocation either validates against committed position and refuses or participates in a defined complete operation, never silently leaves a member at the old position. Narrowly review how docking and other fleet readers use the same contract.
3. **Then K7a2 adapters:** transaction-manager support for exploration, layer knowledge, signatures and field-effect messages; messages persisted within transaction and gateway notifications delayed until successful commit. Keep existing nontransactional callers' behavior intact with regression tests. Repair cancellation already has the required `cancelTasks(manager, ids)` seam.

The two confirmed races require changing behavior of pre-existing navigation/fleet operations, not just adding transaction-aware arrival methods. Stopped under the explicit architectural/scope boundary rather than quietly expanding K7a2 or inventing eligibility restrictions to evade concurrency.

## Transaction / lock / side-effect seam inspection

- `SpacecraftService.prepareFleetMembers` (`:2750-2813`) is intentionally partial for nonfixed fleets, skips members at other locations, loads no member modules, can persist departures and emit events. It must not execute wormhole passage.
- `SpacecraftCrewService.hasEnoughCrew` (`spacecraft-crew.service.ts:214-219`) uses global assignment count; crew requirement is `max(0, crewRequired)`. Its reads need transaction-bound authoritative assignments/locks for K7a2.
- `SpacecraftTractorService` locks relevant ships in its own transactions. Incoming tractor check is currently global in `SpacecraftService.assertNotTractored` (`:1946-1952`). K7a2 must resolve the complete affected set and revalidate it under shared locks, not silently drop a tractor participant.
- Impulse activation is authoritatively free in current `activateDriveForFlight` (`spacecraft.service.ts:2267-2297`) and `toggleSystem` (`:1026-1145`). No new tariff, hull-flight cost or warp charge was introduced. No EPS-zero workaround was implemented.
- Planner inputs need stable detached immutable snapshots throughout awaited checks; stage remains untouched, not durably authorized.
- `WormholeService.findExitsAt` (`wormhole.service.ts:79-86`) uses active local entries or active bidirectional local exits. Random selection must receive every target-layer passable field based on `GalaxyField.isPassable`, not just configured fixed exit or nearby fields. No selector implementation was added.
- `FieldTransitionExecutor` only executes an orthogonal spatial route (`field-transition-executor.ts:64-85`); wormhole destination transition requires a narrow supported destination-entry seam, not imaginary flight through intermediate coordinates.
- `FlightConsequencePipeline` has no manager/event context. Its sole registered consequence is `FieldEffectConsequence` (`spacecraft.module.ts:213-215`). Field effect mutates ship, calls global `MessagingService.sendSystem` and immediately emits gateway events (`field-effect-consequence.ts:108-114`). Merely invoking it from a transaction is not atomic.
- `MessagingService.sendSystem` (`messaging.service.ts:309-364`) uses global repo and immediately calls `notifyRecipient`. A supported narrow transaction persistence + after-commit notification seam is needed; no global mutable service patching or outbox architecture invented.
- `ExplorationService.discoverArea/discoverField` uses global repo (`exploration.service.ts:35-88`). Caller-manager adaptation and rollback regression are necessary.
- K5c mandatory `LayerKnowledgeService.markKnown` uses global repo and calls global `get` (`layer-knowledge.service.ts:22-40`). Needs consistent manager reads/writes and preservation of existing EXPLORED state. K5c is resolved and not optional.
- `FlightSignatureService.createMovement` uses global signature repo and class lookup (`flight-signature.service.ts:36-65`), producing origin/destination signature pair. Needs manager-backed persistence and correct wormhole directional semantics; not implemented.
- `GameEventService.recordSpacecraft` persists globally (`game-event.service.ts:19-33`); alternative per-ship `ShipLogEntry` can use existing entity in caller transaction. No success event/log written.
- `SpacecraftRepairService.cancelTasks(manager, ids)` (`spacecraft-repair.service.ts:255-296`) locks, deletes station/self repair tasks and refunds materials within caller transaction. `notifyCancelled` currently persists messages after transaction; transaction-aware notification persistence is needed if used for the new operation. This repair data seam is already usable and is NOT the stop reason.
- Cartography finalization resets (`cartography-plan.service.ts:167-180`) and takeover cancellation (`spacecraft-takeover.service.ts:73-82`) use global persistence / nested independent transaction and notifications. Existing operation mandates must be preserved transactionally, not called before validation.
- Integration entity registry currently omits wormhole/signature/repair/log entities; future integration tests must register the actual required entities without synchronize or generated migration metadata.
- No existing `navigate`/`flyGalaxy`/arrival/fleet PostgreSQL integration coverage located in current `*.int-spec.ts` search. Existing unit fleet/field/arrival-related suites are not atomicity proof. No tests/exclusions were changed.

## Inputs and setup

Read latest root AGENTS/CONTRIBUTING/CONTEXT, issue-tracker/domain/triage docs, parent K7a and children K7a1/2/3, K1a, K5c, relevant ADR-0002/0003/0004/0006, migration docs and integration harness documentation/source, movement/interaction/tractor/docking/runtime sources.

Initial small environment check (not a baseline re-audit): clean tree at ff16922a, Node v24.22.1, npm 11.19.1, no CodeGraph index, no node_modules, supplied `.workmux/local-inputs/game-data/data` present, root data absent, both ambient DB variables unset. No indexing performed.

Commands:

```sh
npm exec --offline -- node -e 'const fs=require("node:fs");fs.symlinkSync("../.workmux/local-inputs/game-data/data","game-data/data","dir");console.log("Linked repository-root game-data/data to supplied local-only input");'
npm ci --offline --ignore-scripts --no-audit --no-fund
```

Both exit 0. 1,831 packages installed from existing offline cache, deprecation warnings; install scripts intentionally not run. No package/pin/lock edits. Data link is at actual worktree repository root and points only to coordinator-supplied local ignored data. No backend game-data directory or cwd workaround. No external service/secrets/network download used.

Local Docker check via `npm exec --offline -- node -e '…dockerode.listImages()…'`: exit 0. Cached images included `postgres:16-alpine` and `testcontainers/ryuk:0.14.0`. Diagnostics used Testcontainers to create their own disposable databases, never `stu-db-1` or an ambient DB URL.

## Focused execution / RED evidence

Scripts and logs are local ignored diagnostics, not committed tests; JavaScript loader uses in-memory TypeScript CommonJS transpilation to tolerate existing circular entity imports. No casts/test exclusions were added to product tests. Scripts call production public persistence/fleet interfaces, with real database repositories for every executed path. Unused constructor collaborators are not instantiated; this is disclosed diagnostic scope, not Nest registration proof.

### Probe 1 — stale movement persistence

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL
npm exec --offline -- node .workmux/tmw-K7a2-stale-movement-probe.cjs > .workmux/tmw-K7a2-stale-movement-probe.log 2>&1
```

Exit **1**. One focused concurrency regression assertion RED after real lock-wait/production-success checks. Expected location 2/EPS 71/impulse true; actual location 3/EPS 70/impulse false. Full log: `.workmux/tmw-K7a2-stale-movement-probe.log`.

### Probe 2 — concurrent fleet join

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL
npm exec --offline -- node .workmux/tmw-K7a2-stale-fleet-probe.cjs > .workmux/tmw-K7a2-stale-fleet-probe.log 2>&1
```

Run 1 exit **1**, diagnostic asserted returned `fleetId` prematurely (`null !== 1`), not yet proof of split fleet. Run 2 exit **1**, replaced premature returned-object assertion with real persisted state inspection; membership was persisted (fleet ID 1), leader location 2/new member location 1. Final colocation regression assertion RED. Latest full log: `.workmux/tmw-K7a2-stale-fleet-probe.log` (first output summarized accurately here).

Each of these **3 diagnostic runs** created a new PostgreSQL 16 container/database and applied real repository migrations via `connectIntegrationDatabase`, with `synchronize:false` and committed migration building seed fixture. Each stopped its container and destroyed its data source in `finally`, including assertion failures. No migration generated/reverted, no schema synchronize. Neither migration suite count nor migration replay count was collected; no 36/290 historical pass claimed.

Warnings in every diagnostic: PostgreSQL driver deprecation `Calling client.query() when the client is already executing a query ... removed in pg@9.0`. Did not suppress/modify baseline behavior.

### GREEN and final gates

**No GREEN implementation run**: these diagnostics established a scope stop, not an implemented acceptance slice. No new authenticated route tests, single/fleet success/resource/random/arrival/rollback suites or durable committed regression tests were added. No fake green from repository mocks.

Backend lint, spec-inclusive typecheck, complete unit suite, backend build, focused wormhole integration, existing arrival/fleet integrations and full PostgreSQL suite were **not run** because there is no combined backend implementation candidate. None claimed passed/cached. Historical 211/1981 units and 36/290 migration tests remain historical only; K7a1's supplied stage gates remain supplied context, not current verification.

Final local inspection via `npm exec --offline -- node -e '…execFileSync("git",args)…'`: each subcommand exit 0:

- `git rev-parse HEAD`: `ff16922a7b93b620acb4d51d7180cf255dd970b2`.
- `git status --short`: only K7a2 issue modified.
- `git diff --check`: clean.
- `git diff --stat`: 1 file, 2 insertions / 1 deletion.
- `git check-ignore .workmux/tmw-K7a2-integration-report-20261109.md`: confirms ignored.

## Missing acceptance and next handoff

All K7a2 acceptance remains missing: authenticated route, authoritative local wormhole/complete random target set, full transaction-scoped ownership/leadership/navigation/runtime/crew/tractor checks, per-ship authoritative activation, whole fleet move, destination pipeline, local exploration, mandatory K5c knowledge, exactly-once signatures/log and repair effects, rollback/no premature notifications, Nest graph registration and complete final verification.

Stop for narrow independent review and serial prerequisite integration. Do not launch K7a3. Do not merge or resolve K7a1/K7a2. Preserve this worktree/ref and uncommitted issue status for coordinator decision.

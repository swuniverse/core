# K7a2a — fleet mutation concurrency handoff

Date: 2026-11-09

## Candidate identity and disposition

- Ticket: `.scratch/stu-parity/issues/tmw-K7a2a-flottenmutationen-nebenlaeufigkeit.md` only.
- Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2a`.
- Ref: `agent-tmw-k7a2a`.
- Verified clean starting baseline: `940628fa0a2f1986857fc6998d9439a3fe1378eb`.
- Model: `gpt-6.1-sol` (session environment).
- Commit SHA: `9219a25e6965814064fc834821f04847748b1ff5`.
- Commit subject: `fix(spacecraft): serialize fleet mutations (stu-parity tmw-K7a2a)`; final attribution `Co-Authored-By: Claude Code <noreply@anthropic.com>` verified.
- Final checked-in scope: 6 files, 1303 insertions, 140 deletions. `git diff --cached --check` passed; post-commit `git status --short` empty. Report is ignored as verified by `git check-ignore`.
- Disposition: implemented and verified local candidate; stop for narrow independent review and serial integration. Ticket `resolved` means this bounded implementation passed its candidate gates, not that independent review or integration has occurred.
- One local attributed fix commit; no push, merge, PR, main/other-checkout access, nested agents/workflows, source indexing, external service/secrets, STU edits, map/DECISIONS edits, package/lock/Nx configuration changes, migrations or migration generation.
- K7a1 `ff16922a` was not imported and is not required. K7a2b, K7a2 and K7a3 were not implemented or resolved.

## Input evidence versus executed proof

Read the supplied local prerequisites first: `stop-report.md`, `independent-review.md`, `stale-fleet-probe.cjs`, `stale-fleet-probe.log` under `.workmux/local-inputs/prerequisites/`. Reused them as diagnostic evidence; did not rerun their baseline audit or diagnostic script.

The supplied confirmed race was only public `joinFleet`: its global save waited across a locked simulated relocation and persisted membership for the old-location joiner after the leader moved. Persisted state, not the returned stale object, was decisive. Other fleet APIs are required protocol participants, not claims of separately demonstrated identical races. Independent review identified no missing user product decision.

Converted the diagnostic seam into a maintained repository PostgreSQL test before changing production join. Observed a substantive RED: persisted joiner `fleetId` was `1`, expected `null`. Converted join to the shared transaction/helper; observed GREEN. This is a real public production service/repository execution with controlled lock wait and reloaded migration-backed PostgreSQL state, not a wormhole endpoint test.

Environment checked once: exact worktree/ref/baseline; Node v24.22.1, npm 11.19.1; dependencies and actual root `game-data/data` supplied locally; no `.codegraph/`; both ambient DB URLs unset. No reinstall, new data symlink, indexing or data-cwd workaround. Supplied game data is local input, not a private upstream revision claim.

## Supported transaction and lock contract

Exported seam: `lockFleetParticipants(manager, userId, shipId, targetFleetId?)` in `apps/backend/src/modules/spacecraft/fleet-lock.ts`.

1. Caller must provide an active READ COMMITTED transaction, and call before acquiring spacecraft locks. The active transaction is checked; isolation and prior-lock ordering are documented caller obligations, not runtime-enforced introspection.
2. Initial own-ship read is only a hint for locating an inferred fleet. Explicit target fleet is supported for join/leadership operations.
3. Owned fleet row is locked `FOR NO KEY UPDATE`. This serializes fleet protocol participants without a stronger fleet key lock blocking the FK `KEY SHARE` taken by ship-first writers.
4. Select the full current fleet membership after the fleet lock. Include the initiating ship even when it is not a member. Deduplicate and sort numeric spacecraft IDs ascending.
5. Acquire `FOR UPDATE NOWAIT` on that spacecraft set. PostgreSQL `55P03` becomes `BadRequestException('Flottenzustand ist gesperrt; bitte erneut versuchen')`. No spacecraft lock wait is introduced while holding a fleet lock: an existing ship-first writer cannot complete an inverse wait cycle against us.
6. Recheck initiating ownership and inferred membership after spacecraft locks. Reread membership, require exact complete IDs/cardinality, owned members, and current leader among members. Membership changes refuse the operation; do not discover and then add a second fleet lock out of order. Retry, if desired, is a new caller transaction, not a retry within an aborted transaction. No automatic retry policy was added.
7. Hydrate canonical position relations only after row locks; do not issue FOR UPDATE on nullable relation joins.
8. Return `{ fleet, ship, members }`; `members` is the full locked current fleet in ID order. No-fleet returns `fleet: null`, `members: []`, with the initiating ship locked separately. It does not invent fleet membership or prescribe a wormhole policy.

Post-lock membership/leadership/ownership checks are shared; operation-specific state and location rules remain at the public callers. Existing create has no new destroyed/in-flight/crew eligibility restriction. Existing leadership change has its membership rule, not a newly invented movement rule.

A join committed before full selection is included. A join waiting on a committed relocation receives current leader position and refuses a colocation mismatch. Leadership changing during acquisition is read authoritatively; changed inferred membership is refused rather than switching fleet locks. Missing/deleted fleet/ship can refuse with the existing not-found errors.

The contract selects the fleet, not arbitrary future tractor/takeover/arrival participants. Future callers must place this seam before spacecraft locks and integrate any additional participants without violating its no-inverse-wait contract. Existing ship-first tractor/takeover/destruction paths were inspected only to inform this bounded design, not converted or comprehensively audited.

## Mutation, validation and side-effect seams

- `createFleet`: caller transaction; lock own initiating ship/current fleet if any; validate existing nonmembership/name; create Fleet and narrowly update leader `fleetId` in the same transaction. Assignment failure rolls back the Fleet insert.
- `joinFleet`: target fleet/full participants plus joiner locked; revalidate ownership, nonmembership, existing destroyed/IDLE restrictions, current leadership and canonical colocation; update only `fleetId`; return real `findOne` details after commit.
- `leaveFleet`: infer/lock/revalidate current fleet and ship. Current leader departure dissolves within the same transaction; an old leader that no longer leads only departs. Member update is only `fleetId: null`; details are read after commit.
- `dissolveFleet`: fleet hint locates initiating ID; shared helper returns current fleet and full set. Narrow member departures and Fleet deletion share the transaction; delete failure rolls all departures back.
- `changeFleetLeader`: full helper plus proposed leader; existing current-membership rule after locks; update only Fleet `leaderId`.
- `renameFleet`: owned fleet `FOR NO KEY UPDATE`; update only name. No stale whole-Fleet save.
- `toggleFleetFixation`: full helper/current leader set; update only authoritative toggled `isFixed`. No stale whole-Fleet save.
- Ordinary `prepareFleetMembers`: transaction-bound authoritative member/leader/position selection and existing destroyed/IDLE/crew checks, existing synchronous flight validation and in-memory snapshots. Crew count is manager-bound and uses the existing required-crew rule. Nonfixed flight detaches incapable local members; remote members stay attached/unmoved. Fixed flight still refuses the entire blocked subset with the existing error.
- All blocked-member departures in one ordinary selection are narrow `fleetId: null` updates in one transaction. A later failed departure cannot leave an earlier departure committed.
- Existing `FLEET_MEMBER_LEFT_BEHIND` gateway success events are emitted only after that departure transaction commits. No event for its rolled-back departures. No new outbox or delivery guarantee.
- This is **not** a transaction around the entire ordinary navigation operation. Subsequent movement persistence, other collaborators' existing effects, arrival/cartography/signature/statistics paths and stale whole-ship movement writers remain unchanged. Movement protection belongs to K7a2b; future manager-bound wormhole arrival effects belong to K7a2.

## Exact checked-in source/test scope

Five backend files plus only the K7a2a ticket:

1. NEW `apps/backend/src/modules/spacecraft/fleet-lock.ts` — bounded supported exported helper and contract (lines 12–121; hydration assertion at 118).
2. MODIFIED `apps/backend/src/modules/spacecraft/spacecraft.service.ts` — helper/EntityManager imports, fleet/departure block only (approximately lines 2750–3048). No movement/arrival implementation changes. Unrelated service-tail formatter change was removed before final gates.
3. NEW `apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts` — 22 maintained PostgreSQL cases (870 source lines plus final newline).
4. MODIFIED `apps/backend/src/modules/spacecraft/spacecraft-fleet.service.spec.ts` — existing 12 tests retained; transaction-manager/query-builder adapter, stable ID-based fixtures, current-member fixture sets and outcome assertion for fixation. No skipped/excluded tests, one-shot read-count dependence, any-cast waiver or weakened error rule. Existing any-returning ship factory remains.
5. MODIFIED `apps/backend/src/testing/integration/data-source.ts` — imports/registry entries for existing `SpacecraftTakeover`, `FlightSignature`, `SpacecraftRepairTask`, `StationShipRepair` only. These support actual ordinary navigate collaborators. Fleet/base spacecraft were already registered. No schema/config/package changes.
6. MODIFIED `.scratch/stu-parity/issues/tmw-K7a2a-flottenmutationen-nebenlaeufigkeit.md` — accepted checklist, local-candidate status and evidence comments. No neighboring ticket/map resolution.

Ignored report/logs are not included in the commit.

### Maintained PostgreSQL coverage

- Waiting public join after confirmed relocation refuses old colocation; persisted joiner membership/location/energy and leader location/energy checked (`:807`).
- Creation assignment failure rollback (`:780`).
- Leave and dissolve across relocation retain committed location/resources (`:249`, `:264`).
- Dissolve deletion failure rolls all member changes back (`:752`).
- Proposed leader departed while waiting is refused; old leader ceased leading while leave waited does not dissolve (`:287`, `:306`).
- Adjacent rename/fixation preserve committed new leadership (two cases, `:322`).
- Precommitted join/full helper selection with relocation rollback and commit; all members and unchanged energy reloaded (`:342`, `:373`).
- No-fleet result and active transaction requirement (`:405`).
- Ship-first contention refuses rather than waiting; new transaction succeeds afterward (`:421`).
- Actual public `navigate`: nonfixed local blocked departure, remote-member preservation, later departure failure rollback/no success, fixed refusal/no success (`:494`, `:512`, `:526`, `:561`).
- Opposite initiating spacecraft order serializes complete helper selections; returned IDs ascending (`:580`).
- Valid create/join/leadership transfer/member leave/leader dissolution (`:619`).
- Joiner owner/status changes while waiting revalidated (two cases, `:646`).
- Inferred membership changes to another fleet while leave waits: refusal, new membership preserved, no second fleet lock (`:698`).

Barriers control transaction release. `pg_backend_pid()` plus `pg_blocking_pids(pid)`/`pg_stat_activity` confirms actual lock waiting before release; it is not merely a timing sleep. NOWAIT contention uses a held real spacecraft lock. Temporary failure triggers are removed in `finally`.

Integration service fixture registers real repositories, ShipClassService and all collaborators executed by the covered fleet mutations/ordinary navigation. Gateway is an observation mock. Unexecuted DI boundaries use empty providers. It is deliberately not the full production Nest module graph; it is not full arrival/wormhole/tractor coverage. No mocked persistence constitutes the concurrency proof.

## Focused RED/GREEN commands and recorded results

All logs below are under `.workmux/`. Each row is an actual final recorded focused execution on its successive candidate, not historical baseline or cache output. Some intermediate setup/fix attempts reused the same log file; those are disclosed separately below. All substantive REDs precede their respective production conversion.

Common command, replacing `LOG` with the listed filename:

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL
npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --runTestsByPath apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts > .workmux/LOG 2>&1
```

| Step/log | Exit | Tests | Evidence |
| --- | ---: | --- | --- |
| `k7a2a-red-join.log` | 1 | 1 failed / 1 | Persisted joiner fleetId 1, expected null after controlled relocation commit |
| `k7a2a-green-join.log` | 0 | 1 passed / 1 | New colocation rejection and persisted state preserved |
| `k7a2a-red-create.log` | 1 | 1 failed, 1 passed / 2 | Failed leader assignment left one Fleet row, expected zero |
| `k7a2a-green-create.log` | 0 | 2 passed / 2 | Creation atomic |
| `k7a2a-red-leave.log` | 1 | 1 failed, 2 passed / 3 | Persisted member fleetId remained 1, expected null; committed position was already 2, not evidence of old-position restoration |
| `k7a2a-green-leave.log` | 0 | 3 passed / 3 | Departure and committed resources preserved |
| `k7a2a-red-dissolve.log` | 0 | 4 passed / 4 | Preconversion relocation case **passed**, filename is not RED evidence |
| `k7a2a-red-dissolve-rollback.log` | 1 | 1 failed, 4 passed / 5 | Failed deletion left partial departures |
| `k7a2a-green-dissolve.log` | 0 | 5 passed / 5 | Full rollback |
| `k7a2a-red-leadership.log` | 1 | 1 failed, 6 passed / 7 | Leadership promise resolved instead of refusing departed successor |
| `k7a2a-green-leadership.log` | 0 | 7 passed / 7 | Authoritative membership and leadership |
| `k7a2a-red-adjacent.log` | 0 | 9 passed / 9 | Rename/fixation cases **passed** preconversion; protocol participation/narrow writes, not separately confirmed stale-leader failures |
| `k7a2a-flight-preconversion.log` | 1 | 2 failed, 12 passed / 14 | Fixture setup failures, **not behavioral RED** |
| `k7a2a-red-departure.log` | 1 | 1 failed, 13 passed / 14 | First blocked member detached although later departure failed |
| `k7a2a-green-departure.log` | 0 | 14 passed / 14 | All departures roll back and no success emitted |
| `k7a2a-focused-integration.log` | 0 | 20 passed / 20 | Additional ownership/status/membership/order/valid-path cases |

Focused unit command:

```sh
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/spacecraft/spacecraft-fleet.service.spec.ts > .workmux/k7a2a-focused-units.log 2>&1
```

Final exit 0, 1 suite / 12 tests passed, zero skips (1.924 s).

Spec-inclusive type checks ran early beside focused tests:

```sh
npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --pretty false > .workmux/LOG 2>&1
```

Logs: `k7a2a-types-early.log`, `k7a2a-types-helper.log`, `k7a2a-types-flight.log`, `k7a2a-types-departure.log`, `k7a2a-types-unit-adapter.log`, `k7a2a-types-candidate.log`. Their final corrected executions exit 0. Empty successful type logs are normal; execution exit, not text presence, is the evidence. Build mode can use incremental compiler state.

### Intermediate failures and evidence limitations

- Initial integration fixture needed an unexecuted BuoyRepository DI provider; typecheck rejected metadata `string | Function` passed to getRepositoryToken. Corrected with typed existing entity registry. Those failures are setup/type failures, not join RED proof. The join log was reused; the final recorded substantive RED is the persisted fleetId failure.
- Temporary unused EntityManager import was resolved when transactional dissolution was implemented.
- Ordinary flight fixture initially lacked required `StarSystem.systemTypeId` and `SystemField.fieldTypeId`; corrected to actual fixture values. These setup failures are not movement/departure defect proof. `k7a2a-flight-preconversion.log` retains setup failures; the reused departure log contains the final substantive rollback RED.
- Existing fleet unit adapter first failed 6/12, then 5/12 while correcting clone semantics, one-shot lookups and membership filtering. TS7006 callback annotations and self-referential builder TS7022/7024 were corrected. Final unchanged behavioral suite passes 12/12; no skips or casts added to suppress failures.
- Read of nonexistent `spacecraft.service.spec.ts` was an exploration ENOENT, then correct fleet spec located; not a blocker.
- Logs with reused filenames are not an immutable history of every attempt. Raw session transcript retains the attempts; do not describe overwritten setup logs as independent green/red evidence. No supplied baseline audit was rerun.

## Final targeted and broad candidate gates

Stable production/test candidate was finalized before these executions. No substantive production/test edits remain after the gates: a transient guarded hydration cleanup was immediately reverted to the tested non-null assertion. Only ticket/report bookkeeping follows. Broad gates were each launched once; complete PostgreSQL ran as tracked task `bq8me88gb`, completed exit 0, not duplicated after background transition.

### Targeted PostgreSQL plus existing relevant integration

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL
npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --runTestsByPath apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/escape-pod.int-spec.ts apps/backend/src/testing/integration/connection.int-spec.ts apps/backend/src/testing/integration/smoke.int-spec.ts > .workmux/k7a2a-targeted-integration.log 2>&1
```

Exit 0, **4/4 suites, 30/30 tests, zero skips**, 27.591 s. Final fleet file contains 22 cases; the earlier 20-case focused log is not the final targeted count.

### Required broad gates (actual candidate executions)

```sh
NX_DAEMON=false npm exec --offline -- nx run backend:lint --skip-nx-cache > .workmux/k7a2a-gate-lint.log 2>&1
npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --pretty false > .workmux/k7a2a-gate-types.log 2>&1
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand > .workmux/k7a2a-gate-units.log 2>&1
NX_DAEMON=false npm exec --offline -- nx run backend:build --skip-nx-cache > .workmux/k7a2a-gate-build.log 2>&1
unset DATABASE_URL INTEGRATION_DATABASE_URL
npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand > .workmux/k7a2a-gate-postgres.log 2>&1
```

| Gate/log | Exit | Result/cache disclosure |
| --- | ---: | --- |
| `k7a2a-gate-lint.log` | 0 | 0 errors, 1424 warnings; executed with Nx cache disabled |
| `k7a2a-gate-types.log` | 0 | Spec-inclusive tsc build; may reuse compiler incremental state, not claimed clean rebuild |
| `k7a2a-gate-units.log` | 0 | **211/211 suites, 1981/1981 tests, 1/1 snapshot, zero skips**, 83.913 s; actual Jest execution |
| `k7a2a-gate-build.log` | 0 | Executed shared tsc build dependency and backend webpack; webpack success `6a00316cd7c343e5`; Nx cache disabled |
| `k7a2a-gate-postgres.log` | 0 | **37/37 suites, 312/312 tests, zero skips**, 276.473 s; actual full migration-backed PostgreSQL execution |

Historical supplied 211/1981 units and 36/290 PostgreSQL were not candidate gates. Candidate units happen to retain 211/1981 because existing unit cases were preserved; full PostgreSQL adds one suite/22 cases to 37/312. These numbers come from actual new executions above, not copied prerequisites.

Every integration command unsets both `DATABASE_URL` and `INTEGRATION_DATABASE_URL`, uses the existing shared Testcontainers PostgreSQL 16 harness and real repository migrations (`synchronize: false`). Each execution reuses the harness conventions for its tests; no separate full migration setup per test/probe. No shared stu-db-1/dev DB. Standard harness teardown and data-source close completed; command exits normally. No frontend gates, `passWithNoTests`, test skips or reinstall.

### Disclosed warnings and non-success log text

- Lint 1424 warnings remain, unsuppressed. New helper hydration non-null assertion at `fleet-lock.ts:118` contributes one warning. Existing fleet unit factory any remains at its shifted line. No any waiver or lint disable was introduced.
- ts-jest isolatedModules option deprecation.
- pg driver warning about concurrent client.query calls and future pg@9 removal.
- Full PostgreSQL log includes the existing AllianceBannerService deliberately exercised storage-deletion failure (`asset storage unavailable`), then all suites/tests pass. It is not a hidden failed gate.

## Gated backend file fingerprints (SHA-256)

These identify the tested source/test bytes; no substantive edit after final gates.

```text
7830e6386018f81e4cffcd3543e1d0eb6ab06e67e5d362cda24911e1377c8fe8  apps/backend/src/modules/spacecraft/fleet-lock.ts
3b9df50950acedb09ac157bc1696a63d0e96fbf277cd92d9418b63908a8b02d6  apps/backend/src/modules/spacecraft/spacecraft.service.ts
aed7556a03c1d55c4122e7329f3e79e18640ee0e1943cd1acafbc7d4dbd0364c  apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts
e9ac2d928f3b03499fd15e52aca39739fc2a64e1db081516bed4adad492fd653  apps/backend/src/modules/spacecraft/spacecraft-fleet.service.spec.ts
39b163de90ef9a39ecc9f4b8cc1b75d6a8a23505c9d1f58e70f3c92e64a71ac1  apps/backend/src/testing/integration/data-source.ts
```

## Review boundary and stop

Independent review should focus on the helper's documented READ COMMITTED/prior-lock prerequisites, complete-member post-lock checks, NO KEY UPDATE + spacecraft NOWAIT interaction with existing ship-first participants, post-wait operation-specific validation, and ordinary departure rollback/after-commit notification boundaries. Tests establish the bounded scenarios above, not universal all-writer deadlock/stale-movement safety.

No full-Spacecraft persistence refactor, all-writer audit, new eligibility/resource tariff, new retry policy, wormhole endpoint/passage/arrival adapters or architecture. Fleet protocol refuses contention/membership changes rather than guessing a new participant set or adding inverse-order waits. Existing stale movement protection remains K7a2b. Future full relocation and manager-bound wormhole arrival effects remain K7a2.

Stop here. No integration until independent narrow review; coordinator performs serial integration. Do not start the neighboring tasks from this worktree.

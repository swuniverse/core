# tmw-K7a2b — overlapping movement identity follow-up

Date: 2026-11-09. Bounded implementation and fresh final gates complete. Awaiting focused independent re-review; no revised independent PASS or integration is claimed.

## Ref, review inputs and scope

- Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2b`.
- Branch: `agent-tmw-k7a2b`.
- Follow-up parent: `c212d12d28d8edd059b3148dcec638dcd44faac1`, NOT integrated. Preserve this commit/history and its original report/logs.
- Integrated prerequisite base supplied by user: `9219a25e6965814064fc834821f04847748b1ff5`. No main/other-checkout access or merge performed in this follow-up.
- Verified follow-up commit: `59f716f9fbc3056371ff16ebe61c21fac5e45006`, directly on parent `c212d12d28d8edd059b3148dcec638dcd44faac1`. No amend or integration.

Read supplied reports FIRST: `.workmux/local-inputs/review-fix/standards.md` (original Standards PASS, zero findings) and `spec.md` (original Spec BLOCKED, one CONFIRMED P2 valid-movement regression). Read `alias-state-probe.cjs`; did not execute it in this follow-up or use it as durable acceptance evidence. Those review dispositions apply to c212d12d, not an independently reviewed revised candidate.

Only two tracked files differ from c212d12d:

1. `apps/backend/src/modules/spacecraft/spacecraft.service.ts`: only `saveMovementParticipants`, starting at line 2301.
2. `apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts`: one added public two-field navigate regression, starting at line 1005.

Final diff: 2 files, 284 insertions, 86 deletions. Production diff includes callback indentation from returning committed transaction rows. No semantic change outside the helper. `.workmux/k7a2b-scope-proof-alias.log` proves service prefix/suffix outside the helper are byte-identical to c212d12d and removing the added regression restores the entire original test file byte-for-byte. Thus no existing assertion was weakened, reformatted or removed in the final candidate.

No tracker, neighboring ticket, map, DECISIONS, package/lock/Nx/config, schema/migration/entity, STU/index, planner, wormhole/arrival, frontend, or unrelated-writer change. Original tracker completion is inherited implementation status, NOT revised Spec acceptance or integration. The bounded fix completed; no failure-status correction was required. No nested agents/workflows, new architecture/product prohibition, external service/secrets, reinstall, push, merge, PR, amend or lost history. No CodeGraph index exists here; none initialized.

## Confirmed defect and identity semantics

Supported state: an owned local IDLE spacecraft is both a selected fleet member and the leader's tractor target. Fleet preparation and separate target findOne load different JavaScript objects sharing one spacecraft ID. Object-identity Set deduplication previously admitted both writes: the selected object supplied paid/activated state, then the carried alias supplied old EPS/runtime. Their next-step snapshots contradicted the one persisted row, so a valid second field rejected with `veraltet` despite no competing commit.

The bounded helper now:

- Retains distinct loaded objects as `aliases`, so **every original observation** still validates against authoritative current state before any write.
- Chooses moving canonical state with `Map<number, Spacecraft>`. Selected participants precede carried objects: the selected participant owns its existing payment/runtime mutations; a carried alias cannot overwrite them.
- Resolves/reuses authoritative current rows through `Map<number, Spacecraft>` and leader ID, not object identity.
- Saves canonical movement state once per spacecraft ID, using the existing bounded `applyMovementState` on the locked current entity.
- Returns committed current rows from the transaction. After successful commit, applies their bounded fields to **every alias** and only then captures each alias's next original and advances expected fleet location. All aliases now share one committed row state/baseline.

Original snapshots remain per loaded object deliberately: canonicalizing writes must not discard a stale original from an independently loaded alias. Optional module hydration remains per alias; no wholesale whole-entity copy or new snapshot architecture. Existing lockFleetParticipants order, carried NOWAIT locks, full expected fleet checks, terminal/stale distinction, module locks and crew/incoming-tractor checks remain. Failed validation still precedes writes and success effects.

No tariff change or fleet-member towing prohibition. Existing navigate policy charges the leader its ordinary field cost plus target field towing cost; a selected fleet member pays its ordinary selected-member field cost. In the worked two-field fixture, each cost is 1 EPS:

- Leader: 71 - 2 × (1 ordinary + 1 towing) = **67 EPS**.
- Selected/towed member: 53 - 2 × 1 ordinary = **51 EPS**.
- Drive activation retains existing free behavior. Tractor is already active, so this case has no separate tractor activation charge. No undocking or field consequence cost in this fixture.

This retains the caller's existing selected-participant charges; it does not invent a new double-charge policy. Removing the alias overwrite allows those already applied charges/runtime changes to persist coherently.

## Public regression and TDD evidence

New case: `navigates two fields when the towed ship is also a selected fleet member`.

Real disposable PostgreSQL16, checked-in migrations, actual repositories/transactions and public `SpacecraftService.navigate(ship.id, ship.userId, 3, 1)`. Three adjacent system fields; owned local IDLE member with inactive installed sublight drive, same fleet, enough EPS; leader has installed drive/sensors/tractor and an already active towing link. Production navigation executes its actual drive activation, fleet selection, separate carried-target load, per-field charges, shared persistence and signatures. No competing transaction introduced: this directly reproduces a valid movement regression, not an artificial stale-writer race.

Literal assertions: final field for returned leader and persisted member/leader; 67/51 EPS; IDLE and preserved member fleet; preserved towing link; member activated sublight runtime including integrity100/cooldown0; leader active tractor and sublight. Exactly eight ID-ordered signatures: leader origin1 null/EAST, leader destination2 WEST/null, member origin1 null/EAST, member destination2 WEST/null; then the same leader/member ordering for origin2→destination3. No extra carried-only signature. No gateway/system-message notification in this consequence-free case.

**Meaningful RED before production edit, against c212d12d:**

1. `.workmux/k7a2b-red-public-alias.log`: filtered new case, exit1, 1 failed/23 deselected (Jest labels these skipped), 24 total, 8.955s. Real rejection instead of successful movement: `BadRequestException: Bewegungszustand ist veraltet; bitte erneut versuchen`. This is not zero-skip suite evidence; no skip markers were introduced.
2. Immediately reran the **entire movement suite without a name filter**: `.workmux/k7a2b-red-suite-alias.log`, exit1, 1 failed/23 passed/24 total, **zero skips**, 20.074s. Same false-stale public failure. This supplies the required full-suite behavioral RED; not a setup error or helper-only probe.

Commands:

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts --testNamePattern='navigates two fields when the towed ship is also a selected fleet member' > .workmux/k7a2b-red-public-alias.log 2>&1
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts > .workmux/k7a2b-red-suite-alias.log 2>&1
```

After the bounded fix, initial GREEN `.workmux/k7a2b-green-focused-alias.log`: exit0, 2 movement/fleet suites, 46 tests, zero skips, 34.251s. Existing focused units `.workmux/k7a2b-focused-units-alias.log`: exit0, 3 suites/44 tests, zero skips, 2.222s. Forced types `.workmux/k7a2b-types-alias.log`: exit0. Final-byte reruns below supersede these intermediate results.

## Formatting/tooling transparency

Formatter touched unrelated service suffix and existing tests. Removed that formatting-only churn while retaining the helper/new regression, before final gates. Logs: `k7a2b-format-alias.log`, `k7a2b-format-test-alias.log`, `k7a2b-final-scope-restored-alias.log`.

First local Node scope-restoration invocation failed to parse due to shell quoting of apostrophes in test names, exit1: `k7a2b-final-scope-alias.log` (`Unterminated string constant`). No script executed or source changed in that failed invocation. Corrected invocation used explicit quote character construction, exit0, recorded separately without overwriting the failed log. This tooling failure is not behavioral RED. Final scope proof and diff check pass.

## Fresh final gates on final fixed bytes

Final source/test SHA-256 fingerprints were recorded before the broad gates and verified unchanged afterward. No further source/test edits. All commands below exit0. All final tests have **zero skipped/todo cases**. Original c212d12d broad counts are historical, not reused as revised evidence.

| Gate | Actual revised result | Log under `.workmux/` |
|---|---|---|
| Changed-scope lint | 0 errors, 17 retained non-null-assertion warnings; no warning in new regression | k7a2b-final-lint-alias.log |
| Forced production/spec/reference types | exit0; empty successful log | k7a2b-final-types-alias.log |
| Focused movement/fleet PostgreSQL | 2 suites, 46 tests passed, 35.809s | k7a2b-final-focused-postgres-alias.log |
| Existing resource/fleet/cartography tests | 3 suites, 44 tests passed, 2.287s | k7a2b-final-focused-units-alias.log |
| Complete backend units ONCE | 211 suites, 1981 tests passed, 1 snapshot, 62.193s | k7a2b-final-units-alias.log |
| Backend build ONCE | shared + backend tasks succeeded; webpack 840492acd7befbaa | k7a2b-final-build-alias.log |
| Full PostgreSQL ONCE | 38 suites, **336 tests** passed, 219.081s | k7a2b-final-full-postgres-alias.log |

Exact commands, all from this worktree root using existing dependencies/root local game data:

```sh
npm exec --offline -- eslint apps/backend/src/modules/spacecraft/spacecraft.service.ts apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts --no-cache > .workmux/k7a2b-final-lint-alias.log 2>&1
npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --force > .workmux/k7a2b-final-types-alias.log 2>&1
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts > .workmux/k7a2b-final-focused-postgres-alias.log 2>&1
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/spacecraft-movement-resources.spec.ts apps/backend/src/modules/spacecraft/spacecraft-fleet.service.spec.ts apps/backend/src/modules/spacecraft/cartography-lifecycle.integration.spec.ts > .workmux/k7a2b-final-focused-units-alias.log 2>&1
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache > .workmux/k7a2b-final-units-alias.log 2>&1
NX_DAEMON=false npm exec --offline -- nx run backend:build --skip-nx-cache > .workmux/k7a2b-final-build-alias.log 2>&1
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache > .workmux/k7a2b-final-full-postgres-alias.log 2>&1
```

Cache/output: Jest and ESLint result caches disabled. TypeScript spec-inclusive build used `--force`, including production/references, writing normal out-tsc outputs. Nx result cache disabled and daemon off; shared build invokes normal `tsc --build tsconfig.lib.json`, which can reuse existing TypeScript incremental outputs already forced/typechecked by the explicit type gate. No claim that every dependency compile ignores incremental artifacts. Build produces normal webpack outputs. Final broad gates executed once each, concurrently after final focused/types/lint completion; no repeated broad TDD passes and no frontend run.

Warnings retained in logs: ts-jest isolatedModules deprecation; pg concurrent-client-query deprecation. Full units include expected failure-path application ERROR/WARN logging; Jest reports all tests passing. Unit log text saying game ticks were 'skipped' describes domain behavior, not skipped Jest tests. Existing helper non-null assertion remains at service line2422; not hidden or suppressed.

Every PostgreSQL command explicitly unsets both DATABASE_URL and INTEGRATION_DATABASE_URL and uses the unchanged disposable PostgreSQL16/migrations harness. No shared/dev database, synchronize, migration generation, harness change, passWithNoTests or data-directory workaround.

## Final source/test/prerequisite SHA-256

Prefix: `apps/backend/src/modules/spacecraft/`. Machine-readable evidence: `.workmux/k7a2b-final-fingerprints-alias.json`.

```text
d1ca45dac5fff29cba23d7fbce0b68b41afc968060612176a7212ea0bad7bdc6 movement-state.ts (unchanged)
90d7c8fabf7541563b4025e95cbcde5cabec9d6332f6bdda98197716a76ea020 movement-concurrency.int-spec.ts
a3bd3ead4c80ba1c2a680f0de093d42b77bc6330ff64ec92a9314c4af468920e spacecraft.service.ts
59965007d3b7ee63f14fe38f3dec66b883ecc43ec76261a6050908dc44bcc798 spacecraft-destruction.service.ts (unchanged)
953c008f6a2dcb69fb8fe4d73b3020b94754a97f4e8b0df6f36245c8ba09a371 spacecraft-movement-resources.spec.ts (unchanged)
109e409cca68053cc8d04a1248a6a00fad5264143c7f20b46cb26f3ebb9168b1 spacecraft-fleet.service.spec.ts (unchanged)
d88a895c03cfe82f4d1c4159cb59bc1b6fc3a3d9002dadcd5d29a511fc71d93b cartography-lifecycle.integration.spec.ts (unchanged)
7830e6386018f81e4cffcd3543e1d0eb6ab06e67e5d362cda24911e1377c8fe8 fleet-lock.ts (unchanged prerequisite)
```

## Limitations and handoff

Public regression uses a supported **already-active tractor fixture**, not public tractor activation; its standalone activation cost/endpoint is not asserted. The actual existing navigate activation/fleet/target rules execute. Partial Nest TestingModule uses real executed collaborators and observation gateway/messaging mocks, with placeholders for unexecuted dependencies; not an entire production-application acceptance claim. Database assertions observe durable persistence at the explicitly requested public movement seam. Literal resource/signature expectations are independent worked examples, not snapshots recomputed from implementation.

No new arbitrary all-writer, predicate-lock, whole-route/arrival/effect/outbox atomicity claim. Existing scoped stale-lock protection and prior committed-step behavior remain. All old tests remain byte-identical, including separate towing, fleet policy, cartography and concurrency assertions.

One attributed follow-up commit created: `59f716f9fbc3056371ff16ebe61c21fac5e45006`, commit exit0 (`k7a2b-followup-commit-alias.log`). Post-commit verification exit0 (`k7a2b-postcommit-verification-alias.log`): expected c212d12d parent, exactly the two scoped paths, message ends `Co-Authored-By: Claude Code <noreply@anthropic.com>`, clean working tree, report ignored, every working/committed fingerprint matches the final tested bytes. Only this ignored evidence report was updated after verification; no source edits or broad rerun after commit. No amend/merge. Worktree/ref and all previous evidence preserved. **Stopped for focused independent re-review** of the confirmed alias finding; no independent approval or serial integration inferred.

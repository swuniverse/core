# K7a2b alias follow-up — independent Spec re-review, 2026-11-09

**Spec: PASS. Prior confirmed overlapping-ID P2: FIXED.**

Parent: `c212d12d28d8edd059b3148dcec638dcd44faac1`.
Revised candidate: `59f716f9fbc3056371ff16ebe61c21fac5e45006`.
Narrow review of their three-dot diff: one direct-child commit, exactly two files. Source read from Git objects, not old working files. Standards remains separate.

## Spec findings — under 400 words

**(a) Missing/partial requirements:** none verified in this follow-up.

**(b) Unasked scope:** none verified. No new towing restriction, tariff, lock contract, whole-flight/arrival/outbox or all-writer redesign.

**(c) Prior P2 — FIXED.** Authoritative issue at BASE `9219a25e`, `.scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md:23`: “Gültige gewöhnliche Bewegung und bestehende partielle Flottenpolitik bleiben erhalten. Keine Änderung des Ressourcentarifs, kein Rewrite sämtlicher Schiffs-Writer und keine Wurmlochimplementierung.”

Revised `apps/backend/src/modules/spacecraft/spacecraft.service.ts:2307–2437` retains every independently loaded alias and validates each original before any save. Canonical writers and locked current rows use spacecraft IDs. Participants precede carried aliases, preserving selected-member payment/runtime mutations; each ID is saved once. After successful transaction resolution, the committed bounded row state is copied to every alias and detached baselines/fleet locations advance. Validation/save/commit rejection cannot reach that reconciliation; pre-existing caller-local mutations are not claimed rolled back. Module hydration stays alias-specific. Field consequences still run after persistence, leaving the prior committed comparison baseline intact until the next successful step.

New `movement-concurrency.int-spec.ts:1005–1183` invokes actual public two-field `navigate` with one spacecraft both selected member and tractor target. Real repositories reload durable positions, runtime, fleet membership and towing; literal assertions require leader/member EPS **67/51** and exactly **eight** ordered signature records. No persistence/private-method mock or weakened old test.

**Remaining contract:** reuse the prior Spec review's accepted bounded contract; its only blocker is now fixed. No broad audit restarted.

## Actual evidence and limits

Independently matched **8/8 SHA-256 fingerprints** to revised Git blobs: service/test revised, other six unchanged. Service outside the helper is byte-identical; removing the sole 180-line test insertion restores the entire prior test file byte-for-byte. No skip/only/todo declarations. Ref/scope/hash/source/log assertions, `git diff --check`, and final ignored-report/clean-worktree verification passed; all three reviewer shell invocations exited **0**.

Supplied actual logs checked, **not rerun**:

| Evidence | Observed output; exits supplied by worker report |
| --- | --- |
| Full public movement RED before fix | 1 failed / 23 passed / 24 total; false `veraltet` rejection; report exit 1 |
| Revised movement + fleet PostgreSQL | 2 suites / 46 tests passed |
| Revised full PostgreSQL | 38 suites / 336 tests passed |
| Revised focused units | 3 suites / 44 tests passed |
| Revised full units | 211 suites / 1981 tests; 1 snapshot passed |
| Changed-scope lint | 17 warnings / 0 errors |
| Build | Shared/backend success; webpack `840492acd7befbaa` |
| Forced production/spec/reference types | 0-byte log; command and exit 0 are worker-report evidence, not inferred from emptiness |

Test totals show no skipped cases. Fingerprints bind supplied tested-byte claims to candidate objects, not independent execution provenance. Existing disposable migration-backed harness and actual executed collaborators were already reviewed; the new case uses an already-active tractor fixture, not public tractor activation. After-commit/failure reconciliation ordering is source-verified, not separately fault-injected. No supplemental probe, installation, gate/DB rerun, agent or external service used.

HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`; tracked worktree clean before report creation. Only this ignored report written. **Stopped: no integration, issue resolution, tracked edit, branch switch, commit, merge or push.**

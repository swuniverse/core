# tmw-K7a2b — stale ordinary movement candidate

Date: 2026-11-09. Implementation complete; awaiting independent review and serial integration. No independent PASS is claimed.

## Ref and scope

Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2b`.
Branch: `agent-tmw-k7a2b`.
Verified base and pre-commit HEAD: `9219a25e6965814064fc834821f04847748b1ff5` (integrated K7a2a).
Candidate commit: `c212d12d28d8edd059b3148dcec638dcd44faac1` (verified post-commit).

Changed source/tests: movement-state.ts, movement-concurrency.int-spec.ts, spacecraft.service.ts, spacecraft-destruction.service.ts, spacecraft-movement-resources.spec.ts, spacecraft-fleet.service.spec.ts, cartography-lifecycle.integration.spec.ts, all under `apps/backend/src/modules/spacecraft/`.
Only tracker change: K7a2b status/checklist. No neighboring issue, map, DECISIONS, architecture, package, lockfile, Nx, migration, entity schema, STU/source-index, frontend, planner, wormhole, or arrival implementation change.
No nested agent/workflow, external service/secrets, reinstall, push, merge, PR, main or other-checkout access. Commands ran in this worktree using normal npm permissions. Formatting-only changes in the unrelated spacecraft-service suffix were removed before final gates.

## Contract and preconditions

1. Capture a detached original immediately after production findOne, before activation, runtime initialization, undocking, payment, direction or location mutation. Fleet members are captured in the authoritative fleet preparation callback before member mutation; carried navigation target is captured after its real load before mutation.
2. Each ordinary step opens a caller-owned explicit READ COMMITTED transaction and calls unchanged lockFleetParticipants **before spacecraft locks**. Fleet NO KEY UPDATE precedes complete ID-sorted spacecraft FOR UPDATE NOWAIT. The helper's authoritative membership/ownership/leader checks and inference-change refusal remain unchanged. No second fleet lock is added or chased.
3. Revalidate the original bounded row state, full expected fleet IDs/leader/fixation and member locations. Remote attached members remain remote and attached in valid flight; a location change that invalidates the selected subset rejects. A new join rejects. Valid local incapable nonfixed departures retain the prerequisite's distinct preparation transaction; fixed fleets still refuse.
4. Under ship locks revalidate current crew count against crewRequired, incoming leader tractor exclusion, and originally hydrated module-backed eligibility (ID/category/type/integrity/cooldown/activity, ID sorted). Module and the bounded carried-target locks use NOWAIT. The single carried target is a navigate-specific extension, **not** an imaginary universal fleet/tractor/arrival helper contract. No additional fleet is locked for it.
5. Original state contains identity/owner/class/kind, location/status/operating mode/fleet/dock/tractor, EPS and capacities, warp charge/cooldown and capacities, reactor resources/capacities/output, shields/hull and capacities, crew requirement, runtime JSON, sensor cooldown, direction, arrival/origin/target IDs. Comparisons use node isDeepStrictEqual, including order-independent JSON-object equality. Modules are compared only when originally hydrated; legacy member runtime semantics are retained.
6. Validate every moving participant before saving any. Apply only bounded movement fields and location relations to the **current locked row**, preserving unrelated committed battery/name/settings changes. Movement originals advance only after successful step commit. Subsequent local field consequences are applied with the next valid step; the previous persisted step remains the CAS baseline, not a fresh recapture from the database.
7. Fleet preparation revalidates the original leader (including terminal destruction and originally hydrated modules/incoming tractor) before departures or departure events. This is still not whole-flight atomicity. A departure already validly committed in that separate transaction is not rolled back by a later conflict.
8. Optional-original saveUnlessDestroyed is row-lock snapshot protection, not fleet-participant serialization. Missing/destroyed still return false before original comparison. Stale state throws BadRequestException containing `veraltet`; contention refuses distinctly. Calls without originals retain their prior semantics, including intentional saveCombatSurvivor updates. No all-writer or whole-flight safety claim.

Supported related-writer boundaries: fleet mutations follow K7a2a. Existing tractor activation/crew ship-transfer paths lock their affected spacecraft; querying eligibility while holding that ship lock excludes their commits during the step. Existing module rows are locked NOWAIT to serialize updates/deletes. No table/predicate lock, version migration, serializable isolation, or rewrite of unrelated writers was introduced; this does not claim protection against arbitrary out-of-contract insertion/mutation after checks.

## Production callers and rejected effects

Current source anchors: navigate:1970, flyGalaxy:2185, saveMovementParticipants:2301, enterSystem:2466, leaveSystem:2631, legacy warp:2729, prepareFleetMembers:2925. Saver: spacecraft-destruction.service.ts:131; combat survivor:159.

navigate includes both fleet participants and the previously direct tractor save in the bounded step transaction. enterSystem/leaveSystem/warp direct member saves now participate with the leader; there are no stale direct-member bypasses at the ticket's revalidated sites.

Signatures, layer knowledge/discovery, field consequence pipeline, cartography arrival reward, flown-field statistics, post-flight repair cancellation/orbit updates follow successful persistence. An exception rejects before those step effects, including stale leader rejection. Existing preflight cartography-reset/takeover-cancel behavior was retained; those are not claimed to be part of step atomicity. No outbox/effect-atomicity redesign.

A real PostgreSQL public-caller regression proves first-step signatures/state survive later-step stale rejection, and the rejected later destination has no effect notification. Prior genuinely committed steps are not rolled back.

## Cost, ordinary policy and destruction boundaries

No tariff changes. Drive activation stays free, undocking retains 1 EPS, navigate/flyGalaxy retain ship-class per-field EPS, towing retains target flight EPS, legacy warp retains max(1, galaxy distance) charge, existing timing/cooldown. Durable valid movement: 71 EPS -> 69 over two ordinary fields; two signature records per field. Valid local deterministic EPS leak plus second field yields 64 (71 - 1 - 5 - 1). These passing preservation tests did not require a new fix.

Existing focused movement resources (24), fleet policy (12), cartography lifecycle/destruction and existing real fleet tests preserve assertions. Real nonfixed incapable-member departure, unchanged remote attachment, fixed refusal, and departure rollback are covered by unchanged fleet-concurrency.int-spec.ts.

Missing/terminal saver returns false; terminal movement leader refuses `Ship is destroyed` rather than stale, without signatures/discovery/field effects. Terminal leader in preparation does not detach another member. Missing movement initiator retains NotFound via the shared helper. Combat survivor intentionally sets IDLE and persists combat damage/resources without movement-original preconditions; standalone real persistence tests confirm success and terminal false. No combat/arrival redesign or blanket-stale treatment of consequence writes.

## Maintained tests and test seams

23 new cases in movement-concurrency.int-spec.ts. Public production saver and actual navigate/flyGalaxy/enterSystem/leaveSystem/warp seams with real entities/repositories/transactions/migrations. afterLoad subscribers pause actual production loads; barrier release occurs in finally. The saver regression observes actual PostgreSQL lock waiting using backend PID, pg_stat_activity and pg_blocking_pids, then verifies the simulated relocation's committed state wins.

The relocation is simulated, not a full wormhole/navigation relocation endpoint. Caller tests use actual movement methods, not private method monkeypatching. Gateway/messaging mocks are observation boundaries. Nest TestingModule supplies real executed movement, destruction, runtime, field executor/pipeline, exploration/knowledge, signature/statistics collaborators and {} placeholders for unexecuted dependencies. This is not a full production Nest graph acceptance claim; complete backend units also pass the unchanged production graph tests.

No new any casts, lint suppression, skipped tests, weakened existing assertions, synchronize, generated migrations, shared/development DB, or data-cwd/passWithNoTests workaround. Actual root local game-data/data used. DATABASE_URL and INTEGRATION_DATABASE_URL unset for every PostgreSQL run; normal harness starts disposable PostgreSQL16 with real checked-in migrations.

## Incremental TDD evidence

All paths below are ignored `.workmux/` logs. Behavioral RED exit 1 and GREEN exit 0, unless explicitly noted. Integration command form:
`unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --runTestsByPath <paths> > <log> 2>&1`.
Default path is the new movement suite. Green entries that also include existing fleet suite are marked +fleet (22 tests).

| Slice | RED log and counts | GREEN log and counts |
|---|---|---|
| Real saver lock-wait relocation overwrite | k7a2b-red-saver.log: 1 failed/1 | k7a2b-green-saver.log: 1 passed |
| Public flyGalaxy old-origin overwrite | k7a2b-red-caller.log: 1 failed,1 passed/2 | k7a2b-green-caller.log: 2 passed |
| Public navigate resource-only | k7a2b-red-navigate-retry.log: 2 failed,1 passed/3; second failure was mock-history isolation, not production | k7a2b-green-navigate.log: 3 passed |
| Direct enterSystem member | k7a2b-red-direct-entry.log: 1 failed,3 passed/4 | k7a2b-green-direct-entry.log: 4 passed |
| Direct leaveSystem member | k7a2b-red-direct-exit.log: 1 failed,5 passed/6 | k7a2b-green-direct-exit.log: 6 passed |
| Eligible legacy warp member | k7a2b-red-direct-warp-member.log: 1 failed,6 passed/7 | k7a2b-green-direct-warp.log: 7 passed |
| Direct tractor target | k7a2b-red-direct-tractor.log: 1 failed,7 passed/8 | k7a2b-green-direct-tractor.log: 8 passed |
| New fleet join | k7a2b-red-membership.log: 1 failed,12 passed/13 | k7a2b-green-membership.log: 35 passed +fleet |
| Stale leader before preparation departure | k7a2b-red-preparation.log: 1 failed,13 passed/14 | k7a2b-green-preparation.log: 36 passed +fleet |
| Removed installed drive module | k7a2b-red-module.log: 1 failed,14 passed/15 | k7a2b-green-module.log: 37 passed +fleet |
| Remote attached member moves into selected origin | k7a2b-red-remote-selection.log: 1 failed,15 passed/16 | k7a2b-green-remote-selection.log: 38 passed +fleet |
| Whole-old-entity restores unrelated battery/name | k7a2b-red-unrelated-writes.log: 1 failed,18 passed/19 | k7a2b-green-unrelated-writes.log: 41 passed +fleet |
| New incoming tractor | k7a2b-red-incoming-tractor.log: 1 failed,19 passed/20 | k7a2b-green-incoming-tractor.log: 42 passed +fleet |
| Terminal fleet-preparation distinction | k7a2b-red-terminal-preparation.log: 1 failed,21 passed/22 | k7a2b-green-terminal-preparation.log: 44 passed +fleet |

Preservation additions already passed without production fixes: k7a2b-valid-movement.log 5 passed; k7a2b-red-consequence-next-step.log 12 passed (**filename is not a behavioral RED**); k7a2b-preserved-step-terminal.log 18 passed; runtime caller assertion in terminal-preparation RED passed; k7a2b-crew-eligibility.log 23 passed. Runtime saver-only, missing/destroyed and combat-survivor cases were incrementally retained.

Setup/type failures kept separately, not accepted as behavior RED: k7a2b-red-navigate.log disposable-container port startup failure; normal retry used, no harness changes. k7a2b-red-direct-warp.log timeout (leader drive inactive), k7a2b-red-direct-warp-fixture.log excluded inactive member; corrected fixture made eligible-member RED above. Existing adapters initially lacked transaction/module query support: focused-units-initial and focused-module-adapters logs 18 failed/40 passed; fleet adapter recursion 10 failed/2 passed, missing fleet relation 2 failed/10 passed; corrected adapters verified 58/58. Module-adapters-final log contained missing import/signature issues, not behavior proof. All final assertions unchanged.

Early spec-inclusive types used `npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json`; these can reuse TypeScript incremental/reference outputs, not Nx cache. Types-caller/entry/module/module-adapters/incoming-tractor logs preserve transient errors; final types-terminal-preparation exit0. Final forced typecheck below supersedes early incremental evidence.

## Fresh final gates (one candidate)

All ran after final source/test changes and formatting; no later source/test edits. Tracker and evidence only follow these gates. Every final command exit 0. All commands ran from worktree root. No cached Nx/Jest result was used; TypeScript final forced references.

| Gate | Exact command | Result | Log |
|---|---|---|---|
| Backend lint | `NX_DAEMON=false npm exec --offline -- nx run backend:lint --skip-nx-cache` | 0 errors, 1428 warnings | k7a2b-final-lint.log |
| Production + all specs types | `npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --force` | exit0, forced rebuild/typecheck; normal out-tsc artifacts written | k7a2b-final-types.log (empty successful output) |
| Complete backend units | `npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache` | 211 suites,1981 tests passed; 1 snapshot; ZERO skips; 50.184s | k7a2b-final-units.log |
| Build ONCE | `NX_DAEMON=false npm exec --offline -- nx run backend:build --skip-nx-cache` | webpack success dfa4c98e0a402365; backend +1 dependency task | k7a2b-final-build.log |
| Targeted PostgreSQL | `unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/starmap-visibility.int-spec.ts apps/backend/src/modules/spacecraft/starmap-contacts-requests.int-spec.ts apps/backend/src/modules/spacecraft/escape-pod.int-spec.ts` | 5 suites,67 tests passed; zero skips; 40.052s | k7a2b-final-targeted-postgres.log |
| Full PostgreSQL ONCE | `unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache` | 38 suites,335 tests passed; zero skips; 218.363s | k7a2b-final-full-postgres.log |

Warnings explicitly retained: ts-jest isolatedModules deprecation and pg concurrent-client-query deprecation in integration; unit failure-path application logging expected by tests. Lint includes four new warnings: fleet spec unused `_where` :73, `_entity` :165, `_options` :166; spacecraft service non-null assertion :2409. These were not suppressed or hidden, and lint exits0. Remaining warning output retained in full log; no blanket claim that all 1428 are pre-existing. No broad rerun after these successful final gates; independent review should use fingerprints/logs rather than treating historical baseline counts as acceptance.

## Candidate SHA-256 fingerprints (final source/test bytes)

Prefix `apps/backend/src/modules/spacecraft/`:

```
d1ca45dac5fff29cba23d7fbce0b68b41afc968060612176a7212ea0bad7bdc6 movement-state.ts
8b90b5464a2102755f2f26f736852c9410db80853aa4f66c04519987cb1b67e6 movement-concurrency.int-spec.ts
cd2d1486095ed105bd52095be990954942f821b0b678629f445ca6af92dcc804 spacecraft.service.ts
59965007d3b7ee63f14fe38f3dec66b883ecc43ec76261a6050908dc44bcc798 spacecraft-destruction.service.ts
953c008f6a2dcb69fb8fe4d73b3020b94754a97f4e8b0df6f36245c8ba09a371 spacecraft-movement-resources.spec.ts
109e409cca68053cc8d04a1248a6a00fad5264143c7f20b46cb26f3ebb9168b1 spacecraft-fleet.service.spec.ts
d88a895c03cfe82f4d1c4159cb59bc1b6fc3a3d9002dadcd5d29a511fc71d93b cartography-lifecycle.integration.spec.ts
7830e6386018f81e4cffcd3543e1d0eb6ab06e67e5d362cda24911e1377c8fe8 fleet-lock.ts (UNCHANGED prerequisite)
```

`git diff --check` exit0. All evidence under ignored .workmux; report verified ignored. No frontend execution.

## Handoff

Only K7a2b status/checklist marked complete after fresh gates. No neighboring resolution. One attributed focused fix commit created: `c212d12d28d8edd059b3148dcec638dcd44faac1`, commit exit0, `.workmux/k7a2b-commit.log`. Attribution verified: `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Post-commit git status clean; all eight source/test/prerequisite fingerprints unchanged. No broad rerun after commit. Worktree/ref retained. Stop for independent implementation/spec review and serial integration. No merge authorization inferred. Do not start K7a2/K7a3, planner import, wormhole endpoint or arrival redesign.

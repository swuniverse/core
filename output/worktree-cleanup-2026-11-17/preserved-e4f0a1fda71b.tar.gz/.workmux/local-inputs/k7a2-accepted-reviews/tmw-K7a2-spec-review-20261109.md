# K7a1/K7a2 independent Spec review — 2026-11-09

**Final disposition: PASS. No verified source Spec blocker or remaining concrete evidence gap. The final-candidate build evidence hold is CLOSED by the later supplied build log and candidate-bound manifest.**

Base: `59f716f9fbc3056371ff16ebe61c21fac5e45006`.
Candidate: `29ac20e249184b87789b0c7ca0494e549c1e7f10`.
Pinned `git diff 59f716f9...29ac20e2` and `git log 59f716f9..29ac20e2 --oneline`: two commits, rebased planner `b7e8632e` followed by integration `29ac20e2`, exactly 26 paths. Candidate/base Git objects used, not old working source. Standards separate; earlier planner/prerequisite conclusions reused, not re-audited.

## Spec findings — under 400 words

**(a) Missing/partial source requirements:** none verified. Authoritative BASE parent `tmw-K7a-wurmloch-betreten-und-verlassen.md:37` requires: “Flotten werden in SWU vollständig vorab und atomar validiert” and arrival “in derselben erfolgreichen Operation”. BASE child `tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md:27–31` requires complete prevalidation, consistent relocation, mandatory knowledge/repair cancellation and no partial mutation/success message.

The complete selected/tractor/secondary-fleet set is ID-deduplicated and validated under current locks before passage mutation. One READ COMMITTED manager covers destination effects/messages, exploration, K5c knowledge, signatures/log/success messages, cartography/takeover/prestige and repair/refund cancellation. Notifications queue until successful transaction resolution; downstream failures roll back durable writes and emit none.

**(b) Unasked behavior:** none verified. Parent :37 and K7a1 :28–30 require each ENTRY ship's functional impulse and only its own inactive activation EPS; EXIT has no activation/travel resource. Current normal activation is zero EPS, independently confirmed in unchanged ordinary flight code. No new tariff, towing restriction, ordinary partial-policy rewrite or Systementdeckung. K7a3 Shared/frontend is expressly deferred by parent :32 and K7a1 :10, not missing backend work.

**(c) Wrong apparent implementation:** none verified in the bounded reviewed contract. Authenticated route takes owner from JWT and accepts only optional positive selector; current local active entry/reverse direction and complete passable random target set are authoritative. Detached deeply frozen hydrated policy observations include protected Date setters; origin/destination revalidation follows awaited policy. Real public tests cover atomic fleet/arrival rollback and actual join/movement interleavings. Primary-fleet and carried-secondary ID overlap do not repeat the prior alias defect.

**Former evidence hold — CLOSED:** the later supplied corrected build log shows both Nx tasks and successful webpack output for the worker-reported exact clean final candidate. Its log hash, all 23 source-manifest hashes and candidate tree match independently. The earlier build still predates the corrections and remains historical; it was not relabeled. No reviewer build execution/provenance or cleared internal incremental-cache claim is made.

## Source and acceptance evidence

- Fully read new service `wormhole-passage.service.ts:1–423`, service test file :1–1940 (33 literal + 20 parameterized = **53 cases**) and production HTTP file :1–266 (4 literal + 5 parameterized = **9 cases**), plus all adapter/registration/tracker diff hunks. No skip/only/todo declarations.
- `enter:81–308`: primary fleet NO KEY UPDATE then complete sorted spacecraft NOWAIT through unchanged helper; initiating leadership; outgoing tractor closure; secondary fleets/members NOWAIT with current membership/ownership/leader checks; external holder refusal; locked installed modules and crew assignments; hydrated location/field type. Planner validates all ownership/status/station/standby/location/runtime/warp/impulse observations before mutation. Installed impulse integrity/cooldown is additionally checked against locked backing rows.
- `enter:309–404`: one write path per unique participant; destination-only executor and actual production FieldEffectConsequence pipeline; manager-bound persistence throughout. Existing sensor radius matches ordinary getSensorRange. Mandatory knowledge is independent of inactive sensors; transactional conflict-do-nothing preserves EXPLORED. Discontinuous signatures use null compass directions. Repair/task/cargo, cartography and takeover locks use NOWAIT on this path; prestige/history refund uses the same manager. After-commit callbacks are local, not an outbox/retry guarantee.
- Actual full fleet final-cancellation-trigger rollback asserts positions/resources/runtime, cartography, takeover/prestige, repairs/cargo and all arrival records/messages, with zero gateway emissions. Awaited real PostgreSQL message barrier verifies no precommit visibility/notification. Public join observes `pg_blocking_pids` across actual passage; public flyGalaxy must reject specifically `veraltet` after actual passage, without orphan records. Tractor primary overlap and double targets in one secondary fleet assert deduplicated records.
- HTTP uses actual AppModule, production datasource-options/entity metadata, JWT/guards/ValidationPipe and real datasource/repositories/services; ConfigService supplies disposable test settings, DataSource supplies that initialized production-options datasource, and gateway alone replaces behavior. Existing SpacecraftTakeover root registration repairs actual production graph metadata. Service fixture placeholders cover unexecuted dependencies, not persistence. Tests are bounded public-seam evidence, not full application or every possible contention proof.

## Independently bound supplied gates — not rerun

**23/23 integration source fingerprints** match candidate Git blobs. All six rebased stage files match original `ff16922a` bytes at `b7e8632e`; planner implementation/contract/planner tests remain byte-identical at candidate. Integration changes the route safety comment and replaces the deliberate unregistered-route assertion with registration plus constructor DI. Ordinary spacecraft service, fleet-lock, database/global harness and five existing movement/fleet/cartography regression files remain byte-identical to BASE.

All **five supplied gate-log hashes** match the report's raw-byte fingerprints:

| Supplied corrected/final gate | Observed log output; execution exit supplied by worker report |
| --- | --- |
| Targeted PostgreSQL | 5 suites / 116 tests passed, zero skipped totals; 84.399 s; explicit passage HTTP/service + fleet/movement/contact paths |
| Full PostgreSQL | 40 suites / 398 tests passed, zero skipped totals; 284.663 s |
| Corrected full units | 213 suites / 1993 tests passed; 1 snapshot; zero skipped totals; 64.224 s |
| Corrected lint | 1438 warnings / 0 errors |
| Corrected forced spec types | 0-byte log; `tsc --build apps/backend/tsconfig.spec.json --force`, exit 0 are supplied-report evidence, not inferred from emptiness |
| Final candidate build | Later supplied `k7a2-resumed-final-build-corrected.log`: shared `tsc --build` and backend webpack commands shown; success hash `3186603adbe8d3b0`. Log SHA256 and 23-file source manifest/tree match candidate. Exit 0 and exact clean before/after execution observations are worker-reported. |

Expected injected HTTP 500/ERROR is a passing rollback case, not a hidden failed gate. Worker discloses first forced-types exit 2 and first units exit 1; corrected logs supersede them. No unsupplied intermediate RED/build reconstruction. Fingerprint matching binds tested-byte claims, not independent gate execution provenance. PostgreSQL command report explicitly unsets both ambient URLs and uses unchanged disposable PostgreSQL16/committed migrations/synchronize:false.

## Resumed evidence check — 2026-11-10

Re-pinned the same BASE/candidate/HEAD, two-commit log and 26-path scope; `git diff --check` passed and tracked worktree remains clean. The supplied input directory still contains exactly the same six files, with no final-candidate build log or updated report. Reused the completed source/spec/test/hash review rather than restarting it. **Disposition unchanged: BLOCKED only on final-candidate build evidence; no verified source Spec blocker.** This resumed read-only check exited 0; no gate or probe was run.

## Final build-evidence closure — 2026-11-10

Read only the newly supplied `tmw-K7a2-final-candidate-build-20261109.md` and `k7a2-resumed-final-build-corrected.log`; retained the completed source/test/spec review. Independently matched build-log SHA256 `90bc6225a70e7b138f728a5b831ea2a55316efc0c69f2778188b6f069ece8064`, **23/23** source-manifest hashes to candidate Git objects and tree `861825a4c97d637e5b450e839cc967c917ab5fa4`. The preserved original report hash also matches the addendum; its earlier-build timing caveat remains historical.

The supplied log actually shows `nx run shared:build` / `tsc --build tsconfig.lib.json`, then `nx run backend:build` / `webpack-cli build --node-env=production`, compiled successfully (`3186603adbe8d3b0`) and Nx success. Worker reports exit 0 on exact clean committed candidate before/after. `--skip-nx-cache` bypasses Nx task replay; ordinary dependent `tsc --build` may retain incremental artifacts. No internal cache cleanup, reviewer execution or independent execution-provenance claim. Final typecheck exit remains worker-reported as previously bounded.

Both resumed read-only inventory/ref and isolated hash/log checks exited 0. No test/build/type/lint/DB rerun or new source review. **Evidence hold closed; final Spec PASS with no remaining concrete gap.** Only this ignored review report was updated.

## Reviewer actions and stop

Read-only Git refs/log/diff/source plus isolated `python3 -I` hash/extraction/scope/count/log checks; `git diff --check` passed. All executed checks exited 0. No additional probe was necessary; no test/build/DB rerun, install, external service, nested agent/workflow, plan mode or broad prerequisite audit. Ignored source/diff extracts and this report only.

HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`; tracked worktree unchanged. **Final Spec PASS; no remaining concrete evidence gap. Stopped; no tracked source/tracker/config/package/map/STU edit, switch, integration, issue resolution, commit, merge, push, cleanup, dependency change, nested agent/workflow or external service.**

# tmw-K7a1 staged-core independent review — 2026-11-09

## Verdict: PASS — staged core only

Reviewed `ff16922a7b93b620acb4d51d7180cf255dd970b2` against `c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab`. HEAD matches the checkpoint; the comparison contains one commit. No confirmed new defect was found within the agreed nonpersistent planning stage. This is **not** resolution of K7a1 and **not** approval to register or execute public wormhole relocation.

No agents, external services, indexing, source/tracker/map/tooling/STU edits, commits, merges, pushes, database runs, or other checkout writes were used. Only this ignored report and local ignored dependency installation were written. No `.codegraph/` index exists in this worktree; CodeGraph was not invoked.

## Scope and requirements read

- Current parent: `.scratch/stu-parity/issues/tmw-K7a-wurmloch-betreten-und-verlassen.md`, including the 2026-10-30 resource decision and confirmed child split.
- Current K7a1 and its 2026-11-09 staged-core clarification: `.scratch/stu-parity/issues/tmw-K7a1-wurmloch-backend-kern.md`.
- Current K7a2: `.scratch/stu-parity/issues/tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md`.
- Actual diff of all five changed backend paths, plus the K7a1 tracker clarification read without modification.
- Relevant existing location/runtime/operating-mode helpers, wormhole lookup, entity definitions, and minimal impulse activation call path. Repo conventions, domain vocabulary, and relevant navigation/station ADRs were considered without a general repository audit.

## Findings, ranked

**None confirmed.** No file/line defect finding survives the typed, fully hydrated, transaction-scoped snapshot contract of this stage.

### Standards

No concrete documented-standard breach requiring a change in this stage. Backend-local route/DTO design is explicitly not the deferred K7a3 shared/public contract. No speculative refactor or code-smell finding is reported.

### Spec and staged behavior

- **Direction/selection:** `apps/backend/src/modules/spacecraft/wormhole-passage-planner.ts:101-124` filters active local entries and bidirectional local exits; one-way reverse is unavailable. Ambiguous availability requires explicit selection, and explicit IDs are selected only from eligible local candidates. This agrees with existing `findExitsAt` in `apps/backend/src/modules/starmap/wormhole.service.ts:79-86`.
- **Every supplied participant:** `wormhole-passage-planner.ts:59-100` rejects empty/duplicate participants, foreign ownership, stations, standby, combat, destroyed/in-flight states, non-galaxy locations, different fields, absent loaded modules, and active installed warpdrive. It does not discover fleet membership; that is deliberately K7a2.
- **Installed functional impulse on entry:** `wormhole-passage-planner.ts:86-99,132-147` uses the existing module-backed runtime initializer on a copied runtime object. Absent installed drive, destroyed drive, or cooling drive rejects entry, including an already-active drive. Existing stored runtime state remains authoritative in the existing initializer; module state supplies missing runtime systems, including `SUBLIGHT_ENGINE` alias support.
- **Own activation EPS only:** `wormhole-passage-planner.ts:141-146` checks finite nonnegative resolver costs and each participant's own sufficiency, skipping resolver costs for active drives. No hull flight tariff or warpdrive balance is charged. Default zero is justified by the existing `navigate` call at `apps/backend/src/modules/spacecraft/spacecraft.service.ts:1982-1984` and `activateDriveForFlight` at `:2267-2297`: inactive impulse is activated without energy debit. Manual `toggleSystem` at `:1026-1145` likewise has no impulse EPS debit.
- **Reverse exit:** `wormhole-passage-planner.ts:133-134` requires neither impulse nor activation cost. General participant validity and no active warp still apply.
- **Destination:** `wormhole-passage-planner.ts:148-182` selects the direction's target layer. Fixed destinations must exist and be passable. Random destinations are selected only from supplied passable fields on that layer; RNG must be finite in `[0,1)`. Reverse random exit was also exercised.
- **Policy:** `wormhole-passage-planner.ts:125-131` checks every supplied participant, defaults to allow-all as specified, and rejects false or propagates a thrown policy failure without producing a plan.
- **No planner mutation / detached result:** `wormhole-passage-planner.ts:87-96,183-194` copies runtime system entries before the mutating legacy initializer and returns fresh origin/destination/participant objects, without ship/module/field aliases. Deep-frozen snapshots succeed unchanged; legacy SENSORS migration on the copy does not modify source snapshots.
- **No registered operation:** changed controller metadata test at `apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts:118-127` confirms no `:id/wormhole/enter` controller route. `wormhole-entry-contract.ts` is design only; its DTO accepts omission or a positive integer selection.

## Boundary observations — not classified as new defects

These limits were exercised rather than assumed:

1. Output is **detached and deeply readonly at the TypeScript interface level**, not runtime-frozen. `Object.isFrozen` is false for the plan, participant array, and participant objects. There is no supplied issue requirement for a runtime `Object.freeze` boundary, and normal typed consumers cannot assign through the readonly contract. This PASS does not claim runtime tamper-proofing for JavaScript/untyped consumers.
2. Injected policy/resolver ports receive the original snapshot references. A deliberately concurrent mutation during an awaited policy can invalidate earlier checks; this is outside the documented transaction-scoped stable-snapshot contract, not evidence of planner-owned mutation. K7a2 must not hand this planner live shared mutable objects or reuse a plan across state changes.
3. A deliberately out-of-signature activation resolver returning `null` or `undefined` is coalesced to zero. The declared resolver returns `number`; finite negative/nonfinite numbers are rejected. This PASS covers typed authoritative resolvers, not fail-closed validation of arbitrary JavaScript return values. If untyped/config-derived ports are introduced, distinguish an absent resolver from an invalid resolver result.

## Verification commands, counts, and exits

All shell commands were invoked through npm from this review worktree, with no network-enabled dependency installation or Nx remote/shared result-cache use.

### Ref/diff and workspace checks

Invoked through `npm exec --offline -- node -e '…'` using Node's `child_process.execFileSync`:

- `git rev-parse HEAD c79ff89f ff16922a7b93b620acb4d51d7180cf255dd970b2` — exit **0**, checkpoint/ref identities verified.
- `git diff --name-status c79ff89f...ff16922a7b93b620acb4d51d7180cf255dd970b2` — exit **0**, five backend paths plus K7a1 clarification.
- `git log --oneline c79ff89f..ff16922a7b93b620acb4d51d7180cf255dd970b2` — exit **0**, one checkpoint commit.
- `git diff c79ff89f...ff16922a7b93b620acb4d51d7180cf255dd970b2 -- apps/backend` — exit **0**, full backend diff inspected.
- `git check-ignore .workmux/tmw-K7a1-stage-review-20261109.md` — exit **0**, requested report path is ignored.
- Initial and final `git status --short` — exit **0**, clean tracked working tree; final `git rev-parse HEAD` still matches the checkpoint, and final `git check-ignore` confirms the saved report is ignored.

### Dependencies

```sh
npm ci --offline --ignore-scripts --no-audit --no-fund
```

Exit **0**; **1,831 packages** installed into this worktree. Deprecation warnings only. Dependency tarballs came from the existing local npm cache. No shared build/declaration artifacts were borrowed from another checkout.

### Focused checkpoint suites

```sh
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/wormhole-passage-planner.spec.ts apps/backend/src/modules/spacecraft/wormhole-entry-contract.spec.ts apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts
```

Exit **0**; **3 suites / 14 tests passed**, zero snapshots, 1.559 seconds. This is the independent review rerun count, not a claim to have repeated the previously disclosed 5-suite/38-test checkpoint run.

### Focused no-emit typecheck

```sh
npm exec --offline -- node -e 'const ts=require("typescript"),cp=require("child_process");const roots=cp.execFileSync("git",["diff","--name-only","c79ff89f...ff16922a7b93b620acb4d51d7180cf255dd970b2","--","apps/backend"],{encoding:"utf8"}).trim().split("\n");const cfg=ts.readConfigFile("apps/backend/tsconfig.app.json",ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,"apps/backend");const opts={...parsed.options,composite:false,incremental:false,declaration:false,declarationMap:false,emitDeclarationOnly:false,noEmit:true,types:["node","jest"]};delete opts.tsBuildInfoFile;const program=ts.createProgram(roots,opts);const diagnostics=ts.getPreEmitDiagnostics(program);console.log("Focused typecheck roots:",roots.join("\n"));console.log("Diagnostics:",diagnostics.length);if(diagnostics.length){console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCanonicalFileName:f=>f,getCurrentDirectory:ts.sys.getCurrentDirectory,getNewLine:()=>"\n"}));process.exitCode=1;}'
```

Exit **0**; **5 changed backend file roots, zero diagnostics**. Uses backend compiler options and follows imports in memory; disables composite emission and does not replay normal backend/workspace build targets.

### Read-only supplemental probes

Commands were `npm exec --offline -- node -e '…'`, with an in-memory SWC TypeScript loader using the existing spec compiler options, CommonJS output, tsconfig path resolution, and local `.js`-to-`.ts` source import resolution. No test/source/config file was created.

- Initial loader attempt — exit **1**, harness `ERR_MODULE_NOT_FOUND` for extensionless `spacecraft-field`; not a product test failure.
- Second loader attempt — exit **1**, harness `MODULE_NOT_FOUND` for shared source `./lib/auth/index.js`; not a product test failure.
- Corrected boundary probe — exit **0**, **11 explicit checks passed**: deep-frozen input unchanged; default zero; four invalid EPS numbers rejected; four invalid RNG values rejected; random reverse exit chooses the correct layer without impulse/cost resolver. Also printed the three boundary observations above.
- Supplemental module/cost/detachment probe — exit **0**: installed `SUBLIGHT_ENGINE` fallback, per-ship resolver argument/call, exact EPS sufficiency, no legacy runtime migration mutation, four detached output references, and active-drive cost-resolver bypass all verified. Its console label said “10 assertions”; the actual inline body contains **11 assertions** including the callback's ship-ID assertion.

Changed-file lint, normal backend typecheck/build, the other two previously disclosed suites, broad workspace tests, and DB replay were **not repeated**, per the bounded review request. Previous checkpoint results remain supplied context, not independently rerun results.

## K7a2 joint integration prerequisites — deferred, not stage findings

Before registering the public operation or marking K7a1/K7a2 complete:

1. Determine the authoritative complete participant set, enforce initiation/ownership rules, and load all required locations/modules/runtime state through one transaction with stable/locked relevant state. Do not reuse intentionally partial nonfixed-fleet movement semantics.
2. Keep policy and own-cost resolvers authoritative and side-effect-free; ensure snapshots cannot change across awaited checks. Revalidate/replan if the transaction's relevant state changes. Load the authoritative complete eligible target-layer field set for random selection.
3. Validate every member before any mutation; atomically apply planned impulse activation and each ship's own activation EPS, then move every participant to the same planned destination. No hull-dependent passage EPS or warpdrive charge; reverse exit has no activation/travel cost.
4. Apply destination field pipeline, local exploration, K5c layer knowledge, signatures/log or wormhole event, and parent-required repair cancellation in the same successful operation. Handle other existing navigation eligibility/cancellation concerns at their authoritative integration boundary, not through premature planner persistence.
5. Prove success, invalid member, rollback, arrival effects, and exactly-once writes with focused integration tests, including invalid policy/cost and destination outcomes. Failure must leave no partial mutation or success event.
6. Register/authenticate the DTO-backed route only with that atomic integration, then jointly accept the backend stage. Keep K7a3 shared/frontend work separate.

**Summary:** Standards **0 confirmed findings**; Spec/staged correctness **0 confirmed findings**. **PASS for this internal staged core; public relocation and full K7a1 resolution remain deferred.**

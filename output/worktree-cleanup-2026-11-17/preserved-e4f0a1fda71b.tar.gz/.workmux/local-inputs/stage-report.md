# tmw-K7a1 staged core checkpoint — 2026-11-09

## Scope and safe exposure

- Base: `c79ff89f`; checkpoint: `ff16922a7b93b620acb4d51d7180cf255dd970b2` (`feat(spacecraft): stage wormhole passage planning (stu-parity tmw-K7a1)`).
- Internal public seam: `planWormholePassage` in `apps/backend/src/modules/spacecraft/wormhole-passage-planner.ts` takes already-loaded ship/module/location snapshots, wormhole candidates, galaxy fields, optional per-ship activation-cost resolver, RNG, and access policy. It returns a readonly plan, with one destination and per-ship activation requirements; it does not persist or move anything. The default policy permits all; supplied policy is evaluated per participant. Planning uses `GalaxyField.isPassable`, matching `flyGalaxy`'s field-transition criterion. `WormholeService.findExitsAt` is not yet wired; K7a2 must load authoritative active wormholes and appropriate fields inside its transactional adapter.
- `wormhole-entry-contract.ts` preserves intended `POST spacecraft/:id/wormhole/enter` and optional positive integer `wormholeId` but does not register an endpoint. Controller metadata test verifies this route is absent. There is no public working passage or EPS mutation.
- The SWU `toggleSystem` and `activateDriveForFlight` implementation currently charge no EPS for impulse activation. Planner defaults to zero consistent with that code, supports per-ship nonzero activation cost supplied by the integrating caller and checks sufficiency. No new resource tariff has been invented. Parent's entry-only activation and no travel EPS/warp costs remain authoritative.
- The planner validates only participants and snapshots supplied by its caller; it cannot establish complete fleet membership, revalidate concurrency, check fleet leadership/tractor/crew restrictions, or commit effects by itself. Treat plans as transaction-scoped, not durable authorization. K7a2 must load, lock and prevalidate *every affected ship*, resolve all fleet/other movement eligibility in the transaction, and never reuse partial fleet movement. Evaluate access and activation costs against authoritative state, charge each inactive ship's own correct activation EPS, activate and relocate all ships atomically, run destination pipeline, local exploration, mandatory K5c layer knowledge, signature/log and repair cancellation within the same successful operation, and test rollback and exactly-once effects. Register the authenticated endpoint only when all are integrated and jointly accepted; K7a3 follows.
- Issue remains `ready-for-agent`, all acceptance checkboxes open. Endpoint and real mutation acceptance explicitly deferred. No push, merge, other agents, external services, STU/map edits, package-lock edits, or nx.json changes.

## Environment and history

- No `.codegraph` index in this worktree; no index created. Repo root commands only. `game-data/data` linked to ignored `.workmux/local-inputs/game-data/data`; no `apps/backend/game-data` created.
- `npm ci --offline --no-audit --no-fund`: exit 0, 1829 packages installed from cache; deprecation warnings and 11 unapproved install-script warnings. No package-manager files changed.
- `NX_DAEMON=false npx nx show project backend --json`: exit 0; backend typecheck includes spec files. Existing history searches for `wormhole`, `wurmloch`, `K7a` found earlier ticket claim/decision/split tracking and pre-existing generic wormhole code, not a previous completed K7a implementation; no discarded code restored.

## Incremental TDD

Focused runner in every cycle: `TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/spacecraft/wormhole-passage-planner.spec.ts` (except endpoint contract used its own spec path). All reported runs had zero skipped tests.

- Entry plan: RED exit 1 missing planner module; GREEN exit 0, 1 test.
- Reverse bidirectional exit: RED exit 1, destination not found; GREEN exit 0, 2 tests.
- Missing/inactive/one-way and multiple selection: RED exit 1, missing wormhole handling; GREEN exit 0, 3 tests.
- Random destination: RED exit 1, fixed destination used; GREEN exit 0, 4 tests.
- All participant validation: RED exit 1, foreign participant accepted; GREEN exit 0, 5 tests.
- Per-ship activation EPS: RED exit 1, insufficient EPS accepted; GREEN exit 0, 6 tests.
- Functional installed drive: RED exit 1, stale runtime drive with no installed module accepted; GREEN exit 0, 7 tests.
- Access-policy denial: RED exit 1, denial ignored; GREEN exit 0, 8 tests.
- Fixed destination passability: RED exit 1, impassable field accepted; GREEN exit 0, 9 tests.
- Endpoint DTO/route-design contract: RED exit 1 missing module; GREEN exit 0, 1 test.
- Unique participant IDs: RED exit 1, duplicates accepted; first fix exposed an existing same-field fixture with duplicate IDs (exit 1); after correcting fixture GREEN exit 0, 9 tests.
- Hydrated module requirement: RED exit 1, missing modules accepted; GREEN exit 0, 10 tests.
- Added absent-route controller metadata test alongside the existing controller contract suite; this is a safety regression test of the pre-existing no-route behavior rather than a new route implementation.

## Final proof

- `TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/spacecraft/wormhole-passage-planner.spec.ts apps/backend/src/modules/spacecraft/wormhole-entry-contract.spec.ts apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts apps/backend/src/modules/spacecraft/spacecraft-runtime-state.service.spec.ts apps/backend/src/modules/spacecraft/interaction-policy.spec.ts`: exit 0, 5 suites, 38 passed, 0 skipped.
- `NX_DAEMON=false npx nx run backend:lint`: exit 0, 1423 warnings / 0 errors across existing backend lint scope. `npx eslint apps/backend/src/modules/spacecraft/wormhole-passage-planner.ts apps/backend/src/modules/spacecraft/wormhole-passage-planner.spec.ts apps/backend/src/modules/spacecraft/wormhole-entry-contract.ts apps/backend/src/modules/spacecraft/wormhole-entry-contract.spec.ts apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts`: exit 0, no warnings. Backend lint preceded final fixture-only type assertion correction; direct changed-file lint ran after it.
- `NX_DAEMON=false npx nx run backend:typecheck`: initial exit 1 due to new fixture cast TS2352; fixed fixture, rerun exit 0. Backend typecheck ran; shared build and shared typecheck were local cache hits, not fresh checks.
- `NX_DAEMON=false npx nx run backend:build`: exit 0, backend webpack compiled successfully (hash `9145953bf915d9f1`); shared build was a local cache hit, not a fresh build. One backend build run.
- `git diff --cached --check`: exit 0 before checkpoint. No full PostgreSQL or workspace suite run, as requested for nonpersistent stage. No joint backend acceptance claimed.

# STU → SWU Spezialmodule Vollanalyse

Quelle: STU-Wiki, `stu-rump-stats.yaml`, `ship-classes.yaml`, `stu-fabrication.yaml`, `rebels.yaml`, `imperials.yaml`.

Legende:
- `SPECIAL Slots`: aus STU-Rumpfstats übernommen
- `Erwartet`: sinnvolle STU-Spezialmodule für diese Klasse/Rolle
- `Forschung`: Tech im SWU-Researchbaum vorhanden
- `Fabrication`: als baubares Shipyard/Fabrication-Item vorhanden

## AIRFIELD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 161 | Workbee | REBEL_WORKBEE_DROID | 0 | - | - | - | keine SPECIAL-Relevanz |
| 162 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 163 | Workbee | EMPIRE_WORKBEE_DROID | 0 | - | - | - | keine SPECIAL-Relevanz |
| 164 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 165 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 901 | Y-Frachter | REBEL_FREIGHTER_YT | 0 | - | - | - | keine SPECIAL-Relevanz |
| 903 | K-Frachter | EMPIRE_FREIGHTER_GOZANTI | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1401 | Danube | REBEL_SHUTTLE_LAAT | 1 | Shuttlerampe-Modul | Shuttlerampe-Modul (RI) | Shuttlerampe-Modul (nein) | Lücke |
| 1403 | K'toch | EMPIRE_SHUTTLE_LAMBDA | 1 | Shuttlerampe-Modul | Shuttlerampe-Modul (RI) | Shuttlerampe-Modul (nein) | Lücke |
| 1501 | Icarus | REBEL_COLONIZER_ICARUS | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1503 | Saqghom | EMPIRE_COLONIZER_SENTINEL | 0 | - | - | - | keine SPECIAL-Relevanz |

## FIGHTER_SHIPYARD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 161 | Workbee | REBEL_WORKBEE_DROID | 0 | - | - | - | keine SPECIAL-Relevanz |
| 162 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 163 | Workbee | EMPIRE_WORKBEE_DROID | 0 | - | - | - | keine SPECIAL-Relevanz |
| 164 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 165 | Workbee | _absichtlich zusammengefasst_ | 0 | - | - | - | keine SPECIAL-Relevanz |
| 901 | Y-Frachter | REBEL_FREIGHTER_YT | 0 | - | - | - | keine SPECIAL-Relevanz |
| 903 | K-Frachter | EMPIRE_FREIGHTER_GOZANTI | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1101 | Raider | REBEL_FIGHTER_A_WING | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1103 | NuQ'duj | EMPIRE_FIGHTER_TIE_INTERCEPTOR | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1201 | Peregrine | REBEL_FIGHTER_X_WING | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1203 | K'Pak | EMPIRE_FIGHTER_TIE_LN | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1401 | Danube | REBEL_SHUTTLE_LAAT | 1 | Shuttlerampe-Modul | Shuttlerampe-Modul (RI) | Shuttlerampe-Modul (nein) | Lücke |
| 1403 | K'toch | EMPIRE_SHUTTLE_LAMBDA | 1 | Shuttlerampe-Modul | Shuttlerampe-Modul (RI) | Shuttlerampe-Modul (nein) | Lücke |
| 1491 | Venture | REBEL_SHUTTLE_U_WING | 1 | Shuttlerampe-Modul | Shuttlerampe-Modul (RI) | Shuttlerampe-Modul (nein) | Lücke |
| 1501 | Icarus | REBEL_COLONIZER_ICARUS | 0 | - | - | - | keine SPECIAL-Relevanz |
| 1503 | Saqghom | EMPIRE_COLONIZER_SENTINEL | 0 | - | - | - | keine SPECIAL-Relevanz |

## ESCORT_SHIPYARD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 3101 | Miranda | REBEL_ESCORT_HAMMERHEAD | 2 | - | - | - | keine SPECIAL-Relevanz |
| 3103 | K'Vort'cha | EMPIRE_ESCORT_ARQUITENS | 2 | - | - | - | keine SPECIAL-Relevanz |
| 3201 | Defiant | REBEL_CORVETTE_CR90 | 2 | - | - | - | keine SPECIAL-Relevanz |
| 3203 | B'Rel | EMPIRE_CORVETTE_RAIDER | 2 | - | - | - | keine SPECIAL-Relevanz |
| 3401 | Nova | REBEL_SCOUT_HWK_290 | 3 | Astrometrie-Labor, Matrixsensoren, Hyperraumfeldscanner | Astrometrie-Labor (RI), Matrixsensoren (RI), Hyperraumfeldscanner (RI) | Astrometrie-Labor (nein), Matrixsensoren (nein), Hyperraumfeldscanner (nein) | Lücke |
| 3403 | Rotarn | EMPIRE_SCOUT_RAIDER | 0 | - | - | - | keine SPECIAL-Relevanz |
| 3491 | Oberth | REBEL_SCOUT_VCX_100 | 3 | Astrometrie-Labor, Matrixsensoren, Hyperraumfeldscanner | Astrometrie-Labor (RI), Matrixsensoren (RI), Hyperraumfeldscanner (RI) | Astrometrie-Labor (nein), Matrixsensoren (nein), Hyperraumfeldscanner (nein) | Lücke |
| 6501 | Aerie | REBEL_COLONIZER_CR90 | 2 | Crewtransport-Modul, Torpedotransportmodul, Shuttlerampe-Modul | Crewtransport-Modul (RI), Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Crewtransport-Modul (nein), Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6503 | Row | EMPIRE_COLONIZER_LAMBDA_SETTLEMENT | 2 | Crewtransport-Modul, Torpedotransportmodul, Shuttlerampe-Modul | Crewtransport-Modul (RI), Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Crewtransport-Modul (nein), Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6601 | Epsilon | REBEL_FREIGHTER_BFF1 | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6603 | Tong'duj | EMPIRE_FREIGHTER_HEAVY | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6701 | Antares | REBEL_FREIGHTER_GR75 | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6703 | Jolpa'law | EMPIRE_FREIGHTER_IMPERIAL | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |

## FRIGATE_SHIPYARD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 2101 | Saber | REBEL_FRIGATE_CONSULAR | 2 | - | - | - | keine SPECIAL-Relevanz |
| 2203 | Rek'toc | EMPIRE_FRIGATE_MUNIFICENT | 1 | - | - | - | keine SPECIAL-Relevanz |
| 2301 | Aegian | REBEL_FRIGATE_PELTA | 1 | - | - | - | keine SPECIAL-Relevanz |
| 2303 | Na'ket | EMPIRE_FRIGATE_LANCER | 1 | - | - | - | keine SPECIAL-Relevanz |
| 6501 | Aerie | REBEL_COLONIZER_CR90 | 2 | Crewtransport-Modul, Torpedotransportmodul, Shuttlerampe-Modul | Crewtransport-Modul (RI), Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Crewtransport-Modul (nein), Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6503 | Row | EMPIRE_COLONIZER_LAMBDA_SETTLEMENT | 2 | Crewtransport-Modul, Torpedotransportmodul, Shuttlerampe-Modul | Crewtransport-Modul (RI), Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Crewtransport-Modul (nein), Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6601 | Epsilon | REBEL_FREIGHTER_BFF1 | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6603 | Tong'duj | EMPIRE_FREIGHTER_HEAVY | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6701 | Antares | REBEL_FREIGHTER_GR75 | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |
| 6703 | Jolpa'law | EMPIRE_FREIGHTER_IMPERIAL | 1 | Torpedotransportmodul, Shuttlerampe-Modul | Torpedotransportmodul (RI), Shuttlerampe-Modul (RI) | Torpedotransportmodul (nein), Shuttlerampe-Modul (nein) | Lücke |

## CRUISER_SHIPYARD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 5101 | Akira | REBEL_CRUISER_NEBULON_B | 2 | - | - | - | keine SPECIAL-Relevanz |
| 5103 | Fek'lhr | EMPIRE_CRUISER_VINDICATOR | 2 | - | - | - | keine SPECIAL-Relevanz |
| 5191 | Excelsior | REBEL_CRUISER_VENATOR | 2 | - | - | - | keine SPECIAL-Relevanz |
| 5201 | Prometheus | REBEL_CRUISER_MC80 | 2 | - | - | - | keine SPECIAL-Relevanz |
| 5203 | Vor'cha | EMPIRE_CRUISER_IMPERIAL | 2 | - | - | - | keine SPECIAL-Relevanz |
| 5401 | Intrepid | REBEL_CRUISER_HAMMERHEAD_RESEARCH | 0 | - | - | - | keine SPECIAL-Relevanz |
| 5403 | T'Acog | EMPIRE_CRUISER_GOZANTI_RESEARCH | 0 | - | - | - | keine SPECIAL-Relevanz |
| 5491 | Luna | REBEL_CRUISER_CORVUS_RESEARCH | 0 | - | - | - | keine SPECIAL-Relevanz |

## DESTROYER_SHIPYARD

| STU ID | STU Name | SWU Klasse | SPECIAL Slots | Erwartete Spezialmodule | Forschung vorhanden | Fabrication vorhanden | Bewertung |
|---:|---|---|---:|---|---|---|---|
| 4101 | Norway | REBEL_DESTROYER_DREADNOUGHT | 2 | - | - | - | keine SPECIAL-Relevanz |
| 4203 | K't'inga | EMPIRE_DESTROYER_INTERDICTOR | 2 | - | - | - | keine SPECIAL-Relevanz |
| 4301 | Steamrunner | REBEL_DESTROYER_MC75 | 2 | - | - | - | keine SPECIAL-Relevanz |
| 4303 | Koloth | EMPIRE_DESTROYER_PRAETOR | 2 | - | - | - | keine SPECIAL-Relevanz |

## Zusammenfassung

- SPECIAL-Slots sind für viele relevante STU-Rümpfe bereits zahlenmäßig übernommen.
- Die STU-spezifischen Spezialmodule `Crewtransport-Modul`, `Torpedotransportmodul`, `Shuttlerampe-Modul`, `Astrometrie-Labor`, `Matrixsensoren`, `Hyperraumfeldscanner` sind in der Forschung weitgehend vorhanden.
- Diese Spezialmodule fehlen jedoch derzeit als echte baubare `stu-fabrication.yaml` Shipyard-Items.
- Dadurch sind Aerie/Row sowie Scout-/Forschungsschiffe in SWU funktional untermodelliert.


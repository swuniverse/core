# STU Spezialmodule Audit → SWU

## Verifiziert

### STU/Wiki Aerie
Wiki `Aerie` sagt explizit, dass Aerie ausbaubar ist mit:
- Crewtransport-Modul
- Torpedotransport-Modul
- Shuttlerampe-Modul

Zusätzlich sind laut STU-Daten relevant:
- `specialSlots = 2` für Aerie/Row
- `specialSlots = 1` für Epsilon/Tong'duj/Antares/Jolpa'law

### In SWU schon vorhanden
- SPECIAL-Slotanzahl wird aus `game-data/data/ship-building/stu-rump-stats.yaml` übernommen
- Backend berücksichtigt SPECIAL-Slots in `getShipClassSlotRuleForShipClass`
- Backend erlaubt SPECIAL aktuell grob nach `specialSlots > 0`
- Crewtransport-Modul (`19005`) und Torpedotransportmodul (`19009`) sind als Fabrication-Items vorhanden und damit für verfügbare SPECIAL-Slots wähl- und baubar
- Crewtransport-Modul erhöht die Crewtransportkapazität um `baseCrewCapacity × Level`
- Torpedotransportmodul erhöht die Torpedokapazität um `torpedoStorageBonus`

## Lücke
Die folgenden STU-Spezialmodule sind als Commodity/Forschung vorhanden, aber **nicht** als baubare Shipyard/Fabrication-Items integriert:
- `19006` Astrometrie-Labor
- `19008` Matrixsensoren
- `19010` Shuttlerampe
- Hyperraumfeldscanner (Forschung vorhanden, Commodity/Fabrication-Item fehlt/noch nicht verdrahtet)

## Aktuell in SWU vorhandene SPECIAL-Module
Diese echten SPECIAL-Shipyard-Module sind vorhanden:
- Energieverteiler
- Hypermaterie-Reaktor
- Allianz-Hypermaterie-Reaktor
- Tarnvorrichtung
- Crewtransport-Modul
- Torpedotransportmodul

## Konsequenz
Aerie/Row können Crew- und Torpedotransport über ihre SPECIAL-Slots abbilden; für die vollständige STU-Spezialisierung fehlt weiterhin die Shuttlerampe.

## Empfohlene Phase 1
Aerie/Row-orientierte Spezialmodule vervollständigen:
- Shuttlerampe (`19010`)

## Empfohlene Phase 2
Forschungsschiff-Spezialmodule ergänzen:
- Astrometrie-Labor (`19006`)
- Matrixsensoren (`19008`)
- Hyperraumfeldscanner (Tech `60700`/pendant)

## Empfohlene Phase 3
Feinere Zuordnung statt `specialSlots > 0`:
- Aerie/Row: Crewtransport, Torpedotransport, Shuttlerampe
- Epsilon/Tong'duj/Antares/Jolpa'law: eher Teilmenge
- Forschungsschiffe: Astrometrie-Labor, Matrixsensoren, Hyperraumfeldscanner

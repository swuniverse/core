# SWU Mapping-Report gegen STU-Basisliste

Basisliste: `core/dist/db/werftuebersicht_foed_kling_neutral.md`
Zielrepo: `/Users/TMUNDIN/git/github.com/swuniverse/core`

Hinweise:
- STU-Bauzeiten wurden als direkte `buildTimeTicks` übernommen.
- Workbees: gemäß Vorgabe nur ein Workbee/Arbeitsdroide pro Fraktion (`161` Rebel, `163` Imperial); übrige Workbee-Fraktionsvarianten sind absichtlich nicht separat angelegt.
- `Ziel-Werft effektiv` berücksichtigt explizite Overrides, Kategorie-Defaults und Hangar-/Flugfelddefinitionen. Supersets (z. B. `[4, 5]`) gelten für beide Einzelwerften als passend.

## AIRFIELD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 161 | Workbee | Neutral | REBEL_WORKBEE_DROID | Arbeitsdroide | REBEL_ALLIANCE | FIGHTER | 1 | 1 | [4] | [4, 5] | ok |
| 162 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [4] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 163 | Workbee | Neutral | EMPIRE_WORKBEE_DROID | Arbeitsdroide | GALACTIC_EMPIRE | FIGHTER | 1 | 1 | [4] | [4, 5] | ok |
| 164 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [4] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 165 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [4] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 901 | Y-Frachter | Föderation | REBEL_FREIGHTER_YT | YT-1300 Frachter | REBEL_ALLIANCE | FREIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |
| 903 | K-Frachter | Klingonen | EMPIRE_FREIGHTER_GOZANTI | Gozanti-Frachter | GALACTIC_EMPIRE | FREIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |
| 1401 | Danube | Föderation | REBEL_SHUTTLE_LAAT | LAAT Shuttle | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |
| 1403 | K'toch | Klingonen | EMPIRE_SHUTTLE_LAMBDA | Lambda-Klasse Shuttle | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |
| 1501 | Icarus | Föderation | REBEL_COLONIZER_ICARUS | GR-75 Kolonietransporter | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |
| 1503 | Saqghom | Klingonen | EMPIRE_COLONIZER_SENTINEL | Sentinel-Klasse Kolonieschiff | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [4] | [4, 5] | ok |

## FIGHTER_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 161 | Workbee | Neutral | REBEL_WORKBEE_DROID | Arbeitsdroide | REBEL_ALLIANCE | FIGHTER | 1 | 1 | [5] | [4, 5] | ok |
| 162 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [5] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 163 | Workbee | Neutral | EMPIRE_WORKBEE_DROID | Arbeitsdroide | GALACTIC_EMPIRE | FIGHTER | 1 | 1 | [5] | [4, 5] | ok |
| 164 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [5] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 165 | Workbee | Neutral | _absichtlich zusammengefasst_ | Arbeitsdroide | Rebel/Imperial | FIGHTER | 1 | 1 | [5] | [4, 5] | ok (kein separates SWU-Schiff gewünscht) |
| 901 | Y-Frachter | Föderation | REBEL_FREIGHTER_YT | YT-1300 Frachter | REBEL_ALLIANCE | FREIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 903 | K-Frachter | Klingonen | EMPIRE_FREIGHTER_GOZANTI | Gozanti-Frachter | GALACTIC_EMPIRE | FREIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1101 | Raider | Föderation | REBEL_FIGHTER_A_WING | A-Wing Abfangjäger | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1103 | NuQ'duj | Klingonen | EMPIRE_FIGHTER_TIE_INTERCEPTOR | TIE-Abfangjäger | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1201 | Peregrine | Föderation | REBEL_FIGHTER_X_WING | X-Wing Jäger | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1203 | K'Pak | Klingonen | EMPIRE_FIGHTER_TIE_LN | TIE-Jäger | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1401 | Danube | Föderation | REBEL_SHUTTLE_LAAT | LAAT Shuttle | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1403 | K'toch | Klingonen | EMPIRE_SHUTTLE_LAMBDA | Lambda-Klasse Shuttle | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1491 | Venture | Föderation | REBEL_SHUTTLE_U_WING | U-Wing Transporter | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1501 | Icarus | Föderation | REBEL_COLONIZER_ICARUS | GR-75 Kolonietransporter | REBEL_ALLIANCE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |
| 1503 | Saqghom | Klingonen | EMPIRE_COLONIZER_SENTINEL | Sentinel-Klasse Kolonieschiff | GALACTIC_EMPIRE | FIGHTER | 2400 | 2400 | [5] | [4, 5] | ok |

## ESCORT_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 3101 | Miranda | Föderation | REBEL_ESCORT_HAMMERHEAD | Hammerhead-Korvette | REBEL_ALLIANCE | ESCORT | 9600 | 9600 | [6] | [6] | ok |
| 3103 | K'Vort'cha | Klingonen | EMPIRE_ESCORT_ARQUITENS | Arquitens-Korvette | GALACTIC_EMPIRE | ESCORT | 9600 | 9600 | [6] | [6] | ok |
| 3201 | Defiant | Föderation | REBEL_CORVETTE_CR90 | CR90 Korvette | REBEL_ALLIANCE | CORVETTE | 9600 | 9600 | [6] | [6] | ok |
| 3203 | B'Rel | Klingonen | EMPIRE_CORVETTE_RAIDER | Raider-Korvette | GALACTIC_EMPIRE | CORVETTE | 9600 | 9600 | [6] | [6] | ok |
| 3401 | Nova | Föderation | REBEL_SCOUT_HWK_290 | HWK-290 Aufklärer | REBEL_ALLIANCE | ESCORT | 9600 | 9600 | [6] | [6] | ok |
| 3403 | Rotarn | Klingonen | EMPIRE_SCOUT_RAIDER | Raider-Klasse Aufklärer | GALACTIC_EMPIRE | ESCORT | 9600 | 9600 | [6] | [6] | ok |
| 3491 | Oberth | Föderation | REBEL_SCOUT_VCX_100 | VCX-100 Aufklärer | REBEL_ALLIANCE | ESCORT | 9600 | 9600 | [6] | [6] | ok |
| 6501 | Aerie | Föderation | REBEL_COLONIZER_CR90 | CR90 Kolonieschiff | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |
| 6503 | Row | Klingonen | EMPIRE_COLONIZER_LAMBDA_SETTLEMENT | Lambda-Klasse Siedlungsschiff | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |
| 6601 | Epsilon | Föderation | REBEL_FREIGHTER_BFF1 | BFF-1 Massenfrachter | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |
| 6603 | Tong'duj | Klingonen | EMPIRE_FREIGHTER_HEAVY | Imperialer Bulk-Frachter | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |
| 6701 | Antares | Föderation | REBEL_FREIGHTER_GR75 | GR-75 Frachter | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |
| 6703 | Jolpa'law | Klingonen | EMPIRE_FREIGHTER_IMPERIAL | Sienar-Flottenfrachter | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [6] | [6, 7] | ok |

## FRIGATE_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 2101 | Saber | Föderation | REBEL_FRIGATE_CONSULAR | Consular-Fregatte | REBEL_ALLIANCE | FRIGATE | 4800 | 4800 | [7] | [7] | ok |
| 2203 | Rek'toc | Klingonen | EMPIRE_FRIGATE_MUNIFICENT | Munificent-Fregatte | GALACTIC_EMPIRE | FRIGATE | 4800 | 4800 | [7] | [7] | ok |
| 2301 | Aegian | Föderation | REBEL_FRIGATE_PELTA | Pelta-Fregatte | REBEL_ALLIANCE | FRIGATE | 4800 | 4800 | [7] | [7] | ok |
| 2303 | Na'ket | Klingonen | EMPIRE_FRIGATE_LANCER | Lancer-Fregatte | GALACTIC_EMPIRE | FRIGATE | 4800 | 4800 | [7] | [7] | ok |
| 6501 | Aerie | Föderation | REBEL_COLONIZER_CR90 | CR90 Kolonieschiff | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |
| 6503 | Row | Klingonen | EMPIRE_COLONIZER_LAMBDA_SETTLEMENT | Lambda-Klasse Siedlungsschiff | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |
| 6601 | Epsilon | Föderation | REBEL_FREIGHTER_BFF1 | BFF-1 Massenfrachter | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |
| 6603 | Tong'duj | Klingonen | EMPIRE_FREIGHTER_HEAVY | Imperialer Bulk-Frachter | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |
| 6701 | Antares | Föderation | REBEL_FREIGHTER_GR75 | GR-75 Frachter | REBEL_ALLIANCE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |
| 6703 | Jolpa'law | Klingonen | EMPIRE_FREIGHTER_IMPERIAL | Sienar-Flottenfrachter | GALACTIC_EMPIRE | FREIGHTER | 9600 | 9600 | [7] | [6, 7] | ok |

## CRUISER_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 5101 | Akira | Föderation | REBEL_CRUISER_NEBULON_B | Nebulon-B Fregatte | REBEL_ALLIANCE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5103 | Fek'lhr | Klingonen | EMPIRE_CRUISER_VINDICATOR | Vindicator-Kreuzer | GALACTIC_EMPIRE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5191 | Excelsior | Föderation | REBEL_CRUISER_VENATOR | Venator-Klasse Kreuzer | REBEL_ALLIANCE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5201 | Prometheus | Föderation | REBEL_CRUISER_MC80 | MC80 Sternkreuzer | REBEL_ALLIANCE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5203 | Vor'cha | Klingonen | EMPIRE_CRUISER_IMPERIAL | Imperial-I Sternenzerstörer | GALACTIC_EMPIRE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5401 | Intrepid | Föderation | REBEL_CRUISER_HAMMERHEAD_RESEARCH | Hammerhead-Forschungsschiff | REBEL_ALLIANCE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5403 | T'Acog | Klingonen | EMPIRE_CRUISER_GOZANTI_RESEARCH | Gozanti-Forschungsschiff | GALACTIC_EMPIRE | CRUISER | 24000 | 24000 | [8] | [8] | ok |
| 5491 | Luna | Föderation | REBEL_CRUISER_CORVUS_RESEARCH | Corvus-Klasse Forschungsschiff | REBEL_ALLIANCE | CRUISER | 24000 | 24000 | [8] | [8] | ok |

## DESTROYER_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|
| 4101 | Norway | Föderation | REBEL_DESTROYER_DREADNOUGHT | Dreadnought-Kreuzer | REBEL_ALLIANCE | DESTROYER | 18000 | 18000 | [21] | [21] | ok |
| 4203 | K't'inga | Klingonen | EMPIRE_DESTROYER_INTERDICTOR | Interdictor-Kreuzer | GALACTIC_EMPIRE | DESTROYER | 18000 | 18000 | [21] | [21] | ok |
| 4301 | Steamrunner | Föderation | REBEL_DESTROYER_MC75 | MC75 Sternkreuzer | REBEL_ALLIANCE | DESTROYER | 18000 | 18000 | [21] | [21] | ok |
| 4303 | Koloth | Klingonen | EMPIRE_DESTROYER_PRAETOR | Praetor-Klasse Sternzerstörer | GALACTIC_EMPIRE | DESTROYER | 18000 | 18000 | [21] | [21] | ok |

## REPAIR_SHIPYARD

| STU ID | STU Name | Rasse | SWU Klasse | SWU Name | SWU Fraktion | SWU Kategorie | STU Bauzeit | SWU Bauzeit | Ziel-Werft | Ziel-Werft effektiv | Status |
|---:|---|---|---|---|---|---|---:|---:|---|---|---|


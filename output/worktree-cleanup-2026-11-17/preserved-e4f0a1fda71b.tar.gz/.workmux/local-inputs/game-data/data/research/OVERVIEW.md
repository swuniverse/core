# Forschungsbaum — Vollständige Übersicht

Rebellen: 254 | Imperiale: 248 | Inkl. EXCLUDE-Dependencies + konsolidierte Module

## REBELLEN (254 Forschungen)

### Doonium (4 Forschungen)

| Name | FP |
|------|-----|
| Aqua-Zuchtfarm | 5 |
| Chemische Fabrik | 10 |
| Gezeitenkraftwerk | 5 |
| Transparistahl-Manufaktur | 10 |

### Transparistahl (4 Forschungen)

| Name | FP |
|------|-----|
| Durastahlanlage | 12 |
| Hypermateriesynthesizer | 12 |
| Phrik-Mine | 8 |
| Phrik-Raffinerie | 8 |

### Hypermaterie (3 Forschungen)

| Name | FP |
|------|-----|
| GR-75 Transportschiff | 20 |
| Landeplattform | 30 |
| YT-Klasse Frachter | 30 |

### Durastahl (1 Forschungen)

| Name | FP |
|------|-----|
| Forschungszentrum Stufe I | 12 |

### FP Stufe I (46 Forschungen)

| Name | FP |
|------|-----|
| A-Wing Abfangjäger | 20 |
| Allianz-Akademie | 10 |
| Antriebsmodule Stufe I | 40 |
| Antriebsmodulfertigung | 10 |
| Aurodium-Mine | 20 |
| Aurodium-Presse | 20 |
| BFF-1 Massenfrachter | 20 |
| Blaue-Milch-Brauerei | 10 |
| Cantina | 10 |
| Consular-Fregatte | 20 |
| Crewtransport-Modul | 20 |
| Forschungszentrum Stufe II | 20 |
| Fregattenwerft | 10 |
| GR-75 Frachter | 20 |
| Grundlagenforschung der Allianz | 0 |
| Habitatkuppel | 10 |
| Hypermaterie-Pumpen | 10 |
| Jägerwerft | 10 |
| Kolonisierung unwirtlicher Planeten | 40 |
| Kryo-Zuchtanlage | 10 |
| Kyber-Kristallmine | 10 |
| LAAT Shuttle | 20 |
| Leichte Asteroiden-Kolonisierung | 60 |
| Leichter Protonentorpedo | 10 |
| Micro-Protonentorpedo | 10 |
| Mond-Kolonisierung I | 40 |
| Orbital-Solarkollektor | 10 |
| Partikel-Beschleuniger | 10 |
| Pelta-Fregatte | 20 |
| Protonentorpedo-Fabrik | 10 |
| Protonentorpedo-Werfer (Klasse 2) | 10 |
| Raumbahnhof | 20 |
| Schildmodule Stufe I | 40 |
| Schildmodulfertigung | 10 |
| Shuttlerampe-Modul | 20 |
| Solarfokus | 10 |
| Solarspiegel | 10 |
| Strömungsanker | 10 |
| Strömungsturbinen | 10 |
| Geoengineering | 10 |
| U-Wing Transporter | 20 |
| Versorgungskuppel | 10 |
| Waffenmodule Stufe I | 40 |
| Waffenmodulfertigung | 20 |
| Werftkomplex | 10 |
| X-Wing Jäger | 20 |

### FP Stufe II (56 Forschungen)

| Name | FP |
|------|-----|
| Allianz-Schule | 20 |
| Antriebsmodule Stufe II | 80 |
| Antriebsmodulfabrik | 20 |
| Astrometrie-Labor | 20 |
| Außenposten-Upgrade | 30 |
| Bronzium-Mine | 30 |
| Bronzium-Raffinerie | 30 |
| CR90 Kolonieschiff | 30 |
| CR90 Korvette | 30 |
| Cortosis-Mine | 30 |
| Cortosis-Raffinerie | 30 |
| Forschungszentrum Stufe III | 30 |
| Frachtkontainer-Depot | 20 |
| Fusionsreaktor | 30 |
| HWK-290 Aufklärer | 30 |
| Hammerhead-Korvette | 30 |
| Holo-Generator | 30 |
| Holo-Simulator | 20 |
| Hyperraum-Spulen-Fabrik | 30 |
| Klimakontroll-Uplink | 20 |
| Klimakontrollzentrum | 30 |
| Kolonisierung extremer Planeten | 40 |
| Korvetten-Werft | 30 |
| Laminanium-Mine | 30 |
| Laminanium-Raffinerie | 30 |
| Laminanium-Schaltkreis-Fabrik | 30 |
| Matrixsensoren | 20 |
| Mikrodyne-Fabrik | 30 |
| Mittlere Asteroiden-Kolonisierung | 60 |
| Neuranium-Mine | 30 |
| Neuranium-Raffinerie | 30 |
| Orbital-Fallstation | 20 |
| Orbital-Habitat | 20 |
| Orbitales Forschungslabor | 30 |
| Phasenkonverter-Fabrik | 30 |
| Plasma-Extraktor | 20 |
| Plasmakonverter | 30 |
| Plasmasturm-Geoengineering | 20 |
| Produktionshalle | 30 |
| Protonentorpedo | 30 |
| Protonentorpedo-Werfer (Klasse 3) | 20 |
| Protonentorpedo-Werfer (Klasse 4) | 30 |
| Quadranium-Mine | 30 |
| Quadranium-Raffinerie | 30 |
| Raumhafen | 30 |
| Schildmodule Stufe II | 80 |
| Schildmodulfabrik | 20 |
| Siedlung | 30 |
| Speicherchip-Fabrik | 30 |
| Thermal-Extraktor | 20 |
| Thermalkraftwerk | 20 |
| Torpedotransportmodul | 20 |
| VCX-100 Aufklärer | 30 |
| Vulkan-Geoengineering | 20 |
| Waffenmodule Stufe II | 80 |
| Waffenmodulfabrik | 20 |

### FP Stufe III (47 Forschungen)

| Name | FP |
|------|-----|
| Antriebsmodulkomplex | 20 |
| Außencamp | 40 |
| Berg sprengen | 60 |
| Bronzium-Mine | 60 |
| Bronzium-Raffinerie | 60 |
| Cortosis-Mine | 60 |
| Cortosis-Raffinerie | 60 |
| Corvus-Klasse Forschungsschiff | 40 |
| Dreadnought-Kreuzer | 60 |
| Erschütterungsrakete | 60 |
| Exotarium | 20 |
| Freizeitpark | 20 |
| Gebäude-Forschungszentrum | 60 |
| Großkampfschiff-Werft | 60 |
| Hammerhead-Forschungsschiff | 40 |
| Hauptkuppel | 60 |
| Holo-Kern | 40 |
| Holo-Komplex | 40 |
| Hypermaterie-Labor-Upgrade | 40 |
| Hyperraum-Spulen-Fabrik | 60 |
| Kreuzer-Werft | 60 |
| Laminanium-Mine | 60 |
| Laminanium-Raffinerie | 60 |
| Laminanium-Schaltkreis-Fabrik | 60 |
| MC75 Sternkreuzer | 60 |
| MC80 Sternkreuzer | 60 |
| Mikrodyne-Fabrik | 60 |
| Modul-Forschungszentrum | 60 |
| Mond-Kolonisierung II | 160 |
| Nebulon-B Fregatte | 60 |
| Neuranium-Mine | 60 |
| Neuranium-Raffinerie | 60 |
| Phasenkonverter-Fabrik | 60 |
| Plasmareaktor | 60 |
| Plasmatorpedo | 60 |
| Quadranium-Mine | 60 |
| Quadranium-Raffinerie | 60 |
| Raumkonstrukt-Forschungszentrum | 60 |
| Schildmodulkomplex | 20 |
| Schwere Asteroiden-Kolonisierung | 60 |
| Schwerer Plasmatorpedo | 60 |
| Schwerer Protonentorpedo | 60 |
| Sondenboje | 30 |
| Speicherchip-Fabrik | 60 |
| Technologie-Komplex | 60 |
| Venator-Klasse Kreuzer | 60 |
| Waffenmodulkomplex | 20 |

### FP Module (10 Forschungen)

| Name | FP |
|------|-----|
| Antriebsmodule Stufe III | 120 |
| Antriebsmodule Stufe IV | 180 |
| Hyperraum-Scanner | 50 |
| Hyperraumfeldscanner | 50 |
| Protonentorpedo-Werfer (Klasse 5) | 20 |
| Protonentorpedo-Werfer (Klasse 6) | 30 |
| Schildmodule Stufe III | 120 |
| Schildmodule Stufe IV | 180 |
| Waffenmodule Stufe III | 120 |
| Waffenmodule Stufe IV | 180 |

### FP Raumkonstrukte (27 Forschungen)

| Name | FP |
|------|-----|
| A-Wing Abfangjäger | 20 |
| Arbeitsdroide | 20 |
| Außenposten-Upgrade | 70 |
| BFF-1 Massenfrachter | 20 |
| CR90 Korvette | 30 |
| Consular-Fregatte | 20 |
| Corvus-Klasse Forschungsschiff | 40 |
| Dreadnought-Kreuzer | 60 |
| GR-75 Frachter | 20 |
| HWK-290 Aufklärer | 30 |
| Hammerhead-Forschungsschiff | 40 |
| Hammerhead-Korvette | 30 |
| Kleines Versorgungsdepot | 30 |
| LAAT Shuttle | 20 |
| MC75 Sternkreuzer | 60 |
| MC80 Sternkreuzer | 60 |
| Nebulon-B Fregatte | 60 |
| Pelta-Fregatte | 20 |
| Raumbasis | 90 |
| Raumkonstrukt | 30 |
| Sensorphalanx | 40 |
| U-Wing Transporter | 20 |
| VCX-100 Aufklärer | 30 |
| Venator-Klasse Kreuzer | 60 |
| Versorgungsdepot | 50 |
| Werft | 50 |
| X-Wing Jäger | 20 |

### FP Gebäude (35 Forschungen)

| Name | FP |
|------|-----|
| Beskar-Anlage | 40 |
| Beskar-Mine | 150 |
| Beskar-Schmelze | 150 |
| Bronzium-Mine | 190 |
| Bronzium-Raffinerie | 70 |
| Cortosis-Mine | 190 |
| Cortosis-Raffinerie | 70 |
| Freie Universität | 50 |
| Grav-Ball-Arena | 30 |
| Hochenergie-Empfänger | 150 |
| Hochenergie-Hyperraumplasma-Fabrik | 150 |
| Hochenergie-Transformator | 90 |
| Hyperraum-Spulen-Fabrik | 70 |
| Hyperraumteleskop | 80 |
| Laminanium-Mine | 190 |
| Laminanium-Raffinerie | 70 |
| Laminanium-Schaltkreis-Fabrik | 70 |
| Legierungslabor-Upgrade | 50 |
| Mikrodyne-Fabrik | 60 |
| Neuranium-Mine | 190 |
| Neuranium-Raffinerie | 70 |
| Orbitales Torpedogeschütz | 40 |
| Orbitales Turbolasergeschütz | 40 |
| Phasenkonverter-Fabrik | 70 |
| Planetare Schildbatterie | 40 |
| Planetarer Hypermaterie-Reaktor | 80 |
| Planetarer Schildgenerator | 40 |
| Punkt-Abwehrsystem | 40 |
| Quadranium-Mine | 190 |
| Quadranium-Raffinerie | 70 |
| Reparaturstation | 80 |
| Speicherchip-Fabrik | 70 |
| Stadtkomplex | 50 |
| Trainingshalle | 50 |
| Untergrund-Forschungszentrum | 100 |

### FP Untergrund (21 Forschungen)

| Name | FP |
|------|-----|
| Geothermalkraftwerk | 50 |
| Schacht sprengen | 60 |
| Untergrund Beskar-Mine | 50 |
| Untergrund Bronzium-Mine | 40 |
| Untergrund Cortosis-Mine | 40 |
| Untergrund Hypermaterie-Pumpe | 50 |
| Untergrund Hypermaterie-Synthesizer | 50 |
| Untergrund Kyber-Kristall-Mine | 50 |
| Untergrund Laminanium-Mine | 40 |
| Untergrund Neuranium-Mine | 40 |
| Untergrund Phrik-Mine | 50 |
| Untergrund Quadranium-Mine | 40 |
| Untergrund-Habitatkuppel | 40 |
| Untergrund-Hauptkuppel | 40 |
| Untergrund-Lagerkomplex | 40 |
| Untergrund-Partikelbeschleuniger | 50 |
| Untergrund-Plasmakonverter | 50 |
| Untergrund-Versorgungskuppel | 40 |
| Untergrund-Wissen | 40 |
| Untergrundlift (oben) | 50 |
| Untergrundlift (unten) | 50 |

## IMPERIALE (248 Forschungen)

### Doonium (4 Forschungen)

| Name | FP |
|------|-----|
| Chemische Fabrik | 10 |
| Gezeitenkraftwerk | 5 |
| Nerf-Fleischfarm | 5 |
| Transparistahl-Manufaktur | 10 |

### Transparistahl (4 Forschungen)

| Name | FP |
|------|-----|
| Durastahlanlage | 12 |
| Hypermateriesynthesizer | 12 |
| Phrik-Mine | 8 |
| Phrik-Raffinerie | 8 |

### Hypermaterie (3 Forschungen)

| Name | FP |
|------|-----|
| Gozanti-Frachter | 30 |
| Landeplattform | 30 |
| Sentinel-Klasse Kolonieschiff | 20 |

### Durastahl (1 Forschungen)

| Name | FP |
|------|-----|
| Forschungszentrum Stufe I | 12 |

### FP Stufe I (46 Forschungen)

| Name | FP |
|------|-----|
| Allianz-Akademie | 10 |
| Antriebsmodule Stufe I | 40 |
| Antriebsmodulfertigung | 10 |
| Aurodium-Mine | 20 |
| Aurodium-Presse | 20 |
| Cantina | 10 |
| Crewtransport-Modul | 20 |
| Forschungszentrum Stufe II | 20 |
| Fregattenwerft | 10 |
| Habitatkuppel | 10 |
| Hypermaterie-Pumpen | 10 |
| Imperiale Grundlagenforschung | 0 |
| Imperialer Frachter | 20 |
| Juri-Saft Kelterei | 10 |
| Jägerwerft | 10 |
| Kolonisierung unwirtlicher Planeten | 40 |
| Kryo-Nerf-Zucht | 10 |
| Kyber-Kristallmine | 10 |
| Lambda-Klasse Shuttle | 20 |
| Lancer-Fregatte | 20 |
| Leichte Asteroiden-Kolonisierung | 60 |
| Leichter Protonentorpedo | 10 |
| Micro-Protonentorpedo | 10 |
| Mond-Kolonisierung I | 40 |
| Munificent-Fregatte | 20 |
| Orbital-Solarkollektor | 10 |
| Partikel-Beschleuniger | 10 |
| Protonentorpedo-Fabrik | 10 |
| Protonentorpedo-Werfer (Klasse 2) | 10 |
| Protonentorpedo-Werfer Mk-2 | 10 |
| Raumbahnhof | 20 |
| Schildmodule Stufe I | 40 |
| Schildmodulfertigung | 10 |
| Schwerer Imperialer Frachter | 20 |
| Shuttlerampe-Modul | 20 |
| Solarfokus | 10 |
| Solarspiegel | 10 |
| Strömungsanker | 10 |
| Strömungsturbinen | 10 |
| TIE-Abfangjäger | 20 |
| TIE-Jäger | 20 |
| Geoengineering | 10 |
| Versorgungskuppel | 10 |
| Waffenmodule Stufe I | 40 |
| Waffenmodulfertigung | 10 |
| Werftkomplex | 10 |

### FP Stufe II (57 Forschungen)

| Name | FP |
|------|-----|
| Anti-Grav Trainingszentrum | 20 |
| Antriebsmodule Stufe II | 80 |
| Antriebsmodulfabrik | 20 |
| Arquitens-Korvette | 30 |
| Astrometrie-Labor | 20 |
| Außenposten-Upgrade | 30 |
| Bronzium-Mine | 30 |
| Bronzium-Raffinerie | 30 |
| Cortosis-Mine | 30 |
| Cortosis-Raffinerie | 30 |
| Forschungszentrum Stufe III | 30 |
| Frachtkontainer-Depot | 20 |
| Fusionsreaktor | 30 |
| Holo-Generator | 30 |
| Holo-Simulator | 20 |
| Hyperraum-Spulen-Fabrik | 30 |
| Kampftrainingslager | 20 |
| Klimakontrollzentrum | 30 |
| Kolonisierung extremer Planeten | 40 |
| Korvetten-Werft | 30 |
| Lambda-Klasse Siedlungsschiff | 30 |
| Laminanium-Mine | 30 |
| Laminanium-Raffinerie | 30 |
| Laminanium-Schaltkreis-Fabrik | 30 |
| Matrixsensoren | 20 |
| Mikrodyne-Fabrik | 30 |
| Mittlere Asteroiden-Kolonisierung | 60 |
| Neuranium-Mine | 30 |
| Neuranium-Raffinerie | 30 |
| Orbital-Habitat | 20 |
| Orbitales Forschungslabor | 30 |
| Phasenkonverter-Fabrik | 30 |
| Plasma-Extraktor | 20 |
| Plasmakonverter | 30 |
| Plasmasturm-Geoengineering | 20 |
| Produktionshalle | 30 |
| Protonentorpedo | 30 |
| Protonentorpedo-Werfer (Klasse 3) | 20 |
| Protonentorpedo-Werfer (Klasse 4) | 30 |
| Protonentorpedo-Werfer Mk-3 | 20 |
| Protonentorpedo-Werfer Mk-4 | 30 |
| Quadranium-Mine | 30 |
| Quadranium-Raffinerie | 30 |
| Raider-Klasse Aufklärer | 30 |
| Raider-Korvette | 30 |
| Raumhafen | 30 |
| Schildmodule Stufe II | 80 |
| Schildmodulfabrik | 20 |
| Siedlung | 30 |
| Speicherchip-Fabrik | 30 |
| Thermal-Extraktor | 20 |
| Thermalkraftwerk | 20 |
| Torpedotransportmodul | 20 |
| Vulkan-Geoengineering | 20 |
| Waffenmodule Stufe II | 80 |
| Waffenmodulfabrik | 20 |
| Waffenschießsstand\n | 20 |

### FP Stufe III (45 Forschungen)

| Name | FP |
|------|-----|
| Antriebsmodulkomplex | 20 |
| Berg sprengen | 60 |
| Bronzium-Mine | 60 |
| Bronzium-Raffinerie | 60 |
| Cortosis-Mine | 60 |
| Cortosis-Raffinerie | 60 |
| Erschütterungsrakete | 60 |
| Gebäude-Forschungszentrum | 60 |
| Gladiatoren-Arena | 20 |
| Gozanti-Forschungsschiff | 40 |
| Großkampfschiff-Werft | 60 |
| Hauptkuppel | 60 |
| Holo-Kern | 40 |
| Holo-Komplex | 40 |
| Hypermaterie-Labor-Upgrade | 40 |
| Hyperraum-Spulen-Fabrik | 60 |
| Imperiale-Klasse Sternzerstörer | 60 |
| Interdictor-Kreuzer | 60 |
| Kampfsport-Arena | 40 |
| Kreuzer-Werft | 60 |
| Laminanium-Mine | 60 |
| Laminanium-Raffinerie | 60 |
| Laminanium-Schaltkreis-Fabrik | 60 |
| Mikrodyne-Fabrik | 60 |
| Modul-Forschungszentrum | 60 |
| Mond-Kolonisierung II | 160 |
| Neuranium-Mine | 60 |
| Neuranium-Raffinerie | 60 |
| Phasenkonverter-Fabrik | 60 |
| Plasmareaktor | 60 |
| Plasmatorpedo | 60 |
| Praetor-Klasse Sternzerstörer | 60 |
| Quadranium-Mine | 60 |
| Quadranium-Raffinerie | 60 |
| Raumkonstrukt-Forschungszentrum | 60 |
| Schildmodulkomplex | 20 |
| Schwere Asteroiden-Kolonisierung | 60 |
| Schwerer Plasmatorpedo | 60 |
| Schwerer Protonentorpedo | 60 |
| Sondenboje | 30 |
| Speicherchip-Fabrik | 60 |
| Technologie-Komplex | 60 |
| Vibro-Klingen-Halle | 20 |
| Vindicator-Kreuzer | 60 |
| Waffenmodulkomplex | 20 |

### FP Module (12 Forschungen)

| Name | FP |
|------|-----|
| Antriebsmodule Stufe III | 120 |
| Antriebsmodule Stufe IV | 180 |
| Hyperraumfeldscanner | 50 |
| Protonentorpedo-Werfer (Klasse 5) | 20 |
| Protonentorpedo-Werfer (Klasse 6) | 30 |
| Protonentorpedo-Werfer Mk-5 | 20 |
| Protonentorpedo-Werfer Mk-6 | 30 |
| Schildmodule Stufe III | 120 |
| Schildmodule Stufe IV | 180 |
| Tarnfeld-Generator | 50 |
| Waffenmodule Stufe III | 120 |
| Waffenmodule Stufe IV | 180 |

### FP Raumkonstrukte (20 Forschungen)

| Name | FP |
|------|-----|
| Arbeitsdroide | 20 |
| Arquitens-Korvette | 30 |
| Außenposten-Upgrade | 70 |
| Imperiale-Klasse Sternzerstörer | 60 |
| Imperialer Frachter | 20 |
| Interdictor-Kreuzer | 60 |
| Kleines Versorgungsdepot | 30 |
| Lancer-Fregatte | 20 |
| Munificent-Fregatte | 20 |
| Praetor-Klasse Sternzerstörer | 60 |
| Raider-Korvette | 30 |
| Raumbasis | 90 |
| Raumkonstrukt | 30 |
| Schwerer Imperialer Frachter | 20 |
| Sensorphalanx | 40 |
| TIE-Abfangjäger | 20 |
| TIE-Jäger | 20 |
| Versorgungsdepot | 50 |
| Vindicator-Kreuzer | 60 |
| Werft | 50 |

### FP Gebäude (35 Forschungen)

| Name | FP |
|------|-----|
| Beskar-Anlage | 40 |
| Beskar-Mine | 150 |
| Beskar-Schmelze | 150 |
| Blaster-Schießstand | 50 |
| Bronzium-Mine | 190 |
| Bronzium-Raffinerie | 70 |
| Cortosis-Mine | 190 |
| Cortosis-Raffinerie | 70 |
| Halle der Krieger | 50 |
| Hochenergie-Empfänger | 150 |
| Hochenergie-Hyperraumplasma-Fabrik | 150 |
| Hochenergie-Transformator | 70 |
| Hyperraum-Spulen-Fabrik | 70 |
| Hyperraumteleskop | 80 |
| Jagdgründe | 30 |
| Laminanium-Mine | 190 |
| Laminanium-Raffinerie | 70 |
| Laminanium-Schaltkreis-Fabrik | 70 |
| Legierungslabor-Upgrade | 50 |
| Mikrodyne-Fabrik | 60 |
| Neuranium-Mine | 190 |
| Neuranium-Raffinerie | 70 |
| Orbitales Blasterkanonegeschütz | 40 |
| Orbitales Torpedogeschütz | 40 |
| Phasenkonverter-Fabrik | 70 |
| Planetare Schildbatterie | 40 |
| Planetarer Hypermaterie-Reaktor | 80 |
| Planetarer Schildgenerator | 40 |
| Punkt-Abwehrsystem | 40 |
| Quadranium-Mine | 190 |
| Quadranium-Raffinerie | 70 |
| Reparaturstation | 80 |
| Speicherchip-Fabrik | 70 |
| Stadtkomplex | 50 |
| Untergrund-Forschungszentrum | 100 |

### FP Untergrund (21 Forschungen)

| Name | FP |
|------|-----|
| Geothermalkraftwerk | 50 |
| Schacht sprengen | 60 |
| Untergrund Beskar-Mine | 50 |
| Untergrund Bronzium-Mine | 40 |
| Untergrund Cortosis-Mine | 40 |
| Untergrund Hypermaterie-Pumpe | 50 |
| Untergrund Hypermaterie-Synthesizer | 50 |
| Untergrund Kyber-Kristall-Mine | 50 |
| Untergrund Laminanium-Mine | 40 |
| Untergrund Neuranium-Mine | 40 |
| Untergrund Phrik-Mine | 50 |
| Untergrund Quadranium-Mine | 40 |
| Untergrund-Habitatkuppel | 40 |
| Untergrund-Hauptkuppel | 40 |
| Untergrund-Lagerkomplex | 40 |
| Untergrund-Partikelbeschleuniger | 50 |
| Untergrund-Plasmakonverter | 50 |
| Untergrund-Versorgungskuppel | 40 |
| Untergrund-Wissen | 40 |
| Untergrundlift (oben) | 50 |
| Untergrundlift (unten) | 50 |

## EXCLUDE-Gruppen REBELLEN

Innerhalb einer Gruppe: nur EINE Forschung wählbar, Rest permanent gesperrt.

**Gruppe 1** — Wahl zwischen (je mehrstufig):
- Bronzium-Mine
- Cortosis-Mine
- Laminanium-Mine
- Neuranium-Mine
- Quadranium-Mine

**Gruppe 2** — Wahl zwischen (je mehrstufig):
- Hyperraum-Spulen-Fabrik
- Laminanium-Schaltkreis-Fabrik
- Phasenkonverter-Fabrik
- Speicherchip-Fabrik

**Gruppe 3** — Wahl zwischen (je mehrstufig):
- MC80 Sternkreuzer
- Nebulon-B Fregatte
- Venator-Klasse Kreuzer

**Gruppe 4** — Wahl zwischen:
- Consular-Fregatte
- Pelta-Fregatte

**Gruppe 5** — Wahl zwischen:
- A-Wing Abfangjäger
- X-Wing Jäger

**Gruppe 6** — Wahl zwischen:
- LAAT Shuttle
- U-Wing Transporter

**Gruppe 7** — Wahl zwischen:
- BFF-1 Massenfrachter
- GR-75 Frachter

**Gruppe 8** — Wahl zwischen:
- Beskar-Mine
- Hochenergie-Empfänger

**Gruppe 9** — Wahl zwischen:
- CR90 Korvette
- Hammerhead-Korvette

**Gruppe 10** — Wahl zwischen:
- HWK-290 Aufklärer
- VCX-100 Aufklärer

**Gruppe 11** — Wahl zwischen:
- Dreadnought-Kreuzer
- MC75 Sternkreuzer

**Gruppe 12** — Wahl zwischen:
- Corvus-Klasse Forschungsschiff
- Hammerhead-Forschungsschiff

**Gruppe 13** — Wahl zwischen:
- Plasmatorpedo
- Schwerer Protonentorpedo

## EXCLUDE-Gruppen IMPERIALE

Innerhalb einer Gruppe: nur EINE Forschung wählbar, Rest permanent gesperrt.

**Gruppe 1** — Wahl zwischen (je mehrstufig):
- Bronzium-Mine
- Cortosis-Mine
- Laminanium-Mine
- Neuranium-Mine
- Quadranium-Mine

**Gruppe 2** — Wahl zwischen (je mehrstufig):
- Hyperraum-Spulen-Fabrik
- Laminanium-Schaltkreis-Fabrik
- Phasenkonverter-Fabrik
- Speicherchip-Fabrik

**Gruppe 3** — Wahl zwischen:
- Lancer-Fregatte
- Munificent-Fregatte

**Gruppe 4** — Wahl zwischen:
- TIE-Abfangjäger
- TIE-Jäger

**Gruppe 5** — Wahl zwischen:
- Imperialer Frachter
- Schwerer Imperialer Frachter

**Gruppe 6** — Wahl zwischen:
- Beskar-Mine
- Hochenergie-Empfänger

**Gruppe 7** — Wahl zwischen:
- Arquitens-Korvette
- Raider-Korvette

**Gruppe 8** — Wahl zwischen:
- Imperiale-Klasse Sternzerstörer
- Vindicator-Kreuzer

**Gruppe 9** — Wahl zwischen:
- Interdictor-Kreuzer
- Praetor-Klasse Sternzerstörer

**Gruppe 10** — Wahl zwischen:
- Plasmatorpedo
- Schwerer Protonentorpedo


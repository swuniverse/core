# K7a2 final committed candidate build — 2026-11-09

## Result

**PASS:** the actual backend build ran successfully on exact clean committed candidate `29ac20e249184b87789b0c7ca0494e549c1e7f10`, including the final LayerKnowledge readback correction. This NEW ignored report closes only the final-source build evidence gap. No implementation or independent review was performed.

The earlier build was not a build of the final corrected candidate. Its historical timing caveat remains true and unchanged in `.workmux/tmw-K7a2-resumed-atomic-report-20261109.md`. This later invocation supplies separate final-candidate evidence; it does not relabel the first build.

## Exact invocation and output

Working directory: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2`

```sh
NX_DAEMON=false NX_NO_CLOUD=true npm exec --offline -- nx run backend:build --skip-nx-cache > .workmux/k7a2-resumed-final-build-corrected.log 2>&1
```

- Actual command exit: **0**.
- NEW ignored log: `.workmux/k7a2-resumed-final-build-corrected.log`.
- Log SHA256: `90bc6225a70e7b138f728a5b831ea2a55316efc0c69f2778188b6f069ece8064`.
- Log records `nx run shared:build` executing `tsc --build tsconfig.lib.json`, followed by `nx run backend:build` executing `webpack-cli build --node-env=production`.
- Webpack: **compiled successfully**, hash **`3186603adbe8d3b0`**.
- Nx: successfully ran backend build and its one dependent task.
- Cache accounting: Nx task cache was explicitly bypassed with `--skip-nx-cache`; the log shows both dependency and backend commands, without a cached-task replay marker. `NX_DAEMON=false` and `NX_NO_CLOUD=true` were supplied. This does **not** claim that every internal TypeScript/webpack incremental artifact was cleared: the dependency's actual command is `tsc --build`, without `--force`, and no build caches were deleted. No additional dependency build was invoked outside the requested backend target.

## Before/after candidate and worktree checks

| Observation | Before build | After build |
| --- | --- | --- |
| HEAD | `29ac20e249184b87789b0c7ca0494e549c1e7f10` | `29ac20e249184b87789b0c7ca0494e549c1e7f10` |
| Branch | `agent-tmw-k7a2` | `agent-tmw-k7a2` |
| Tree | `861825a4c97d637e5b450e839cc967c917ab5fa4` | `861825a4c97d637e5b450e839cc967c917ab5fa4` |
| `git status --porcelain=v1 --untracked-files=all` | empty / clean | empty / clean |

Before execution, the exact expected HEAD and clean status were enforced, and both new evidence targets were confirmed absent and ignored. All 23 files changed by the candidate were SHA256-fingerprinted before and after. Their raw bytes remained identical; after-build hashes also matched `git show HEAD:<path>` for every file, with **zero mismatches**.

The shared source/hash manifest below is the identical **before and after** manifest, not an assumed snapshot. It includes all candidate production source, maintained test and tracker changes.

```text
04cc528842d8da52380c24277e21f0a7f7b4f168981ad7ff213348629ceaa715  .scratch/stu-parity/issues/tmw-K7a-wurmloch-betreten-und-verlassen.md
fcb50757faf93e1249874cf940deeb57ab22c16aa8019bc1277a7b52f0aa09ea  .scratch/stu-parity/issues/tmw-K7a1-wurmloch-backend-kern.md
5e7ff0bcaecbcfdb61e79a3d801e15d9f185271524ed6ffc771419b0a30f79ba  .scratch/stu-parity/issues/tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md
5de43c348f73681578e98cdc569daec369fb9ec35f026ffdef1acf036d697f44  apps/backend/src/app.module.ts
6498515bed9da3551f6e0a77dd4ac12fd764e3aa45e889ee63770c92c0d3cc43  apps/backend/src/modules/messaging/messaging.service.ts
a13be29c56836e7909130c42707d7025ccd48f174ee9f7d95c9c107b3417cf13  apps/backend/src/modules/spacecraft/cartography-plan.service.ts
335e9b10ec3ca4bbe9f69ce0bcd9830b401e14f9cbdcc45e72ec8e663c7f64e3  apps/backend/src/modules/spacecraft/field-effect-consequence.ts
2d875df54e10a3554db3ac85c2a383f193cb34692f448fcff890031d5d2d9d71  apps/backend/src/modules/spacecraft/field-transition-executor.ts
dc3b17b6f1d5f18bd00e6a1b73e46aad29b41312f1f69352cc7be2fd827314c8  apps/backend/src/modules/spacecraft/flight-consequence-pipeline.ts
d4abd1a1a1d4b86b95f8ba6164e615c5711e6928fd2074812062ad673d738b1b  apps/backend/src/modules/spacecraft/flight-signature.service.ts
15b4776df5415aea3f348302dd110dfcdc2206164a8267f6c5fd327bdd53194e  apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts
efc357df26896811b30b09931031e84db776ec9570d21b767047f4151bf39d9d  apps/backend/src/modules/spacecraft/spacecraft-repair.service.ts
ed8b6492a539898352d92323cf63464e6c2c718ac931b5f434242434c94b77e9  apps/backend/src/modules/spacecraft/spacecraft-takeover.service.ts
ac542db2034f11fb80bcaec3e1159bb8cd685d452208c5fc2c6304c42c4955fb  apps/backend/src/modules/spacecraft/spacecraft.controller.ts
933fbc0d54e59acb5f9740f3abd63541cd53e7c311209b8db5dfea911918605f  apps/backend/src/modules/spacecraft/spacecraft.module.ts
e0a8b58e9db28c9a05e573c63bdfc1818ddb586448d5e59424df3962ef733e8a  apps/backend/src/modules/spacecraft/starmap-contacts-requests.int-spec.ts
e379a39a68bbe9ef7211640f5ed89bb055a2348f4ee59a8db764b95dd1895ff7  apps/backend/src/modules/spacecraft/wormhole-entry-contract.ts
fcb18a91ae25b7c074abcc2c235f04f9b1232baeddef959014d2b74fdfc8d80e  apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts
fbe4392fd75de23e75f9e6c2ab0833869da2fcf345640bbb9dd46b712042963a  apps/backend/src/modules/spacecraft/wormhole-passage.int-spec.ts
a93530714abf3a21a59e5f75246289ecb79caf689da808d4f8385d2e22ab846b  apps/backend/src/modules/spacecraft/wormhole-passage.service.ts
775bfc98807a12157fd8b7a8cebc0246e5397b715f4c5cad4d394fc5fb4979f0  apps/backend/src/modules/starmap/exploration.service.ts
8a45ff201604ad8baab9e351a5b5cb78ad98d6f3acdfcf485608fa95e4e98dde  apps/backend/src/modules/starmap/layer-knowledge.service.ts
ca3758e3146d30520bd9985f69e16a0cff328fa9acedad5413ff5798d7b13812  apps/backend/src/testing/integration/data-source.ts
```

Preserved historical evidence has identical before/after SHA256:

- `.workmux/tmw-K7a2-resumed-atomic-report-20261109.md`: `ae8c783cd59692888801e25d616ac4d53c196d7eab039fb6d56384576497aa33`.
- `.workmux/k7a2-resumed-final-build.log`: `79ea383b5665b6eb0dd382d941a2d24a2548fb4af2de3180d10a53b9ab4f9dba`.

## Scope and stop

Only the requested actual backend build and read-only candidate/evidence checks ran, plus creation of this new ignored report. No source/tracker/package changes, other-checkout/STU access, new dependencies, external service, commit, push, merge, nested agent or workflow. No repeated tests, standalone typecheck/lint, database or frontend runs. The shared build dependency was executed solely as part of the requested backend build target.

Prior corrected unit/PG/type/lint evidence remains historical and was not rerun here. Independent reviews start separately; this build result does not claim review approval. No further implementation. Worker stops.

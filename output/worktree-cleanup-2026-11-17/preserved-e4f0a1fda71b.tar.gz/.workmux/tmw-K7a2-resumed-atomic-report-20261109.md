# tmw-K7a2 resumed atomic backend report — 2026-11-09

## Outcome and handoff

K7a2 atomic wormhole fleet/arrival integration is implemented, completing the joint local backend acceptance of K7a1/K7a2. The authenticated route is registered with the complete executor, not a partial public planner. Final corrected type, lint, unit and real PostgreSQL gates pass. Implementation and local acceptance are complete; **independent review and serial integration have not run and remain outstanding**. No PASS from an independent reviewer is claimed.

Stop here for independent review/serial integration. No push, merge, main-checkout access or K7a3 start. Shared/frontend remain out of scope. The single build passed before the bounded final corrections described below; the final corrected source was not rebuilt.

Implementation commit: `29ac20e249184b87789b0c7ca0494e549c1e7f10` (`feat(spacecraft): integrate atomic wormhole passage (stu-parity tmw-K7a2)`), with required Co-Authored-By attribution. Direct parent remains the separate planner checkpoint `b7e8632ec1276515cd0658ec62d2ca7693d342f8`; committed tree is `861825a4c97d637e5b450e839cc967c917ab5fa4`. Post-commit branch is still `agent-tmw-k7a2`, tracked/untracked nonignored working tree is clean, and integrated baseline ancestry remains valid. The report is ignored and not committed. All 32 individual report source/final-log hashes were verified against raw file bytes with zero mismatches; committed complete patch fingerprint matches the staged value. No amend, push or merge.

## Exact branch, baseline and preservation

- Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-tmw-k7a2`
- Branch: `agent-tmw-k7a2`
- Original starting HEAD: `ff16922a7b93b620acb4d51d7180cf255dd970b2`
- Original old base: `c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab`
- Supplied integrated prerequisites: fleet `9219a25e6965814064fc834821f04847748b1ff5`, stale movement `c212d12d28d8edd059b3148dcec638dcd44faac1`, movement identity follow-up `59f716f9fbc3056371ff16ebe61c21fac5e45006`.
- This branch alone was rebased from the old base onto exact integrated baseline `59f716f9fbc3056371ff16ebe61c21fac5e45006`, without conflicts.
- Rebased K7a1 planner checkpoint: `b7e8632ec1276515cd0658ec62d2ca7693d342f8`. All six original stage files were byte-identical immediately after rebase. The planner implementation and planner/contract tests remain unchanged by K7a2; the contract safety comment/controller registration assertion changed only with complete route activation.
- Baseline ancestry verified again before implementation commit.
- The rejected worker issue edit was preserved exactly before restoring only that edit. Backups remain ignored and intact:
  - `.workmux/k7a2-stop-preserved/issue.md`: SHA256 `4be5a66ebc3d7787852f50ce69e49b6ed7d0bf509ba688bd758c3868f2bd885a`
  - `.workmux/k7a2-stop-preserved/issue.diff`: SHA256 `338b752ebeca82e64f5864d0a50cb13d9f4eb6bc54be5e744e384ec905c51684`
- Historical `.workmux/tmw-K7a2-integration-report-20261109.md` was not overwritten; SHA256 `8167e87fb2cec80fc77bbb4568ffd9faa6ea3ead4df60fe0aecd137d778bdabe`. Its earlier ready-for-human recommendation was not accepted and is superseded by this implementation. Old race diagnostics were not repeated.
- This report is a NEW ignored file. No stash, force, amend, dependency reinstall, indexing, external service, secret, migration generation or synchronize operation was introduced. No `.codegraph/` exists, so CodeGraph was not invoked.

## Atomic public execution contract

`POST /api/spacecraft/:id/wormhole/enter` uses existing JWT authentication/game-access guarding, ParseIntPipe and production-style ValidationPipe. The backend-local DTO accepts optional positive integer `wormholeId`; forged user/destination body fields cannot override authenticated ownership or authoritative destination. Backend-local result is `{ wormholeId, direction, shipIds, locationId }`; no Shared contract expansion.

`WormholePassageService.enter` owns one READ COMMITTED transaction and passes its EntityManager through all passage persistence. It invokes the integrated fleet helper before initiating ship locks: current initiating fleet FOR NO KEY UPDATE, complete sorted member spacecraft FOR UPDATE NOWAIT, membership/ownership revalidation, and current initiating leadership. Unlike ordinary nonfixed-fleet partial preparation, passage validates every participant and refuses the entire operation if any is invalid.

Outgoing tractor closure is deduplicated by spacecraft ID. A carried target belonging to another fleet brings that fleet's complete current membership. Secondary spacecraft and fleet locks exclusively use NOWAIT (including secondary fleet FOR NO KEY UPDATE); they never wait in inverse fleet/ship ordering while primary locks are held. Secondary ownership, current exact membership and leader membership are revalidated. Multiple outgoing targets in the same carried fleet do not duplicate writes. External incoming tractor holders refuse passage. Installed modules are sorted/write-locked NOWAIT; crew assignments are sorted by crewId/read-locked NOWAIT. All affected ships receive hydrated authoritative location/field/layer/star-system/field-type relations and their own loaded modules before policy checks.

Existing ownership, location, station, standby, combat, destroyed, in-flight, module/runtime, active-warp, required-crew and tractor constraints apply to the complete selected set. ENTRY checks both runtime impulse state and locked backing installed impulse integrity/cooldown; stale runtime values cannot authorize a destroyed/cooling installed drive. Each ship activates only its own inactive impulse and pays only its own normal activation EPS, currently **zero** in SWU. Already-active drives are not charged. EXIT requires no impulse activation or travel resource. No invented passage, hull-flight, warp or tractor tariff. Relocation clears the docking reference without adding a flight tariff.

Wormholes are active authoritative local entries or bidirectional local reverse exits, selected explicitly when ambiguous. Candidate wormhole rows are read-locked. Missing/inactive/nonlocal selectors, invalid direction, blocked fixed exit, no passable random exit and invalid RNG refuse. Injected default-allow policy and Math.random are production providers; tests can override them. Random selection considers the complete passable target-layer field set.

Policy arguments are structured-cloned detached deeply frozen hydrated snapshots. Cross-realm Dates are recognized via node:util types.isDate and wrapped so date setters throw while reads remain bound; awaited policy code cannot mutate the live locked entity or its snapshot timestamp. Planner output alone is not durable authorization: after awaited checks, the current origin field coordinates/layer and origin location field identity are reloaded/locked and compared, and the selected destination field is reloaded/locked and deeply compared against its pre-policy state. Changed state refuses with no passage mutation.

## Transaction-bound arrival and cancellation adapters

- `FieldTransitionExecutor.enterDestination` invokes only the destination, never an invented orthogonal path through intermediate galaxy coordinates. Passability is checked and the existing FlightConsequencePipeline receives optional caller transaction context.
- Existing field effects mutate the locked ship in the transaction. Durable effect messages use the caller manager. FIELD_EFFECT gateway callbacks are collected for afterCommit.
- Exploration terrain writes use the caller manager and existing sensor-range semantics from already hydrated modules. Destination-layer knowledge is mandatory even with sensors inactive. Ordinary arrival does **not** grant SystemExploration/Systementdeckung.
- Transactional KNOWN insertion uses ON CONFLICT DO NOTHING, preserving concurrently committed EXPLORED status/timestamps. Existing nontransaction entrypoints retain their prior behavior. A concurrent terrain FULL upgrade is preserved by existing save behavior (preservation test, not a new exploration algorithm).
- FlightSignatureService uses the caller manager, including class metadata lookup, and writes origin/destination signatures with null compass directions for discontinuous passage.
- Each unique participant receives one manager-saved ship log `Wurmloch durchflogen` and one manager-saved success message, plus any actual effect/cancellation messages.
- Cartography finalization reset, takeover cancellation/prestige refund/history/two-owner durable messages, station-repair removal, own repair cancellation/part refunds and cancellation messages are caller-manager bound. Relevant cartography/takeover/repair/cargo row locks are NOWAIT on the passage path, preventing inverse waits under spacecraft locks. Existing other callers retain their default lock behavior.
- Repair refund creates an absent CargoItem with amount 0 before addition, avoiding NaN.
- MessagingService accepts a local `{ manager, afterCommit }` context; no outbox, global mutable manager or new event architecture. Gateway callbacks run only after the transaction resolves successfully. A thrown transaction discards all durable writes and emits none. Post-commit delivery errors remain possible after durable commit; no retry/outbox guarantee is claimed.
- SQL lock contention code 55P03 is translated to a controlled BadRequest only after transaction rollback. Unexpected persistence failures propagate (HTTP fault-injection deliberately returns 500).
- Production AppModule datasource metadata now includes the existing SpacecraftTakeover entity; the real production HTTP graph exposed its prior omission. No synchronize/options/migration changes.

## Maintained public acceptance evidence

New service integration suite: 53 cases against real disposable PostgreSQL and committed migrations. New authenticated production HTTP suite: 9 cases using the real AppModule dependency graph, actual production datasource options/entities, JWT strategy, guards, repositories and arrival services. Only the gateway is replaced for observing externally visible events; no mocked persistence or private movement method proves atomicity. The service fixture uses real executed collaborators; placeholders cover unrelated, unexecuted dependencies only.

Maintained cases cover full fleet success, seven additional member eligibility failures plus existing status/kind failures, no partial nonfixed fleet, own zero-cost inactive activation/active balances, reverse EXIT without impulse, complete random target selection, explicit/missing/ambiguous/inactive/nonlocal/invalid selectors, all-member crew, installed impulse stale-runtime mismatch, stable hydrated awaited snapshots including Date setters, changed origin/destination, docking link, destination-only effects, literal sensor radius, mandatory knowledge, no Systementdeckung, signatures/log/messages exactly once per unique participant, repair/task/cargo contention and refunds, cartography/takeover/prestige cancellation, tractor single/overlap/carried-complete-fleet/double-target deduplication and secondary contention.

Real public `SpacecraftService.joinFleet(userId, fleetId, shipId)` demonstrably waits across an actual passage transaction (pg_blocking_pids/pg_stat_activity barrier), then refuses an old-location joiner after commit without splitting the fleet. Real ordinary `flyGalaxy` loaded before an actual passage then rejects specifically with the stale-state error containing `veraltet`, leaving no orphan arrival/signature/success writes. These preserve the supplied concurrency prerequisites, not reenact the old simulated diagnostics.

Actual PostgreSQL triggers/subscribers inject downstream failure/barriers. Full fleet rollback verifies spacecraft/resource/runtime, effects, terrain/knowledge, signatures/log/all messages, cartography, takeover/prestige, repairs/refund cargo and zero gateway emissions. Production HTTP durable-message failure verifies 500 and unchanged durable state/no gateway. Barriers are released in cleanup and race checks have bounded NOWAIT deadlines; premature public operation failure is surfaced rather than hanging indefinitely.

## Focused TDD history and honest failure classifications

Retained `.workmux/k7a2-resumed-*.log` files contain both failed and passing runs. One vertical behavioral slice was implemented at a time at the agreed public service/HTTP seams. Existing already-green assertions were labeled preservation, not credited as RED.

Representative substantive RED -> eventual GREEN:

- initial unimplemented passage -> single atomic relocation; missing manager-bound destination effects -> arrival adapters;
- running repair persists -> caller cancellation; missing amount initialization -> refund fix;
- missing complete fleet crew refusal -> locked assignments; incoming/outgoing tractor set and overlap -> full selection/dedup;
- policy lacked detached hydration -> immutable snapshots; Date setters mutated frozen Dates -> Date proxy, then cross-realm recognition;
- destination changed while policy awaited -> locked current state comparison (24 passing cases);
- destroyed installed impulse with stale runtime -> backing integrity check (25); cooling installed impulse with stale runtime -> backing cooldown check (26);
- concurrent EXPLORED became KNOWN -> transactional conflict-do-nothing insert (29);
- missing snapshot fieldType -> final hydration (46);
- actual production route 404 -> registration; subsequent 500 missing SpacecraftTakeover metadata -> production entity registration, then real successful route;
- outgoing target's secondary fleet split -> complete secondary NOWAIT fleet integration (47); raw contention error -> controlled refusal (48);
- repair lock caused inverse wait -> passage NOWAIT tasks (combined service/HTTP 58);
- origin changed while policy awaited -> origin field/location revalidation (50);
- two outgoing targets in same secondary fleet produced duplicate participant -> ID dedup (51);
- refund cargo lock waited -> propagated NOWAIT refund lock (52).

Do not mistake intermediate filenames for a passing gate: the first `green-snapshot-date` still failed because instanceof Date did not recognize the cloned cross-realm Date; later types.isDate fixed it. `green-production-http` initially failed 500 and only `green-production-http-entities` passed. The first `green-repair` exposed NaN and the refund follow-up passed.

Fixture/setup failures are not behavioral RED evidence: initial join arguments were wrong and corrected to the actual public signature; generic movement error was insufficient proof and strengthening it exposed a missing installed HYPERDRIVE fixture, then the actual stale-state rejection passed. CrewAssignment sorting was corrected from nonexistent id to crewId. The newest terrain save literals caused forced typecheck failure and were replaced by ExplorationLevel enum values, not casts/assertion weakening.

Already-green preservation runs include destination discontinuity, fleet/direction/selection coverage, before-commit notifications, public concurrency after fixture fixes, complete rollback and concurrent terrain preservation. `red-terrain-preservation.log` is misleadingly named: all 53 cases already passed; no implementation change followed and it is **not** a meaningful RED.

Protocol caveat: the first isolated Date RED used a test-name filter and reported 1 failure/22 filtered skips. Those existing tests were not deleted or skipped in source, but this incremental run did contain skips and is not described as zero-skip. Final complete unit/PostgreSQL runs have zero skips. No any casts, skip/todo exclusions, passWithNoTests tricks, weakened assertions or silent baseline exceptions were added.

## Exact final gates, exits and timing

All commands ran at the worktree root with existing dependencies, normal permissions and offline npm. PostgreSQL runs unset ambient DATABASE_URL/INTEGRATION_DATABASE_URL; the existing harness then supplies a disposable PostgreSQL 16 database with committed migrations and synchronize:false, never ambient/shared stu-db-1. Existing local root game-data remains in use. No frontend rerun.

```sh
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/modules/spacecraft/wormhole-passage.int-spec.ts apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts apps/backend/src/modules/spacecraft/fleet-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/movement-concurrency.int-spec.ts apps/backend/src/modules/spacecraft/starmap-contacts-requests.int-spec.ts > .workmux/k7a2-resumed-final-targeted-postgresql.log 2>&1
npm exec --offline -- eslint apps/backend --no-cache > .workmux/k7a2-resumed-final-lint.log 2>&1
npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --force > .workmux/k7a2-resumed-final-spec-types.log 2>&1
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache > .workmux/k7a2-resumed-final-units.log 2>&1
NX_DAEMON=false NX_NO_CLOUD=true npm exec --offline -- nx run backend:build --skip-nx-cache > .workmux/k7a2-resumed-final-build.log 2>&1
npm exec --offline -- tsc --build apps/backend/tsconfig.spec.json --force > .workmux/k7a2-resumed-final-spec-types-corrected.log 2>&1
npm exec --offline -- jest --config apps/backend/jest.config.cts --runInBand --no-cache > .workmux/k7a2-resumed-final-units-corrected.log 2>&1
unset DATABASE_URL INTEGRATION_DATABASE_URL; npm exec --offline -- jest --config apps/backend/jest.integration.config.cts --runInBand --no-cache > .workmux/k7a2-resumed-final-full-postgresql.log 2>&1
npm exec --offline -- eslint apps/backend --no-cache > .workmux/k7a2-resumed-final-lint-corrected.log 2>&1
```

| Gate | Actual result | Exit |
| --- | --- | --- |
| Targeted PostgreSQL | 5 suites / 116 tests pass, zero skips, 84.399s | 0 |
| First lint | 0 errors / 1438 warnings | 0 |
| First forced spec types | ExplorationLevel literal/overload errors | 2 |
| First complete units | 1 failed / 212 passed suites; 2 failed / 1991 passed tests, 62.715s | 1 |
| Build, executed ONCE | Actual shared:build dependency then backend webpack; hash 1aa5f5cd8028bf7d, success, no Nx-cache replay | 0 |
| Corrected forced spec types | Pass, empty output | 0 |
| Corrected complete units | 213 suites / 1993 tests pass, zero skips, 64.224s | 0 |
| Full PostgreSQL, executed ONCE | 40 suites / 398 tests pass, zero skips, 284.663s | 0 |
| Corrected final lint | 0 errors / 1438 warnings | 0 |
| Final worktree/staged diff checks | git diff --check and git diff --cached --check pass | 0 |

The first unit failure was the existing LayerKnowledge unit fixture lacking findOneByOrFail. Source readback was changed to the selected repository's findOneBy plus an explicit missing-row error; existing assertions were not weakened. The other final correction was replacing test terrain literals with actual ExplorationLevel enum members. These **two bounded corrections occurred after the single successful build**. Corrected forced types/complete units/full PostgreSQL/lint all ran successfully afterward; no second build/full PostgreSQL invocation was used. Subsequent edits were tracker evidence/report only. Do not report the earlier artifact as a build of final corrected source.

Warnings are retained: ts-jest isolatedModules deprecation, pg concurrent-query deprecation, 1438 ESLint warnings. The deliberate HTTP trigger failure logs a Nest ERROR/500; the test passed by asserting full rollback. No warning suppression or hidden baseline exemption.

## Acceptance tracking and review boundary

Only K7a1/K7a2 genuine backend criteria and their parent backend child checkboxes are completed. Historical comments are retained. Child `resolved` explicitly means implementation/local backend acceptance, not independent approval or merge. Parent remains the already-resolved tracking split; K7a3 remains unchecked, with no implementation changes.

Independent review should examine primary/secondary fleet lock semantics and full current membership, manager coverage and exact rollback, snapshot Date handling/post-await field validation, resource semantics, production registration and preserved ordinary movement/join behavior. No all-writer concurrency redesign is claimed; relational field-type/admin edits and post-commit notification failure semantics are not new guaranteed architectures. Independent reviewers should also account for the final-source build timing caveat.

## Final source and evidence fingerprints

Staged complete binary patch against planner checkpoint SHA256: `2575178be446cc90b0cfef78bbc9923c1a51a0bd598b1f707a74e2ee87862a06`.
Staged repository tree: `861825a4c97d637e5b450e839cc967c917ab5fa4`.
Scope: 23 files, 2811 insertions / 83 deletions. No package, lockfile, nx.json, map/DECISIONS, Shared/frontend or migrations.

Source SHA256 (raw final file bytes):

```text
04cc528842d8da52380c24277e21f0a7f7b4f168981ad7ff213348629ceaa715  .scratch/stu-parity/issues/tmw-K7a-wurmloch-betreten-und-verlassen.md
fcb50757faf93e1249874cf940deeb57ab22c16aa8019bc1277a7b52f0aa09ea  .scratch/stu-parity/issues/tmw-K7a1-wurmloch-backend-kern.md
5e7ff0bcaecbcfdb61e79a3d801e15d9f185271524ed6ffc771419b0a30f79ba  .scratch/stu-parity/issues/tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md
5de43c348f73681578e98cdc569daec369fb9ec35f026ffdef1acf036d697f44  apps/backend/src/app.module.ts
6498515bed9da3551f6e0a77dd4ac12fd764e3aa45e889ee63770c92c0d3cc43  apps/backend/src/modules/messaging/messaging.service.ts
a13be29c56836e7909130c42707d7025ccd48f174ee9f7d95c9c107b3417cf13  apps/backend/src/modules/spacecraft/cartography-plan.service.ts
335e9b10ec3ca4bbe9f69ce0bcd9830b401e14f9cbdcc45e72ec8e663c7f64e3  apps/backend/src/modules/spacecraft/field-effect-consequence.ts
2d875df54e10a3554db3ac85c2a383f193cb34692f448fcff890031d5d2d9d71  apps/backend/src/modules/spacecraft/field-transition-executor.ts
dc3b17b6f1d5f18bd00e6a1b73e46aad29b41312f1f69352cc7be2fd827314c8  apps/backend/src/modules/spacecraft/flight-consequence-pipeline.ts
d4abd1a1a1d4b86b95f8ba6164e615c5711e6928fd2074812062ad673d738b1b  apps/backend/src/modules/spacecraft/flight-signature.service.ts
15b4776df5415aea3f348302dd110dfcdc2206164a8267f6c5fd327bdd53194e  apps/backend/src/modules/spacecraft/spacecraft-cartography-api.spec.ts
efc357df26896811b30b09931031e84db776ec9570d21b767047f4151bf39d9d  apps/backend/src/modules/spacecraft/spacecraft-repair.service.ts
ed8b6492a539898352d92323cf63464e6c2c718ac931b5f434242434c94b77e9  apps/backend/src/modules/spacecraft/spacecraft-takeover.service.ts
ac542db2034f11fb80bcaec3e1159bb8cd685d452208c5fc2c6304c42c4955fb  apps/backend/src/modules/spacecraft/spacecraft.controller.ts
933fbc0d54e59acb5f9740f3abd63541cd53e7c311209b8db5dfea911918605f  apps/backend/src/modules/spacecraft/spacecraft.module.ts
e0a8b58e9db28c9a05e573c63bdfc1818ddb586448d5e59424df3962ef733e8a  apps/backend/src/modules/spacecraft/starmap-contacts-requests.int-spec.ts
e379a39a68bbe9ef7211640f5ed89bb055a2348f4ee59a8db764b95dd1895ff7  apps/backend/src/modules/spacecraft/wormhole-entry-contract.ts
fcb18a91ae25b7c074abcc2c235f04f9b1232baeddef959014d2b74fdfc8d80e  apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts
fbe4392fd75de23e75f9e6c2ab0833869da2fcf345640bbb9dd46b712042963a  apps/backend/src/modules/spacecraft/wormhole-passage.int-spec.ts
a93530714abf3a21a59e5f75246289ecb79caf689da808d4f8385d2e22ab846b  apps/backend/src/modules/spacecraft/wormhole-passage.service.ts
775bfc98807a12157fd8b7a8cebc0246e5397b715f4c5cad4d394fc5fb4979f0  apps/backend/src/modules/starmap/exploration.service.ts
8a45ff201604ad8baab9e351a5b5cb78ad98d6f3acdfcf485608fa95e4e98dde  apps/backend/src/modules/starmap/layer-knowledge.service.ts
ca3758e3146d30520bd9985f69e16a0cff328fa9acedad5413ff5798d7b13812  apps/backend/src/testing/integration/data-source.ts
```

Final log SHA256 (under `.workmux/`):

```text
79ea383b5665b6eb0dd382d941a2d24a2548fb4af2de3180d10a53b9ab4f9dba  k7a2-resumed-final-build.log
ec77b28cc69be52be0da09fd2566d75b33a69158bd7622c76a324fcaae08d571  k7a2-resumed-final-full-postgresql.log
0e38d961e4cf75cb18ed1d16ddeea4b4b089334b29bed1c15a52d24cdd3eef00  k7a2-resumed-final-lint-corrected.log
86d8fbdac2219d63164462738951990c9afc4c6f35f0edea1b59b53b50a7c240  k7a2-resumed-final-lint.log
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  k7a2-resumed-final-spec-types-corrected.log
8bfc134003526e79821b3e73426638672965d724e6a46aa6caa084a15c83a2d2  k7a2-resumed-final-spec-types.log
dca5efac400482dc178837e43d06e0abbf58d54b22ed92b679537d9abd5c1aa6  k7a2-resumed-final-targeted-postgresql.log
970164106a4b6d401259b1314db3ac096745ff11cc219f89395dbfdcbadef005  k7a2-resumed-final-units-corrected.log
a13be3ad8bfb4e2bc9ccde8799d088d033d35e80ee873e1341bf8131e5c2d942  k7a2-resumed-final-units.log
```

All 109 resumed `.log` files, including failed/intermediate runs and type logs, remain intact. Aggregate SHA256 `dd62ece07f9744bd9484d9a69e2c47e8588df391aefc4839f888af267b5ad106` hashes the sorted basename inventory formatted as `<sha256>  <basename>\n` for every `.workmux/k7a2-resumed-*.log`. This is an aggregate inventory fingerprint, not a claim that all named logs passed.

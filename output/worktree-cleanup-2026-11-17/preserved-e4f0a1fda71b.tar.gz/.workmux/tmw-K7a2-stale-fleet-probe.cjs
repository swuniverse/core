// Local-only diagnostic; no wormhole route or implementation is added.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const { setTimeout: pause } = require('node:timers/promises');
const resolve = Module._resolveFilename;
Module._resolveFilename = function (request, parent, ...rest) {
  if (request === '@swuniverse/shared') return path.resolve('packages/shared/src/index.ts');
  if (request.startsWith('.') && request.endsWith('.js') && parent) {
    const source = path.resolve(path.dirname(parent.filename), request.slice(0, -3) + '.ts');
    if (fs.existsSync(source)) return source;
  }
  return resolve.call(this, request, parent, ...rest);
};
require.extensions['.ts'] = function (module, filename) {
  const { outputText } = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    fileName: filename,
    compilerOptions: {
      module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
      experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true,
    },
  });
  module._compile(outputText, filename);
};
require('reflect-metadata');
const { PostgreSqlContainer } = require('@testcontainers/postgresql');
const root = path.resolve('apps/backend/src');
const load = file => require(path.join(root, file));
const { connectIntegrationDatabase, createUser } = load('testing/integration/database.ts');
const { Spacecraft } = load('modules/spacecraft/entities/spacecraft.entity.ts');
const { SpacecraftModule } = load('modules/spacecraft/entities/spacecraft-module.entity.ts');
const { Fleet } = load('modules/spacecraft/entities/fleet.entity.ts');
const { ShipClassDef } = load('modules/spacecraft/entities/ship-class-def.entity.ts');
const { Layer } = load('modules/starmap/entities/layer.entity.ts');
const { StarSystem } = load('modules/starmap/entities/star-system.entity.ts');
const { CelestialObject } = load('modules/starmap/entities/celestial-object.entity.ts');
const { GalaxyField } = load('modules/starmap/entities/galaxy-field.entity.ts');
const { SystemField } = load('modules/starmap/entities/system-field.entity.ts');
const { SpaceLocation } = load('modules/starmap/entities/space-location.entity.ts');
const { User } = load('modules/auth/user.entity.ts');
const { FactionEntity } = load('modules/faction/entities/faction.entity.ts');
const { GameDataService } = load('modules/game-data/game-data.service.ts');
const { ShipClassService } = load('modules/spacecraft/ship-class.service.ts');
const { SpacecraftService } = load('modules/spacecraft/spacecraft.service.ts');

async function run() {
  assert.equal(process.env.DATABASE_URL, undefined);
  assert.equal(process.env.INTEGRATION_DATABASE_URL, undefined);
  let container;
  let dataSource;
  try {
    container = await new PostgreSqlContainer('postgres:16-alpine')
      .withDatabase('tmw_k7a2_stale_fleet_probe').start();
    console.log('PREREQUISITE: fresh disposable PostgreSQL 16, actual migrations, synchronize=false');
    process.env.INTEGRATION_DATABASE_URL = container.getConnectionUri();
    process.env.SWU_MIGRATION_BUILDING_SEED_PATH = path.join(root, 'testing/integration/fixtures/migration-buildings.yaml');
    dataSource = await connectIntegrationDatabase();
    const repo = entity => dataSource.getRepository(entity);
    const owner = await createUser(dataSource);
    const shipClass = await repo(ShipClassDef).save({
      key: 'K7A2_FLEET_DIAGNOSTIC', name: 'Diagnostic ship', category: 'SHIP', role: 'SCOUT',
    });
    const layer = await repo(Layer).save({ name: 'Diagnostic layer', width: 5, height: 5 });
    const locations = [];
    for (let cx = 1; cx <= 2; cx++) {
      const field = await repo(GalaxyField).save({ layerId: layer.id, cx, cy: 1, fieldTypeId: 1 });
      locations.push(await repo(SpaceLocation).findOneByOrFail({ galaxyFieldId: field.id }));
    }
    const leader = await repo(Spacecraft).save({ name: 'Fleet leader', userId: owner.id, shipClassId: shipClass.id, locationId: locations[0].id });
    const joiner = await repo(Spacecraft).save({ name: 'Concurrent fleet joiner', userId: owner.id, shipClassId: shipClass.id, locationId: locations[0].id });
    const fleet = await repo(Fleet).save({ name: 'Diagnostic fleet', userId: owner.id, leaderId: leader.id });
    await repo(Spacecraft).update(leader.id, { fleetId: fleet.id });
    const gameData = new GameDataService();
    const classes = new ShipClassService(repo(ShipClassDef), repo(FactionEntity), gameData);
    // All dependencies used by joinFleet/findOne are real repositories/services.
    // Unused constructor collaborators are deliberately not instantiated.
    const service = new SpacecraftService(
      repo(Spacecraft), repo(SpacecraftModule), repo(Fleet), repo(StarSystem), repo(Layer),
      repo(CelestialObject), repo(GalaxyField), repo(SystemField), repo(User), dataSource,
      gameData, classes,
    );
    let release;
    let locked;
    const barrier = new Promise(resolve => { release = resolve; });
    const acquired = new Promise(resolve => { locked = resolve; });
    const relocation = dataSource.transaction(async manager => {
      await manager.findOne(Fleet, { where: { id: fleet.id }, lock: { mode: 'pessimistic_write' } });
      const participants = await manager.find(Spacecraft, {
        where: { fleetId: fleet.id }, order: { id: 'ASC' }, lock: { mode: 'pessimistic_write' },
      });
      assert.deepEqual(participants.map(ship => ship.id), [leader.id]);
      participants[0].locationId = locations[1].id;
      await manager.save(participants);
      locked();
      await barrier;
    });
    await acquired;
    const joining = service.joinFleet(owner.id, fleet.id, joiner.id);
    try {
      const deadline = Date.now() + 5000;
      let blocked = false;
      while (Date.now() < deadline) {
        const rows = await dataSource.query(
          `SELECT count(*)::int AS count FROM pg_stat_activity
           WHERE datname = current_database() AND wait_event_type = 'Lock'
             AND query ILIKE '%spacecraft%'`,
        );
        if (rows[0].count > 0) { blocked = true; break; }
        await pause(10);
      }
      assert.equal(blocked, true, 'production join must actually wait while relocation holds fleet lock');
      console.log('EXECUTION: production joinFleet read old leader position, then waited on the relocation fleet lock');
    } finally {
      release();
      await relocation;
    }
    const joined = await joining;
    const members = await repo(Spacecraft).find({ where: { fleetId: fleet.id }, order: { id: 'ASC' } });
    const persistedJoiner = await repo(Spacecraft).findOneByOrFail({ id: joiner.id });
    console.log(JSON.stringify({
      committedDestinationLocationId: locations[1].id,
      joinReturnedFleetId: joined.fleetId,
      persistedJoinerFleetId: persistedJoiner.fleetId,
      actualFleetAfterProductionJoin: members.map(ship => ({ shipId: ship.id, locationId: ship.locationId, fleetId: ship.fleetId })),
    }, null, 2));
    if (persistedJoiner.fleetId !== fleet.id) {
      console.log('INCONCLUSIVE for stale membership: production join did not persist membership; no phantom-member claim');
      return;
    }
    assert.equal(members.every(ship => ship.locationId === locations[1].id), true,
      'concurrent fleet join must revalidate leader location after waiting for relocation commit');
  } finally {
    if (dataSource?.isInitialized) await dataSource.destroy();
    if (container) await container.stop();
    delete process.env.INTEGRATION_DATABASE_URL;
    delete process.env.SWU_MIGRATION_BUILDING_SEED_PATH;
    console.log('CLEANUP: disposable connection/container removed; worktree/ref retained');
  }
}
run().catch(error => { console.error(error); process.exitCode = 1; });

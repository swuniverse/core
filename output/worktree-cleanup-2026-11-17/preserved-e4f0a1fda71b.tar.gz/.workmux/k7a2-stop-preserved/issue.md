# Wurmlochpassage: atomare Flotten- und Ankunftsintegration

**Status:** ready-for-human
**Priority:** P2
**Size:** M
**Blocked by:** tmw-K7a1

## Ziel

Integriert Wurmlochpassagen sicher in Flotten- und Ankunftsabläufe: alle betroffenen Schiffe werden vorab atomar validiert, anschließend gemeinsam versetzt und erhalten die notwendigen Zielfeldfolgen. Der Backend-Kern aus `tmw-K7a1` ist Voraussetzung.

## STU-Quellen

- `src/Module/Spacecraft/Action/EnterWormhole/EnterWormhole.php`
- `src/Module/Spacecraft/Lib/Movement/Route/RandomSystemEntry.php`
- `src/Module/Spacecraft/Lib/Movement/Route/FlightRouteFactory.php`

## SWU-Pfade

- `apps/backend/src/modules/spacecraft/spacecraft.service.ts`
- `apps/backend/src/modules/spacecraft/field-transition-executor.ts` und `flight-consequence-pipeline.ts`
- `apps/backend/src/modules/starmap/` (Orts-/Ebenenkenntnis)
- Flotten- und Signaturdienste

## Akzeptanzkriterien

- [ ] Flottenmitglieder werden vor jeder Mutation in einer gemeinsamen Transaktion vollständig geprüft; ein ungültiges Mitglied lehnt die ganze Passage ab. Keine partiellen Ergebnisse.
- [ ] Bei erfolgreicher Passage werden alle Teilnehmer konsistent zum gewählten Ausgangs-/Zielfeld versetzt.
- [ ] Zielfeld-Pipeline, lokale Erkundung und bei gesetzter Ebenenkenntnis-Integration `tmw-K5c` werden in derselben erfolgreichen Operation ausgeführt.
- [ ] Bewegungs-/Signaturdaten und Schiffslog beziehungsweise Ereignis „Wurmloch durchflogen“ werden konsistent geschrieben; fehlgeschlagene Passage hinterlässt keine Teilmutation oder Erfolgsmeldung.
- [ ] Ressourcen für eine nötige Sublight-Aktivierung werden je Schiff atomar geprüft und abgezogen; keine zusätzlichen Flug-/Warp-Kosten.
- [ ] Backend-Integrationstests prüfen erfolgreiche Flotte, ein ungültiges Flottenmitglied, Rollback, Ankunftsfolgen und genau-einmal-Schreibvorgänge.

## Entscheidung

Flottenpassagen sind vollständig vorab und atomar zu validieren; STU-Teilresultate werden nicht übernommen. Erfolgreiche Passage führt Zielfeldfolgen, Erkundung, Ebenenkenntnis, Signatur und Log innerhalb derselben Operation aus.

## Comments

- 2026-11-06: Aus `tmw-K7a` als zweiter geordneter Teilauftrag extrahiert; blockiert durch `tmw-K7a1`.
- 2026-11-09: Abbruch vor Produktcode im isolierten Worktree auf `ff16922a`; keine Endpunktaktivierung und keine gemeinsame Backend-Abnahme. Zwei lokale Diagnoseproben auf jeweils frischem PostgreSQL 16 mit echten Migrationen bestätigen fehlende gemeinsame Nebenläufigkeitsverträge: `SpacecraftDestructionService.saveUnlessDestroyed` wartet auf eine Positionswechsel-Zeilensperre und überschreibt danach den bereits bestätigten Ort, EPS und Impulszustand aus einem alten Navigationssnapshot. `SpacecraftService.joinFleet` liest die alte Führerposition vor der Sperre und persistiert nach deren Freigabe ein neues Mitglied am zurückgelassenen Ort; die vollständige Flotte ist danach nicht am bestätigten Ziel. Eine alleinige K7a2-Transaktion mit Flotten-/Schiffssperren schützt deshalb nicht vor bestehenden Schreibern. Benötigte eng begrenzte Vorarbeiten: (1) veraltete Bewegungswrites am gemeinsamen Persistenzpunkt ablehnen beziehungsweise Navigation autoritativ im selben Transaktionskontext validieren; (2) Flottenbeitritt/-austritt, Auflösung und Führerwechsel nach gemeinsamen Sperren autoritativ validieren. Kein monolithischer Spacecraft-Umbau und keine erfundene Passagebeschränkung als Ersatz. Zusätzlich benötigen Feldfolgen/Messaging, Erkundung, Ebenenkenntnis und Signaturen minimale Manager-/Nach-Commit-Anpassungen; `SpacecraftRepairService.cancelTasks(manager, ids)` ist bereits vorhanden. Status `ready-for-human` für die Abgrenzung dieser Vorarbeiten; alle Akzeptanzkriterien bleiben offen. Diagnoseproben, exakte Ergebnisse und Kopplungen: ignorierter lokaler Bericht `.workmux/tmw-K7a2-integration-report-20261109.md`. Keine Tests wurden geschwächt, keine gemeinsamen Gates als bestanden behauptet; K7a1 und K7a3 bleiben unverändert offen.

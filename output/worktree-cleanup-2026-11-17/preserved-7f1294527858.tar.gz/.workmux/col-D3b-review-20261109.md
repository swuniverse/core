# col-D3b independent review — 2026-11-09

**Current final-review result:** reviewed `c12939d4aa81e40b2b67b235388714c8b31f630d`. Both follow-up TS2769 findings are **fixed**; no remaining change-specific findings. **Acceptance coverage: PASS. Change-specific typecheck: PASS. Integration: BLOCKED pending global consolidation gates**, with eight prior other-file frontend diagnostics still independently reproduced. See the latest typed-props review appended below; earlier sections are historical evidence, not current findings.

## Original review — scope / verdict

**Integration: BLOCKED.** No concrete production-source defect established, but production-rendering acceptance evidence is missing and normal gates are not green.

- Reviewed SHA: `7ccc125d9c5254afacedb6ebfe169d433a60a6a5`.
- Parent: `ad581f97665396880f0a1fa94f8d1dcd7919488d`.
- Current local `stu-parity`: `7e7143d80d155b312dca1ad0d6a5304c38d54571`.
- Reviewed `git diff 7ccc125d^...HEAD` and `git diff stu-parity HEAD`; current parity-only changes are colony shield-toggle changes, with no research-path changes from the reviewed parent.
- `git merge-base --is-ancestor 7ccc125d stu-parity` exits **1**: this commit is NOT integrated.
- Read AGENTS.md, CONTRIBUTING.md, CONTEXT.md, README.md, docs/agents/domain.md and docs/agents/issue-tracker.md. The user-provided ticket is authoritative over the stale local ticket status/comment. No relevant additional context/ADR files surfaced. No worktree CodeGraph index exists; none was created.
- Configured gpt-6.1-sol used, including inherited-model parallel standards/spec reviewers. No permission override, remote service, push, source/tracker/config/ref change, or other checkout access. STU files were not available in this worktree and were not accessed elsewhere. `game-data/` is empty; no private YAML or real-data application acceptance run was attempted.
- Dependencies installed only with offline npm. Generated dependency/build/cache outputs are ignored. Final tracked/staged diffs are empty. Only this ignored review report was saved; issue was not marked resolved.

## Standards

**0 findings.** No newly introduced documented-standard violation or actionable baseline smell. Frontend edge/node types are implementation details rather than shared DTOs. Shared state construction and centralized edge styles avoid duplication.

## Spec — verified findings, severity-ranked

### P2 — Rendering acceptance tests do not exercise production renderers

`apps/frontend/src/pages/research.spec.tsx:1033` (mock at `:189–268`, excluded-label assertion at `:1074`).

The ticket requires frontend tests establishing that the three edge types render differently. The mocked ReactFlow emits synthetic `div` data attributes, ignores the supplied production node/edge components, replaces `BaseEdge` with null, and synthesizes `AUSGESCHLOSSEN`. The production legend also satisfies the unscoped excluded-label assertion.

**Concrete scenario, independently verified:** removing `style={style}` from production `RoutedEdgeComponent` (`research-tree.tsx:401`) and removing the production excluded-node label (`:356–357`), using an in-memory Vite transform with no file changes, still yields **2 passing new tests, 13 skipped, exit 0**. Actual SVG style forwarding and production-node exclusion visibility are therefore unestablished. This is a confirmed test/acceptance gap, not an assertion that current production rendering is broken.

No other concrete production-source behavior defect or unjustified scope creep established.

## Acceptance / coverage ledger

| Item | Evidence | Status |
|---|---|---|
| REQUIRE / REQUIRE_SOME / EXCLUDE distinct colors/styles with legend | Production style map `research-tree.tsx:41–48`: blue solid, purple `6 4`, red `2 4`; legend `:558–580`; production edge forwards style at `:401` | Implemented by source inspection; props assertions pass; actual SVG rendering unverified |
| Excluded research retained and visibly excluded | Tree service `research.service.ts:129–162`; production red node style `research-tree.tsx:276`, label `:356–357`; backend test `research.service.spec.ts:282–306` | Retained target/status, faction filtering, unchanged list omission tested; production-node rendering unverified |
| Frontend tests establish actual distinct rendering | `research.spec.tsx:1033–1081`; mock `:189–268` | **GAP**, confirmed by rendering-regression sensitivity probe |
| REQUIRE_SOME fallback when first alternative is EXCLUDED | Production fallback `research-tree.tsx:86–90`; `[EXCLUDED 105, LOCKED 107]` test `research.spec.tsx:1083–1101` | **PASS at path/props boundary**; restoring old fallback causes test failure; not SVG-animation proof |
| EXCLUDE direction | Backend source A excludes referenced B; frontend edge A → B (`research-tree.tsx:136–137`); test retains B=20 as EXCLUDED after A=10 starts | Consistent with local documented direction; STU source/data not independently read |
| Layout/routing | EXCLUDE omitted from ELK layering `research-tree.tsx:184–190`; no route points for EXCLUDE `:246–249`, production Bézier fallback `:392–399` | Inspected; ELK/ReactFlow mocked in tests, no real routing/browser proof; no demonstrated routing defect |
| API consumers / auth | Tree page uses `/research/tree`; list/dashboard retain `/research`; controller forwards JWT player/faction `research.controller.ts:47–68`; repository-wide callers searched | No checked consumer relies on former raw tree payload; no controller HTTP regression test present |
| Hidden / progression / awards / faction | Shared builder preserves hidden, excludeFromNormalProgression, award, faction and root filters (`research.service.ts:131–145`) | Inspected; existing list award/faction tests pass; tree-specific hidden/progression/award cases absent |
| Focus/modal/actions | Existing tree focus/details/clear tests pass; excluded status fails AVAILABLE/LOCKED action predicates in detail modal | Covered at mocked graph boundary / inspected; no production-graph interaction proof |

## Exact gate commands and results

All commands executed from this review worktree. `npx --no-install` below uses dependencies after the offline install. No full-workspace test run was performed.

```sh
npm ci --offline --ignore-scripts --no-audit --no-fund
```
Exit **0**, 1,831 packages installed from local cache. No lockfile changes. Initial pre-install runner-version probes found nonlocal versions and were not used as gate evidence.

```sh
NX_NO_CLOUD=true NX_DAEMON=false NX_ISOLATE_PLUGINS=false npx --no-install nx show project frontend --json
NX_NO_CLOUD=true NX_DAEMON=false NX_ISOLATE_PLUGINS=false npx --no-install nx show project backend --json
NX_NO_CLOUD=true NX_DAEMON=false NX_ISOLATE_PLUGINS=false npx --no-install nx run-many --targets=typecheck,build --projects=backend,frontend --skipSync --skipNxCache
```
Each fails before targets execute (exit **1**). Exact blocker: `Failed to parse pnpm lockfile`, `Could not find ".modules.yaml" .../node_modules/.modules.yaml`; project graph cannot be processed. No package-manager or nx.json workaround made.

```sh
npx --no-install vitest run --config apps/frontend/vite.config.mts apps/frontend/src/pages/research.spec.tsx
```
Exit **0**, **15/15 tests**, **1/1 file**. Run twice unchanged, including after probes; both pass. Vitest v4.1.5.

```sh
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/research/research.service.spec.ts
```
Exit **0**, **28/28 tests**, **1/1 suite**, zero snapshots.

```sh
npx --no-install eslint apps/backend/src/modules/research/research.controller.ts apps/backend/src/modules/research/research.service.ts apps/backend/src/modules/research/research.service.spec.ts apps/frontend/src/pages/research-tree.tsx apps/frontend/src/pages/research.spec.tsx
```
Exit **0**, **0 errors / 57 warnings**. Additionally `@nx/enforce-module-boundaries` was skipped because no cached ProjectGraph exists; this is not a complete normal-Nx lint pass.

```sh
npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly --pretty false
npx --no-install tsc --build apps/backend/tsconfig.json --emitDeclarationOnly --pretty false
```
Both exit **2**. These are the project-reference app-plus-spec checks (the local Nx TypeScript plugin constructs `tsc --build ... --emitDeclarationOnly`). Frontend has **8** diagnostics; backend has **4**:

- Frontend `components/spacecraft/SpacecraftMessageBar.spec.tsx(10,54)` TS1117 duplicate object property; `(11,26)` and `(13,26)` TS2345 missing `ToastContextValue.error`.
- Frontend `pages/colonies/components/PanelFabrication.spec.tsx(102,23)` TS2352 missing CommodityDef.nameShort.
- Frontend `pages/colonies/components/PanelTelescope.spec.tsx(11,15)` TS2352 incomplete StarmapExploredGalaxyFieldDto.
- Frontend `pages/dashboard/DashboardLowerSections.spec.tsx(74,18)` TS2352 incomplete DashboardData.
- Frontend `pages/holonet.spec.tsx(143,93)` TS2353 unexpected `characters` property.
- Frontend `pages/tutorial-targets.spec.tsx(76,25)` TS2488 non-iterable NodeList under configured libs.
- Backend `modules/starmap/layer-map-cycle.service.spec.ts(145,21)`, `(157,21)`, `(177,21)`, `(191,21)` TS2554: `Expected 2 arguments, but got 1`.

```sh
npx --no-install tsc --build apps/frontend/tsconfig.app.json apps/backend/tsconfig.app.json --emitDeclarationOnly --pretty false
```
Exit **0**, production app projects and shared reference pass. This does not override the failing spec-inclusive gates.

```sh
npm exec --offline --no --workspace=@org/frontend -- vite build
```
Exit **0**, **1,104 modules transformed**. Warnings: CSS @import ordering, chunks over 500 kB. No browser launched and no external font request made.

```sh
NX_NO_CLOUD=true NX_DAEMON=false NX_ISOLATE_PLUGINS=false npm exec --offline --no --workspace=@org/backend -- webpack-cli build --node-env=production
```
Exit **2**, backend config cannot load: `[readCachedProjectGraph] ERROR: No cached ProjectGraph is available`. No backend bundle established.

```sh
git diff --check 7ccc125d^ HEAD
git diff --exit-code
git diff --cached --exit-code
git status --short
```
Exit **0** each; no whitespace errors or tracked/staged changes; status empty.

## Independent baseline verification (read-only)

**Typecheck baseline independently established: YES.** TypeScript SolutionBuilder was rerun with forced checking and in-memory writes, overlaying changed source/config text from Git objects at the parent and local stu-parity. Both refs reproduced the same **8 frontend / 4 backend diagnostics**, compiler exit **2** for each of four builds. Wrapper exit **0** because it reports the compiler exit codes rather than propagating them. No branch switch, alternate checkout, or source edits. Diagnostic files plus constructor source are also blob-identical across parent/HEAD/stu-parity.

**Build infrastructure baseline: shared configuration established, but no separate parent build run.** nx.json, package-lock.json, pnpm-lock.yaml and backend build configuration are unchanged; current npm-only Nx graph and backend build fail before compilation. Do not interpret this as a passing build exemption. The historical frontend TS2554/TS6305 narrative is not used; the current eight frontend errors above were directly reproduced.

Exact in-memory baseline command:

```sh
npm exec --offline --no -- node <<'NODE'
const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const path = require('node:path');
const root = process.cwd();
for (const ref of ['7ccc125d^', 'stu-parity']) {
  const changed = execFileSync('git', ['diff', '--name-only', 'HEAD', ref], { encoding: 'utf8' }).trim().split('\n').filter(Boolean);
  const overlay = new Map();
  for (const file of changed) {
    if (!/\.(?:[cm]?tsx?|json)$/.test(file)) continue;
    try { overlay.set(path.resolve(root, file), execFileSync('git', ['show', `${ref}:${file}`], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })); }
    catch { overlay.set(path.resolve(root, file), undefined); }
  }
  console.log(`BASELINE ${ref} (${execFileSync('git', ['rev-parse', ref], {encoding:'utf8'}).trim()}), ${overlay.size} in-memory source/config overlays; no disk writes`);
  for (const project of ['frontend', 'backend']) {
    const emitted = new Map();
    let errors = 0;
    const system = {
      ...ts.sys,
      readFile(file) { const p = path.resolve(file); return emitted.has(p) ? emitted.get(p) : overlay.has(p) ? overlay.get(p) : ts.sys.readFile(file); },
      fileExists(file) { const p = path.resolve(file); return emitted.has(p) || (overlay.has(p) ? overlay.get(p) !== undefined : ts.sys.fileExists(file)); },
      writeFile(file, content) { emitted.set(path.resolve(file), content); },
      createDirectory() {},
    };
    const host = ts.createSolutionBuilderHost(system, undefined, diagnostic => {
      if (diagnostic.category === ts.DiagnosticCategory.Error) errors++;
      const location = diagnostic.file && diagnostic.start !== undefined ? (() => { const p = diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start); return `${path.relative(root, diagnostic.file.fileName)}(${p.line+1},${p.character+1}): `; })() : '';
      console.log(`${location}TS${diagnostic.code}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n')}`);
    });
    const result = ts.createSolutionBuilder(host, [`apps/${project}/tsconfig.json`], { force: true, emitDeclarationOnly: true }).build();
    console.log(`BASELINE_RESULT ${ref} ${project}: TypeScript exit ${result}; ${errors} errors`);
  }
}
NODE
```

## Exact read-only regression probes

These alter only Vite's in-memory module text, not source files or assertions. They are sensitivity checks, not real production-rendering tests.

### Production rendering regressions escape coverage

Exit **0**: **2 passed / 13 skipped** despite both injected regressions.

```sh
npm exec --offline --no -- node --input-type=module <<'NODE'
import { createVitest } from 'vitest/node';
let injected = false;
const ctx = await createVitest('test', {
  config: 'apps/frontend/vite.config.mts',
  watch: false,
  testNamePattern: 'renders each research relationship|does not highlight an excluded REQUIRE_SOME',
}, {
  plugins: [{
    name: 'read-only-rendering-regression-probe',
    enforce: 'pre',
    transform(code, id) {
      if (!id.split('?')[0].endsWith('/src/pages/research-tree.tsx')) return;
      const droppedStyle = code.replace('markerEnd={markerEnd} style={style}', 'markerEnd={markerEnd}');
      const droppedNodeLabel = droppedStyle.replace("tech.status === 'EXCLUDED'\n          ? 'AUSGESCHLOSSEN'", "tech.status === 'EXCLUDED'\n          ? ''");
      if (droppedStyle === code || droppedNodeLabel === droppedStyle) throw new Error('Probe did not apply both regressions');
      injected = true;
      console.log('IN_MEMORY_PROBE: production BaseEdge style forwarding and production EXCLUDED node label removed; no file edits');
      return {code: droppedNodeLabel, map: null};
    },
  }],
});
try {
  await ctx.start(['apps/frontend/src/pages/research.spec.tsx']);
  if (!injected) throw new Error('Production module was not transformed');
} finally {
  await ctx.close();
}
NODE
```

### REQUIRE_SOME regression is detected

Exit **1**, expected sensitivity failure: **1 failed / 14 skipped**, `research.spec.tsx:1097`: `expected 'false' to be 'true'` for edge `107 → 106` animation flag.

```sh
npm exec --offline --no -- node --input-type=module <<'NODE'
import { createVitest } from 'vitest/node';
let injected = false;
const ctx = await createVitest('test', {
  config: 'apps/frontend/vite.config.mts',
  watch: false,
  testNamePattern: 'does not highlight an excluded REQUIRE_SOME',
}, {
  plugins: [{
    name: 'read-only-fallback-regression-probe',
    enforce: 'pre',
    transform(code, id) {
      if (!id.split('?')[0].endsWith('/src/pages/research-tree.tsx')) return;
      const previous = "const fallback = dependency.techIds.find((depId) => {\n                const depTech = techById.get(depId);\n                return depTech && depTech.status !== 'EXCLUDED';\n              });";
      if (!code.includes(previous)) throw new Error('Fallback probe did not apply');
      injected = true;
      console.log('IN_MEMORY_PROBE: restore pre-fix REQUIRE_SOME fallback; no file edits; test should fail');
      return {code: code.replace(previous, 'const fallback = dependency.techIds.find((depId) => techById.has(depId));'), map: null};
    },
  }],
});
try {
  await ctx.start(['apps/frontend/src/pages/research.spec.tsx']);
  if (!injected) throw new Error('Production module was not transformed');
} finally {
  await ctx.close();
}
NODE
```

## Smallest follow-up

1. Add a focused test exercising the actual production node/edge renderers (real SVG path style/marker checks, excluded label scoped to its production node), retaining the current useful props/path tests. It must fail if production style forwarding or the node label is removed. Consider tree-specific visibility/HTTP cases separately; these are presently inspection-only gaps.
2. Consolidate the independently reproduced spec-typecheck fixes and restore normal npm-only Nx/backend build execution in the coordinator's isolated baseline work; then rerun normal gates. No inherited exception is granted here and no baseline fixes were imported.

**Original axis summary:** Standards: **0 findings**. Spec: **1 confirmed P2 acceptance/test-coverage gap**. Integration was **BLOCKED**; superseded for acceptance coverage by the correction review below.

---

# Resumed correction review — ee90beb6 — 2026-11-09

## Exact scope and verdicts

- Reviewed correction/HEAD: `ee90beb6d98386912361c5c89d01a8d0a48271ff`.
- Correction parent/original implementation: `7ccc125d9c5254afacedb6ebfe169d433a60a6a5`.
- Original implementation parent: `ad581f97665396880f0a1fa94f8d1dcd7919488d`.
- Local `agent-col-D3b`: `ee90beb6d98386912361c5c89d01a8d0a48271ff`.
- Local `stu-parity`: `7e7143d80d155b312dca1ad0d6a5304c38d54571`, unchanged. Ancestry checks exit **1** for both original and correction: neither is integrated.
- Per explicit authorization, `git merge --ff-only agent-col-D3b` fast-forwarded only this clean review branch from `7ccc125d` to `ee90beb6`, exit **0**. One commit, one file: `research.spec.tsx`, **137 insertions / 81 deletions**. No merge commit, source edits, additional commits, other-checkout access, or parity merge.
- Fixed-point diff: `git diff 7ccc125d...HEAD`; commit list `git log 7ccc125d..HEAD --oneline`: `ee90beb6 test(research-tree): exercise production renderers`.
- Same configured gpt-6.1-sol, normal permissions. No external services, secrets, package-manager/nx.json/STU changes. No consolidation checkout accessed and no baseline fixes imported. Report is ignored; final tracked/staged diff remains empty.

**Acceptance coverage: PASS.** The prior P2 rendering gap is independently closed: actual production renderers and the real BaseEdge now produce SVG paths; separate style/label/marker mutations are detected.

**Integration: BLOCKED.** The correction introduces two test-harness TS2769 errors. Existing baseline consolidation and normal global gates remain outstanding; no inherited exemption or final integration approval.

## Standards axis

**0 findings** under documented standards and baseline heuristics. Tooling-enforced type errors are recorded separately below, not disguised as standards smells.

## Verified correction findings (severity-ranked)

### P2 — Production node invocation supplies incomplete NodeProps

`apps/frontend/src/pages/research.spec.tsx:248`.

The mock spreads a public `Node` into a `NodeTypes` component invocation. `Node` has optional dragging/selection flags, whereas installed `NodeProps` requires flags including dragging, zIndex, selectable, deletable, selected, draggable, and runtime fields isConnectable/positionAbsoluteX/positionAbsoluteY. **Concrete failure:** the configured frontend typecheck reports TS2769 at `(248,66)` because optional flags cannot satisfy required renderer props. This call was added by ee90beb6 and was absent in the parent; runtime tests pass because they transpile without this typecheck.

### P2 — Production edge invocation omits required EdgeProps

`apps/frontend/src/pages/research.spec.tsx:268`.

The new `EdgeTypes` invocation omits required `source` and `target` endpoints; its required `type` is also not supplied. `MockTreeEdge` lacks endpoint fields. **Concrete failure:** the configured frontend typecheck reports TS2769 at `(268,66)`, explicitly listing missing source/target. This is introduced by the correction, not the established baseline.

Independent typed-contract review confirmed both diagnoses; no repair applied.

## Prior P2 closure / acceptance ledger

| Check | Independent evidence | Result |
|---|---|---|
| Real BaseEdge | Partial mock imports/spreads actual module at `research.spec.tsx:202–205`, no BaseEdge replacement; supplied production edge component invoked at `:268` | PASS at renderer boundary |
| Actual SVG styles | `<svg>` contains real BaseEdge paths; selectors/assertions `:1079–1097` check REQUIRE blue + width, REQUIRE_SOME purple + `6 4`, EXCLUDE red + `2 4` | PASS; not synthetic data-attribute-only evidence |
| Production marker forwarding | REQUIRE and EXCLUDE real-path `marker-end` asserted `:1089–1097`; removing forwarding fails | PASS for URL propagation, not marker-definition correctness |
| Production excluded label | Production node component invoked `:248`; node wrapper no longer synthesizes label; `within(node-105)` assertion `:1099–1101` | PASS; independent label-only removal fails even with legend intact |
| Existing useful tests | Original 15 tests and prior props/highlight/focus/socket/module/fallback assertions retained; no prior expectations removed by correction | PASS; actual node detail button now used |
| REQUIRE_SOME excluded fallback | Existing regression test retained at `:1139–1158`, full suite green | PASS at path/props boundary; original independent fallback sensitivity proof retained above |
| Scope | Only frontend test file changed | No source behavior changes |

**Mock fidelity limits:** ReactFlow outer wrapper, ELK, handles and Bézier fallback remain mocked. Extra synthetic node-click buttons still test page focus callbacks rather than actual ReactFlow interaction handling. Node/edge prop omissions are the confirmed typing defects above. Marker URLs are synthesized at `:276–278`; no `<marker>` definitions are emitted, and marker shape/type/color/size are not asserted. Consequently these tests prove production SVG style/marker-*forwarding* and node label rendering, not arrowhead appearance, geometry, browser layout, or full ReactFlow integration. Those bounds do not reopen the ticket's previous rendering-coverage P2.

## Commands/counts/exits — resumed review

```sh
git merge --ff-only agent-col-D3b
```
Exit **0**, fast-forward only as described above.

```sh
npx --no-install vitest run --config apps/frontend/vite.config.mts apps/frontend/src/pages/research.spec.tsx
```
Exit **0**, **15/15 tests, 1/1 file**. Run before mutation probes and again unchanged afterward; both green, Vitest v4.1.5.

```sh
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/research/research.service.spec.ts
```
Exit **0**, **28/28 tests, 1/1 suite**, 0 snapshots. Backend source unchanged by correction.

```sh
npx --no-install eslint apps/frontend/src/pages/research.spec.tsx
```
Exit **0**, **0 errors / 0 file warnings**; infrastructure warning says `@nx/enforce-module-boundaries` skipped because no cached ProjectGraph exists. This is changed-file lint, not a complete normal Nx lint pass.

```sh
NX_NO_CLOUD=true NX_DAEMON=false NX_ISOLATE_PLUGINS=false npx --no-install nx run frontend:lint --files=apps/frontend/src/pages/research.spec.tsx --skipSync --skipNxCache
```
Exit **1**, before target execution: `Failed to parse pnpm lockfile`; missing `node_modules/.modules.yaml`. Confirms current normal-gate infrastructure limitation. No workaround made.

```sh
npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly --pretty false
```
Exit **1** on this incremental invocation; **10 error diagnostics**: **2 new TS2769** at research.spec.tsx `(248,66)` and `(268,66)`, plus the **8 prior frontend baseline diagnostics** listed in the original review. This targeted frontend gate was run to confirm correction-local failures, not to repeat global tests. No new backend/full-workspace typecheck, broad test, or build run this round; their earlier results are historical and outstanding until coordinator consolidation gates pass.

```sh
git diff --check 7ccc125d...HEAD
git diff --check ad581f97665396880f0a1fa94f8d1dcd7919488d...HEAD
git diff --exit-code
git diff --cached --exit-code
git status --short
```
Exit **0** each; no whitespace errors or tracked/staged changes; status empty.

### Separate no-write mutation proof

Each mutation is applied only by Vite's pre-transform to the production module; assertions and files on disk stay unchanged. A fresh Vitest context is used each time.

| Probe | Actual assertion failure | Counts | Individual process exit |
|---|---|---|---:|
| Remove only production style forwarding | `research.spec.tsx:1086`, expected `#38bdf8`, received empty SVG stroke | 1 failed / 14 skipped | **1** |
| Remove only production excluded-node label | `:1100`, cannot find AUSGESCHLOSSEN within node-105; legend left intact | 1 failed / 14 skipped | **1** |
| Remove only production marker forwarding | `:1089`, expected URL, received null marker-end | 1 failed / 14 skipped | **1** |
| No mutation (GREEN) | None | 1 passed / 14 skipped | **0** |

The enclosing shell loop exits **0** after printing individual `PROBE_EXIT` values; the expected RED failures above are not hidden by that wrapper. Full unmodified suite afterward again passes **15/15**.

Exact command:

```sh
for probe in style label marker green; do
  PROBE="$probe" DEBUG_PRINT_LIMIT=1200 npm exec --offline --no -- node --input-type=module <<'NODE'
import { createVitest } from 'vitest/node';
const probe = process.env.PROBE;
let injected = false;
const ctx = await createVitest('test', {
  config: 'apps/frontend/vite.config.mts',
  watch: false,
  testNamePattern: 'renders each research relationship and excluded technology distinctly',
}, {
  plugins: [{
    name: `independent-read-only-${probe}-probe`,
    enforce: 'pre',
    transform(code, id) {
      if (probe === 'green' || !id.split('?')[0].endsWith('/src/pages/research-tree.tsx')) return;
      const [before, after] = {
        style: ['markerEnd={markerEnd} style={style}', 'markerEnd={markerEnd}'],
        label: ["tech.status === 'EXCLUDED'\n          ? 'AUSGESCHLOSSEN'", "tech.status === 'EXCLUDED'\n          ? ''"],
        marker: ['markerEnd={markerEnd} style={style}', 'style={style}'],
      }[probe];
      if (!code.includes(before)) throw new Error(`Probe ${probe} did not apply`);
      injected = true;
      console.log(`IN_MEMORY_MUTATION ${probe}: remove only production ${probe} forwarding/label; source and assertions unchanged on disk`);
      return { code: code.replace(before, after), map: null };
    },
  }],
});
try {
  await ctx.start(['apps/frontend/src/pages/research.spec.tsx']);
  if (probe !== 'green' && !injected) throw new Error('Production module not transformed');
} finally { await ctx.close(); }
NODE
  printf '\nPROBE_EXIT %s %s\n' "$probe" "$?"
done
```

### Correction-local typecheck/baseline distinction

A standalone no-write spec/import-closure TypeScript check found **3 errors**, exit **2**: the two new TS2769 plus inherited unused `getSocket` in use-socket.ts. Repeating that same standalone check with parent research.spec.tsx overlaid from Git found **1 unchanged import-closure error** at parent versus **3** at HEAD. This standalone check is not the normal composite gate; the configured `tsc --build` above independently confirms exactly the two new correction errors.

Exact comparison command (wrapper exit **0**, reports diagnostics rather than propagating them):

```sh
npm exec --offline --no -- node <<'NODE'
const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const path = require('node:path');
const file = 'apps/frontend/src/pages/research.spec.tsx';
const absolute = path.resolve(file);
const config = ts.readConfigFile('apps/frontend/tsconfig.spec.json', ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, 'apps/frontend');
for (const ref of ['7ccc125d', 'HEAD']) {
  const source = execFileSync('git', ['show', `${ref}:${file}`], {encoding:'utf8'});
  const options = { ...parsed.options, composite:false, incremental:false, declaration:false, declarationMap:false, emitDeclarationOnly:false, noEmit:true };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host);
  host.readFile = name => path.resolve(name) === absolute ? source : read(name);
  host.writeFile = () => { throw new Error('Unexpected write'); };
  const program = ts.createProgram([file], options, host);
  const errors = ts.getPreEmitDiagnostics(program).filter(d=>d.category===ts.DiagnosticCategory.Error);
  console.log(`FOCUSED_PARENT_COMPARISON ${ref}: ${errors.length} errors; no writes; standalone test/import closure`);
  for (const d of errors) {
    const p = d.file.getLineAndCharacterOfPosition(d.start);
    console.log(`${path.relative(process.cwd(),d.file.fileName)}:${p.line+1}:${p.character+1} TS${d.code}: ${ts.flattenDiagnosticMessageText(d.messageText,'\n')}`);
  }
}
NODE
```

A preliminary attempt to retain composite references while replacing their root list was **invalid for normal-gate inference**: it additionally generated TS6379/TS6307 harness diagnostics (exit **2**). Those are not attributed to repository baseline or correction; the proper configured frontend build supersedes that attempt. No exhaustive global rerun was performed.

## Smallest remaining follow-up

Supply properly typed renderer props in the test harness: complete required NodeProps runtime flags/absolute coordinates, preserve edge source/target and type, and retain actual BaseEdge/node invocation plus the stronger SVG/node-scoped assertions. Do not suppress errors with any-casts or weaken the tests. Then rerun focused tests, the same no-write sensitivity checks and frontend typecheck. Coordinator still must complete isolated baseline consolidation and obtain normal lint/typecheck/build/test gates before integration.

**ee90beb6 historical axis summary:** Standards **0 findings**; prior rendering acceptance gap **closed**, with **2 confirmed P2 test-harness typing defects** subsequently addressed by c12939d4 below.

---

# Final typed-props correction review — c12939d4 — 2026-11-09

## Scope / precise refs

- **Reviewed SHA / final HEAD:** `c12939d4aa81e40b2b67b235388714c8b31f630d`.
- **Parent:** `ee90beb6d98386912361c5c89d01a8d0a48271ff` (renderer coverage correction).
- **Original implementation:** `7ccc125d9c5254afacedb6ebfe169d433a60a6a5`; original base `ad581f97665396880f0a1fa94f8d1dcd7919488d`.
- **Worker ref:** `agent-col-D3b` = reviewed SHA.
- **Local parity ref:** `stu-parity` = `7e7143d80d155b312dca1ad0d6a5304c38d54571`, unchanged.
- `git merge --ff-only agent-col-D3b` exited **0**, fast-forwarding only this clean review branch. No new commit/merge commit. Inspected `git diff ee90beb6...HEAD`: one file, **14 additions / 0 deletions**, all in test adapter props.
- `git merge-base --is-ancestor <sha> stu-parity` exits **1** for each of 7ccc125d, ee90beb6 and c12939d4: none is integrated.
- Same configured Sol / normal permissions. No other-checkout access, source edits, implementation, commits, tracker changes, private/STU data changes, package-manager/nx.json changes, remote services or pushes. Report ignored; tracked/staged diffs empty.

## Verdicts

**Acceptance coverage: PASS.** Production-renderer SVG styling and node-scoped excluded label assertions remain strong and independently mutation-sensitive.

**Change-specific typecheck: PASS.** Both previous TS2769 errors are eliminated, no casts/suppressions added. The configured spec-inclusive frontend typecheck now reports only the eight previously established other-file diagnostics.

**Integration: BLOCKED pending global consolidation gates.** No baseline exemption granted. No baseline fixes imported and no consolidation checkout inspected. Coordinator must complete normal lint/typecheck/build/test gates before integration; issue not marked resolved.

## Verified finding outcomes

| Prior finding | Outcome | Current evidence |
|---|---|---|
| P2 incomplete NodeProps at old `research.spec.tsx:248` | **FIXED** | Current `:250–262` explicitly supplies required flags, zIndex, isConnectable and absolute coordinates; standalone parent comparison and configured TypeScript gate no longer report this error |
| P2 missing EdgeProps at old `:268` | **FIXED** | Current `:279–294` supplies source/target/type; MockTreeEdge declares endpoint strings; no TS2769 remains |
| Original production-rendering P2 | **Remains closed** | Actual BaseEdge/production node/edge invocation preserved; style-only and label-only mutations independently fail |

**No remaining verified change-specific findings.** Standards axis independently reports **0 findings**; spec/contract axis confirms both fixes, no weakened tests. No any/unknown casts, ts-ignore, assertions removed, or production source changes were added by this 14-line correction.

### Acceptance bounds retained

Actual SVG path stroke/dash/style and marker-forwarding assertions, node-scoped excluded label and all 15 original test cases remain. REQUIRE_SOME fallback selection test remains green. Mocked ReactFlow wrapper/ELK/handles/Bézier fallback and synthesized marker URLs still limit these tests to production-renderer evidence: not actual arrowhead definitions/colors or browser geometry/interaction integration. Those unchanged limits do not reopen the original acceptance gap.

## Commands, counts, exits — this round

```sh
git merge --ff-only agent-col-D3b
npx --no-install vitest run --config apps/frontend/vite.config.mts apps/frontend/src/pages/research.spec.tsx
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/modules/research/research.service.spec.ts
npx --no-install eslint apps/frontend/src/pages/research.spec.tsx
npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly --pretty false
```

- Fast-forward: **exit 0**.
- Frontend: **15/15 tests, 1/1 file, exit 0**, both before and after probes. Vitest v4.1.5.
- Backend: **28/28 tests, 1/1 suite, 0 snapshots, exit 0**.
- Changed-file ESLint: **exit 0**, 0 file errors/warnings. Infrastructure warning: `@nx/enforce-module-boundaries` skipped due to unavailable cached ProjectGraph; not a complete normal lint pass.
- Configured frontend typecheck: **exit 1** on this incremental invocation, **8 diagnostics**, **0 research.spec.tsx errors**, no TS2769. Remaining diagnostics:
  - SpacecraftMessageBar.spec.tsx `(10,54)` TS1117, `(11,26)` and `(13,26)` TS2345.
  - PanelFabrication.spec.tsx `(102,23)` TS2352.
  - PanelTelescope.spec.tsx `(11,15)` TS2352.
  - DashboardLowerSections.spec.tsx `(74,18)` TS2352.
  - holonet.spec.tsx `(143,93)` TS2353.
  - tutorial-targets.spec.tsx `(76,25)` TS2488.
- No broad baseline test suite, backend/full-workspace typecheck, build or repeated Nx attempt this round. Earlier Nx graph/backend build and baseline findings remain historical pending actual consolidation gates, not new passes/exemptions.

```sh
git diff --check ee90beb6...HEAD
git diff --check ad581f97665396880f0a1fa94f8d1dcd7919488d...HEAD
git diff --exit-code
git diff --cached --exit-code
git status --short
```
All **exit 0**; no whitespace errors; tracked/staged diff empty; status empty.

### Independent narrow no-write type comparison

`ee90beb6` overlaid from Git: **3 standalone closure diagnostics / 2 research.spec.tsx diagnostics**. Current HEAD: **1 standalone closure diagnostic / 0 research.spec.tsx diagnostics**. The remaining standalone closure error is unchanged use-socket.ts `(2,43)` TS6133 for getSocket; it is an artifact of checking the imported app closure under spec options, not a new correction failure. The configured composite gate above independently shows the correct eight other-file failures and no research errors.

Exact command, **wrapper exit 0** for change-specific success (explicitly reports the still-blocked standalone closure):

```sh
npm exec --offline --no -- node <<'NODE'
const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const path = require('node:path');
const file = 'apps/frontend/src/pages/research.spec.tsx';
const absolute = path.resolve(file);
const config = ts.readConfigFile('apps/frontend/tsconfig.spec.json', ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, 'apps/frontend');
for (const ref of ['ee90beb6', 'HEAD']) {
  const source = execFileSync('git', ['show', `${ref}:${file}`], {encoding:'utf8'});
  const options = { ...parsed.options, composite:false, incremental:false, declaration:false, declarationMap:false, emitDeclarationOnly:false, noEmit:true };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host);
  host.readFile = name => path.resolve(name) === absolute ? source : read(name);
  host.writeFile = () => { throw new Error('Unexpected write'); };
  const program = ts.createProgram([file], options, host);
  const errors = ts.getPreEmitDiagnostics(program).filter(d=>d.category===ts.DiagnosticCategory.Error);
  const localErrors = errors.filter(d => d.file && path.resolve(d.file.fileName) === absolute);
  console.log(`FOCUSED_TYPES ${ref}: ${errors.length} closure errors / ${localErrors.length} research.spec.tsx errors; no writes`);
  for (const d of errors) {
    const p = d.file.getLineAndCharacterOfPosition(d.start);
    console.log(`${path.relative(process.cwd(),d.file.fileName)}:${p.line+1}:${p.character+1} TS${d.code}: ${ts.flattenDiagnosticMessageText(d.messageText,'\n')}`);
  }
  if (ref === 'HEAD') {
    console.log(`CHANGE_SPECIFIC_TYPECHECK: ${localErrors.length ? 'BLOCKED' : 'PASS'} (closure still ${errors.length ? 'BLOCKED' : 'PASS'})`);
    process.exitCode = localErrors.length ? 2 : 0;
  }
}
NODE
```

### Independent mutation proof retained after typed-props fix

| In-memory-only probe | Failure/count | Individual exit |
|---|---|---:|
| Remove only production style forwarding | `research.spec.tsx:1100`: expected blue SVG stroke, received empty; **1 failed / 14 skipped** | **1** |
| Remove only production excluded-node label | `:1114`: no AUSGESCHLOSSEN within node-105, legend intact; **1 failed / 14 skipped** | **1** |
| No mutation | **1 passed / 14 skipped** | **0** |

Fresh Vitest contexts per probe; no disk/source/assertion edits. Shell loop exits **0** after printing individual exits. Full unchanged suite afterward passes **15/15, exit 0**. Marker-forwarding sensitivity was independently proven at ee90beb6 and its assertion/forwarding are unchanged; not re-probed this round.

Exact command:

```sh
for probe in style label green; do
  PROBE="$probe" DEBUG_PRINT_LIMIT=1200 npm exec --offline --no -- node --input-type=module <<'NODE'
import { createVitest } from 'vitest/node';
const probe = process.env.PROBE;
let injected = false;
const ctx = await createVitest('test', {
  config: 'apps/frontend/vite.config.mts',
  watch: false,
  testNamePattern: 'renders each research relationship and excluded technology distinctly',
}, {
  plugins: [{
    name: `independent-read-only-${probe}-probe`,
    enforce: 'pre',
    transform(code, id) {
      if (probe === 'green' || !id.split('?')[0].endsWith('/src/pages/research-tree.tsx')) return;
      const [before, after] = {
        style: ['markerEnd={markerEnd} style={style}', 'markerEnd={markerEnd}'],
        label: ["tech.status === 'EXCLUDED'\n          ? 'AUSGESCHLOSSEN'", "tech.status === 'EXCLUDED'\n          ? ''"],
      }[probe];
      if (!code.includes(before)) throw new Error(`Probe ${probe} did not apply`);
      injected = true;
      console.log(`IN_MEMORY_MUTATION ${probe}: production module only; no disk or assertion edits`);
      return { code: code.replace(before, after), map: null };
    },
  }],
});
try {
  await ctx.start(['apps/frontend/src/pages/research.spec.tsx']);
  if (probe !== 'green' && !injected) throw new Error('Production module not transformed');
} finally { await ctx.close(); }
NODE
  printf '\nPROBE_EXIT %s %s\n' "$probe" "$?"
done
```

## Final review disposition

**No further change-specific follow-up requested.** Both typing findings fixed; original acceptance coverage gap remains closed. Await coordinator's consolidated normal global lint/typecheck/build/test results. Do not integrate on the basis of focused acceptance PASS alone.

**Final: acceptance PASS; change-specific typecheck PASS; integration BLOCKED pending consolidation gates. Issue unresolved.**

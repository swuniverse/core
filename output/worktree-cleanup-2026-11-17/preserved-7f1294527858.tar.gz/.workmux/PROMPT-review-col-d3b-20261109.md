Independent review and verification ONLY of existing col-D3b commit 7ccc125d9c5254afacedb6ebfe169d433a60a6a5. This review worktree is based on agent-col-D3b; the commit is NOT merged into stu-parity. Do not implement, commit, merge, modify tracker files, or touch another checkout. Use the configured gpt-6.1-sol model with normal permissions. No push, no external services, no secrets in reports, npm/npx only, no package-manager or nx.json edits. Keep STU references read-only.

Read AGENTS.md, CONTRIBUTING.md, CONTEXT.md and relevant domain docs/ADRs if present. Use CodeGraph first only if this worktree has an index; do not try to index it. Review the commit against its parent and current stu-parity, inspect actual callers and acceptance behavior, and run focused reproducible tests/typechecks/lint/build with output. Avoid unnecessary full-workspace test runs at this review stage; final broad gates will follow isolated baseline consolidation. Do not weaken tests or change source. If an acceptance assertion cannot be established, report the gap instead of silently approving it.

Authoritative current ticket:
# Forschungsbaum: EXCLUDE- und REQUIRE_SOME-Kanten unterscheiden
Status ready-for-agent; Priority P3; Size S; Blocked by —.
Goal: Players can recognize mutually excluding research and alternatives where one of several requirements suffices. The normal SWU research tree previously rendered all dependencies alike.
STU reference: src/Module/Admin/View/ResearchTree/ (read-only).
Relevant SWU paths: apps/frontend/src/pages/research-tree.tsx; apps/backend/src/modules/research/research.service.ts; research.controller.ts and accompanying backend/frontend tests.
Acceptance criteria:
- REQUIRE, REQUIRE_SOME and EXCLUDE edges have distinct colors and/or line styles, with a legend.
- Excluded research is visibly identifiable as excluded in the tree.
- Frontend tests establish that the three types render differently.
Current ticket comment (2026-10-28, amended later): Earlier focused implementation/tests and build were green; the then-global frontend typecheck blocker was superseded by sh-AP-21 on 2026-10-30. Re-run normal gates; no inherited baseline exception applies.

Context to verify, not conclusions to rubber-stamp:
The commit changes five files: research.controller.ts, research.service.ts, research.service.spec.ts, research-tree.tsx, research.spec.tsx. GET /research/tree changes from raw definitions to player-specific state, with EXCLUDED entries retained only for the tree. Inspect all API consumers, hidden/faction/award visibility, exclusion direction, layout/routing, focus paths, and actual production node/edge rendering. Check real rendering coverage: an earlier version mocked @xyflow/react and emitted synthetic data attributes/excluded labels, so such assertions alone must not be called real SVG or production-node proof. A follow-up was requested to regression-test REQUIRE_SOME fallback selection when an alternative is EXCLUDED; determine what is actually fixed and covered now.

Prior gate reports are historical, NOT current exemptions: backend:typecheck had TS2554 constructor calls in layer-map-cycle.service.spec.ts (145,157,177,191), apparently also on base; full test run had missing private research YAML and additional unisolated failures. Some matching fixes are preserved uncommitted in the coordinator checkout and are NOT imported here. Report exact current limitations without asserting all failures are unrelated.

Return a concise report with: reviewed SHA; verified findings ranked by severity with file:line and concrete scenario (or none); acceptance/test coverage ledger; exact commands, test counts and exit status; whether any build/typecheck baseline blocker was independently established; explicit PASS/BLOCKED verdict for integration; smallest follow-up if blocked. Do not mark the issue resolved. You may save the report under .workmux/col-D3b-review-20261109.md if ignored, otherwise just provide terminal output. Stop after report.
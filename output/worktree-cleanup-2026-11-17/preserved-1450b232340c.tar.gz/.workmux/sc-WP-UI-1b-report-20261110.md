# sc-WP-UI-1b implementation evidence

Date: 2026-11-10
Base/HEAD before implementation: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`
Branch: `agent-sc-wp-ui-1b`
Final local commit: `bab783d091693c6b75e75319c68ae69b17e1bbe3`
Final Git tree: `7b88eead34342bc86c24f11f0009304f18302806`
Working tree: clean after commit; no push or merge performed.

## Scope and tree

Implemented only `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md` plus its frontend implementation and tests. No backend, shared DTO/package, dependency/lock/Nx/map/DECISIONS/STU source edits.

Changed tracked paths:
- `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md`
- `apps/frontend/src/components/Tooltip.spec.tsx`
- `apps/frontend/src/components/Tooltip.tsx`
- `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx`
- `apps/frontend/src/pages/spacecraft.spec.tsx`
- `apps/frontend/src/pages/spacecraft.tsx`

The issue history was preserved and the current checklist/status updated. Build output is ignored. This report is ignored under `.workmux/`.

## Public behavior/seams

- `SpacecraftPage` renders each ship image as a button using the shared `Tooltip`; `Tooltip.onOpen` runs on hover, keyboard focus, and first touch open.
- The tooltip fetches `/spacecraft/:id/cargo` only on first open. Successful promise/results are cached by ship ID; concurrent opens share the in-flight request; rejected requests are removed for retry.
- Display includes commodity icon/name and amount, occupied/capacity, loading and error feedback, and “Leer” for empty cargo.
- Public component tests exercise the production ship list and API boundary: no initial cargo fetch, first-hover fetch, cached reopen, separate ship identities/capacities, commodity image/amount, and touch opening for an empty hold.
- Shared Tooltip test covers callback behavior on hover/focus/touch and verifies cursor movement does not invoke it repeatedly.

## RED/GREEN evidence

- Meaningful pre-implementation RED: `.workmux/gates/ui1b-red-fleet-hover-v2.log`, receipt `.json`; actual process exit 1, source unchanged. The public ship-list cargo tooltip behaviors failed because the expected ship-image tooltip trigger was absent; the existing coordinate test remained passing.
- An earlier attempted RED (`ui1b-red-fleet-hover`) is not used as feature evidence because its test setup had invalid sequential API mocks; see its log for the confounded failure.
- First GREEN run (`ui1b-green-hover-first`) surfaced a missing `commodityImage` test mock and is setup-failure evidence only.
- GREEN: `.workmux/gates/ui1b-green-hover-second.log`, receipt `.json`; exit 0, source unchanged.
- Focused final-after-last-code-change verification: `.workmux/gates/ui1b-focused-after-guard.log`, receipt `.json`; exit 0, source unchanged.

## Final gates (direct wrapper)

Each final command ran through `python3 -I .workmux/local-inputs/direct-gate.py`; receipt confirms numeric subprocess exit 0 and unchanged source while the gate ran.

- `ui1b-focused-after-guard`: `nx test frontend --skip-nx-cache --run src/pages/spacecraft.spec.tsx src/components/Tooltip.spec.tsx` — exit 0.
- `ui1b-typecheck-final`: `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false` — exit 0.
- `ui1b-lint-final`: `nx lint frontend --skip-nx-cache` — exit 0; project-wide existing lint warnings, no warnings in changed files.
- `ui1b-frontend-test-final`: `nx test frontend --skip-nx-cache --run` — exit 0; 93 test files, 666 tests passed, zero failed, zero skipped. Existing act warnings and one existing NaN SVG-attribute warning appeared.
- `ui1b-build-final`: `nx build frontend --skip-nx-cache` — exit 0. Existing CSS `@import` ordering and large-chunk warnings appeared.
- `git diff --check` — clean.

Logs and JSON receipts for all listed gate IDs are in `.workmux/gates/`. Final-gate source hashes were for the implementation tree immediately before status/checklist/history and this report were updated; these completion/evidence-only changes do not alter executable sources.

## Source hash manifest

SHA-256 values below are for the five implementation/test files at the last code-gate source tree, before the issue status/history update. The issue file hash changed when its status/checklist/history was updated, and is intentionally excluded here. The final tree commit will contain the final issue file.

```text
2fe98b9a9c2eb78252ceee2313035a82def73b364141f603f1792c39570f622f  apps/frontend/src/components/Tooltip.spec.tsx
055235398092bc65b20e1b1ceced4c15599888e4bfca138dcab3cec311180a0e  apps/frontend/src/components/Tooltip.tsx
e28fe6b321bd78b4185876b4e9d8bc9d4109addefc4a84e77e66924e2978ffa5  apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx
dc56e67f1dd1364821c390f50ee5380ca325b3a5017252b7a942b1e99bf3281c  apps/frontend/src/pages/spacecraft.spec.tsx
43fcb82a769b2a9161e2f5ed1dade494ae5f09ef3d44e283f487093debc26081  apps/frontend/src/pages/spacecraft.tsx
```

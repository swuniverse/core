# sc-WP-UI-1b Standards correction evidence

Date: 2026-11-10
Original candidate (preserved): `bab783d091693c6b75e75319c68ae69b17e1bbe3`
Original tree (preserved): `7b88eead34342bc86c24f11f0009304f18302806`
Branch: `agent-sc-wp-ui-1b`

## Review context and exact scope

Read and checked `.workmux/local-inputs/ui1b-standards-review-20261110.md` against the candidate/source. The review identifies exactly two documented standards breaches; those findings are valid:

1. `SpacecraftListDto` lacked `cargoMax`, so the page invented a required intersection, row props redundantly made it optional, and the UI defaulted missing capacity to zero. Added `cargoMax: number` to the canonical DTO in `packages/shared/src/lib/spacecraft/index.ts`; `/spacecraft` response and `ShipRow` now use `SpacecraftListDto`, with no local duplicate type or fallback. No backend runtime behavior changed.
2. The new cargo tooltip displayed raw item/used/capacity numbers. It now uses the existing `formatNumber` helper from `apps/frontend/src/lib/format.tsx` for item amounts, used cargo, and capacity. The pre-existing eager detail `ShipStoragePanel` behavior/display was left unchanged.

No other UI/cache-policy redesign or unrelated source changes. No backend runtime code changed. No dependency, lock, Nx, map, DECISIONS, or STU edits. Original candidate commit and `.workmux/sc-WP-UI-1b-report-20261110.md` remain untouched. No backend runtime suite was run; shared DTO consumer impacts were checked by backend spec-inclusive compilation.

## Public formatting regression RED/GREEN

- `ui1b-correction-format-red`: direct wrapper exit 1, `source_unchanged: true`. This uses the real `SpacecraftPage` and production tooltip with cargo amount 1234 and list `cargoMax` 10000; prior UI failed the public role-cell assertion for `1.234` and the formatted occupancy assertion.
- `ui1b-correction-format-green`: direct wrapper exit 0, `source_unchanged: true`; the exact public production-list test now sees the item cell `1.234` and tooltip text `Lagerraum 1.234/10.000`.
- Earlier tooltip lazy-load/cache/empty/touch tests remain in the same real page suite and passed in both the correction-focused and final complete run.

## Final direct gates

Every command below ran through `python3 -I .workmux/local-inputs/direct-gate.py` with unique gate ID. Receipts record the numeric process exit and `source_unchanged: true`.

- `ui1b-correction-format-green`: focused actual production list and shared Tooltip tests — exit 0.
- `ui1b-correction-shared-build`: `nx build shared --skip-nx-cache` — exit 0; shared DTO declarations rebuilt.
- `ui1b-correction-frontend-spec-types`: `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false` — exit 0.
- `ui1b-correction-backend-spec-types`: `tsc --build apps/backend/tsconfig.spec.json --force --pretty false` — exit 0; backend fixtures/consumers included; no diagnostics.
- `ui1b-correction-frontend-lint`: `nx lint frontend --skip-nx-cache` — exit 0; existing project-wide warnings, no correction-file findings.
- `ui1b-correction-frontend-full-test`: `nx test frontend --skip-nx-cache --run` — exit 0; 93 files, 667 tests passed, zero skipped. Existing warnings are present in the direct log.
- `ui1b-correction-frontend-build`: `nx build frontend --skip-nx-cache` — exit 0; shared dependency rebuilt. Existing CSS `@import` ordering and large-chunk warnings remain.
- `git diff --check` — clean.

All direct logs/JSON receipts are `.workmux/gates/<gate-id>.log` and `.json`. No arbitrary backend runtime/PG suite was run because no backend executable changed and both spec-inclusive compiler projects passed.

## Issue and reviewer state

The ticket preserves all historical comments, including the original completion/gate record, and appends the correction history. Its status is `resolved`; corrected feature criteria and fresh gate evidence are recorded, while independent narrow re-review remains pending. No reviewer was spawned; handoff is for the original independent reviewers/coordinator as requested.

## Correction commit and tree

A new local attributed follow-up commit retains the original candidate as its direct parent; no amend/reset/rebase/merge/push was performed.

- Follow-up commit: `c5b1d3604b00d843c9750d72799394f650db4bf4` (parent is original candidate `bab783d091693c6b75e75319c68ae69b17e1bbe3`; attributed Conventional Commit).
- Standards-fix commit tree: `96f463a1dff43d207caf20755539e16e28736a50`.
- Tracker evidence commits: `67fc06bc2ffebb4b6891b309a6cca31a5c38df39` (gate checklist) and `88dfa9ca27685da165859d304880a7db557e4a77` (resolved/review-pending status); both attributed Conventional Commits, serial after the standards-fix commit.
- Final Git tree: `eaf5ee009a695b6260a0c2229d0128833fb46b39`.
- Final tracked working tree: clean.
- Diff scope from original candidate: `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md`, `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx`, `apps/frontend/src/pages/spacecraft.spec.tsx`, `apps/frontend/src/pages/spacecraft.tsx`, `packages/shared/src/lib/spacecraft/index.ts`.
- SHA-256 manifest (implementation sources before tracker/report-only completion update):
  - `2688e9f631378fd6f9a1331f8e3a4a4f4732fb9cb78a226736c39237b7a09099` — `packages/shared/src/lib/spacecraft/index.ts`
  - `a9405ad3affa740e9c5f62b4efcbe3469362b67ba82c3f6463595f2536605fbb` — `apps/frontend/src/pages/spacecraft.tsx`
  - `bdb0678c9b3af07825b6b4daa0c2e326d3b7ebf71cc4d53eadb9c6d15ace6955` — `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx`
  - `181c7e7cbe55f6bf016dc2ae0f51ce8af9390661afb9e329dde72924f656b574` — `apps/frontend/src/pages/spacecraft.spec.tsx`

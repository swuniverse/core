# UI-1b — independent Sol Standards review

Date: 2026-11-10

## Outcome: BLOCKED — 2 documented-standard breaches, 0 consequential smell findings

This is the original `review-tmw-k7a1` **Standards axis only**. Independent Spec review belongs to `review-baseline-20261109`; no Spec disposition is issued here. Candidate/source/evidence binding passes, but green tooling does not waive the two documented conventions below. No integration was attempted; stop for coordinator disposition.

## Pinned candidate and scope

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Candidate: `bab783d091693c6b75e75319c68ae69b17e1bbe3`.
- Tree: `7b88eead34342bc86c24f11f0009304f18302806`.
- Pinned diff: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...bab783d091693c6b75e75319c68ae69b17e1bbe3`.
- Pinned log: `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..bab783d091693c6b75e75319c68ae69b17e1bbe3`.
- Exactly **1 commit / 6 paths**, direct parent exactly BASE; committed whitespace check passes.
- Commit: `feat(frontend): show ship cargo on list hover`, ending `Co-Authored-By: Claude Code <noreply@anthropic.com>`.
- Originating issue read at BASE: `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md`.

Six changed paths: that issue, `apps/frontend/src/components/Tooltip.spec.tsx`, `apps/frontend/src/components/Tooltip.tsx`, `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx`, `apps/frontend/src/pages/spacecraft.spec.tsx`, and `apps/frontend/src/pages/spacecraft.tsx`.

Reviewed exact candidate Git blobs, not this reviewer's older working source. Current worker `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/agent-sc-wp-ui-1b` is on `agent-sc-wp-ui-1b` at the exact candidate/tree with empty porcelain status. All six worker raw files equal candidate blobs byte-for-byte.

## Findings — under 400 words

1. **Shared API field defined outside the canonical DTO.** `CONTRIBUTING.md:73` requires “Shared DTOs/interfaces go in `packages/shared`”. New `apps/frontend/src/pages/spacecraft.tsx:33` declares `SpacecraftListDto & { cargoMax: number }` locally and uses it as the `/spacecraft` response at :44; :224 independently makes the same field optional, followed by a zero fallback at :239. Canonical `packages/shared/src/lib/spacecraft/index.ts:370–419` still omits `cargoMax`. This is a backend/frontend response field, not merely a private presentation prop: the existing backend list actually supplies it. The change leaves the new required capacity contract unexpressed at the shared boundary and inconsistently required/optional within its consumer. Carry the response field in the appropriate Shared DTO and reuse that contract through the list. The pre-existing local `CargoItem` declaration is not counted as a newly introduced violation, and no backend runtime failure is claimed.

2. **New cargo numbers bypass German formatting.** `.scratch/stu-parity/inventory/shell-admin-runtime.md:302–310` documents global numeric presentation with a German thousands point and `toLocaleString('de-DE')` pending a central formatter. New `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx:94` passes raw `item.amount`; :120 renders raw `used` and `cargoMax`. For amount/usage 1234 and capacity 10000, the tooltip shows `1234` and `Lagerraum 1234/10000`, rather than `1.234` and `Lagerraum 1.234/10.000`. The document's claim that no formatter exists is historical: current `apps/frontend/src/lib/format.tsx` already exports `formatNumber` using `Intl.NumberFormat('de-DE')`. Reuse that helper, or equivalent German formatting, for these new values. Existing unformatted detail-panel numbers are outside this diff's finding.

## Standards sources and heuristic judgement

Read candidate `CONTRIBUTING.md`, `AGENTS.md`, `CONTEXT.md`, `docs/agents/domain.md`, `docs/agents/issue-tracker.md`, and `docs/agents/triage-labels.md`; relevant ADRs 0002, 0003, 0004 and 0006; the frontend conventions in `.scratch/stu-parity/inventory/shell-admin-runtime.md`; and the shared Tooltip issue `sh-AP-11`. Bounded tracked-file discovery found no `CODING_STANDARDS` file or additional relevant frontend-specific ADR directory. No CodeGraph index exists in this reviewer worktree; none was created.

All twelve retained Fowler heuristics were considered: Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man, and Refused Bequest. Repository guidance takes precedence; tooling-enforced issues are excluded. No independent consequential smell finding survives judgement. Small cargo-projection/empty-table repetition does not justify generic extraction; co-locating the new tooltip with cargo presentation is cohesive. The new `onOpen` hook has a concrete production consumer.

The production list uses the actual shared Tooltip/TooltipTable, theme tokens, compact bordered cells, right-aligned monospace values and the commodity asset helper. Inspected lazy per-ID promise caching/in-flight sharing, rejection eviction, mounted/active-ship guards, loading/error/empty presentation, and shared hover/focus/touch behavior as bounded implementation context; no invented cache invalidation, security policy or UI redesign requirement is imposed. This does not substitute for the independent Spec axis.

Tracker binding passes: the candidate resolves the issue/checklist and appends one completion/evidence comment; the **entire BASE `## Comments` block remains verbatim**, consistent with `docs/agents/issue-tracker.md:11`. Historical discarded attempts are not rewritten as successful executions.

## Source and receipt binding — PASS

All five supplied implementation/test digests independently match candidate Git blobs and worker raw bytes:

| Path | SHA-256 |
| --- | --- |
| `apps/frontend/src/components/Tooltip.spec.tsx` | `2fe98b9a9c2eb78252ceee2313035a82def73b364141f603f1792c39570f622f` |
| `apps/frontend/src/components/Tooltip.tsx` | `055235398092bc65b20e1b1ceced4c15599888e4bfca138dcab3cec311180a0e` |
| `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx` | `e28fe6b321bd78b4185876b4e9d8bc9d4109addefc4a84e77e66924e2978ffa5` |
| `apps/frontend/src/pages/spacecraft.spec.tsx` | `dc56e67f1dd1364821c390f50ee5380ca325b3a5017252b7a942b1e99bf3281c` |
| `apps/frontend/src/pages/spacecraft.tsx` | `43fcb82a769b2a9161e2f5ed1dade494ae5f09ef3d44e283f487093debc26081` |

Read supplied `.workmux/local-inputs/ui1b-review/report.md`, `manifest.json`, and all seven direct logs/JSON receipts under `gates/`. All **14 artifact SHA-256 values** match the supplied manifest; each receipt's `log_sha256` matches its actual log. Every receipt records unchanged before/after HEAD at BASE, unchanged recorded source hashes and `source_unchanged: true`.

The five final focused/types/lint/full-test/build receipts each contain numeric `process_exit: 0` and the exact five hashes above **both before and after** execution. Their precommit BASE HEAD is not a candidate-commit execution claim: executable/test bytes transfer to the committed candidate by exact identity. Tracker finalization is intentionally excluded from executable-source records and independently reviewed above.

## Supplied gate results and historical RED/GREEN

| Evidence ID | Numeric process exit | Observed result |
| --- | --- | --- |
| `ui1b-red-fleet-hover-v2` | 1 | 1 file, 2 failed / 7 passed / 9 total; actual production list renders but expected `Lager von Falke` and `Lager von Leerer Falke` triggers are absent. Meaningful feature RED, not an import/mock setup failure. |
| `ui1b-green-hover-second` | 0 | 1 file / 9 tests passed; historical pre-final source, not final guard coverage. |
| `ui1b-focused-after-guard` | 0 | Actual Tooltip and SpacecraftPage specs: 2/2 files, 15/15 tests, no skipped totals. |
| `ui1b-typecheck-final` | 0 | Forced `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false`, no diagnostics. Spec config includes TSX tests and references app config. |
| `ui1b-lint-final` | 0 | Nx success, 0 errors / 110 warnings; independently counted 110 warning rows, no changed-file diagnostics. |
| `ui1b-frontend-test-final` | 0 | Nx success, 93/93 files, 666/666 tests; independently summed successful file rows to 93 and 666, zero skipped totals. |
| `ui1b-build-final` | 0 | Nx/Vite build success, 1104 modules transformed. CSS `@import` ordering and large-chunk warnings remain warnings. |

Commands in the receipts use `npm exec --offline --`; Nx gates use `--skip-nx-cache`. Public tests import the production SpacecraftPage and Tooltip; only API/assets are mocked, not the component DOM or a private cache helper. Unique ship fixtures exercise lazy first load, cached reopen, separate cargo/capacity identities and empty touch opening; the Tooltip spec covers hover/focus/touch callbacks and no callback on mouse movement.

RED v2 records only its earlier test digest `f8d1d71e9ec9ba53573b17f89e8414e82283db304d8eca831a73d469bd1c2dfd`, not final test bytes. Second GREEN has four source records, with storage/page/test hashes predating final guards. Neither is relabeled as five-source final evidence. The handoff's earlier confounded RED and missing-asset-mock first GREEN are not supplied here and are not used as successful feature evidence.

These are **supplied candidate executions, not reviewer reruns**. Hash/receipt matching establishes byte integrity and recorded source identity, not forensic execution provenance or universally cleared internal caches. Nx task-cache bypass is not an all-cache-clear guarantee; the dependent build uses ordinary shared `tsc --build`. No fresh main execution or baseline-wide gate claim is made.

## Reviewer state and stop

Reviewer remains `review-tmw-k7a1`, HEAD `ff16922a7b93b620acb4d51d7180cf255dd970b2`, tracked/porcelain clean. This NEW report is ignored under `.workmux/`; final state/ignore verification passes.

Only bounded read-only candidate/source/document/hash/log checks and this ignored report were performed. No source/tracker/config/package/map/STU edits, private transcripts/tool-result exports, gates/tests/types/lint/build/DB reruns, installs/secrets/external services, agents/workflows/plan mode, branch switching, commits, merge, push or cleanup. No K7a/migration/baseline re-audit or K5b cross-candidate assumptions. **Stopped for coordinator; no integration.**

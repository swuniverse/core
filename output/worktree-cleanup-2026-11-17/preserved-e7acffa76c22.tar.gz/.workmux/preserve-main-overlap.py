import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

record = json.loads(Path('.workmux/serial-integration-before.json').read_text())
main = Path(record['main'])
TAG = 'stu-parity-original-baseline-20261109'


def git(*args):
    return subprocess.check_output(['git', '-C', str(main), *args])


def inventory():
    result = {}
    for raw in git('status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0'):
        if not raw:
            continue
        status = raw[:2].decode()
        path = raw[3:].decode()
        assert status in (' M', '??'), f'Concurrent index/conflict/rename change: {status} {path}'
        p = main / path
        details = p.lstat()
        content = os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
        result[path] = {
            'status': status,
            'sha256': hashlib.sha256(content).hexdigest(),
            'mode': stat.S_IMODE(details.st_mode),
            'symlink': p.is_symlink(),
        }
    return result


assert git('rev-parse', 'HEAD').decode().strip() == record['base']
assert git('branch', '--show-current').decode().strip() == 'stu-parity'
assert not git('diff', '--cached', '--name-only')
assert not git('ls-files', '--unmerged')
assert inventory() == {**record['overlap'], **record['unrelated']}, 'Concurrent main changes; refusing stash'
existing = git('stash', 'list', '--format=%H %gs').decode().splitlines()
assert existing == record['existingStashes'], 'Concurrent stash changes before preservation'
assert not any(TAG in entry for entry in existing)
paths = sorted(record['overlap'])
assert len(paths) == 35
subprocess.run(['git', '-C', str(main), '--literal-pathspecs', 'stash', 'push',
                '--include-untracked', '-m', TAG, '--', *paths], check=True)
# Capture by unique tag immediately, never assume stash@{0} in a shared stack.
entries = git('stash', 'list', '--format=%H %gs').decode().splitlines()
matches = [entry for entry in entries if entry.split(' ', 1)[1] == f'On stu-parity: {TAG}']
assert len(matches) == 1, 'Cannot uniquely identify preserved stash; STOP, do not pop/drop'
oid = matches[0].split()[0]
Path('.workmux/serial-integration-stash.json').write_text(json.dumps({
    'oid': oid, 'tag': TAG, 'main': str(main), 'paths': paths,
}, indent=2) + '\n')
assert git('rev-parse', f'{oid}^1').decode().strip() == record['base']
tracked = set(git('diff', '--name-only', f'{oid}^1', oid).decode().splitlines())
untracked = set(git('ls-tree', '-r', '--name-only', f'{oid}^3').decode().splitlines())
expected_tracked = {p for p, info in record['overlap'].items() if info['status'] == ' M'}
expected_untracked = {p for p, info in record['overlap'].items() if info['status'] == '??'}
assert tracked == expected_tracked and untracked == expected_untracked, 'Stash scope mismatch; STOP'
assert not git('diff', '--name-only', f'{oid}^1', f'{oid}^2'), 'Stash index unexpectedly changed; STOP'
for p, info in record['overlap'].items():
    tree = f'{oid}^3' if info['status'] == '??' else oid
    content = git('show', f'{tree}:{p}')
    assert hashlib.sha256(content).hexdigest() == info['sha256'], f'Original preservation mismatch: {p}; STOP'
assert git('diff', f'{oid}^1', oid, '--', 'apps') == Path('.workmux/preserved-baseline/apps-tracked.patch').read_bytes()
assert git('diff', f'{oid}^1', oid, '--', 'nx.json') == Path('.workmux/preserved-local-inputs/existing-npm-pin.patch').read_bytes()
assert inventory() == record['unrelated'], 'Unrelated changes differ after preservation; STOP'
assert not git('diff', '--cached', '--name-only')
assert git('rev-parse', 'HEAD').decode().strip() == record['base']
assert all(entry in entries for entry in existing)
print(f'Preserved original baseline stash: {oid}; 32 tracked + 3 untracked paths; all original bytes verified.')
print('Unrelated 65 paths unchanged; index empty; HEAD still base; existing stash retained.')
print('No stash pop/drop or merge performed by this preservation step.')

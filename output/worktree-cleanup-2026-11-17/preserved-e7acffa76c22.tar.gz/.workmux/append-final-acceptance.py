import hashlib
import json
import re
import subprocess
from pathlib import Path

BASE = '7e7143d80d155b312dca1ad0d6a5304c38d54571'
NAMES = ['buoy-permanent-green', 'buoy-backend-types', 'buoy-backend-lint',
         'buoy-backend-focused', 'buoy-backend-spec-types', 'buoy-backend-unit-full',
         'buoy-backend-build', 'buoy-integration-full', 'buoy-runtime-probe-green',
         'buoy-final-sync-check']
rows = {}
for line in Path('.workmux/gate-results.tsv').read_text().splitlines():
    fields = line.split('\t')
    rows[fields[0]] = fields
assert all(rows[name][1] == '0' for name in NAMES)
commits = json.loads(Path('.workmux/followup-commits.json').read_text())
assert len(commits) == 8
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert commits[-1]['sha'] == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
final_integrity = json.loads(Path('.workmux/final-candidate-integrity.json').read_text())
assert final_integrity['files'] == {p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                                   for p in final_integrity['files']}
lines = ['\n## Final committed acceptance result — 2026-11-09\n',
         '**All required current gates and permanent Buoy runtime metadata regression pass.**',
         f'Base: `{BASE}`. Final source/HEAD: `{head}`. Eight focused local commits; worktree and index clean.',
         'No merge/push, external transfer, main-checkout access, autoload/synchronize, private submodule fetch, tracker/feature integration or other tooling/data edits.',
         '\n| Fresh backend acceptance command ID | Exit | Duration ms | Log |',
         '| --- | ---: | ---: | --- |']
for name in NAMES:
    r = rows[name]
    lines.append(f'| `{name}` | {r[1]} | {r[2]} | `{r[4]}` |')
lines.append('\nExact commands (serial, actual exits above):\n```sh')
for name in NAMES:
    lines.append(rows[name][3])
lines.append('```\n\nThe full append-only gate ledger contains ' + str(len(Path('.workmux/gate-results.tsv').read_text().splitlines())) + ' executions, including historical failures and explicitly invalid probes. These are preserved, not deleted or counted as acceptance successes.\n\nObserved fresh summaries:')
for name in ['buoy-backend-focused', 'buoy-backend-unit-full', 'buoy-integration-full']:
    text = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', Path(rows[name][4]).read_text())
    summary = [line.strip() for line in text.splitlines()
               if re.search(r'^Test Suites:|^Tests:', line)]
    lines.append(f'- `{name}`: ' + '; '.join(summary))
lines.extend([
    '- Fresh permanent and ignored acceptance probes pass; all recorded passing suites report no skipped tests. The previous missing-data mining conditional skip now runs with the authorized local inputs.',
    '- Frontend retained byte-identical evidence: 92 files / 653 tests; 8 focused files / 64 tests; forced spec-inclusive types; lint 108 warnings / zero errors; Vite production build. Shared normal type/build/lint evidence retained; prerequisite shared builds also refreshed by backend targets. No unchanged-gate rerun falsely claimed.',
    '- Backend lint 1423 warnings / zero errors, graph-boundary checks active with no graph-unavailable skips. Aggregate prior proper-cwd lint 1531 warnings / zero errors. No rule/suppression removals or disabled rules.',
    '- Existing ts-jest isolatedModules deprecation, React NaN strokeDashoffset fixture warning, CSS import-order and >500kB bundle warnings retained. Passing intentional negative-path service/asset/socket error logs are not hidden failures.',
    '\n### Focused local commit ledger\n',
    '| SHA | Subject | Paths |', '| --- | --- | ---: |',
])
for commit in commits:
    lines.append(f"| `{commit['sha']}` | {commit['subject']} | {len(commit['paths'])} |")
lines.extend([
    '\nEach commit ends with `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Research async assertion correction is the final independent one-file commit for later conflict resolution. Provider consumers/registrations, root Buoy fix and permanent regression stay in the same backend logical repair commit.',
    '\n### Scope, integrity and limitations\n',
    'Final range contains exactly 43 authorized paths: previous 42 plus `app.module.ts`, with permanent regression in an already-imported testing file. No package/lockfile/other tooling/STU/tracker/map changes; exact three-line preserved npm pin is the only nx.json delta. Local data is a relative symlink to ignored coordinator snapshot; 49-file manifest and immutable original snapshots verified. Data-backed local validation, not proof of private submodule commit provenance. Assets absent but no current gate required a download or modification.',
    'Final source SHA-256 hashes for every candidate path are in `.workmux/final-candidate-integrity.json`; root and regression SHA-256/Git blob IDs are recorded above. Commit SHA covers the actual final source, not merely a test log.',
    'Actual application root metadata and Buoy/User/Spacecraft/SpaceLocation relation targets now pass without connecting. **This does not establish full Nest application boot/provider instantiation or end-to-end HTTP operation.**',
    'Migration `.ts` actual datasource replay remains 204 then 0 migrations, pending false, synchronize false; full fresh disposable integration also passes after root-options correction. `.mts` source parity passed, but **`.mts` runtime unverified**. Duplicate migration/app metadata for users/factions/faction_modifiers remains a schema-generation/synchronization risk; no migration generation or synchronization approved. Historical previous-calendar owner rollback remains limited to demonstrated forward adoption/new-migration rollback, not absent owner implementation.',
    'No ee90beb6, F3d/H1/I1c correction, tracker resolution or branch integration. Stop for independent review and serial integration. All required current acceptance gates green within these explicitly bounded seams; no broad application-boot/asset/schema-generation claim.',
])
report = Path('.workmux/baseline-verification-20261109.md')
with report.open('a') as f:
    f.write('\n'.join(lines) + '\n')
print('Final committed acceptance section appended:', head)

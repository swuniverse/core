import { Test } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { MODULE_METADATA } from '@nestjs/common/constants';
import { DataSource, type DataSourceOptions } from 'typeorm';
import { AppModule } from '../apps/backend/src/app.module';
import { Buoy } from '../apps/backend/src/modules/spacecraft/entities/buoy.entity';

it('application datasource gives injected Buoy repository usable entity metadata', async () => {
  const imports = Reflect.getMetadata(MODULE_METADATA.IMPORTS, AppModule);
  const modules = imports.flatMap((item: any) => [item, ...(item?.imports ?? [])]);
  const databaseModule = modules.find((item: any) =>
    item?.providers?.some((provider: any) =>
      String(provider.provide) === 'TypeOrmModuleOptions' && provider.useFactory,
    ),
  );
  expect(databaseModule).toBeDefined();
  const module = await Test.createTestingModule({
    providers: [
      ...databaseModule.providers.filter((provider: any) => String(provider.provide) === 'TypeOrmModuleOptions'),
      { provide: ConfigService, useValue: { get: (key: string) => key === 'NODE_ENV' ? 'production' : undefined } },
    ],
  }).compile();
  const options = module.get<DataSourceOptions>('TypeOrmModuleOptions');
  try {
    console.log('Application datasource registers Buoy:', Array.isArray(options.entities) && options.entities.includes(Buoy));
    const source = new DataSource({ ...options, synchronize: false });
    // Metadata construction requires no database connection.
    await (source as unknown as { buildMetadatas(): Promise<void> }).buildMetadatas();
    expect(source.getRepository(Buoy).metadata.target).toBe(Buoy);
  } finally {
    await module.close();
  }
});

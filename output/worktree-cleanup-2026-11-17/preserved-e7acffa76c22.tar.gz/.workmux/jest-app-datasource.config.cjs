const path = require('node:path');
const config = require('../apps/backend/jest.config.cts');
module.exports = {
  ...config,
  rootDir: path.resolve('apps/backend'),
  roots: [path.resolve('apps/backend'), path.resolve('.workmux')],
  testMatch: [path.resolve('.workmux/app-datasource-buoy.spec.ts')],
  transform: {
    ...config.transform,
    '^.+\\.[tj]s$': ['ts-jest', {
      isolatedModules: true,
      tsconfig: {
        module: 'commonjs', moduleResolution: 'node10',
        experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true,
      },
    }],
  },
};

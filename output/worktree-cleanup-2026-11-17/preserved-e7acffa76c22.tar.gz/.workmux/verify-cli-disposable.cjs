const setup = require('../apps/backend/src/testing/integration/global-setup.ts').default;
const teardown = require('../apps/backend/src/testing/integration/global-teardown.ts').default;
(async () => {
  let source;
  try {
    await setup();
    process.env.DATABASE_URL = process.env.INTEGRATION_DATABASE_URL;
    source = require('../apps/backend/src/database/typeorm-migration.config.ts').default;
    await source.initialize();
    const migrated = await source.runMigrations({ transaction: 'each' });
    const repeat = await source.runMigrations({ transaction: 'each' });
    if (await source.showMigrations()) throw new Error('Pending migrations after replay');
    if (repeat.length) throw new Error('Repeat migration run was not empty');
    const duplicateTables = [...new Set(source.entityMetadatas.map(m => m.tableName))]
      .filter(table => source.entityMetadatas.filter(m => m.tableName === table).length > 1);
    console.log(`Disposable CLI datasource: initialized; first migrations=${migrated.length}; repeat migrations=${repeat.length}; pending=false; synchronize=${source.options.synchronize}`);
    console.log(`Duplicate table metadata (migration-only risk): ${duplicateTables.join(', ')}`);
  } finally {
    if (source?.isInitialized) await source.destroy();
    await teardown();
    delete process.env.DATABASE_URL;
  }
})().catch(error => { console.error(error.message); process.exitCode = 1; });

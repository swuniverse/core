import { ApplicationConfig } from '@nestjs/core/application-config';
import { DependenciesScanner } from '@nestjs/core/scanner';
import { GraphInspector } from '@nestjs/core/inspector/graph-inspector';
import { NestContainer } from '@nestjs/core/injector/container';
import { MetadataScanner } from '@nestjs/core/metadata-scanner';
import { AppModule } from '../app.module';

describe('AppModule imports', () => {
  it('scans the complete Nest module graph without undefined imports', async () => {
    const container = new NestContainer();
    const scanner = new DependenciesScanner(
      container,
      new MetadataScanner(),
      new GraphInspector(container),
      new ApplicationConfig(),
    );

    await expect(scanner.scan(AppModule)).resolves.toBeUndefined();
  });
});

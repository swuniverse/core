import json
import subprocess
from pathlib import Path

before = json.loads(Path('.workmux/serial-integration-before.json').read_text())
after = json.loads(Path('.workmux/serial-integration-after.json').read_text())
environment = json.loads(Path('.workmux/serial-integration-environment.json').read_text())
preserved = after['stash']
assert environment['packagesEquivalent'] and all(environment['configMatches'].values()) and environment['localDataMatches']
lines = [
    '\n## Serial baseline integration into stu-parity — 2026-11-09\n',
    'Independent gpt-6.1-sol review PASS for exact eight commits / 43 paths supplied by user; no blocking P0/P1/P2. Two nonblocking P3 notes (DI test titles and duplicate random formulas) deliberately not refactored.',
    'User explicitly narrowed the prior worker main-checkout ban only for safe reviewed-range fast-forward and path-scoped original preservation. No other checkout/feature/tracker/tooling work authorized or performed.',
    f'Main checkout discovered via `git worktree list --porcelain`: `{after["main"]}` on `stu-parity`.',
    f'Before HEAD: `{after["beforeHead"]}`. After HEAD: `{after["afterHead"]}`. Ordinary `git merge --ff-only` of this exact SHA, automatic stash disabled; exit 0. Eight existing linear commits, no merge/squash/rebase/new commit.',
    '\n### Original overlap preserved permanently\n',
    f'Named stash **`{preserved["tag"]}`**, OID **`{preserved["oid"]}`**. **35 paths: 32 tracked (31 original app files + nx.json) and 3 original untracked app regression specs.**',
    'Before preservation: expected base HEAD, empty index, no unmerged/rename entries. Original tracked apps patch, exact npm pin patch and all three untracked regressions matched immutable local snapshots byte-for-byte. No concurrent content/index changes observed during pre/post checks.',
    'Preservation used `git --literal-pathspecs stash push --include-untracked -m stu-parity-original-baseline-20261109 -- <exact 35 overlap paths>`. No unrelated tracker/brag path passed, staged or stashed. Stash captured immediately by unique tag/OID rather than shared-stack position.',
    'Stash tracked diff matches original app and npm pin snapshots; untracked parent contains exactly the three regression files; all 35 preserved blobs match original hashes. Stash index parent matches base; no unrelated entries. Originals recoverable by OID; **do not automatically pop/drop**. New committed baseline supersedes original working bytes without silently discarding them.',
    '\nPreserved tracked paths:\n```text',
]
lines.extend(sorted(p for p, info in before['overlap'].items() if info['status'] == ' M'))
lines.extend(['```\nPreserved original untracked regressions:\n```text'])
lines.extend(sorted(p for p, info in before['overlap'].items() if info['status'] == '??'))
lines.extend([
    '```',
    'Pre-existing stash also remains intact: `' + before['existingStashes'][0].split()[0] + '`. Neither stash popped/dropped; no stash cleanup.',
    '\n### Unrelated changes / integrated source integrity\n',
    '**65 unrelated paths unchanged**, checked by SHA-256, file mode/symlink state and exact status: **10 tracked dirty + 55 untracked**. Includes **20 issue paths** (10 tracked + 10 untracked) and **45 untracked brag paths**. No issue/map/brag/STU/package/lockfile content edited or staged.',
    'Before and after full status/hash inventories: `.workmux/serial-integration-before.json` and `.workmux/serial-integration-after.json`. The 43 reviewed candidate source paths now match main and committed reviewed blobs against `.workmux/final-candidate-integrity.json`; 8 originally clean candidate paths were also verified against base before FF. Main index empty; expected unrelated issue/brag dirt remains. Candidate worktree stays clean.',
    'All worktrees and branches retained; no force/reset/checkout/clean/stash drop, cleanup, branch deletion or remote operation. Ordinary fast-forward details in `.workmux/serial-integration-ff.log`; retained stash identification in `.workmux/serial-integration-stash.json`.',
    '\n### Exact verification performed — no duplicate full suites\n',
    'Verified candidate range contains exactly 43 authorized paths and eight existing linear commits. Verified original overlapping files/snapshots; asserted before HEAD/index; saved unrelated status/content manifest; verified preserved stash tree and every original blob; asserted post-stash main dirt; FF exit 0; verified after HEAD/index/dirt; matched all 43 source hashes in candidate/main/reviewed Git blobs; checked existing/new stash OIDs retained.',
    'Material environment comparison: Node v24.22.1 / npm 11.19.1; candidate/main versions match for Nx, Jest, ts-jest, SWC Jest, TypeScript, Vitest, Vite, TypeORM, Nest core and Nest TypeORM. Relevant package/lockfile/tsconfig/Jest/SWC/Vite config bytes match. All 49 main local-data input files match reviewed local snapshot. `.workmux/serial-integration-environment.json` records comparison without data-content disclosure.',
    '**No material environment difference found; no sanity or exhaustive suites rerun, and no new full-suite success claimed.** Exact existing gate ledger remains `.workmux/gate-results.tsv` (81 executions). Reviewed acceptance evidence retained: backend 211 suites / 1980 tests, focused 13 / 69, integration 36 / 290, frontend 92 files / 653 tests, zero skipped; current required types/lint/build/sync and permanent Buoy metadata GREEN. Existing warnings and no full app-boot claim unchanged.',
    'Migration generation/synchronization still excluded because duplicate users/factions/faction_modifiers metadata; migration replay accepted only synchronize=false. `.mts` source parity only, runtime unverified. No database operation in this integration phase.',
    '\nSTOP: reviewed baseline integrated into stu-parity only. **No push, no D3b/ee90beb6 or other feature integration, no tracker resolution.** Ready for coordinator-controlled next serial phase; do not start it automatically.',
])
with Path('.workmux/baseline-verification-20261109.md').open('a') as f:
    f.write('\n'.join(lines) + '\n')
print('Serial integration report appended; originals preserved:', preserved['oid'])

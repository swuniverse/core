const fs = require('node:fs');
const { execFileSync } = require('node:child_process');
const { resolve } = require('node:path');
const read = fs.readFileSync.bind(fs);
const selected = new Map((process.env.BASELINE_OVERLAY_PATHS ?? '').split(',').filter(Boolean).map(file => [
  resolve(file), execFileSync('git', ['show', `HEAD:${file}`]),
]));
fs.readFileSync = function(file, options) {
  if (typeof file === 'string' && selected.has(resolve(file))) {
    const content = selected.get(resolve(file));
    const encoding = typeof options === 'string' ? options : options?.encoding;
    return encoding ? content.toString(encoding) : Buffer.from(content);
  }
  return read(file, options);
};

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

record = json.loads(Path('.workmux/serial-integration-before.json').read_text())
preserved = json.loads(Path('.workmux/serial-integration-stash.json').read_text())
reviewed = record['reviewed']
main = Path(record['main'])
candidate = Path.cwd()
final = json.loads(Path('.workmux/final-candidate-integrity.json').read_text())['files']


def git(*args):
    return subprocess.check_output(['git', '-C', str(main), *args])


def inventory():
    result = {}
    for raw in git('status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0'):
        if not raw:
            continue
        status = raw[:2].decode()
        path = raw[3:].decode()
        assert status in (' M', '??'), f'Unexpected index/conflict/rename: {status} {path}'
        p = main / path
        content = os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
        result[path] = {'status': status, 'sha256': hashlib.sha256(content).hexdigest(),
                        'mode': stat.S_IMODE(p.lstat().st_mode), 'symlink': p.is_symlink()}
    return result


assert git('rev-parse', 'HEAD').decode().strip() == record['base']
assert git('branch', '--show-current').decode().strip() == 'stu-parity'
assert not git('diff', '--cached', '--name-only')
assert not git('ls-files', '--unmerged')
assert inventory() == record['unrelated'], 'Concurrent unrelated content change; STOP'
entries = git('stash', 'list', '--format=%H %gs').decode().splitlines()
assert any(entry.startswith(preserved['oid'] + ' ') for entry in entries), 'Preserved stash missing'
assert all(entry in entries for entry in record['existingStashes'])
assert git('rev-parse', 'consolidate-baseline-20261109').decode().strip() == reviewed
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == reviewed
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
assert set(git('diff', '--name-only', record['base'], reviewed).decode().splitlines()) == set(final)
assert len(final) == 43
for p, digest in final.items():
    assert hashlib.sha256((candidate / p).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(git('show', f'{reviewed}:{p}')).hexdigest() == digest
    if p in {item for item, info in record['overlap'].items() if info['status'] == '??'}:
        assert not os.path.lexists(main / p), f'Concurrent untracked overlap: {p}'
    else:
        assert (main / p).read_bytes() == git('show', f"{record['base']}:{p}"), f'Concurrent tracked overlap: {p}'
command = ['git', '-C', str(main), '-c', 'merge.autoStash=false', 'merge', '--ff-only', reviewed]
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
Path('.workmux/serial-integration-ff.log').write_text(result.stdout)
print(result.stdout)
assert result.returncode == 0, 'Fast-forward failed; originals remain in named stash; no automatic rollback'
assert git('rev-parse', 'HEAD').decode().strip() == reviewed
assert not git('diff', '--cached', '--name-only')
assert inventory() == record['unrelated'], 'Post-FF unrelated content mismatch; STOP'
for p, digest in final.items():
    assert hashlib.sha256((main / p).read_bytes()).hexdigest() == digest, f'Integrated source mismatch: {p}'
    assert hashlib.sha256((candidate / p).read_bytes()).hexdigest() == digest
entries_after = git('stash', 'list', '--format=%H %gs').decode().splitlines()
assert entries_after == entries, 'Concurrent stash change; inspect preserved OID before proceeding'
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
after = {'main': str(main), 'beforeHead': record['base'], 'afterHead': reviewed,
         'stash': preserved, 'unrelated': inventory(), 'matchedCandidatePaths': 43,
         'mainIndexEmpty': True, 'candidateClean': True, 'ffExit': result.returncode,
         'ffCommand': command, 'stashListAfter': entries_after}
Path('.workmux/serial-integration-after.json').write_text(json.dumps(after, indent=2) + '\n')
print(f'Fast-forward complete: {record["base"]} -> {reviewed}')
print(f'All 43 integrated source hashes match; unrelated 65 paths unchanged; index empty; stash {preserved["oid"]} retained.')
print('Candidate clean, all worktrees retained, no merge commit/push/cleanup.')

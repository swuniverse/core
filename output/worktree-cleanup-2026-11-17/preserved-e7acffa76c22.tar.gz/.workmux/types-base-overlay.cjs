const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const { resolve, relative } = require('node:path');
const configFile = 'apps/backend/tsconfig.spec.json';
const config = ts.readConfigFile(configFile, ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, resolve('apps/backend'), undefined, resolve(configFile));
const host = ts.createCompilerHost(parsed.options);
const read = host.readFile.bind(host);
const target = 'apps/backend/src/modules/starmap/layer-map-cycle.service.spec.ts';
host.readFile = (file) => relative(process.cwd(), file) === target
  ? execFileSync('git', ['show', `HEAD:${target}`], { encoding: 'utf8' })
  : read(file);
const program = ts.createProgram({ rootNames: parsed.fileNames, options: { ...parsed.options, noEmit: true }, host, projectReferences: parsed.projectReferences });
const diagnostics = ts.getPreEmitDiagnostics(program);
console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics, {
  getCanonicalFileName: (f) => f, getCurrentDirectory: () => process.cwd(), getNewLine: () => '\n',
}));
console.log(`diagnostics=${diagnostics.length}; overlay=${target} from HEAD`);
process.exitCode = diagnostics.length ? 2 : 0;

import hashlib
import json
import subprocess
from pathlib import Path

BASE = '7e7143d80d155b312dca1ad0d6a5304c38d54571'
REQUIRED = {
    'followup-nx-graph', 'followup-nx-sync-check',
    'followup-frontend-lint-config', 'followup-hook-lint-proof',
    'followup-nx-lint', 'followup-nx-types',
    'followup-backend-spec-types', 'followup-frontend-spec-types',
    'followup-backend-unit-full', 'followup-frontend-unit-full',
    'followup-nx-builds', 'followup-backend-focused',
    'followup-frontend-focused', 'followup-integration-full',
    'followup-datasource-source-parity', 'followup-cli-datasource-disposable',
    'followup-final-sync-check',
    'buoy-permanent-green', 'buoy-backend-types', 'buoy-backend-lint',
    'buoy-backend-focused', 'buoy-backend-spec-types',
    'buoy-backend-unit-full', 'buoy-backend-build', 'buoy-integration-full',
    'buoy-runtime-probe-green', 'buoy-final-sync-check',
}


def output(*args):
    return subprocess.check_output(args, text=True).strip()


def run(*args):
    subprocess.run(args, check=True)


results = {}
for line in Path('.workmux/gate-results.tsv').read_text().splitlines():
    fields = line.split('\t')
    results[fields[0]] = int(fields[1])
assert REQUIRED <= results.keys(), 'Required gates missing'
assert all(results[name] == 0 for name in REQUIRED), 'Required gate remains red'
assert output('git', 'rev-parse', 'HEAD') == BASE
assert output('git', 'branch', '--show-current') == 'consolidate-baseline-20261109'
assert not output('git', 'diff', '--cached', '--name-only')
run('git', 'diff', '--check')
groups = json.loads(Path('.workmux/followup-commit-groups.json').read_text())
paths = [p for group in groups for p in group['paths']]
changed = output('git', 'diff', '--name-only').splitlines() + output('git', 'ls-files', '--others', '--exclude-standard').splitlines()
assert len(paths) == len(set(paths)) == 43 and set(paths) == set(changed)
pin = Path('.workmux/preserved-local-inputs/existing-npm-pin.patch').read_text()
assert output('git', 'diff', '--', 'nx.json') == pin.strip(), 'Npm pin not exact'
assert results.get('buoy-permanent-red') == 1, 'Permanent regression RED not recorded'
final_integrity = json.loads(Path('.workmux/final-candidate-integrity.json').read_text())
assert final_integrity['files'] == {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
previous_integrity = json.loads(Path('.workmux/precommit-candidate-integrity.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest
           for p, digest in previous_integrity['files'].items() if p.startswith('apps/frontend/'))
snapshot = Path('.workmux/preserved-local-inputs/game-data/data')
manifest = json.loads(Path('.workmux/preserved-local-inputs/local-data-manifest.json').read_text())
assert manifest == {str(p.relative_to(snapshot)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in snapshot.rglob('*') if p.is_file()}
commits = []
for group in groups:
    run('git', 'add', '--', *group['paths'])
    staged = set(output('git', 'diff', '--cached', '--name-only').splitlines())
    assert staged == set(group['paths'])
    run('git', 'diff', '--cached', '--check')
    run('git', 'diff', '--cached', '--stat')
    message = group['subject'] + '\n\nCo-Authored-By: Claude Code <noreply@anthropic.com>'
    run('git', '-c', f'core.hooksPath={Path(".githooks").resolve()}', 'commit', '-m', message)
    commits.append({**group, 'sha': output('git', 'rev-parse', 'HEAD')})
    Path('.workmux/followup-commits.json').write_text(json.dumps(commits, indent=2) + '\n')
assert set(output('git', 'diff', '--name-only', BASE, 'HEAD').splitlines()) == set(paths)
assert not output('git', 'status', '--porcelain')
print('Eight verified logical local commits created; working tree clean; no merge/push.')

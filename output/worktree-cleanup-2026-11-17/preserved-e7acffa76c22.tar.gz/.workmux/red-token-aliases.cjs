const { resolve } = require('node:path');
// Test-only aliases make new token imports usable on the old production source.
// No provider implementation or decorator is substituted.
for (const [file, exports] of [
  ['spacecraft/field-effect-consequence', { STU_RANDOM_TOKEN: 'STU_RANDOM', STU_CLOCK_TOKEN: 'STU_CLOCK' }],
  ['spacecraft/spacecraft-boarding.service', { BOARDING_RANDOM_TOKEN: 'BOARDING_RANDOM' }],
  ['tick/wreck-decay.service', { WRECK_DECAY_RANDOM_TOKEN: 'WRECK_DECAY_RANDOM' }],
  ['tutorial/tutorial-definitions', { TUTORIAL_DEFINITIONS_TOKEN: 'TUTORIAL_DEFINITIONS' }],
]) {
  const path = resolve(process.cwd(), 'apps/backend/src/modules', file);
  jest.doMock(path, () => ({ ...jest.requireActual(path), ...exports }));
}

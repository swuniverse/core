const { ESLint } = require('eslint');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
(async () => {
  const file = path.resolve('apps/frontend/src/pages/colonies/ColoniesPage.tsx');
  const source = fs.readFileSync(file, 'utf8');
  const eslint = new ESLint({ cwd: path.resolve('apps/frontend') });
  const config = await eslint.calculateConfigForFile(file);
  assert.equal(config.rules['react-hooks/exhaustive-deps'][0], 1);
  assert.equal(config.rules['react-hooks/rules-of-hooks'][0], 2);
  assert.equal(config.rules['@nx/enforce-module-boundaries'][0], 2);
  const directives = /^\s*\/\/ eslint-disable-next-line react-hooks\/exhaustive-deps[^\n]*$/gm;
  assert.equal([...source.matchAll(directives)].length, 3);
  const [original] = await eslint.lintText(source, { filePath: file });
  const suppressed = original.suppressedMessages.filter(m => m.ruleId === 'react-hooks/exhaustive-deps');
  assert.equal(suppressed.length, 3);
  assert.equal(original.fatalErrorCount, 0);
  assert.equal(original.messages.filter(m => m.message.includes("Definition for rule")).length, 0);
  const [counterfactual] = await eslint.lintText(source.replace(directives, ''), { filePath: file });
  const exposed = counterfactual.messages.filter(m => m.ruleId === 'react-hooks/exhaustive-deps');
  for (const message of suppressed) {
    assert.ok(exposed.some(m => m.message === message.message), 'Existing suppression catches an active hook warning');
  }
  assert.deepEqual((await eslint.calculateConfigForFile(file)).rules, config.rules);
  assert.equal(fs.readFileSync(file, 'utf8'), source);
  console.log('Frontend effective rules: exhaustive-deps=warn; rules-of-hooks=error; module-boundaries=error.');
  console.log(`Unchanged source: ${suppressed.length} active hook warnings suppressed by existing directives; in-memory comment removal exposes all three.`);
  console.log('Runtime source and active rule configuration unchanged; no stale-suppression correction warranted.');
})().catch(error => { console.error(error.message); process.exitCode = 1; });

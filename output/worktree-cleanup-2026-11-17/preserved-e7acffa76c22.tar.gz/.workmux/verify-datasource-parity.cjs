const fs = require('node:fs');
const assert = require('node:assert/strict');
const ts = fs.readFileSync('apps/backend/src/database/typeorm-migration.config.ts', 'utf8');
const mts = fs.readFileSync('apps/backend/src/database/typeorm-migration.config.mts', 'utf8');
assert.equal(mts.replace(/(from ['"]\.[^'"]+)\.js(['"])/g, '$1$2'), ts);
console.log('Datasource .ts/.mts source parity: PASS (only ESM .js specifiers differ)');

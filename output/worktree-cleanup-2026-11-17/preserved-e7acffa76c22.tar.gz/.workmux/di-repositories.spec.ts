import { Test } from '@nestjs/testing';
import { PARAMTYPES_METADATA, SELF_DECLARED_DEPS_METADATA } from '@nestjs/common/constants';
import { Repository } from 'typeorm';
import { SpacecraftScanService } from '../apps/backend/src/modules/spacecraft/spacecraft-scan.service';
import { SpacecraftService } from '../apps/backend/src/modules/spacecraft/spacecraft.service';

// Ignored verification probe at the already authorized Nest dependency seam.
// Register repository tokens, never generic Repository, to detect absent decorators.
for (const service of [SpacecraftScanService, SpacecraftService]) {
  it(`${service.name} resolves repositories with actual TypeORM provider tokens`, async () => {
    const types: unknown[] = Reflect.getMetadata(PARAMTYPES_METADATA, service) ?? [];
    const explicit: Array<{ index: number; param: unknown }> = Reflect.getMetadata(SELF_DECLARED_DEPS_METADATA, service) ?? [];
    for (const { index, param } of explicit) types[index] = param;
    const tokens = [...new Set(types)].filter(token => token && token !== Repository && token !== Object && token !== Function);
    const module = await Test.createTestingModule({
      providers: [service, ...tokens.map(token => ({ provide: token as never, useValue: {} }))],
    }).compile();
    expect(module.get(service)).toBeInstanceOf(service);
    await module.close();
  });
}

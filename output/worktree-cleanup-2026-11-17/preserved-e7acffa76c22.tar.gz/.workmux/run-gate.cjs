const { spawnSync } = require('node:child_process');
const { appendFileSync, openSync, closeSync } = require('node:fs');
const [name, command] = process.argv.slice(2);
if (!name || !command || !/^[a-z0-9-]+$/.test(name)) throw new Error('name and command required');
const log = `.workmux/gates/${name}.log`;
const fd = openSync(log, 'w');
const start = Date.now();
const result = spawnSync('/bin/zsh', ['-c', command], {
  cwd: process.cwd(), stdio: ['ignore', fd, fd], timeout: 600000,
  env: { ...process.env, npm_config_offline: 'true', NX_DAEMON: 'false', NX_INTERACTIVE: 'false' },
});
closeSync(fd);
const exit = result.status ?? (result.error?.code === 'ETIMEDOUT' ? 124 : 125);
appendFileSync('.workmux/gate-results.tsv', `${name}\t${exit}\t${Date.now() - start}\t${command}\t${log}\n`);
console.log(`${name}: exit=${exit}; log=${log}`);
if (result.error) console.log(result.error.message);

const path = require('node:path');
const rootDir = path.resolve(process.cwd(), 'apps/backend');
module.exports = {
  ...require(path.join(rootDir, 'jest.integration.config.cts')),
  rootDir,
  roots: [rootDir, path.resolve(process.cwd(), '.workmux')],
  displayName: 'baseline-overlay',
  globalSetup: undefined,
  globalTeardown: undefined,
  testMatch: [path.resolve(process.cwd(), '.workmux/di-repositories.spec.ts')],
};

"""Verify new backend receipts once; transfer only unchanged frontend/shared scopes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

start = time.monotonic()
root = Path.cwd()
candidate = '7d662cd43057f7aab7581806023074461b8ecc70'
candidate_tree = '3050b22f1df509028da843571ad0d4e7162b0f06'
allowed = {
    'apps/backend/src/modules/spacecraft/wormhole-restriction.service.ts',
    'apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts',
}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)


def excluded(path):
    return path.startswith(('.workmux/', '.scratch/stu-parity/issues/'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


head = git('rev-parse', 'HEAD').decode().strip()
assert git('rev-parse', candidate + '^{tree}').decode().strip() == candidate_tree
paths = (git('diff', candidate, '--name-only', '-z') +
         git('ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')
changed = {p for p in paths if p and not excluded(p)}
assert changed == allowed, 'Unexpected scope change; frontend/shared transfer not valid'
# Everything outside these two backend paths is byte-identical to the original
# candidate, including frontend/shared source, tests and repository build configs.
transfers = []
for name, scope in [
    ('k7b-final-frontend', 'frontend tests: 94 files / 674 tests'),
    ('k7b-final-lint', 'frontend/shared lint only; backend superseded'),
    ('k7b-final-types', 'frontend/shared application types only; backend superseded'),
    ('k7b-final-forced-specs', 'frontend forced spec compilation only; backend superseded'),
    ('k7b-final-build', 'frontend/shared production builds only; backend superseded'),
]:
    receipt = root / '.workmux/gates' / (name + '.json')
    log = receipt.with_suffix('.log')
    facts = json.loads(receipt.read_text())
    assert type(facts['process_exit']) is int and facts['process_exit'] == 0
    assert facts['source_unchanged'] is True and facts['before'] == facts['after']
    assert digest(log.read_bytes()) == facts['log_sha256']
    assert log.read_bytes().rstrip().endswith(b'process_exit=0')
    before = facts['before']
    assert git('rev-parse', before['head'] + '^{tree}').decode().strip() == before['tree']
    recorded = {p: h for p, h in before['source_hashes'].items() if not excluded(p)}
    candidate_paths = git('diff', before['head'], candidate, '--name-only', '-z').decode().split('\0')
    original = {p: digest(git('show', candidate + ':' + p))
                for p in candidate_paths if p and not excluded(p)}
    assert recorded == original, 'Original receipt does not bind candidate code'
    scoped = {p: h for p, h in recorded.items()
              if p.startswith(('apps/frontend/', 'packages/shared/'))}
    assert len(scoped) == 5
    for path, expected in scoped.items():
        assert digest((root / path).read_bytes()) == expected
    transfers.append({
        'receipt': str(receipt.relative_to(root)),
        'receipt_sha256': digest(receipt.read_bytes()),
        'process_exit': 0,
        'scope': scope,
        'original_checkpoint_head': before['head'],
        'original_candidate': candidate,
        'verified_frontend_shared_changed_paths': len(scoped),
        'identity': 'All tracked frontend/shared/config bytes unchanged from original candidate; only two backend paths differ',
    })

# The supplied verifier is unmodified and runs exactly once for new backend gates.
result = subprocess.run([
    sys.executable, '-I', str(root / '.workmux/local-inputs/verify-evidence-fast.py'),
    *sys.argv[1:],
], cwd=root, capture_output=True, text=True, check=True)
backend = json.loads(result.stdout)
assert git('rev-parse', 'HEAD').decode().strip() == head
print(json.dumps({
    'verified_at': datetime.now(timezone.utc).isoformat(),
    'head': head,
    'original_candidate': candidate,
    'changed_code_paths': sorted(changed),
    'backend_verification': backend,
    'unchanged_evidence_transfers': transfers,
    'verification_elapsed_seconds': round(time.monotonic() - start, 3),
    'limitations': 'Point-in-time Git/code/log identity only, not independent review or execution provenance. Old backend portions are NOT transferred; issue metadata excluded.',
}, indent=2))

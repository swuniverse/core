# K7b — original independent fast Spec review

Date: 2026-11-10. **SPEC BLOCKED — one confirmed P2 integration-contract finding.**
Spec axis only; no Standards verdict, coordinator integration or MAIN mutation authority.

## Pin and bounded scope
- BASE: `4e2da9569b996d5a18cd428142a34ce8555e0853`.
- Candidate: `7d662cd43057f7aab7581806023074461b8ecc70`.
- Tree: `3050b22f1df509028da843571ad0d4e7162b0f06`.
- `git diff BASE...candidate` / `git log BASE..candidate --oneline`: one direct-parent commit, 25 paths (24 code/test/config + issue); subject `feat(spacecraft): enforce station-managed wormhole restrictions`.
- Reviewed exact candidate blobs and originating BASE issue, not older checkout; bounded central store/resolver, canonical location, lifecycle cleanup, module/migration and passage seams. No prior feature/history re-audit.

## Findings — under 400 words
**P2 — Dissolved-alliance wormhole rules are neither removed nor hidden.** Anchor: `apps/backend/src/modules/spacecraft/wormhole-restriction.service.ts:20–21,114–129`.
Originating K7b goal :10 identifies the central alliance integration; its binding access contract `.scratch/alliance-stu-parity/allianz-infrastruktur-spec.md:158` states: “Die Auflösung einer Allianz entfernt in ihrer Transaktion alle Regeln, die auf diese Allianz zielen.” It also requires: “Eine gelöschte Zielallianz wird nie als gültiges Ziel angezeigt.” :164–165 requires registration at `AllianceContextCleanup`, with writes through the lifecycle transaction handle.
Concrete supported sequence: an entry station has one ALLIANCE ALLOW rule; that alliance is dissolved through `AllianceService.dissolveAlliance`. The actual service invokes `contextCleanup.allianceDissolved` before deleting the alliance (:1749–1759), but the new wormhole service never registers a consumer. Its migration has only a wormhole FK, not an alliance FK; central `deleteAlliance` deletes only the alliance. The rule therefore survives and `read()` returns it unfiltered to the real panel. With the station still present, the policy treats the orphan as configured rules, so every otherwise-unmatched ship remains denied instead of returning to no-rules unrestricted passage. This is a persistent game-state and UI defect, not hypothetical ID reuse.
Register wormhole-rule cleanup for alliance dissolution using the supplied EntityManager, following the existing docking consumer; retain rollback semantics and cover actual dissolution → persisted rules/list/passage behavior. Apply the documented reset callback contract where appropriate. No separate finding is asserted about prior docking behavior.

## Goal and all five acceptance criteria
- Goal :10 / AC1 :28: persistent wormhole, USER/ALLIANCE/FACTION/SHIP, target ID, ALLOW/DENY implemented. Migration creates positive-ID/type/mode constraints, unique target key and wormhole cascade; both migration configs and integration discovery include it; AppModule/module entity wiring checked.
- AC2 :29: matching DENY precedes ALLOW; empty rules allow; configured unmatched rules deny. Current DB User/faction and membership come from the same manager-bound central AllianceStore used by the resolver, not JWT faction, station ownership or stance. Exceptions return closed policy. Core behavior implemented; required alliance-lifecycle integration remains partial as above.
- Configured default-deny is consistent with explicit-grant/current-membership contract (:154–157) and the settled decision; no verified unasked-policy finding. The cited STU utility itself is not present in this review's tracked inputs, so exact external STU implementation parity is not claimed.
- AC3 :30 / settled decision :36: JWT sub only; owned STATION at canonical GALAXY entry required for every list/create/delete, otherwise 403. Arbitrary wormhole creates refused, unrelated rule deletes scoped harmlessly, target type/mode/int range/existence validated. No admin game UI. No station ignores even stale rules; exit-side station does not acquire entry administration.
- AC4 :31: actual rejection uses `Du hast keine Berechtigung, in das Wurmloch einzufliegen.`; requested sentence preserved with terminal punctuation. Planner catches policy exceptions and checks every fleet/tractor participant before durable activation/movement/arrival effects. Existing transaction and after-commit notification ordering retains rollback.
- AC5 :32: four target types, DENY priority, current membership removal, owner/foreign/nonstation/missing-entry, stale rules, resolver failure and fleet/tractor denial covered. Actual AppModule PostgreSQL HTTP seam and real station-detail/panel tests read; typed shared GET/POST/DELETE contracts, rendered list/create/delete/error paths verified. Missing lifecycle regression corresponds to the confirmed finding.
- Passage queries lock actual local active forward/reverse candidates; arbitrary selector cannot inject another wormhole. Canonical entry station governs that wormhole's snapshot in either direction; no separate reverse-side administration semantics added. Wormhole locks serialize rule management; existing station/User/membership rows are locked and immutable callbacks do no later reads. This is not a claim of serializable negative-space locking or exhaustive concurrent schedules.

## Independently checked technical evidence — not reviewer execution
Inputs: `.workmux/local-inputs/k7b-fast-review/`.
- One deterministic read-only hash/identity script verified all **29/29 manifest artifacts**, candidate parent/tree/counts, all **25 current raw worker files**, worker candidate HEAD/tree and clean tracked status.
- Seven final receipt/log pairs and current worker copies match. Each actual exit is integer 0; before=after, source_unchanged=true, BASE checkpoint/tree correct. Each exact **24-code-path map matches candidate Git SHA-256**; issue metadata excluded. Supplied verification's seven receipt hashes/checkpoints/counts agree.
- Actual backend summary: **215 suites / 2008 tests / 1 snapshot**; frontend successful file rows independently sum **94 / 674**, matching summaries. No skipped/todo totals.
- Actual targeted PostgreSQL summary: **2 suites / 81 tests**, zero skipped totals. Includes production AppModule HTTP plus narrower passage-service integration with substituted policy/RNG. **Not all PostgreSQL and not 81 production-only HTTP tests.** Raw log omits per-case/suite PASS rows; no invented per-suite count split.
- The sole verifier assertion failure expected those absent PG case rows. Only this concrete log-format assumption was inspected/corrected; earlier artifact/source checks were not repeated broadly. This was a reviewer parser limitation, not a candidate gate failure.
- Lint backend/frontend/shared succeeds: 0 errors, frontend 110/backend 1438 warnings. Regular typecheck, explicit forced backend/frontend spec compilation and three-project build all exit 0; frontend build transforms 1105 modules. ts-jest/pg deprecations, negative-fixture Nest errors and CSS/chunk warnings retained.
- Final worker gate elapsed seconds: backend 52.624; frontend 30.888; targeted PG 63.594; lint 17.988; types 24.590; forced specs 28.154; build 10.195.
- Worker automated verifier's **1.079s** is supplied timing, not independent execution provenance. Scripts were read, not executed. Point-in-time source/log identity proves neither continuous filesystem/process provenance nor all internal caches cleared; ordinary compiler builds may be incremental, forced spec compilation is separate evidence.
- Representative candidate SHA-256: policy `6eee8895fdc89cd6722624f55b222990a94b6b3620900580d9ad25274f7c5391`; restriction service `a625ec742767369a8bd631c29751e51d06a2912a8704721b812006b874984c9c`; panel `80d9c59b95efccde4c00fa0c02f599bee77b1c91b6b610a7b73f4372339e7d4a`.

## Timing, tracker and stop
- Source-review wall time from recorded start: **494.9s (~8m15s)**. Evidence/handoff approximately three minutes, within the ten-minute alert budget; no execution blocker. The concrete remaining hold is the P2 cleanup defect.
- Candidate issue stays `ready-for-agent`, five implementation criteria checked and two independent-review checkboxes unchecked; historical comments retained. This is not resolved acceptance, and tracker prose does not close the finding.
- Reviewer HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`, tracked clean. New report target was absent and ignored before creation; prior reports preserved.
- Only read-only Git/source/docs/evidence and this new ignored report. No gates/tests/types/lint/build/DB runs, installs, external services, secret/environment inspection, private transcript/tool-result access/export, agents/workflows/plan mode, source/tracker/config/package/map/STU edits, branch switch, commit/merge/push or cleanup.

**Stop for coordinator's narrow correction and separate integration phase. No next ticket.**

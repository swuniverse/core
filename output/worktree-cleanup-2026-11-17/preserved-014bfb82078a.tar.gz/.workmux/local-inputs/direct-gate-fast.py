import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command or '/' in args.name or args.name in ('.', '..'):
    parser.error('Use a simple unique gate name and a command after --')
root = Path.cwd()


def git(*values):
    return subprocess.check_output(['git', *values], cwd=root)


def state():
    changed = git('diff', 'HEAD', '--name-only', '-z') + git('ls-files', '--others', '--exclude-standard', '-z')
    paths = sorted(set(p for p in changed.decode().split('\0') if p and not p.startswith('.workmux/')))
    hashes = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() if (root / p).is_file() else None for p in paths}
    return {'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'source_hashes': hashes}


output = root / '.workmux/gates'
output.mkdir(parents=True, exist_ok=True)
log = output / (args.name + '.log')
receipt = output / (args.name + '.json')
if log.exists() or receipt.exists():
    parser.error('Existing evidence would be overwritten; use a new name')
before = state()
env = os.environ.copy()
env.pop('DATABASE_URL', None)
env.pop('INTEGRATION_DATABASE_URL', None)
env['NX_DAEMON'] = 'false'
env['NX_NO_CLOUD'] = 'true'
started_at = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
with log.open('xb') as stream:
    stream.write(('Command: ' + json.dumps(command) + '\nAmbient DB URLs removed; NX_DAEMON=false; NX_NO_CLOUD=true\n').encode())
    stream.flush()
    result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    stream.write(('\nprocess_exit=' + str(result.returncode) + '\n').encode())
elapsed = time.monotonic() - start
finished_at = datetime.now(timezone.utc).isoformat()
after = state()
facts = {'command': command, 'process_exit': result.returncode, 'started_at': started_at, 'finished_at': finished_at, 'elapsed_seconds': round(elapsed, 3), 'before': before, 'after': after, 'source_unchanged': before == after, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
with receipt.open('x') as stream:
    json.dump(facts, stream, indent=2)
    stream.write('\n')
print(json.dumps({'gate': args.name, 'process_exit': result.returncode, 'elapsed_seconds': facts['elapsed_seconds'], 'source_unchanged': facts['source_unchanged'], 'receipt': str(receipt)}))
sys.exit(result.returncode if before == after else 99)

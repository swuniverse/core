import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser(description='Verify selected direct green gate receipts against current code')
parser.add_argument('receipts', nargs='+')
args = parser.parse_args()
root = Path.cwd()
start = time.monotonic()


def git(*values):
    return subprocess.check_output(['git', *values], cwd=root)


def excluded(path):
    return path.startswith(('.workmux/', '.scratch/stu-parity/issues/'))


def sha(path):
    file = root / path
    return hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None


head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
results = []
for value in args.receipts:
    receipt = Path(value)
    facts = json.loads(receipt.read_text())
    assert type(facts['process_exit']) is int and facts['process_exit'] == 0, f'{receipt}: nonzero/noninteger exit'
    assert facts['source_unchanged'] is True and facts['before'] == facts['after'], f'{receipt}: inputs changed'
    log = receipt.with_suffix('.log')
    assert hashlib.sha256(log.read_bytes()).hexdigest() == facts['log_sha256'], f'{receipt}: log hash mismatch'
    assert log.read_bytes().rstrip().endswith(b'process_exit=0'), f'{receipt}: log exit mismatch'
    before = facts['before']
    assert git('rev-parse', before['head'] + '^{tree}').decode().strip() == before['tree'], f'{receipt}: checkpoint tree mismatch'
    recorded = {p: h for p, h in before['source_hashes'].items() if not excluded(p)}
    paths = (git('diff', before['head'], '--name-only', '-z') + git('ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')
    current = {p: sha(p) for p in sorted(set(paths)) if p and not excluded(p)}
    assert current == recorded, f'{receipt}: code differs from gate checkpoint'
    results.append({'receipt': str(receipt), 'receipt_sha256': hashlib.sha256(receipt.read_bytes()).hexdigest(), 'process_exit': 0, 'gate_elapsed_seconds': facts['elapsed_seconds'], 'checkpoint_head': before['head'], 'verified_changed_code_paths': len(recorded)})
assert git('rev-parse', 'HEAD').decode().strip() == head, 'HEAD changed during verification'
print(json.dumps({'verified_at': datetime.now(timezone.utc).isoformat(), 'head': head, 'tree': tree, 'verified_gates': results, 'verification_elapsed_seconds': round(time.monotonic() - start, 3), 'limitations': 'Point-in-time Git/code/log identity, not independent execution provenance; issue metadata excluded'}, indent=2))

# K7b fast independent Standards/security review — 2026-11-10

## Verdict and pin
- **STANDARDS: HOLD — 1 confirmed P2 documented-standard/correctness finding.** No independent Spec verdict supplied.
- Original reviewer: `review-tmw-k7a1`; exact candidate Git blobs reviewed, not this older checkout's source.
- BASE: `4e2da9569b996d5a18cd428142a34ce8555e0853`.
- Candidate: `7d662cd43057f7aab7581806023074461b8ecc70`; tree `3050b22f1df509028da843571ad0d4e7162b0f06`.
- Pinned commands: `git diff BASE...candidate`; `git log BASE..candidate`, with those exact SHAs.
- Verified: one direct-parent commit; 25 paths (24 code/test + issue), 1360 insertions/46 deletions; Conventional Commit and required attribution.

## Findings (Standards axis only)
1. **P2 — Remove dissolved-alliance wormhole rules in the lifecycle transaction.** New `apps/backend/src/modules/spacecraft/wormhole-restriction.service.ts:20–21` registers no `AllianceContextCleanup` consumer. ADR `docs/adr/0004-stationen-als-spacecraft-und-stationsrollen.md:53` requires “Regeln auf eine aufgelöste Allianz werden in derselben Transaktion entfernt” and explicitly extends the privilege model to wormholes. The real dissolution path calls cleanup before deleting the alliance (`alliance.service.ts:1749–1759`); the existing docking consumer deletes only `DockingPrivilege` (`docking-privilege.service.ts:46–60`). The new entity/migration has only a wormhole FK, so ALLIANCE-target rules survive. With an entry station and a sole ALLIANCE ALLOW rule, dissolving that alliance leaves a nonempty rule set that matches nobody: `wormhole-access.ts` continues denying passage instead of reaching the unrestricted zero-rule state. The stale rule also remains in the station list. Register a wormhole cleanup consumer using the supplied transaction manager, including the analogous alliance-reset lifecycle, and add dissolution/reset regression coverage. This is a confirmed ADR/lifecycle breach, not a request for stance-based access or a broader redesign.

## Bounded source/security scrutiny
- Read changed production/test source and relevant unchanged transaction, canonical-location, JWT, central AllianceStore, station/docking, migration-registration and alliance-lifecycle seams.
- Real controller uses JWT/game-access guards; CRUD derives principal from `req.user.sub`, requires owned STATION on the canonical entry field, rejects arbitrary hole creation, and scopes deletion to managed holes.
- Shared DTOs have actual backend/frontend consumers; positive bounded IDs/enums and target existence are validated; migration checks target/mode, uniqueness and wormhole cascade.
- Explicit DENY precedence/default-deny, current manager-backed player/faction/membership resolution, ignored rules without an entry station, and fail-closed exceptions traced.
- Passage holds wormhole read locks; CRUD takes wormhole write locks. Snapshot uses station/current identity/existing membership read locks with NOWAIT and performs no callback reads.
- All fleet/tractor participants are checked before activation/arrival writes; durable arrival dependencies share the transaction and notifications occur after commit. Production HTTP denial/failure and complete-participant no-write tests inspected.
- No additional concrete authorization/concurrency defect established by this bounded read; this is not an exhaustive concurrency proof.
- Mandatory standards considered: CONTRIBUTING, AGENTS, CONTEXT, docs/agents domain/tracker/triage, relevant ADRs 0004/0006 and frontend inventory. No CODING_STANDARDS file exists in the candidate tree.
- All 12 Fowler heuristics considered as judgments with repository overrides; tooling-enforced items excluded. No additional consequential smell retained.
- Real station panel uses Shared contracts, existing API/formatNumber, functional local state, text-xs/theme tokens, compact bordered table, German numbers and accessible CRUD controls; no new admin/hover UI.
- Issue history is appended under Comments; ready-for-agent remains, with independent reviews explicitly pending.

## Verified worker evidence (not reviewer execution)
- One deterministic read-only identity script completed in **2.353 s** at `2026-11-10T17:49:49.679Z`; no mismatch/retry. Worker `agent-tmw-k7b-fast` clean HEAD/tree match the pin; all 25 raw changed files equal candidate blobs.
- Verified 19 selected supplied artifact hashes: seven final receipts/logs plus report, timing, verification and two tools. Every receipt has actual integer exit 0, source_unchanged=true, identical before/after, exact BASE HEAD/tree and all 24 candidate code hashes; issue metadata excluded.
- Actual final summaries: backend **215/215 suites, 2008/2008 tests, 1/1 snapshot**; frontend **94/94 files, 674/674 tests**; targeted PostgreSQL **2/2 suites, 81/81 tests**. Summaries contain no skipped tests.
- PG selector is `wormhole-passage-http|wormhole-passage.int-spec`: production AppModule/JWT HTTP graph plus service-level atomic passage tests with injected policies/dependencies. **81 is neither all PostgreSQL tests nor 81 production-only authorization tests.** Quiet log does not provide per-suite case counts.
- Runner source/log bind ambient DB-URL removal; setup uses disposable PostgreSQL 16 Testcontainers, committed migrations and synchronize:false. No reviewer DB invocation or independent process provenance claim.
- Lint backend/frontend/shared passes, 0 errors; **110 frontend/1438 backend warnings**. Application types, forced backend/frontend spec builds (`tsc --build ... --force`), and three-project production builds pass; frontend **1105 modules**.
- Known warnings: ts-jest isolatedModules/pg concurrent-query deprecations; CSS optimization/large chunk warnings; expected negative-fixture Nest error logs. Worker verifier's **1.079 s** is technical identity evidence, not security review or proof all caches were cleared.
- RED receipts were not reaudited; acceptance above is limited to final receipts/source identity. No gates rerun, install, external service or secret/environment-value inspection.

## Timing, remaining hold and handoff
- Review started `2026-11-10T17:41:19.308Z`; bounded source phase ended `17:48:59.420Z` (**7m40s**). Final evidence check finished `17:49:49.679Z`; report prepared immediately afterward, evidence/handoff phase under the ten-minute alert budget.
- Remaining hold: the confirmed alliance-lifecycle cleanup finding. Coordinator owns narrow correction, invalidated-gate reverification, separate Spec acceptance and any later integration authorization.
- Only this NEW ignored report written. No source/tracker/config edits, reviewer checkout change, branch switch, commit, merge, push, cleanup, nested agents, workflows or next-ticket work. Prior reports preserved; stop for coordinator.

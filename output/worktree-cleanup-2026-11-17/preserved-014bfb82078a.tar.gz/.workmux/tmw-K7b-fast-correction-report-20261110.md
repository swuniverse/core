# K7b narrow lifecycle correction — 2026-11-10

## Identity and scope
- Follow-up SHA: `84b9e257aa7561d9e0d6999bf704b2bbfcb48774`
- Tree: `54488f25520e7f60f04ce5a77c83aa13257991e4`
- Direct parent/original candidate: `7d662cd43057f7aab7581806023074461b8ecc70`
- Original base: `4e2da9569b996d5a18cd428142a34ce8555e0853`; branch `agent-tmw-k7b-fast`.
- Three follow-up paths: `apps/backend/src/modules/spacecraft/wormhole-restriction.service.ts`, `apps/backend/src/modules/spacecraft/wormhole-passage-http.int-spec.ts`, `.scratch/stu-parity/issues/tmw-K7b-wurmloch-zugangsbeschraenkungen.md`.
- Only lifecycle production code changed; six regression cases added to the existing HTTP/PG suite. Prettier also normalized existing test-only wrapping without changing assertions.
- Original commit/reports/RED and failed logs preserved; new attributed Conventional Commit. Tracked working tree clean; no integration or push.

## Finding and correction
- Both initial independent Standards/security and Spec reviews finished, identifying the same confirmed P2; no additional finding supplied.
- ADR 0004:53 and real AllianceService dissolution/reset ports validated; cleanup handle is the caller's TypeORM EntityManager.
- WormholeRestrictionService now implements OnModuleInit and registers with AllianceContextCleanup, using the existing docking consumer pattern.
- Dissolution deletes ALLIANCE rules for that alliance; reset deletes all ALLIANCE rules. Both execute in the supplied caller transaction, not a global manager.
- No target, ownership, station-role, direction, matcher, API, migration or frontend policy changes.
- Existing owner/foreign/station, DENY/membership, fleet/tractor and atomic arrival tests retained.

## Meaningful RED/GREEN
- Receipts/logs under `.workmux/gates/`; original artifacts untouched.
- `k7b-correction-lifecycle-red`: actual exit 1, 2 failed lifecycle cases; alliance deleted but HTTP station list retained the sole ALLIANCE rule. Focus selector excluded 28 existing cases; not final acceptance.
- Only after that RED was the production consumer implemented.
- `k7b-correction-lifecycle-green`: actual exit 0, full HTTP suite 30 tests, zero skips.
- `k7b-correction-rollback-green`: actual exit 0, full HTTP suite 34 tests, zero skips.
- Six new cases cover dissolution/reset sole-rule removal and actual unrestricted passage; USER/FACTION/SHIP preservation and another alliance's retention on dissolution; rollback after a later consumer observes transaction-local deletion then throws.
- Rollback preserves persisted rules, alliance/membership and HTTP list, with real denied passage and unchanged durable arrival state.
- Real AppModule services/DB graph and JWT HTTP list/passage; only asset-storage output boundary additionally replaced with in-memory storage, preventing real asset deletion.
- Early `k7b-correction-fixture-types`: forced backend spec compilation exit 0. No assertion weakening, any waiver or disabled test.

## Stable final backend gates (all numeric exit 0, source unchanged)
- Receipt names below mean `.workmux/gates/<name>.json` and matching `.log`.
- `k7b-correction-final-backend-units`: 215 suites / 2008 tests / 1 snapshot; zero skips; 38.967 s.
- `k7b-correction-final-pg`: targeted passage HTTP/migration + passage integration, 2 suites / 87 tests; zero skips; 63.621 s. Not all PG and not 87 production-only HTTP tests.
- `k7b-correction-final-backend-lint`: 0 errors / 1438 warnings; 11.638 s.
- `k7b-correction-final-backend-types`: 6.136 s.
- `k7b-correction-final-backend-forced-specs`: explicit backend tsc --build --force; 12.633 s.
- `k7b-correction-final-backend-build`: 10.877 s.
- Disposable PG16, committed migrations, synchronize:false; unchanged runner removes both ambient DB URLs. No full PG, installs, shared DB or frontend rerun.
- Known warnings retained: backend lint warnings, ts-jest isolatedModules and pg concurrent-query deprecations, expected negative-fixture Nest errors.

## Evidence transfer and verification
- All tracked frontend/shared/config bytes unchanged from the original candidate; exactly two code paths differ, both backend.
- Transferred unchanged scopes: `k7b-final-frontend` (94 files / 674 tests), frontend/shared portions only of `k7b-final-lint`, `k7b-final-types`, `k7b-final-build`, and frontend portion of `k7b-final-forced-specs`.
- Original mixed-gate backend portions are NOT transferred; new backend receipts replace them. Frontend lint 110 warnings and original CSS/chunk warnings remain known.
- `.workmux/verify-k7b-correction.py` ran once: verifies original receipt/log hashes, numeric zero exits, candidate checkpoint/code identity and unchanged scope, then invokes unmodified `verify-evidence-fast.py` ONCE on six new backend receipts.
- Verification: `2026-11-10T18:06:14.513234Z`; supplied verifier 0.821 s; combined scoped verification 5.767 s.
- Output: `.workmux/tmw-K7b-fast-correction-verification-20261110.json`; checkpoint original HEAD plus exact two-code-path diff. Commit preserves verified code bytes; later issue metadata excluded.
- Point-in-time technical identity evidence only, not independent correction review or independent execution provenance.

## Timing and remaining acceptance
- UTC implementation: 17:52:18.152254Z → 18:01:05.155541Z.
- UTC final gates phase: 18:01:05.155541Z → 18:05:22.219558Z; last actual GREEN 18:04:59.120668Z.
- UTC handoff: 18:05:22.219558Z → 18:07:42.200341Z; 163.080 s from last GREEN; blocked minutes 0, within ten-minute alert budget.
- Timing: `.workmux/tmw-K7b-fast-correction-timing-20261110.json`.
- Issue history appended, status ready-for-agent, independent correction acceptance checklist open; no resolved/integrated claim.
- Initial reviewers' finding is technically corrected and regression-tested; independent correction acceptance and any later integration remain coordinator-owned.
- No nested agents/workflows, index, dependencies/config changes, external services, private transcripts, cleanup, amend/reset/rebase/merge/push or next ticket.

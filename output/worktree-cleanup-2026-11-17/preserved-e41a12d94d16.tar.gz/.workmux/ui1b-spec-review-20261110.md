# UI-1b — independent Spec review

Date: 2026-11-10

**SPEC: PASS — zero verified findings.** Standards remains the other independent reviewer’s axis; no Standards verdict is supplied here. Stop for coordinator serial integration; this review does not perform or approve a merge.

## Exact candidate pin

- Fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Candidate: `bab783d091693c6b75e75319c68ae69b17e1bbe3`.
- Candidate tree: `7b88eead34342bc86c24f11f0009304f18302806`.
- Reviewer HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`; old checkout source was not used as candidate source.
- Pinned diff: `git diff 699258b4f7f23cdd4cdc6675781677e9a8307b6b...bab783d091693c6b75e75319c68ae69b17e1bbe3`.
- Pinned log: `git log 699258b4f7f23cdd4cdc6675781677e9a8307b6b..bab783d091693c6b75e75319c68ae69b17e1bbe3 --oneline`.
- BASE independently verified as merge-base and direct parent; exactly **one commit / six paths**: `bab783d0 feat(frontend): show ship cargo on list hover`.

## Spec findings — under 400 words

**No concrete missing, partial, unasked or incorrectly implemented requirement was verified.**

Original BASE issue `.scratch/stu-parity/issues/sc-WP-UI-1b-schiffslager-hover-in-liste.md:10` requires “mit der gemeinsamen Tooltip-Komponente … ohne Ad-hoc-Hover-Panel”. The list uses production `ShipStorageTooltip`, which delegates its popup and populated table to the existing shared `Tooltip`/`TooltipTable`, rather than inventing another hover panel.

Spec :27 requires “Hover (Desktop) bzw. Tap (Touch) auf das Schiffsbild … Titel „Lager“, Waren mit Icon … und Menge, darunter Belegung/Kapazität”. The image button opens immediately through shared hover/focus/touch handlers, displays loading feedback while awaiting cargo, then commodity icon/name/amount and summed positive occupancy against that ship’s capacity. Empty cargo displays “Leer”. Production `GET /spacecraft` really carries `cargoMax` via the existing entity/summary spread; it is not merely supplied by synthetic fixtures. Icons use the established commodity asset resolver, including its existing generated-image mappings.

Spec :28 requires “erst beim ersten Hover geladen (lazy) und je Schiff gecacht”. No initial cargo request occurs. A ship-ID promise map shares pending and successful requests; the local open guard prevents repeated requests; failures evict the failed promise and allow retry. Ship-tagged state and mounted/current-ID checks prevent displaying another ship’s completed request. Actual list rows are keyed by ship ID.

Spec :29 requires “Hover löst genau einen Ladevorgang aus und rendert Ware und Menge”. New public production-page tests exercise first-open loading, cached reopen, two independent ships/capacities, icon/amount presentation, and first-touch empty cargo. Only API/assets are mocked; list, cargo presentation and shared Tooltip execute. New shared-Tooltip test checks hover/focus/touch callbacks without mouse-move repetition. Existing cases remain.

Spec :30 requires green lint/typecheck/test/build. Supplied final direct evidence is green and bound to the five candidate implementation/test files, as detailed below. Historical tracker comments remain byte-identical; no historical baseline exception was used.

## Production seams and bounded review

Read exact candidate Git blobs/diffs, original BASE issue, supplied report, every log/receipt, and the directly relevant unchanged API/DTO/asset seams. No full K7a, migration or baseline audit, no K5b assumptions.

- `spacecraft.tsx:224–240`: production ship row passes ID/name/image/capacity to the image tooltip; existing row navigation remains.
- `ShipStoragePanel.tsx:13–25,46–82`: ship-ID promise cache, concurrent reuse, rejection eviction, retry guard and late-response protection. Existing eager detail `ShipStoragePanel` behavior remains unchanged.
- `ShipStoragePanel.tsx:85–134`: shared title/table, cargo rows, loading/error alert, empty “Leer”, occupancy/capacity.
- `Tooltip.tsx:124–185`: hover/focus/touch open callback; cursor movement only repositions; first touch suppresses its following click’s row navigation. Existing global-single-tooltip, Escape/outside-close and second-tap behavior remain covered by retained shared-component tests.
- `spacecraft.controller.ts:655–657` → `spacecraft.service.ts:343–362,1463–1580`: actual list response spreads the ship summary/entity; `entities/spacecraft.entity.ts:185–186` supplies `cargoMax`. Shared list typing omits this existing runtime field, so the frontend intersection is not proof of a nonexistent backend field.
- `assets.ts:460–469`: real commodity image resolver supplies existing generated icons or numeric fallback; the asset mock does not independently test that resolver, which was source-inspected.
- Concurrency, rejection/retry and same-component ID changes were source-reviewed, not claimed as executed regression tests. The supplied added tests use successful resolved cargo and distinct production rows; no unprovided race/retry test is claimed.

## Input and direct evidence integrity

Directory: `.workmux/local-inputs/ui1b-review/`.

Verified **14/14 manifest log/JSON hashes** before substantive review. Verified all seven JSON `log_sha256` links, equal before/after records, and `source_unchanged: true`. Final focused/types/lint/full-test/build receipts each record numeric integer **`process_exit: 0`**, unchanged BASE HEAD before/after, and exactly the same **five implementation/test hashes** as the candidate Git blobs:

| Candidate path | SHA-256 |
|---|---|
| `apps/frontend/src/components/Tooltip.spec.tsx` | `2fe98b9a9c2eb78252ceee2313035a82def73b364141f603f1792c39570f622f` |
| `apps/frontend/src/components/Tooltip.tsx` | `055235398092bc65b20e1b1ceced4c15599888e4bfca138dcab3cec311180a0e` |
| `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx` | `e28fe6b321bd78b4185876b4e9d8bc9d4109addefc4a84e77e66924e2978ffa5` |
| `apps/frontend/src/pages/spacecraft.spec.tsx` | `dc56e67f1dd1364821c390f50ee5380ca325b3a5017252b7a942b1e99bf3281c` |
| `apps/frontend/src/pages/spacecraft.tsx` | `43fcb82a769b2a9161e2f5ed1dade494ae5f09ef3d44e283f487093debc26081` |

Gates ran before the tracker completion update/commit: receipts correctly record BASE HEAD, not candidate HEAD. Executable/test-file identity matches candidate; final tracker status/history changes are deliberately outside that five-file receipt comparison. Candidate HEAD/tree are verified from Git; worker checkout cleanliness is a report statement, not independently inspected here.

| Supplied gate log | Observable result |
|---|---|
| `ui1b-red-fleet-hover-v2.log` | Intended missing image-tooltip triggers on rendered production list; **2 failed / 7 passed**, numeric process exit **1**. No import/setup error; all retained cases pass. This RED has only its preimplementation test hash and is not relabeled candidate-bound final evidence. |
| `ui1b-green-hover-second.log` | **1 file / 9 tests passed**, process exit **0**; intermediate four-file hashes differ from final candidate and are treated as historical GREEN only. |
| `ui1b-focused-after-guard.log` | Candidate-bound final **2 files / 15 tests passed** (page 9, shared Tooltip 6), process exit **0**. |
| `ui1b-typecheck-final.log` | Explicit `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false`, process exit **0**. Candidate spec config includes frontend specs and references app config. |
| `ui1b-lint-final.log` | **110 warnings / 0 errors**, independently counted; no changed-file diagnostic sections; Nx success and process exit **0**. |
| `ui1b-frontend-test-final.log` | **93 files / 666 tests passed**, all totals passed/no skipped totals. Independently summed 93 successful file rows to 666, including page 9 and Tooltip 6; Nx success and process exit **0**. |
| `ui1b-build-final.log` | Vite **1104 modules**, successful production build; CSS import-order and large-chunk warnings; Nx success and process exit **0**. |

The report’s earlier confounded RED/setup-failing first GREEN are not acceptance evidence and their unsupplied logs were not accessed. `git diff --check` is report-only; no direct log is supplied for that check.

Nx receipts/log headers explicitly carry `--skip-nx-cache`; types carry `--force`. This is supplied direct execution evidence, not reviewer execution or forensic provenance, and does not prove internal caches were cleared. The hash records establish byte matching and recorded unchanged gate inputs, not independent observation of the worker process.

## Reviewer actions and stop

Only read-only exact Git/source/hash/log checks and this NEW ignored report. A quoted-path lookup was corrected after a zsh wildcard produced no match; an entity filename inventory initially counted aliases and was resolved to the actual entity. Neither was gate execution. Large tool output was subsequently read in bounded fresh Git queries; private transcript/tool-result files were not accessed or exported.

Report target confirmed absent and ignored before creation. No tracked source/tracker/config/package/map/STU edits, gates/test/lint/types/build/DB rerun, install/external service/secrets access, agents/workflow/plan mode, branch switch, commit/merge/push or cleanup. Reviewer tracked worktree remains unchanged. **Spec PASS, zero findings. Stopped for coordinator serial integration.**

module.exports = {
  rootDir: '..',
  testEnvironment: 'node',
  transform: {
    '^.+\\.[tj]s$': ['ts-jest', { isolatedModules: true, tsconfig: { module: 'commonjs', moduleResolution: 'node10', experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true } }],
  },
  moduleNameMapper: { '^@swuniverse/shared$': '<rootDir>/packages/shared/src/index.ts', '^(\\.{1,2}/.*)\\.js$': '$1' },
  testMatch: ['<rootDir>/.workmux/independent-metadata.spec.ts'],
};

import { type DynamicModule } from '@nestjs/common';
import { MODULE_METADATA } from '@nestjs/common/constants';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModule, getRepositoryToken } from '@nestjs/typeorm';
import { Test } from '@nestjs/testing';
import { DataSource, type DataSourceOptions } from 'typeorm';
import { AppModule } from '../apps/backend/src/app.module';
import { SpacecraftService } from '../apps/backend/src/modules/spacecraft/spacecraft.service';
import { SpacecraftScanService } from '../apps/backend/src/modules/spacecraft/spacecraft-scan.service';
import { SpacecraftModule } from '../apps/backend/src/modules/spacecraft/spacecraft.module';
import { CargoItem } from '../apps/backend/src/modules/spacecraft/entities/cargo-item.entity';
import { Buoy } from '../apps/backend/src/modules/spacecraft/entities/buoy.entity';
import { Spacecraft } from '../apps/backend/src/modules/spacecraft/entities/spacecraft.entity';
import { SpacecraftWreck } from '../apps/backend/src/modules/spacecraft/entities/spacecraft-wreck.entity';
import { UserTutorialProgress } from '../apps/backend/src/modules/tutorial/entities/user-tutorial-progress.entity';
import { GameTickState } from '../apps/backend/src/modules/tick/entities/game-tick-state.entity';
import { User } from '../apps/backend/src/modules/auth/user.entity';
import { Message } from '../apps/backend/src/modules/messaging/entities/message.entity';

class MetadataSource extends DataSource {
  async metadataOnly() { await this.buildMetadatas(); }
}

it('checks all repaired repository slots against real root metadata and module registrations', async () => {
  const imports: DynamicModule[] = Reflect.getMetadata(MODULE_METADATA.IMPORTS, AppModule);
  const core = imports.find(m => m.module === TypeOrmModule)?.imports?.[0] as DynamicModule;
  const provider = core.providers?.find(p => typeof p === 'object' && 'provide' in p && p.provide === 'TypeOrmModuleOptions');
  if (!provider) throw new Error('Root options provider missing');
  const module = await Test.createTestingModule({ providers: [provider, { provide: ConfigService, useValue: { get: () => undefined } }] }).compile();
  try {
    const options = module.get<DataSourceOptions>('TypeOrmModuleOptions');
    expect(options.synchronize).toBe(false);
    const source = new MetadataSource(options);
    await source.metadataOnly();
    for (const entity of [Buoy, CargoItem, SpacecraftWreck, UserTutorialProgress, GameTickState, User, Message]) {
      expect(source.getRepository(entity).metadata.target).toBe(entity);
    }
    expect(source.getMetadata(CargoItem).findRelationWithPropertyPath('spacecraft')?.inverseEntityMetadata.target).toBe(Spacecraft);
    const featureImports: DynamicModule[] = Reflect.getMetadata(MODULE_METADATA.IMPORTS, SpacecraftModule);
    const registered = featureImports.flatMap(m => m.providers ?? []).filter(p => typeof p === 'object' && 'provide' in p).map(p => (p as { provide: unknown }).provide);
    for (const entity of [Buoy, CargoItem]) expect(registered).toContain(getRepositoryToken(entity));
    const serviceSlots: Array<{ index: number; param: unknown }> = Reflect.getMetadata('self:paramtypes', SpacecraftService);
    const scanSlots: Array<{ index: number; param: unknown }> = Reflect.getMetadata('self:paramtypes', SpacecraftScanService);
    expect(serviceSlots.filter(s => [getRepositoryToken(Buoy), getRepositoryToken(CargoItem)].includes(s.param as string))).toHaveLength(2);
    expect(scanSlots.filter(s => s.param === getRepositoryToken(Buoy))).toHaveLength(1);
    expect(source.isInitialized).toBe(false);
  } finally { await module.close(); }
});

# UI-1b correction — independent final Spec review

Date: 2026-11-10

**SPEC: PASS — zero verified findings. No source/evidence hold remains on this narrow Spec review.** Previous Spec PASS is preserved. Standards closure belongs to the other original reviewer; this report does not supply their verdict or authorize integration.

## Exact candidate pin and bounded scope

- Original fixed BASE: `699258b4f7f23cdd4cdc6675781677e9a8307b6b`.
- Previously accepted Spec candidate: `bab783d091693c6b75e75319c68ae69b17e1bbe3`, tree `7b88eead34342bc86c24f11f0009304f18302806`.
- Correction commit: `c5b1d3604b00d843c9750d72799394f650db4bf4`, tree `96f463a1dff43d207caf20755539e16e28736a50`.
- Subsequent metadata commits: `67fc06bc2ffebb4b6891b309a6cca31a5c38df39`, then final `88dfa9ca27685da165859d304880a7db557e4a77`.
- Final tree: `eaf5ee009a695b6260a0c2229d0128833fb46b39`.
- Reviewer HEAD remains `14b860813b988165f8470c0c9d3b31e087f70aa2`; exact Git blobs, not older checkout source, were reviewed.
- Narrow diff/log: `git diff bab783d091693c6b75e75319c68ae69b17e1bbe3...88dfa9ca27685da165859d304880a7db557e4a77`; `git log bab783d091693c6b75e75319c68ae69b17e1bbe3..88dfa9ca27685da165859d304880a7db557e4a77 --oneline` — **five paths / three commits**.
- Overall diff/log against BASE verified **seven paths / four commits**. BASE and original candidate are respective merge-bases; every follow-up direct-parent link and supplied tree identity was verified. The last two commits change only the issue. No backend runtime path is changed.

Relied on the original own-axis acceptance in `.workmux/ui1b-spec-review-20261110.md`; did not repeat the full feature review. New inputs are `.workmux/local-inputs/ui1b-correction-review/{report.md,manifest.json,gates/}`. Original reports/evidence remain historical, unchanged.

## Spec assessment — under 400 words

**No concrete missing, partial, unasked or incorrectly implemented requirement was verified in the correction.**

The original BASE issue requires “mit der gemeinsamen Tooltip-Komponente … ohne Ad-hoc-Hover-Panel” and “Hover (Desktop) bzw. Tap (Touch) … Waren mit Icon … und Menge, darunter Belegung/Kapazität”. The production list still uses the same shared Tooltip/table; formatting changes presentation, not cargo retrieval or occupancy calculation.

Current candidate issue additionally records “Cargo-Mengen und Belegung/Kapazität werden mit deutscher Tausendertrennung dargestellt” and a production test for “1.234” / “10.000”. `ShipStoragePanel.tsx:95,121` uses the existing `formatNumber` for each amount, summed used cargo and capacity. The unchanged real formatter (`lib/format.tsx:5–8`) uses `Intl.NumberFormat('de-DE')`. The new actual list-page test (`spacecraft.spec.tsx:110–139`) supplies amount 1234/capacity 10000, opens the real image tooltip, and observes the rendered cell and occupancy. It mocks API/assets, not formatting, list, Tooltip or cargo presentation.

The original “lazy … je Schiff gecacht; leeres Lager zeigt „Leer“” contract is preserved: cache/loading/retry/ship-tagged state and late-response protection are byte-identical to the previously accepted candidate. Shared Tooltip implementation/tests are also unchanged. Existing page tests still cover one lazy request, cached reopen, separate ships and first-touch empty cargo.

The canonical `SpacecraftListDto.cargoMax: number` now flows through list API typing, state, grouping and row props (`spacecraft.tsx:35–52,206–237`), without required/optional local intersections or a zero fallback. This coordinator-authorized shared field formalizes the existing backend list capacity previously verified at the production response seam; no new runtime backend behavior is assumed.

Current fresh supplied focused/full tests, compilation, lint and builds are green. Historical failures are not waived or relabeled. The two Standards findings’ formal closure remains the other reviewer’s axis.

## Source and receipt identity

Verified **17/17 manifest file hashes**: report plus eight log/JSON pairs. Every receipt’s raw log SHA-256 matches, before/after records are equal, and `source_unchanged:true` is recorded. All seven GREEN receipts contain numeric integer `process_exit:0`; formatting RED contains numeric integer `process_exit:1`.

All correction gates record **original candidate HEAD `bab783d...`**, not final HEAD. The seven GREEN receipts hash these four then-uncommitted correction files, each byte-matching final Git blobs:

| Final candidate path | SHA-256 |
|---|---|
| `packages/shared/src/lib/spacecraft/index.ts` | `2688e9f631378fd6f9a1331f8e3a4a4f4732fb9cb78a226736c39237b7a09099` |
| `apps/frontend/src/pages/spacecraft.tsx` | `a9405ad3affa740e9c5f62b4efcbe3469362b67ba82c3f6463595f2536605fbb` |
| `apps/frontend/src/components/spacecraft/ShipStoragePanel.tsx` | `bdb0678c9b3af07825b6b4daa0c2e326d3b7ebf71cc4d53eadb9c6d15ace6955` |
| `apps/frontend/src/pages/spacecraft.spec.tsx` | `181c7e7cbe55f6bf016dc2ae0f51ce8af9390661afb9e329dde72924f656b574` |

RED hashes only the added page test, which also matches final bytes; it does not hash the final formatting implementation and is not final-candidate execution evidence.

The two inherited Tooltip files are omitted from these correction receipts because they did not change against that checkpoint. Independently verified final/original byte equality and previously accepted hashes:

- `Tooltip.tsx`: `055235398092bc65b20e1b1ceced4c15599888e4bfca138dcab3cec311180a0e`.
- `Tooltip.spec.tsx`: `2fe98b9a9c2eb78252ceee2313035a82def73b364141f603f1792c39570f622f`.

Actual backend list controller/service/entity and real format helper are byte-identical to the original reviewed candidate. Cache/state/request logic and the older eager detail component were explicitly compared as unchanged; no unrelated formatting migration was required.

The final issue was read from Git: status `resolved`, checklist checked, added German-formatting criteria, appended correction history and independent re-review still pending. All original candidate comment bytes remain an unchanged prefix. Final issue SHA-256: `2dd7e7e0d694126d1236fbb0e35e0ac7c2498f26d207ecd56548fa42e84a9e3f`. Later tracker-only commits are metadata, not execution. Worker checkout cleanliness is a report observation; only this reviewer’s checkout state was checked directly.

## Supplied direct execution observations

| Evidence | Observed result |
|---|---|
| `ui1b-correction-format-red.log` | **1 failed / 9 passed** in real spacecraft page suite; fails finding rendered cell `1.234` at :138, after opening the production tooltip; process exit **1**. No setup/import failure. The subsequent occupancy assertion is present but not reached in RED, so this is not two separately observed failed assertions. |
| `ui1b-correction-format-green.log` | **2 files / 16 tests passed**: spacecraft page 10 and shared Tooltip 6; process exit **0**. The new formatting test retains both cell and `Lagerraum 1.234/10.000` assertions. Existing lazy/cache/touch tests remain. |
| `ui1b-correction-shared-build.log` | Shared declaration build succeeds; process exit **0**. Ordinary `tsc --build` incremental caveat retained. |
| `ui1b-correction-frontend-spec-types.log` | Explicit `tsc --build apps/frontend/tsconfig.spec.json --force --pretty false`; no diagnostics, process exit **0**. |
| `ui1b-correction-backend-spec-types.log` | Explicit `tsc --build apps/backend/tsconfig.spec.json --force --pretty false`; no diagnostics, process exit **0**. Consumer/compiler coverage, **not backend runtime suite evidence**. |
| `ui1b-correction-frontend-lint.log` | **110 warnings / 0 errors**, diagnostic count reconciled; Nx success/process exit **0**. |
| `ui1b-correction-frontend-full-test.log` | **93 files / 667 tests passed**, all totals passed/no skipped totals; independently summed 93 successful file rows to 667, including page 10 and Tooltip 6; Nx success/process exit **0**. |
| `ui1b-correction-frontend-build.log` | Shared dependency and production Vite build succeed (**1104 modules**); CSS import-order and large-chunk warnings retained; Nx success/process exit **0**. |

Public RED uses the same final test bytes and genuinely missing formatted cell, not a private-helper or synthetic-DOM proof. Its raw log truncates the DOM dump; no claim is made that it independently shows both unformatted numeric values. GREEN validates both production formatting outputs. Original failed/setup runs stay historical; no correction gate erases them.

Raw manifest-linked logs/receipts establish supplied evidence consistency and recorded byte identity. They are not reviewer execution or forensic process provenance. Nx logs carry `--skip-nx-cache`; forced compiler logs carry `--force`; neither is represented as proof that all internal caches were cleared. Report-only `git diff --check` was not promoted to direct execution evidence. No backend runtime/PG gate was supplied or claimed.

## Reviewer boundaries and stop

Only exact read-only Git/source/hash/log checks plus this NEW ignored report. Target was absent and ignored before creation. No source/tracker/config/package/map/STU edits, gates/tests/lint/types/build/DB execution, install, environment/secret inspection, external services, private transcript/tool-result access or export, nested agents/workflows/plan mode, branch switch, commit/merge/push or cleanup.

No K5b/combined-candidate/main assumptions. No Standards duplication, full old-feature re-audit, or integration. Reviewer tracked tree remains unchanged. **Final UI-1b Spec PASS, zero findings; no narrow Spec source/evidence hold. Stopped for coordinator serial integration after independent axes.**

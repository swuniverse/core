# Independent docs-only tracker review — 2026-11-09

## Disposition

**Docs integration: PASS** for `c8e14f1c5282a30e77b25020ee9a27a70aba249e` → `c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab`. No verified blocker to integrating this reconciliation. This is not approval to implement or independently deploy every graph-unblocked ticket.

**NEXT feature:** the proposed K7a1 chain needs its intermediate exposure/integration boundary settled before implementation. Its resource policy does not need a new product decision. T11b has a separate, pre-existing phased-scope contradiction that must be resolved before that ticket is selected. Neither requires blocking these docs or inventing product semantics.

Scope independently confirmed: exactly 60 `.scratch/stu-parity/issues/*.md` paths, 550 insertions / 98 deletions, no unauthorized paths or whitespace errors. The isolated worktree remains clean at `14b860813b988165f8470c0c9d3b31e087f70aa2`; neither reviewed docs ref was checked out. No source reads, suites, dependency installation, architectural exploration, nested agents, tracked edits, commits, merge, main-checkout access, push or external service in this phase. Only ignored review artifacts were written.

## Verified observations and execution limits

Line references below are exact **candidate issue** lines, not diff/extract line numbers. Paths share `.scratch/stu-parity/issues/`.

1. **P2, NEXT K7a1 staging only — intermediate public passage safety is unspecified.** `tmw-K7a1-wurmloch-backend-kern.md:10,27,40` assigns an authenticated endpoint to the first child while explicitly deferring atomic fleet/arrival integration to K7a2. `tmw-K7a-wurmloch-betreten-und-verlassen.md:37` requires fleet validation, arrival pipeline, discovery, knowledge, signatures/log and repair cancellation in the same successful operation. Concrete risk: implementing and exposing a successful relocating endpoint after K7a1 alone permits passage before the required arrival/fleet contract exists. The split itself is confirmed; it does not specify independently deployable intermediate behavior. Coordinator/maintainer input is needed on the safe delivery/exposure boundary, not on a new resource rule. No incomplete movement implementation was inspected or alleged. **Not a docs-integration blocker.**

2. **P2, future T11b execution only — optional extensions conflict with mandatory auction/lottery acceptance.** `tmw-T11b-kontoloeschung-raeumt-handel-ab.md:25` explicitly permits later T6/T8b/T9 handler extensions, but `:26` requires highest-bid reassignment and `:28` requires deleting a player with bids and lottery tickets. Its formal prerequisites at `:6` are only T4b and sh-AP-05a. Concrete execution risk: selecting it once those prerequisites resolve either requires out-of-scope auction/lottery work or leaves mandatory acceptance unmet. This issue is byte-for-byte unchanged by the candidate. `tmw-T12c-postenzerstoerung-und-aufgabe.md:6,21,31` correctly names T11b for the actual TradeDeletionHandler rather than pretending the orchestrator provides it. A scope/prerequisite decision is needed before T11b execution; the later-extension sentence alone does not waive its other criteria. **Not a new formal missing-ID defect or docs-integration blocker.**

3. **P3, inherited K7a2 acceptance detail — arrival knowledge is mandatory and repair cancellation remains required.** `tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md:29` uses conditional K5c wording and `:27–32` does not explicitly enumerate repair cancellation. Its own decision at `:36` requires knowledge, K5c is resolved (`tmw-K5c-ebenenkenntnis-bekanntwerden.md:3,28–29`), and the authoritative parent at `tmw-K7a-wurmloch-betreten-und-verlassen.md:37` expressly requires knowledge and repair cancellation in the successful operation. A child-only reading could omit these effects. They must remain in implementation/acceptance; **no new product decision is needed** and no waiver is created by the split. Not a docs-integration blocker.

4. **P3, D5 child allocation detail — award names/images and documentation remain inherited scope.** `tmw-D5a-datenbank-award-konfiguration-und-completion.md:27–32` allocates productive mappings but does not explicitly allocate the former parent's award-name/image and missing-asset acceptance checkbox. `tmw-D5-award-bei-vollstaendiger-kategorie.md:10` retains the agent's Star-Wars name/image selection and `map.md` documentation duty; the pre-split acceptance required asset convention or missing-asset documentation. An implementation using only the child could omit that documentation. Assigning this work to the configuration delivery is scope bookkeeping, **not a request for a new product choice or permission to invent authoritative data**. No map/assets were selected or edited in this review. Not a docs-integration blocker.

**K7a resource wording is already settled:** K7a1 `:28` broadly describes functional drive/activation, but `:29,36` and parent K7a `:37` distinguish entry from exit. Entry may charge each ship's own normal activation EPS if its drive is inactive; passage charges no flight EPS or Warpdrive, and exit requires no activation/resource charge. Do not turn the broad wording into exit EPS or reopen the recorded resource decision. This review does not invent additional exit validation semantics.

## Status, import and evidence fidelity

- All 20 reported imported decision/split issue IDs exist in the candidate: col-C3, col-D2b, col-D3b, COMBAT-1a/1c, RES-1, K1b2, D5/K10a/K7a and ten new children. Their actual diff/content preserves the confirmed decisions. The three newly resolved parents explicitly say **tracking split**, retain unchecked child boxes, and leave implementation to children. No feature completion is claimed for them.
- Original import `manifest.json`/patch/child snapshots are **not supplied in this review-input directory**, which contains only report.md. Thus the coordinator's pre-reconciliation 20/20 SHA-256 check is reported evidence, not an independently reproduced byte-hash check. Presence and candidate decision/split fidelity were independently checked.
- col-C3 records integrated 7e7143d8 and bounded PanelDefense evidence; col-D2b records the maintainer's wontfix decision, not implementation of the abandoned discovery hook. COMBAT-1a/1c keep the confirmed System/Galaxy-only scope and defer the other movement paths. RES-1 records confirmed public seams. K1b2 retains required authoritative field-data verification and explicitly says the baseline proves no product data (`:44,49–50`).
- All **30 technical retry transitions** have dated 2026-11-09 baseline/retry notes, require fresh issue tests/current gates and reject completion or exemptions. Independent comparison of each issue's entire pre-Comments body, excluding the four headers, found **zero scope changes**. All 30 retain their full specification. Actual diff inspection compares the latest documented blockers, including UI-1b's later tutorial/repository failures and T6's 2026-11-02 backend failures; no later distinct prerequisite blocker was overwritten.
- Exactly two needs-info issues remain: sh-AP-05d and T12a. sh-AP-05d `:6,28,38–39` now formally requires unfinished 05c and preserves ship-before-colony ordering. T12a `:6,28,33` preserves the unfinished purchase/deposit/offer chain and remains blocked, not completed by baseline evidence.
- Of eight original needs-triage issues, only NAV-3b becomes ready. Its origin/current-valid-location migration is already explicit at `:35`; the dated note at `:41` does not teleport ships to destination or introduce a new decision. SPEC-1 through SPEC-6 and sh-AP-22 remain triage. SPEC-6 does not invent commodities/quantities; sh-AP-22 does not claim exhaustive flake elimination.
- soc-F3d, soc-H1 and soc-I1c remain ready-for-agent, **not resolved**, and are excluded from next-feature selection.
- col-D3b `col-D3b-forschungsbaum-kantentypen.md:30` accurately attributes integration to c8e14f1c with b46988ff/67e8d36e/typed adapter, fresh reported frontend focus 15/15, independent backend 211 suites / 1981 tests without skips, Research service 28/28, and reported full frontend 92 files / 655 tests with shared-build cache reuse. This matches supplied report.md's root-normal/no-cache backend account. It expressly bounds cached gates, mocked ReactFlow/ELK/geometry/marker URLs, no real-browser arrowhead/layout evidence, no research-specific PostgreSQL test, and no rerun of baseline 36/290 integration. **These later test results were consistency-reviewed as supplied evidence, not independently executed or log-reproduced in this docs phase.** No fresh DB/browser/uncached-full-frontend claim was found.

## Independent header/dependency results

Local Git-object parser read only the issue Markdown trees at the two supplied refs. It validated unique IDs; exactly one required Status/Priority/Size/Blocked by header each; allowed values; all formal dependency IDs; and DFS acyclicity.

| Check | Independent result |
|---|---|
| Candidate issues | 276 |
| Resolved / ready / wontfix / triage / info | 185 / 79 / 3 / 7 / 2 |
| Claimed / ready-for-human | 0 / 0 |
| New / deleted issue IDs | 10 / 0 |
| Candidate header errors / missing formal dependencies / cycles | 0 / 0 / 0 |
| Ready dependency-blocked | 41 |
| Ready dependency-unblocked, excluded F3d/H1/I1c | 3 |
| Ready dependency-unblocked after exclusions | 35 (15 P2, 20 P3), exact list matches supplied report |
| Thirty retry scope changes / defective retry notes | 0 / 0 |
| Open formal dependencies on resolved split parents | 0 |

The split-parent check included every resolved issue with unchecked acceptance boxes, not only a keyword heuristic; soc-G1b's optional unchecked revoke is not a split prerequisite. Historical issue-shaped prose/family shorthand is not interpreted as a formal dependency or newly invented issue. No speculative missing-ID finding is raised from it. Frontier is **graph eligibility**, not proof that every child is execution-ready, implemented, or tested.

Trade/deletion replacements match the actual candidate child contracts:

- T3 → T2d: its `:29` requires the license-purchase menu; T2d supplies it and transitively requires purchase T2b, validity T2c, model/presence T2a, plus existing prerequisites.
- T6 → T2c: network read/write entitlement requires the explicit expiry/validity contract, with purchase/model transitively retained.
- T13 → T2b plus existing T7a: free-license benefit extends actual transactional purchase; no arbitrary new UI prerequisite introduced.
- T12a → T4a plus existing station prerequisites: T4a → T3 → T2d → T2b/T2c → T2a covers its explicit license/deposit/offer end-to-end test. Status remains info.
- T12c → T12a and T11b: actual named TradeDeletionHandler; sh-AP-05a remains transitive. The separate T11b scope contradiction is preserved, not silently solved.
- 05d adds actual ship deletion child 05c and preserves existing 05a/col-E2.
- K7b → K7a1 plus station UI prerequisite: actual access-policy contract. K10b/K10c → K10a3: actual scan/context contract, with lifecycle/effect chain retained. No resolved-parent shortcut.

## Commands and artifacts

All completed shell commands in this docs phase exited **0**; no test command was run. Exact Git refs are expanded above.

```sh
git status --short
git rev-parse c8e14f1c c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab HEAD
git diff --stat c8e14f1c c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab
git diff --name-only c8e14f1c c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab
git diff --check c8e14f1c c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab
git diff c8e14f1c c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab -- .scratch/stu-parity/issues
python3 -I .workmux/tracker-independent-check.py
python3 -I .workmux/tracker-independent-check.py > .workmux/tracker-independent-check.log
ls -la .workmux/tracker-review-inputs
git check-ignore .workmux/tracker-independent-check.py .workmux/tracker-independent-check.json .workmux/tracker-independent-doc-extract.txt .workmux/tracker-independent-review-20261109.md
git diff --check c8e14f1c5282a30e77b25020ee9a27a70aba249e c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab
git rev-parse HEAD
```

The retained parser script records the exact per-ref `git ls-tree -r --name-only <ref> -- .scratch/stu-parity/issues/` and `git show <ref>:<issue-path>` calls. Its JSON/log captures counts, status/header transitions, graph/frontier, scope comparison, all 20 IDs and split check candidates. A final inline `python3 -I` Git-object cross-check expanded the split check to all resolved unchecked parents and confirmed no open dependencies; its final `git status --porcelain=v1 -z` returned the empty string. Numbered selected candidate excerpts are saved in `.workmux/tracker-independent-doc-extract.txt`. Complete actual diff was read; no source lookup followed its listed paths.

Supplied report read: `.workmux/tracker-review-inputs/report.md`. This review does not repeat the completed baseline audit or claim the earlier baseline's executions as new tracker validation.

**No changes or integration performed. Stopped for coordinator.**

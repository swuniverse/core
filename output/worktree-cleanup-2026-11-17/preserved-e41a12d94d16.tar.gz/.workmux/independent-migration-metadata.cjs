const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const ts = fs.readFileSync('apps/backend/src/database/typeorm-migration.config.ts', 'utf8');
const mts = fs.readFileSync('apps/backend/src/database/typeorm-migration.config.mts', 'utf8').replace(/(from\s+["']\.{1,2}\/[^"']+)\.js(["'])/g, '$1$2');
assert.equal(mts, ts);
const ds = require(path.resolve('apps/backend/src/database/typeorm-migration.config.ts')).default;
ds.buildMetadatas().then(() => {
  const groups = new Map();
  for (const metadata of ds.entityMetadatas) {
    const list = groups.get(metadata.tablePath) ?? [];
    list.push(metadata);
    groups.set(metadata.tablePath, list);
  }
  const duplicates = [...groups].filter(([, list]) => list.length > 1).map(([table, list]) => ({ table, mappings: list.length }));
  const users = groups.get('users');
  assert.equal(users.length, 2);
  const sets = users.map(metadata => new Set(metadata.columns.map(column => column.databaseName)));
  const differences = sets.map((set, index) => [...set].filter(column => !sets[1 - index].has(column)));
  console.log(JSON.stringify({ sourceParity: true, synchronize: ds.options.synchronize, initialized: ds.isInitialized, metadataCount: ds.entityMetadatas.length, duplicateTables: duplicates, userColumnDifferences: differences }));
}).catch(error => { console.error(error); process.exitCode = 1; });

import collections
import json
import re
import subprocess
from pathlib import Path

BASE = 'c8e14f1c5282a30e77b25020ee9a27a70aba249e'
CANDIDATE = 'c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab'
ROOT = '.scratch/stu-parity/issues/'
ID = re.compile(r'^(col-[A-Z]\d+[a-z]?\d*|soc-[A-Z]\d+[a-z]?\d*|tmw-[A-Z]+\d+[a-z]?\d*|sh-AP-\d+[a-z]?\d*|sc-WP-[A-Z]+-\d+[a-z]?\d*)(?:-|\.md)')
FIELDS = ('Status', 'Priority', 'Size', 'Blocked by')
ALLOWED = {'Status': {'needs-triage', 'needs-info', 'ready-for-agent', 'claimed', 'ready-for-human', 'resolved', 'wontfix'}, 'Priority': {'P0', 'P1', 'P2', 'P3'}, 'Size': {'S', 'M', 'L'}}

def git(*args):
    return subprocess.check_output(['git', *args]).decode()

def snapshot(ref):
    issues = {}
    errors = []
    for path in git('ls-tree', '-r', '--name-only', ref, '--', ROOT).splitlines():
        if not path.endswith('.md'):
            errors.append(['non-markdown', path])
            continue
        match = ID.match(Path(path).name)
        if not match:
            errors.append(['unparsed-id', path])
            continue
        key = match.group(1)
        text = git('show', ref + ':' + path)
        headers = {}
        lines = {}
        for field in FIELDS:
            matches = [(i, re.fullmatch(r'\*\*' + re.escape(field) + r':\*\*\s*(.*)', line)) for i, line in enumerate(text.splitlines(), 1)]
            values = [(i, m.group(1)) for i, m in matches if m]
            if len(values) != 1:
                errors.append(['header-count', path, field, len(values)])
                continue
            line, value = values[0]
            headers[field] = value
            lines[field] = line
            if field in ALLOWED and value not in ALLOWED[field]:
                errors.append(['invalid-value', path, field, value])
        deps = [d.strip().strip('`') for d in headers.get('Blocked by', '').split(',') if d.strip() not in {'', '—'}]
        if key in issues:
            errors.append(['duplicate-id', key])
        issues[key] = {'path': path, 'headers': headers, 'header_lines': lines, 'deps': deps, 'text': text}
    return issues, errors

base, base_errors = snapshot(BASE)
candidate, errors = snapshot(CANDIDATE)
missing = [(key, dep) for key, issue in candidate.items() for dep in issue['deps'] if dep not in candidate]
cycles = []
visited = set()
active = []
def visit(key):
    if key in active:
        cycles.append(active[active.index(key):] + [key])
        return
    if key in visited:
        return
    active.append(key)
    for dep in candidate[key]['deps']:
        if dep in candidate:
            visit(dep)
    active.pop()
    visited.add(key)
for key in candidate:
    visit(key)

changed = git('diff', '--name-only', BASE, CANDIDATE).splitlines()
transitions = {key: {'before': base[key]['headers'], 'after': issue['headers']} for key, issue in candidate.items() if key in base and issue['headers'] != base[key]['headers']}
ready = {key: issue for key, issue in candidate.items() if issue['headers'].get('Status') == 'ready-for-agent'}
excluded = {'soc-F3d', 'soc-H1', 'soc-I1c'}
blocked = {key: [dep for dep in issue['deps'] if candidate.get(dep, {}).get('headers', {}).get('Status') not in {'resolved', 'wontfix'}] for key, issue in ready.items()}
frontier = sorted((key for key in ready if not blocked[key] and key not in excluded), key=lambda key: (ready[key]['headers']['Priority'], key))
retries = [key for key in transitions if base[key]['headers'].get('Status') == 'needs-info' and ready.get(key) and 'Die integrierte Baseline 14b86081/c8e14f1c' in candidate[key]['text']]
splits = [key for key, issue in candidate.items() if issue['headers'].get('Status') == 'resolved' and re.search(r'Tracking-Split|Child-Issues|Teilissues|Child-Tickets|aufgeteilt|aufgespalten', issue['text'], re.I)]
summary = {
    'base': BASE, 'candidate': CANDIDATE, 'head': git('rev-parse', 'HEAD').strip(),
    'changed_count': len(changed), 'unauthorized_paths': [p for p in changed if not p.startswith(ROOT) or not p.endswith('.md')],
    'total': len(candidate), 'statuses': dict(collections.Counter(i['headers'].get('Status') for i in candidate.values())),
    'priorities': sorted({i['headers'].get('Priority') for i in candidate.values()}), 'sizes': sorted({i['headers'].get('Size') for i in candidate.values()}),
    'base_header_errors': base_errors, 'candidate_header_errors': errors, 'missing_dependencies': missing, 'cycles': cycles,
    'new_ids': sorted(set(candidate) - set(base)), 'deleted_ids': sorted(set(base) - set(candidate)), 'transitions': transitions,
    'needs_info': [key for key, i in candidate.items() if i['headers'].get('Status') == 'needs-info'],
    'triage_before': [key for key, i in base.items() if i['headers'].get('Status') == 'needs-triage'],
    'triage_after': [key for key, i in candidate.items() if i['headers'].get('Status') == 'needs-triage'],
    'excluded_statuses': {key: candidate[key]['headers']['Status'] for key in sorted(excluded)},
    'ready_total': len(ready), 'ready_blocked': sum(bool(v) for v in blocked.values()), 'excluded_unblocked': sorted(key for key in excluded if key in ready and not blocked[key]),
    'frontier_count': len(frontier), 'frontier': frontier, 'retry_note_count': len(retries), 'retry_note_ids': retries,
    'resolved_split_candidates': splits,
    'open_dependencies_on_split_candidates': [(key, dep) for key, i in candidate.items() if i['headers'].get('Status') not in {'resolved', 'wontfix'} for dep in i['deps'] if dep in splits],
}
scope_changes = []
retry_note_errors = []
for key in retries:
    def scope(text):
        before_comments = text.split('## Comments', 1)[0]
        return '\n'.join(line for line in before_comments.splitlines() if not any(line.startswith('**' + field + ':**') for field in FIELDS)).strip()
    if scope(base[key]['text']) != scope(candidate[key]['text']):
        scope_changes.append(key)
    note = next((line for line in candidate[key]['text'].splitlines() if 'Die integrierte Baseline 14b86081/c8e14f1c' in line), '')
    if not all(term in note for term in ['2026-11-09', 'laut Baseline-Review', 'keine Feature-Fertigstellung', 'aktuellen Issue-Tests', 'keine Ausnahme']):
        retry_note_errors.append(key)
summary['retry_scope_changes'] = scope_changes
summary['retry_note_errors'] = retry_note_errors
summary['resolved_with_unchecked_boxes'] = {key: [line for line in issue['text'].splitlines() if re.match(r'- \[ \]', line)] for key, issue in candidate.items() if issue['headers'].get('Status') == 'resolved' and re.search(r'^- \[ \]', issue['text'], re.M)}
summary['unchanged_T11b'] = base['tmw-T11b']['text'] == candidate['tmw-T11b']['text']
summary['imported_20_ids_present'] = sorted(key for key in ['col-C3', 'col-D2b', 'col-D3b', 'sc-WP-COMBAT-1a', 'sc-WP-COMBAT-1c', 'sc-WP-RES-1', 'tmw-K1b2', 'tmw-D5', 'tmw-K10a', 'tmw-K7a', *summary['new_ids']] if key in candidate)
Path('.workmux/tracker-independent-check.json').write_text(json.dumps(summary, indent=2) + '\n')
selected = ['col-C3', 'col-D2b', 'col-D3b', 'sc-WP-COMBAT-1a', 'sc-WP-COMBAT-1c', 'sc-WP-RES-1', 'tmw-K1b2', 'tmw-D5a', 'tmw-K10b', 'tmw-K10c', 'tmw-K7a', 'tmw-K7a1', 'tmw-K7a2', 'tmw-K7a3', 'tmw-K7b', 'tmw-K5c', 'tmw-D5', 'tmw-T2', 'tmw-T2a', 'tmw-T2b', 'tmw-T2c', 'tmw-T2d', 'tmw-T3', 'tmw-T6', 'tmw-T4a', 'tmw-T7a', 'tmw-T11a', 'tmw-T11b', 'tmw-T12a', 'tmw-T12c', 'tmw-T13', 'sh-AP-05a', 'sh-AP-05c', 'sh-AP-05d', 'sc-WP-NAV-3b']
with Path('.workmux/tracker-independent-doc-extract.txt').open('w') as out:
    for key in selected:
        issue = candidate.get(key)
        if issue:
            out.write('\n=== ' + key + ' ' + issue['path'] + ' @ ' + CANDIDATE + ' ===\n')
            for i, line in enumerate(issue['text'].splitlines(), 1):
                out.write(str(i) + '\t' + line + '\n')
        else:
            out.write('\nMISSING SELECTED ID: ' + key + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'transitions'}, indent=2))
print('HEADER TRANSITIONS')
for key, value in transitions.items():
    print(key + ': ' + json.dumps({f: [value['before'].get(f), value['after'].get(f)] for f in FIELDS if value['before'].get(f) != value['after'].get(f)}))
assert len(changed) == 60 and not summary['unauthorized_paths']
assert not errors and not missing and not cycles
assert len(candidate) == 276

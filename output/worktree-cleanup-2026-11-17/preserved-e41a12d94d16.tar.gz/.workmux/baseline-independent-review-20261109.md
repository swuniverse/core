# Independent final baseline review — 2026-11-09

## Disposition

**Integration: PASS for the authorized baseline repair range only.** No verified blocking correctness defect in the eight commits / 43 authorized paths. This is review approval, not an integration action and not authorization for migration generation or synchronization.

- Base: `7e7143d80d155b312dca1ad0d6a5304c38d54571`
- Candidate: `14b860813b988165f8470c0c9d3b31e087f70aa2`
- Comparison: `git diff 7e7143d8...HEAD`; base is an ancestor and comparison covers the requested range.
- Eight commits, 43 paths, 556 insertions / 52 deletions. All 43 actual file SHA-256 values match the supplied final-candidate-integrity.json. Exact nx.json delta is only cli.packageManager=npm.
- Model: gpt-6.1-sol. Normal permissions; npm/npx package execution only. No CodeGraph index exists; no indexing performed.
- Tracked worktree/index remain clean; HEAD unchanged. Only ignored review artifacts were written. No repairs, tracker/map/package/lockfile/nx.json/STU edits, commits, merge, push, fetch, publication, external services, other-checkout reads, or shared database access.

## Verified findings, ranked

No P0/P1/P2 integration blockers verified. Two P3 source-quality observations, not correctness blockers:

1. **P3 — misleading DI regression title.** `apps/backend/src/modules/tutorial/tutorial.service.spec.ts:31` says “optional definitions omitted”, but `:40` explicitly supplies TUTORIAL_DEFINITIONS_TOKEN. Concrete misleading scenario: a maintainer treats this green test as proof that Nest can omit the token; the test does not exercise that case and the production constructor requires the token. Similar “default” titles in field-effect, boarding and wreck-decay tests also supply explicit dependencies. Actual application registrations are present; no missing production token was demonstrated. This is a naming/coverage-description issue, not a requested behavior change.
2. **P3 — duplicated production random defaults.** `apps/backend/src/modules/spacecraft/spacecraft.module.ts:201` duplicates the boarding constructor algorithm at `spacecraft-boarding.service.ts:34`; `apps/backend/src/modules/tick/tick.module.ts:76` duplicates `wreck-decay.service.ts:9`. Concrete maintenance scenario: changing one formula but not its copy makes Nest-created instances and direct construction use different distributions. Current formulas are identical, preserving inclusive boarding min/max and wreck damage 5–15. No current wrong output was found. Optional consolidation is outside this review-only task.

## Standards

Independent Standards axis: **0 documented-standard violations; 2 low-severity heuristic observations** above (possible Mysterious Name and Duplicated Code). The repo's explicit root entity registration, Nest conventions, migration-only schema policy and relevant domain vocabulary/ADRs are respected. No tooling-enforced matters counted as manual findings.

Guidance read: AGENTS.md, CONTRIBUTING.md, CONTEXT.md, docs/agents/domain.md, issue-tracker.md, triage-labels.md, docs/typeorm-migrations.md, integration README, and relevant ADRs 0002–0007. No originating issue references occur in the eight commit messages; the user's explicit scoped requirements and ledger authorization sections are the specification for this baseline repair.

## Spec

Independent Spec axis: **0 verified in-scope defects or scope creep** in tutorial/NPC/frontend fixtures/research behavior. All existing assertions/scenarios remain; typed defaults and `satisfies` fixtures do not weaken expectations. The research assertion now awaits the accessible downstream button while retaining the “(eine von)” requirement. NPC persisted username fits varchar(32), with the display name retained.

## Correctness and call-path assessment

### Datasource relation identity

Actual `.ts` metadata builds successfully both with the recorded compiler override and with TS_NODE_COMPILER_OPTIONS unset under the documented TS_NODE_PROJECT. The permanent regression verifies class identity, not merely class/table names: LayerKnowledge.user, News.author and ProfileVisit visitor/profileUser target AppUser; MigrationAccountToken.user targets MigrationUser. AppUser's faction relation needs the application FactionEntity and its modifier relation, explaining the three additional application classes. Entity enum/default literals match the current shared values and remove the CommonJS CLI's runtime ESM import at these entity boundaries.

Independent no-connection inspection built **28 metadata entries** and confirmed source parity after normalizing relative ESM `.js` imports. It also confirmed **two mappings each for users, factions and faction_modifiers**. MigrationUser lacks `permissions` and `vacationRequestedAt`, which AppUser contains. Neither mapping is excluded from entity-level schema synchronization. TypeORM's installed RdbmsSchemaBuilder filters entity metadata without deduplicating table paths and drops columns missing from each mapping before adding new columns. Therefore these mappings are not a safe schema-generation model: generation can propose dropping/recreating application-only columns (potentially losing data if applied). No schema SQL was generated, no synchronization run, and no database touched by this inspection. This is a confirmed metadata inconsistency and a retained **generation/synchronization exclusion**, not a demonstrated failure of authorized migration replay.

### Historical ownership

Reviewed PrepareUserCharacters up/down, characterMigrationId's schema-qualified configured history table, original epoch owner up/down and actual TypeORM discovery/order tests. The bridge adopts only an explicitly recorded epoch or previous-calendar owner and requires its table; an untracked table is still rejected. Bridge rollback preserves the previous owner; the late epoch migration remains a no-op owner when its history id follows the bridge. Fresh chain, previous-calendar rows, original epoch rollback ownership and untracked/missing-table refusal all passed the real PostgreSQL regression (**6 tests**). The deliberately logged negative-path migration errors are expected assertions, not hidden failures.

Rollback beyond newly applied migrations into the absent previous-calendar implementation is not supported/proven. Adoption checks table presence, not arbitrary historical schema equivalence. No forward data loss or new rollback defect was verified within the requested compatibility seam.

### Nest/module/repository graph

Reviewed changed modules/providers and consumers: Alliance→Colony import deferral, Messaging→Websocket→GameGateway/JwtService visibility, TickAdmin→TickService, tutorial definitions token, field random/clock, boarding random, wreck random, and SpacecraftService/SpacecraftScanService Buoy/Cargo repository slots. Defaults remain callable for existing direct-construction behavior; concrete tokens are provided in the owning modules.

The enduring root test obtains the actual nested TypeORM options factory and builds real metadata without connecting. Buoy is explicitly registered beside CargoItem. Supplied permanent RED log confirms the old root failed with EntityMetadataNotFoundError; current permanent test passed independently. A further ignored focused probe verified actual root repository metadata for Buoy, CargoItem, SpacecraftWreck, UserTutorialProgress, GameTickState, User and Message; CargoItem's Spacecraft target; SpacecraftModule's Buoy/Cargo repository providers; and the actual repaired injection tokens. **1/1 passed.** No analogous newly impacted missing metadata/provider defect was verified. Existing unrelated entities/runtime concerns were not expanded into a whole-repo cleanup.

Scanner/static tests do not prove full provider instantiation or a complete application boot. A green metadata boundary also does not prove all HTTP/transaction/runtime paths.

### Tutorial and fixtures

Navigation-required response shape is checked before findIndex: steps must be an array of suitable entries, IDs/navigation ID must have the needed types. The response regression is act-flushed and independently passed with no unhandled error. This is not full TutorialViewDto or renderer validation. Typed fixture repairs preserve test scenarios and assertions; no compiler exclusions, unknown casts or product changes were used for frontend fixture repairs. Research await fixes the downstream render race, not an exhaustive flake guarantee.

## Independently executed validation

For test/type/lint commands below the session supplied:

```sh
export npm_config_offline=true NX_DAEMON=false NX_INTERACTIVE=false NX_NO_CLOUD=true
```

Every completed gate's actual shell exit was observed. No exhaustive full unit or integration suite was independently rerun.

| Command | Exit | Count / result | Local log |
|---|---:|---|---|
| `npm ci --offline --no-audit --no-fund` | 0 | 1829 packages; local cache; existing deprecation/install-script-policy warnings | harness task b388x3w27 output |
| Backend focused command below | 0 | 13 suites / 69 tests, zero skipped | independent-backend-focused.log |
| Character PostgreSQL command below | 0 | 1 suite / 6 tests, zero skipped; harness-created PostgreSQL 16 and UUID schemas | independent-character-postgres.log |
| Frontend focused command below | 0 | 8 files / 64 tests, zero skipped | independent-frontend-focused.log |
| `npx --no-install tsc --build apps/backend/tsconfig.json --emitDeclarationOnly --force` | 0 | Forced spec-inclusive project-reference type build; no diagnostics | independent-backend-spec-types.log |
| `npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly --force` | 0 | Forced spec-inclusive project-reference type build; no diagnostics | independent-frontend-spec-types.log |
| `npx --no-install nx run-many --target=lint --projects=shared,frontend,backend --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static` | 0 | 3 projects; 1423 backend + 108 frontend = 1531 warnings, 0 errors; no graph-unavailable warnings | independent-nx-lint.log |
| Metadata probe command below | 0 | 1 suite / 1 test, no connection | independent-metadata.log |
| Migration inspection command below | 0 | source parity; 28 metadata entries; 3 duplicate tables; synchronize=false; initialized=false | independent-migration-metadata.log |
| Same inspection with TS_NODE_COMPILER_OPTIONS explicitly unset | 0 | Documented CLI compiler environment loads metadata too | independent-migration-no-override.log |
| `git diff --check 7e7143d8...HEAD` | 0 | No whitespace errors | tool output |
| Final `git status --short`, `git diff --name-only`, `git diff --cached --name-only`, `git rev-parse HEAD` | 0 | Empty tracked/index diffs; pinned candidate HEAD | tool output |
| SHA-256 manifest verification via `npm exec --offline -- node -e ...` | 0 | 43 paths / 43 entries / 0 mismatches, verified twice | tool output |

Exact successful focused commands (output redirected to the corresponding ignored logs):

```sh
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/testing/app-module-graph.spec.ts apps/backend/src/database/typeorm-migration-config.spec.ts apps/backend/src/modules/messaging/messaging.module.spec.ts apps/backend/src/modules/auth/npc-account.service.spec.ts apps/backend/src/modules/spacecraft/spacecraft-field.spec.ts apps/backend/src/modules/spacecraft/spacecraft-scan.service.spec.ts apps/backend/src/modules/spacecraft/spacecraft-core-controls.spec.ts apps/backend/src/modules/spacecraft/spacecraft-boarding.service.spec.ts apps/backend/src/modules/spacecraft/field-effect-consequence.spec.ts apps/backend/src/modules/tick/tick-admin.service.spec.ts apps/backend/src/modules/tick/wreck-decay.service.spec.ts apps/backend/src/modules/tutorial/tutorial.service.spec.ts apps/backend/src/modules/starmap/layer-map-cycle.service.spec.ts

env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.integration.config.cts --runInBand --runTestsByPath apps/backend/src/database/migration-tests/20261023-character-order.int-spec.ts

npx --no-install vitest run --config apps/frontend/vite.config.mts apps/frontend/src/components/tutorial/useTutorial.spec.tsx apps/frontend/src/components/spacecraft/SpacecraftMessageBar.spec.tsx apps/frontend/src/pages/colonies/components/PanelFabrication.spec.tsx apps/frontend/src/pages/colonies/components/PanelTelescope.spec.tsx apps/frontend/src/pages/dashboard/DashboardLowerSections.spec.tsx apps/frontend/src/pages/holonet.spec.tsx apps/frontend/src/pages/tutorial-targets.spec.tsx apps/frontend/src/pages/research.spec.tsx --maxWorkers=1

env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config .workmux/independent-metadata.config.cjs --runInBand --no-cache

env -u DATABASE_URL -u INTEGRATION_DATABASE_URL DATABASE_URL=postgresql://unused:unused@127.0.0.1:1/metadata_only TS_NODE_PROJECT=apps/backend/tsconfig.app.json TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npm exec --offline -- node --require ts-node/register --require tsconfig-paths/register .workmux/independent-migration-metadata.cjs

env -u TS_NODE_COMPILER_OPTIONS -u DATABASE_URL -u INTEGRATION_DATABASE_URL DATABASE_URL=postgresql://unused:unused@127.0.0.1:1/metadata_only TS_NODE_PROJECT=apps/backend/tsconfig.app.json npm exec --offline -- node --require ts-node/register --require tsconfig-paths/register .workmux/independent-migration-metadata.cjs
```

No focused test required the private game-data snapshot, so no symlink or data copy was needed here. The supplied snapshot remains local coordinator-preserved input, not fetched data or proof of private submodule provenance.

### Failed / blocked review setup commands, not gate successes

- Initial inventory shell exit 1 because node_modules was absent; range and inputs discovery succeeded. Offline npm ci subsequently passed.
- A combined shell-array changed-path lint invocation was blocked before execution by a built-in shell-parser safety check; **not executed**. No removal was requested. Conventional Nx lint then passed. No policy bypass/removal attempt occurred.
- Initial inline migration metadata/parity probe exited 1 with zsh `bad pattern` from quoting; no metadata code ran. Replaced by the ignored script above, which passed.
- Initial inline ledger audit exited 1 with `TypeError: Cannot read properties of undefined (reading 'split')` from using field 5 instead of field 4 in the five-field TSV. Corrected audit passed and found 81 matching log files. Not treated as a product failure or green proof.
- A lookup typo for spacecraft/field-effect-query and auth/jwt-auth.guard returned file-not-found; actual starmap FieldEffectQuery registration was subsequently located. Not a missing production symbol finding.

Warnings retained: ts-jest isolatedModules deprecation; React NaN strokeDashoffset fixture warning; all 1531 active Nx lint warnings. Recorded build CSS import-order/large-bundle and pg concurrent-query deprecations also remain disclosed.

## Complete gates ledger-reviewed, NOT independently rerun

The 81-row supplied gate-results.tsv retains actual historical failures/invalid probes; these are not counted as successful acceptance. Original logs now supplied under .workmux/baseline-inputs/gates correspond to all 81 rows. Final acceptance rows report exit 0 and their original terminal summaries were checked:

| Ledger ID(s) | Recorded exit | Original log evidence |
|---|---:|---|
| buoy-backend-unit-full | 0 | 211 suites / 1980 tests; 1 snapshot; no skipped |
| followup-frontend-unit-full | 0 | 92 files / 653 tests; no skipped; frontend candidate hashes match |
| buoy-integration-full | 0 | 36 suites / 290 tests; no skipped; real migrations, disposable PostgreSQL |
| followup-nx-types; buoy-backend-types; forced spec-type rows | 0 | Normal target success and forced spec-inclusive checks; forced checks additionally rerun here |
| followup-nx-builds; buoy-backend-build | 0 | Shared tsc, frontend 1104-module Vite build, actual backend Webpack success |
| followup-nx-lint; buoy-backend-lint | 0 | 1531 aggregate warnings / 0 errors; independent Nx lint agrees |
| followup-cli-datasource-disposable | 0 | Actual `.ts` initialization; 204 then 0 migrations, pending=false, synchronize=false |
| followup-datasource-source-parity | 0 | `.ts`/`.mts` normalized parity; independently confirmed |
| buoy-final-sync-check | 0 | Workspace up to date |
| buoy-permanent-red / buoy-permanent-green | 1 / 0 | Real missing-Buoy failure 1 failed/1 passed → 2/2 passed; permanent green independently rerun |

Build/full-test/source proof logs are recorded evidence, not a claim they ran in this review worktree. Byte-hash identity binds the candidate files; it does not reconstruct every environmental input or prove production data provenance.

## Acceptance / coverage bounds

PASS is restricted to normal baseline consolidation repair, synchronization disabled, the exact eight local commits and 43 authorized paths. No migration generation/synchronize approval. No `.mts` runtime proof. No full Nest boot/provider-instantiation/end-to-end HTTP proof. No runtime asset validation (assets remain absent), no full tutorial DTO validation, no rollback through the absent previous-calendar owner, and no exhaustive research flake elimination. The reviewed test/source seams and original complete gates support the bounded PASS, not these broader claims.

No repair or integration was performed. **Stopped for coordinator.**

Axis summary: Standards 0 hard findings / 2 P3 heuristic observations (worst: misleading DI test title); Spec 0 verified findings. No blocker within the authorized acceptance bounds.

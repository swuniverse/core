import {
  Injectable,
  BadRequestException,
  ForbiddenException,
  UnauthorizedException,
  Inject,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Raw, Repository } from 'typeorm';
import { isEmail } from 'class-validator';
import * as bcrypt from 'bcrypt';
import { User } from '../auth/user.entity';
import { AccountDeletionMark } from '@swuniverse/shared';
import { AccountTokenPurpose } from '../auth/account-token.entity';
import { AccountTokenService } from '../auth/account-token.service';
import { MailService } from '../mail/mail.service';
import { ConfigService } from '@nestjs/config';
import { UserSetting } from './entities/user-setting.entity';
import {
  EMAIL_BLOCKLIST,
  type EmailBlocklistPort,
} from './email-blocklist.port';
import { RpgBehavior } from '@swuniverse/shared';

const SETTING_DEFAULTS: Record<string, string> = {
  email_notification: '1',
  storage_notification: '0',
  show_pm_read_receipt: '1',
  profile_visit_optout: '0',
  inbox_messenger_style: '0',
  fleet_fixed_default: '0',
  reactor_auto_carryover_default: '0',
  rgb_code: '',
  default_view: 'maindesk',
  rpg_behavior: String(RpgBehavior.NOT_SET),
};

const RPG_BEHAVIORS = new Set(
  Object.values(RpgBehavior)
    .filter((value): value is RpgBehavior => typeof value === 'number')
    .map(String),
);

const BOOLEAN_SETTINGS = new Set([
  'email_notification',
  'storage_notification',
  'show_pm_read_receipt',
  'profile_visit_optout',
  'inbox_messenger_style',
  'fleet_fixed_default',
  'reactor_auto_carryover_default',
]);
const DEFAULT_VIEWS = new Set([
  'maindesk',
  'colonies',
  'spacecraft',
  'starmap',
  'messages',
  'research',
  'holonet',
]);
const VALID_SETTINGS = Object.keys(SETTING_DEFAULTS);

const VACATION_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;
const ACCOUNT_DELETION_LIFETIME_MS = 48 * 60 * 60 * 1000;

@Injectable()
export class SettingsService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    @InjectRepository(UserSetting)
    private readonly settingRepo: Repository<UserSetting>,
    @Inject(EMAIL_BLOCKLIST)
    private readonly emailBlocklist: EmailBlocklistPort,
    private readonly accountTokenService: AccountTokenService,
    private readonly mailService: MailService,
    private readonly config: ConfigService,
  ) {}

  async getSettings(userId: number): Promise<Record<string, string>> {
    const rows = await this.settingRepo.find({ where: { userId } });
    const result = { ...SETTING_DEFAULTS };
    for (const row of rows) {
      result[row.key] = row.value;
    }
    return result;
  }

  async updateSettings(
    userId: number,
    updates: Record<string, string>,
  ): Promise<Record<string, string>> {
    for (const [key, value] of Object.entries(updates)) {
      if (!VALID_SETTINGS.includes(key)) {
        throw new BadRequestException(`Invalid setting key: ${key}`);
      }
      if (BOOLEAN_SETTINGS.has(key) && value !== '0' && value !== '1') {
        throw new BadRequestException(`Invalid setting value: ${key}`);
      }
      if (key === 'default_view' && !DEFAULT_VIEWS.has(value)) {
        throw new BadRequestException(`Invalid setting value: ${key}`);
      }
      if (key === 'rpg_behavior' && !RPG_BEHAVIORS.has(value)) {
        throw new BadRequestException(`Invalid setting value: ${key}`);
      }
      if (
        key === 'rgb_code' &&
        (typeof value !== 'string' ||
          (value !== '' &&
            (value.length !== 7 || !/^#[0-9a-f]{6}$/i.test(value))))
      ) {
        throw new BadRequestException('Ungültiger Farbcode');
      }
    }

    for (const [key, value] of Object.entries(updates)) {
      await this.settingRepo.upsert(
        {
          userId,
          key,
          value: key === 'rgb_code' ? value.toLowerCase() : value,
        },
        ['userId', 'key'],
      );
    }

    return this.getSettings(userId);
  }

  async changePassword(
    userId: number,
    oldPassword: string,
    newPassword: string,
  ): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    const valid = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!valid) {
      throw new BadRequestException('Current password is incorrect');
    }

    if (newPassword.length < 8 || newPassword.length > 128) {
      throw new BadRequestException(
        'Password must be between 8 and 128 characters',
      );
    }

    user.passwordHash = await bcrypt.hash(newPassword, 12);
    await this.userRepo.save(user);
  }

  async changeEmail(
    userId: number,
    password: string,
    newEmail: string,
  ): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      throw new BadRequestException('Password is incorrect');
    }

    const email =
      typeof newEmail === 'string' ? newEmail.trim().toLowerCase() : '';
    if (email.length > 254 || !isEmail(email)) {
      throw new BadRequestException('Die E-Mail-Adresse ist ungültig');
    }

    const existing = await this.userRepo.findOne({
      where: {
        email: Raw((column) => `LOWER(${column}) = :email`, { email }),
      },
    });
    if (existing && existing.id !== userId) {
      throw new BadRequestException(
        'Die E-Mail-Adresse wird bereits verwendet',
      );
    }
    if (await this.emailBlocklist.isBlocked(email)) {
      throw new BadRequestException('Die E-Mail-Adresse ist blockiert');
    }

    user.email = email;
    await this.userRepo.save(user);
  }

  async updateProfile(
    userId: number,
    data: { description?: string; displayName?: string },
  ): Promise<{ description: string | null; displayName: string | null }> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    if (data.description !== undefined) {
      if (data.description.length > 2000) {
        throw new BadRequestException('Description too long (max 2000)');
      }
      user.description = data.description || null;
    }

    if (data.displayName !== undefined) {
      const name = data.displayName.trim();
      if (name.length > 0 && name.length < 3) {
        throw new BadRequestException(
          'Display name must be at least 3 characters',
        );
      }
      if (name.length > 60) {
        throw new BadRequestException('Display name too long (max 60)');
      }
      user.displayName = name || null;
    }

    await this.userRepo.save(user);
    return { description: user.description, displayName: user.displayName };
  }

  async updateAvatar(
    userId: number,
    avatar: string | null,
  ): Promise<{ avatar: string | null }> {
    if (avatar && avatar.length > 350_000) {
      throw new BadRequestException('Avatar too large (max ~250KB)');
    }
    if (avatar && !avatar.startsWith('data:image/')) {
      throw new BadRequestException('Avatar must be a data URL image');
    }
    await this.userRepo.update(userId, { avatar });
    return { avatar };
  }

  async activateVacation(userId: number): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    if (user.vacationMode) {
      throw new BadRequestException('Vacation mode is already active');
    }

    if (user.vacationRequestedAt) {
      const elapsed = Date.now() - user.vacationRequestedAt.getTime();
      if (elapsed < VACATION_COOLDOWN_MS) {
        const remainingDays = Math.ceil(
          (VACATION_COOLDOWN_MS - elapsed) / (24 * 60 * 60 * 1000),
        );
        throw new BadRequestException(
          `Vacation cooldown active. ${remainingDays} days remaining.`,
        );
      }
    }

    const now = new Date();
    user.vacationMode = true;
    user.vacationRequestedAt = now;
    user.vacationStartedAt = now;
    user.refreshToken = null;
    await this.userRepo.save(user);
  }

  async deactivateVacation(userId: number): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    if (!user.vacationMode) {
      throw new BadRequestException('Vacation mode is not active');
    }

    user.vacationMode = false;
    user.vacationEndedAt = new Date();
    await this.userRepo.save(user);
  }

  async requestDeletion(userId: number, password: string): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      throw new BadRequestException('Password is incorrect');
    }

    if (user.deletionMark === AccountDeletionMark.Forbidden) {
      throw new ForbiddenException(
        'Account deletion has been forbidden by admin',
      );
    }

    user.deletionMark = AccountDeletionMark.Requested;
    await this.userRepo.save(user);
    if (this.config.get<string>('ACCOUNT_DELETION_ENABLED') !== 'true') return;

    const { token } = await this.accountTokenService.create(
      user.id,
      AccountTokenPurpose.AccountDeletion,
      ACCOUNT_DELETION_LIFETIME_MS,
    );
    const baseUrl = (this.config.get<string>('APP_BASE_URL') ?? '').replace(
      /\/$/,
      '',
    );
    void this.mailService.sendAccountDeletionMail(
      user.email,
      user.username,
      `${baseUrl}/confirm-deletion?token=${encodeURIComponent(token)}`,
    );
  }

  async revokeDeletion(userId: number): Promise<void> {
    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new UnauthorizedException();
    if (user.deletionMark !== AccountDeletionMark.Requested) {
      throw new BadRequestException('Deletion request cannot be revoked');
    }
    user.deletionMark = AccountDeletionMark.None;
    await this.userRepo.save(user);
  }

  async searchUsers(
    query: string,
  ): Promise<{ id: number; username: string }[]> {
    if (!query || query.length < 2) return [];

    const users = await this.userRepo
      .createQueryBuilder('u')
      .select(['u.id', 'u.username'])
      .where('u.username ILIKE :q', { q: `%${query}%` })
      .limit(10)
      .getMany();

    return users.map((u) => ({ id: u.id, username: u.username }));
  }
}

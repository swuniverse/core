# K7a2 technical prerequisites — 2026-11-09

## Outcome

Docs-only candidate **`940628fa0a2f1986857fc6998d9439a3fe1378eb`**, based on `c79ff89fdf5d16d5ad87e91369eaaaaa06ddb7ab`, committed on `reconcile-tracker-20261109`; no merge or push. Stop for narrow independent docs review. No source, map, DECISIONS, tooling, package or STU changes; no feature implementation.

Exactly three issue Markdown paths:

1. `.scratch/stu-parity/issues/tmw-K7a2a-flottenmutationen-nebenlaeufigkeit.md`: P2/M ready-for-agent, no prerequisite; shared fleet mutation/relocation transaction, locking and post-lock validation contract with durable real-PostgreSQL barrier coverage.
2. `.scratch/stu-parity/issues/tmw-K7a2b-bewegung-veraltete-schreibvorgaenge.md`: P2/M ready-for-agent, blocked by K7a2a; stale movement writer protection including implicated direct member saves and affected caller effects.
3. `.scratch/stu-parity/issues/tmw-K7a2-wurmloch-flottenintegration-und-ankunft.md`: remains ready-for-agent, blocked by K7a1, K7a2a and K7a2b. Mandatory K5c arrival knowledge and repair cancellation clarify the settled parent requirement; manager-bound arrival effects and commit-safe notifications remain here. All acceptance boxes remain open.

## Evidence boundary

The supplied stop report and independent review confirm two pre-existing races. The stale-movement probe invokes the real public persistence seam against real disposable PostgreSQL after a simulated locked relocation; it is not a complete `navigate` or wormhole operation. The join probe invokes the real public join and verifies persisted fleet/ship state after simulated relocation; its earlier returned-object assertion was inconclusive. Other fleet operations are shared protocol participants, not independently demonstrated instances of the same race. Neither probe establishes an implementation, green fix, or K7a2 acceptance. No user product decision or human-only implementation requirement was inferred.

## Checks and next child

- Clean initial worktree at `c79ff89f`; both new issue IDs collision-checked.
- Existing tracker parser validates required headers, allowed status/priority/size and unique issue IDs/referenced blockers for 278 issues. DFS found zero dependency cycles.
- Exact required status/dependency tuples checked: K7a2a unblocked, K7a2b blocked by K7a2a, K7a2 blocked by K7a1/K7a2a/K7a2b. K7a2's acceptance boxes remain unchecked.
- Counts: 185 resolved, 81 ready-for-agent, 3 wontfix, 7 needs-triage, 2 needs-info.
- Staged scope asserted exactly three named Markdown paths; `git diff --cached --check` passed. Commit carries the required attribution. No full suite, diagnostics, code exploration or external services performed.
- Proposed next executable child, subject to review and serial integration: **`tmw-K7a2a`**, then `tmw-K7a2b`; K7a2 additionally needs K7a1. Readiness is a tracker status, not feature completion.

# col-D3b final independent post-rebase review — 2026-11-09

## Final verdict

**Final candidate: PASS — ready for coordinator’s serial integration.** No new Standards or Spec finding in this narrow post-rebase/conflict review. Previous production, acceptance, renderer-sensitivity and typed-adapter approval remains applicable: all five research files are byte-identical to the previously reviewed `c12939d4`.

The worker’s snapshot-cwd backend result with one skipped suite/test is **not accepted as the final gate**. It is replaced by one fresh, root-normal, no-cache backend unit run: **211/211 suites, 1981/1981 tests, 1/1 snapshot; zero failures, skipped/pending suites/tests, or todo tests**. The conditional mining fixture executed and passed. Focused frontend conflict verification also passed **15/15**.

No merge, push, implementation, commit, issue change or other-checkout access performed. Stop here for serial integration. This verdict concerns the exact candidate below and does not claim a fresh execution of every supplied baseline/global gate.

## Fixed point and review scope

- Worktree: `/Users/TMUNDIN/git/github.com/swuniverse/core__worktrees/review-col-d3b-20261109`.
- New local review branch: `review/col-D3b-final-20261109`.
- Reviewed rebased SHA: **`c8e14f1c5282a30e77b25020ee9a27a70aba249e`**.
- Integrated base / merge-base: `stu-parity` = `14b860813b988165f8470c0c9d3b31e087f70aa2`.
- Previous approved tip: `c12939d4aa81e40b2b67b235388714c8b31f630d`.
- Actual old review branch `review-col-d3b-20261109` remains at `c12939d4`; the existing `backup/agent-col-D3b-pre-rebase-20261109` ref is also preserved. No old ref rewritten.
- Exactly three rebased assignment commits, in order:
  1. `b46988ffcc2789b2f30f929fafb175f8df8030d2` — dependency behavior.
  2. `67e8d36e8402114cf299de44740e5ff615f5e2ca` — production-renderer tests.
  3. `c8e14f1c5282a30e77b25020ee9a27a70aba249e` — typed renderer props.
- Final delta versus base: exactly five research files, **468 insertions / 141 deletions**. No tooling, lockfile, STU, migration or integration-config delta.
- No `.codegraph/` index exists here; no index created. Existing review instructions and prior independent review retained; this was not a restarted full audit.

## Range-diff / conflict verification

Executed locally:

```sh
git switch -c review/col-D3b-final-20261109 agent-col-D3b
git range-diff \
  ad581f97665396880f0a1fa94f8d1dcd7919488d..c12939d4aa81e40b2b67b235388714c8b31f630d \
  stu-parity..HEAD
git diff --name-only stu-parity HEAD
git diff --stat stu-parity...HEAD
git diff --exit-code c12939d4aa81e40b2b67b235388714c8b31f630d HEAD -- \
  apps/backend/src/modules/research/research.controller.ts \
  apps/backend/src/modules/research/research.service.ts \
  apps/backend/src/modules/research/research.service.spec.ts \
  apps/frontend/src/pages/research-tree.tsx \
  apps/frontend/src/pages/research.spec.tsx
```

Successful commands, exit **0**. Range-diff maps:

```text
7ccc125d ! b46988ff
ee90beb6 = 67e8d36e
c12939d4 = c8e14f1c
```

The sole patch difference is the first commit’s preimage/context at the alternative-detail button assertion. The newer base already awaits an exact accessible button name. The final candidate retains the previously reviewed awaited `findByRole('button', { name: /Alternative Reaktortheorie.*eine von/ })` assertion. It still requires the intended accessible alternative action and waits for rendering; the conflict does not remove or bypass that check.

The two corrective patches compare equal. The final-content comparison over all five research paths exits **0 with no diff**. Thus production behavior, production node/edge invocation, actual BaseEdge SVG assertions, node-scoped `AUSGESCHLOSSEN`, typed props, and the excluded REQUIRE_SOME fallback regression test are unchanged from the already approved content. The final diff versus parity was also inspected directly.

**Standards axis: PASS, 0 new findings. Spec axis: PASS, 0 new findings.** Prior mutation/type review evidence is preserved in `.workmux/col-D3b-review-20261109.md`, particularly the final `c12939d4` review. Its historical global BLOCKED status predates the supplied consolidated baseline and this fresh final backend evidence; it is not the current candidate verdict.

## Independently verified final source hashes

Command, exit **0**; repeated after fresh tests with identical output:

```sh
shasum -a 256 \
  apps/backend/src/modules/research/research.controller.ts \
  apps/backend/src/modules/research/research.service.ts \
  apps/backend/src/modules/research/research.service.spec.ts \
  apps/frontend/src/pages/research-tree.tsx \
  apps/frontend/src/pages/research.spec.tsx
```

| Final path | SHA-256 |
|---|---|
| `apps/backend/src/modules/research/research.controller.ts` | `708837ac8c6d397b33488f29fcd49ae382c386c0791628b6a5ffc74bcd030567` |
| `apps/backend/src/modules/research/research.service.ts` | `7b31e82c4520b5f3cf3f8662d1acb04957f02c1507a49ee5cc8f6bcddadf3405` |
| `apps/backend/src/modules/research/research.service.spec.ts` | `fa8ee03c2f5451de5b6f82bf9f5f29057479a852112ca63788fe88b5def687cb` |
| `apps/frontend/src/pages/research-tree.tsx` | `80826dd8238c01806dc414ac40082d41dbbc10a207d434b944c2c498a982092c` |
| `apps/frontend/src/pages/research.spec.tsx` | `c1351524247cd41482cf2f04b096adc8b4b56104189f86396bcd4915f3e318df` |

All five match the supplied candidate report.

## Authorized local fixture setup

Before linking, checked `game-data/data` with filesystem lstat: **absent**. `game-data` was an existing directory, and `apps/backend/game-data` was absent. Verified the supplied snapshot’s two mining fixture files and the repository constants file exist; no fixture content copied, invented, generated, suppressed or published.

Executed from the actual repository root, exit **0**:

```sh
ln -s ../.workmux/final-review-inputs/game-data/data game-data/data
```

A local Node assertion verified:

- `process.cwd()` is the exact review repository root above.
- `realpath('game-data/data')` is this worktree’s `.workmux/final-review-inputs/game-data/data`.
- Both `buildings/swu-field-build-categories.yaml` and `colony-classes/swu-letter-resources.yaml` resolve through the link.
- `apps/frontend/src/pages/colonies/constants.ts` exists.

This satisfies `swu-mining-fields.spec.ts`’s repository-relative fixture predicate; no `apps/backend/game-data` workaround or cwd change used. The only local environment addition outside ignored report/artifact paths is the explicitly authorized symlink under the empty game-data gitlink. Tracked status remains clean.

## Fresh backend final gate — exactly one execution

Executed **once**, from the actual repository root, via local npm/npx. No Nx cache, remote service, `GAME_DATA_PATH` workaround, fixture suppression, `passWithNoTests`, or snapshot-cwd invocation:

```sh
set -o pipefail
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' \
  npx --no-install jest \
    --config apps/backend/jest.config.cts \
    --runInBand --no-cache --json \
    --outputFile .workmux/col-D3b-final-backend-20261109.json \
  2>&1 | tee .workmux/col-D3b-final-backend-20261109.log
```

**Process/pipeline exit: 0.** Jest summary:

```text
Test Suites: 211 passed, 211 total
Tests:       1981 passed, 1981 total
Snapshots:   1 passed, 1 total
Time:        62.458 s
Ran all test suites.
```

Independently parsed the JSON artifact, rather than inferring zero skips from silence:

| JSON field | Result |
|---|---:|
| `success` | `true` |
| `numTotalTestSuites` / `numPassedTestSuites` | 211 / 211 |
| `numFailedTestSuites` / `numRuntimeErrorTestSuites` | 0 / 0 |
| `numPendingTestSuites` | 0 |
| `numTotalTests` / `numPassedTests` | 1981 / 1981 |
| `numFailedTests` / `numPendingTests` / `numTodoTests` | 0 / 0 / 0 |
| Snapshot matched / total | 1 / 1 |

Also inspected actual assertion statuses: no pending, disabled or todo assertions.

- `swu-mining-fields.spec.ts`: suite **passed**; `SWU mining-field fixture coverage covers ore sources and keeps generation deterministic` **passed**, **1/1**, suite duration 20475 ms. This is the conditional fixture that the worker’s snapshot-cwd run skipped.
- `research.service.spec.ts`: suite **passed**, all **28/28 assertions passed**, including retained excluded tree payload, faction filtering and unchanged list omission. These are fresh execution within the full suite, replacing the supplied focused Nx cache output as final research-service evidence.
- GameDataService logs resolve to this repository’s `game-data/data`, not the snapshot as cwd or an application source-tree workaround.
- Expected test error-path logging and the existing ts-jest `isolatedModules` deprecation warning appeared. No failing test or fixture-skip warning.

JSON evidence SHA-256:
`b7564f6f9e36bd71108b11363e814f26085768e3799ff5152889fbc886d4561e`.

## Fresh focused frontend conflict verification

Executed once from the same root:

```sh
set -o pipefail
npx --no-install vitest run \
  --config apps/frontend/vite.config.mts \
  apps/frontend/src/pages/research.spec.tsx \
  2>&1 | tee .workmux/col-D3b-final-frontend-20261109.log
```

**Exit 0; 1/1 file, 15/15 tests passed**, Vitest 4.1.5, duration 2.03 s. This covers the awaited accessible-button conflict and preserved production-renderer assertions. No full frontend suite or repeat mutation run was needed because the final source is identical to the already approved content.

## Supplied report and cache accounting

Read local `.workmux/final-review-inputs/candidate-report.md`; SHA-256:
`53ad392331c2a047757e10ad52a0988a2ff6964f384424e4339381f60bb201fd`.

This report is a supplied record, **not raw independently rerun gate output**. Its source hashes were independently matched. No separate baseline/raw gate logs were supplied in this input directory. The user confirmed baseline `14b86081` was independently reviewed/integrated; this narrow review does not restart those gates.

| Supplied gate | Reported command/result | Current-review treatment |
|---|---|---|
| Full frontend units | `npx nx test frontend`; exit 0, 92 files / 655 tests | Not rerun. Report states frontend tests executed, with shared build cache reuse. |
| Focused frontend | `npx vitest run --config apps/frontend/vite.config.mts apps/frontend/src/pages/research.spec.tsx`; exit 0, 15/15 | Superseded by fresh independent 15/15 above. |
| Focused backend | `npx nx run backend:test --runInBand --runTestsByPath src/modules/research/research.service.spec.ts`; cached 28/28 output | Not fresh execution. Fresh 28/28 independently executed within the full backend suite above. |
| Frontend spec-inclusive types | `npx tsc --build apps/frontend/tsconfig.spec.json --force --pretty false`; exit 0 | Reported forced check, not rerun here. Research content is identical to previously approved typed correction. |
| Lint | `npx nx run frontend:lint`; `npx nx run backend:lint`; succeeded with warnings (frontend 109) | Supplied success only; not rerun or represented as fresh execution. |
| Types | `npx nx run frontend:typecheck`; `npx nx run backend:typecheck`; succeeded | Cache use disclosed, including backend two of three tasks cached; not new test/type execution here. |
| Builds | `npx nx run frontend:build`; `npx nx run backend:build`; succeeded | Shared build cache disclosed; existing CSS/chunk warnings reported; not rebuilt here. |
| Backend full units from snapshot cwd | 210 passed / 1 skipped suites, 1980 passed / 1 skipped tests | **Rejected as final evidence**, including its `--passWithNoTests=true` invocation; replaced by fresh root-normal zero-skip run. |

Cached outputs are not described as new test execution. The old review’s pre-consolidation global tooling/type blockers are historical, not silently reused as current blockers or exemptions.

## Limits and final integrity checks

- No research-specific backend `*.int-spec.ts` found. Local inventory confirms **36** backend `*.int-spec.ts` files overall, **0** under research. No research-specific HTTP/DB integration test was found or run.
- Full DB/migration replay **not rerun**, as requested. Unchanged baseline reference: **36 suites / 290 tests passed**. This is not fresh candidate DB verification.
- `git diff --exit-code stu-parity HEAD -- apps/backend/src/database apps/backend/src/testing/integration apps/backend/jest.integration.config.cts` exits **0**, no changes. Tooling/lockfile/AGENTS comparison also exits **0**.
- Production renderer tests invoke the production custom nodes/edges and real BaseEdge, but mock ReactFlow wrapper, ELK, handles/geometry and marker URLs. No full browser/real ReactFlow integration proof is claimed. Prior independent no-write style/label/marker sensitivity remains applicable to unchanged content.
- No remote/private fetch, data publication, tooling/package-manager edits, permission override or other checkout used. npm/npx only for execution.
- `git diff --check stu-parity...HEAD`, `git diff --exit-code`, `git diff --cached --exit-code`, and `git status --short` all exit **0**; tracked/staged status is clean before report creation.
- `git check-ignore` confirms this report and backend JSON/log/frontend log paths are ignored. Original review report and supplied candidate report remain unchanged.

**Disposition: PASS at `c8e14f1c5282a30e77b25020ee9a27a70aba249e`; ready for serial integration. No integration or issue resolution performed.**

# Baseline verification — 2026-11-09

## Status
COMPLETE / REVIEW PASS / BASELINE FAST-FORWARDED INTO STU-PARITY (2026-11-09). Main before `7e7143d80d155b312dca1ad0d6a5304c38d54571`, after `14b860813b988165f8470c0c9d3b31e087f70aa2`: exactly eight reviewed commits / 43 authorized paths, no merge commit or push. Original overlapping 32 tracked + 3 untracked paths permanently preserved in named stash `stu-parity-original-baseline-20261109`, OID `c46b537b8517893d741ce701ba14939d58663506`; original bytes verified, never popped/dropped. All 43 main/candidate/reviewed source hashes match; main index empty, unrelated 65 issue/brag statuses/hashes/modes unchanged; candidate worktree/index clean. Main was located via Git worktree metadata and accessed only under explicit serial-integration authorization. Environment/config/local-data comparisons found no material difference; no exhaustive/sanity test rerun or new full-suite claim. Existing verified acceptance remains backend 211/1980, focused 13/69, disposable integration 36/290, frontend 653/653, zero skips, types/lint/build/sync and permanent Buoy metadata RED→GREEN. Existing warnings, duplicate migration metadata and unverified `.mts` runtime retained; **no full application-boot claim, migration generation or synchronization**. No D3b/ee90beb6, other feature/tracker/STU/package/lockfile integration, cleanup, worktree deletion or remote transfer. STOPPED after baseline integration, next serial phase awaits coordinator. See final serial integration section and exact manifests below; earlier stopping points are historical.

## Authorization and scope
Original authorization: `.workmux/preserved-baseline/apps-tracked.patch` (31 tracked app files, 319 additions/35 deletions) and three new app regression specs, plus minimal evidenced fixture corrections. Follow-up authorization narrows the original `nx.json` prohibition ONLY to the exact user's pre-existing npm pin in `.workmux/preserved-local-inputs/existing-npm-pin.patch`. No other tooling/package/lockfile/package-manager changes or fake pnpm metadata. Authorized local input use is a symlink from previously absent `game-data/data` to the ignored coordinator snapshot; no production-data modification. Latest narrowed authorization permits ONLY `apps/backend/src/app.module.ts` and permanent focused datasource metadata regression under testing, for explicit existing Buoy registration. The already-imported `testing/app-module-graph.spec.ts` carries that regression, so total scope increases by only one file. No autoLoadEntities or synchronize enabled. Both snapshots immutable. F3d/H1/I1c excluded; `ee90beb6` not imported. Original worker ban on main access/merge applied through acceptance; latest explicit serial-integration prompt narrows it ONLY to inspection, exact path-scoped original preservation and reviewed-range FF into stu-parity. No other-checkout edits, external services/data transfer, fetches, push, shared DB migration, tracker/map changes or worktree removal.

Project guidance read: AGENTS.md, CONTRIBUTING.md, CONTEXT.md, docs/agents/domain.md, docs/typeorm-migrations.md, integration README, TDD skill and its test/mocking references. No CodeGraph index exists in this worktree. Existing authorized seams: TypeORM config metadata loading; migration runner against disposable PostgreSQL; Nest dependency resolution/module graph; NPC public get; tutorial hook response; existing spacecraft/tick behavior specs. No new test seam added.

## Import ledger
- Datasource/entity graph: both `.ts`/`.mts` configs, application User and LayerKnowledge metadata; new typeorm-migration-config.spec.ts.
- Character history: prepare migration, history helper, character-order integration regression.
- Nest wiring: alliance/messaging/spacecraft/tick/tutorial modules; app-module-graph and messaging.module specs; Jest ts-jest transformer for circular real entity imports.
- Runtime dependency guards: field consequence random/clock, boarding random, spacecraft/scan Buoy and Cargo repositories, tick admin TickService runtime import, wreck-decay randomness; matching preserved regressions.
- NPC username length fixture/definition while retaining display name.
- Layer-map-cycle constructor fixture repair for required award dependency.
- Tutorial definitions DI and service regression; frontend undefined steps guard/regression.

Review limitations: duplicate table metadata in migration graph remains a migration-only risk despite successful disposable actual datasource replay (204 migrations, repeat zero); module-graph test uses Nest internal scanner and scans imports, not full provider instantiation/application boot; messaging test reflects static metadata rather than exercising notifications. Some preserved test names saying optional/default injection are inaccurate because tokens are explicitly provided. The tutorial regression was strengthened with `act` response flushing and now fails as an actual test on base; its guard validates navigation-required shape, not every TutorialViewDto field. No broader DTO validation or product redesign was added.

## Environment
`npm ci --offline --ignore-scripts --no-audit --no-fund`: exit 0. Log `.workmux/npm-ci.log`. Installation restricted to own worktree; no dependency manifest edits. Private game-data and assets submodules are uninitialized (directories empty). Do not fabricate production YAML. Disposable integration harness explicitly sets checked-in migration-building fixture; that fixture is authorized existing test input, not production data.

## Verification evidence
Exact commands, actual exits, durations in milliseconds and log paths are recorded in `.workmux/gate-results.tsv` (51 executions); complete local logs in `.workmux/gates/`. Commands ran serially, not concurrent builds/typechecks. The ignored runner sets `npm_config_offline=true`, `NX_DAEMON=false`, `NX_INTERACTIVE=false`, with a 600000ms per-command timeout. Its batch exit is NOT a gate verdict: it records each command exit separately and continues after failure. RED proof below identifies behavior/assertion failures, not environment failures; invalid/superseded probes are explicitly excluded. No test failures, coverage skips, or tool warnings waived.

## RED / GREEN evidence so far
- `red-character-postgres`: exit 1, 1 failed / 5 passed / 6 total; historical calendar owner causes `relation user_characters already exists`. `green-character-postgres`: exit 0, 6/6. Both runs unset ambient database URLs and use harness-created PostgreSQL 16; no shared development DB.
- `red-backend-focused`: exit 1, 9 failed suites; 8 failed / 16 passed tests. NPC assertion sees overlength original username; messaging module lacks WebsocketModule; application graph loads cyclic ColonyModule prematurely; TickAdminService lacks runtime TickService. TypeORM CLI config load fails with ERR_REQUIRE_ESM importing shared enum from LayerKnowledge: a config-load defect under the documented ts-node CommonJS migration command, not DB/environment failure.
- Four DI tests initially imported token exports absent on base, yielding invalid undefined providers. Those initial metatype failures are NOT used as RED proof. `.workmux/red-token-aliases.cjs` supplies test-only exported token names without changing production classes/decorators. `red-di-valid-tokens`: exit 1, four failed / fourteen passed; all four now report actual unresolved function/object dependencies at the relevant constructor index.
- `green-backend-focused`: exit 0, 10 suites / 32 tests; includes layer cycle, config metadata, module graph, NPC, field/boarding/tick/wreck/tutorial DI.
- Initial tutorial regression run: exit 1, 3 assertions pass but one unhandled findIndex TypeError, exposing premature test completion. Added `act` response flushing to the same existing hook seam before production import. `red-frontend-tutorial-flushed`: exit 1, actual test failure at undefined steps.findIndex. `green-frontend-tutorial`: exit 0, 3/3, no unhandled errors.
- `base-backend-spec-types`: exit 2 from intentionally missing new token exports; layer constructor fixture had already been imported. NOT claimed as the old four-constructor RED. Valid compiler-host Git overlay proof is recorded below (`red-layer-overlay-valid`).
- `base-frontend-spec-types`: exit 2, reproduces exactly the known eight frontend diagnostics across six files. Minimal fixture/type corrections were applied and verified as recorded below; no compiler exclusions or weakening unknown casts added.

## Tooling decision — historical first pass (superseded by authorized exact pin)
The follow-up user prompt explicitly authorizes ONLY the preserved pin recorded in the current scope above. The following original diagnosis is retained as RED/environment evidence, not a current unresolved decision.
`npm-nx-graph` (`npx --no-install nx show projects`): exit 1. Nx selects pnpm-lock.yaml and cannot find node_modules/.modules.yaml after offline npm install. Nx implementation honors nx.json cli.packageManager before lockfile discovery; no supported environment override found. Proposed minimal decision: coordinator/user authorize existing local `cli: { packageManager: 'npm' }` pin in nx.json here. NOT applied. Do not fake pnpm metadata, patch dependency tooling, or treat direct gates as Nx green.

## Broad gates — first pass
- Backend spec-inclusive `tsc --build apps/backend/tsconfig.json --emitDeclarationOnly`: exit 0. Frontend same build command: exit 2 (known eight diagnostics).
- Direct lint: exit 1, **1503 problems: 3 errors / 1500 warnings**. All errors are unregistered `react-hooks/exhaustive-deps` suppressions in ColoniesPage.tsx lines 287, 845, 850. Additionally **1198** emitted no-cached-graph warnings: Nx module boundaries were skipped, not verified. No lint rules disabled or suppressions removed.
- Backend full unit suite: exit 1, **209 passed suites / 1 failed / 1 skipped** (211 total); **1944 passed / 34 failed / 1 skipped**, 1979 tests. All failures in game-data.service.spec.ts loading missing private game-data. Existing conditional skip: SWU mining-field fixture coverage because swu-field-build-categories.yaml and swu-letter-resources.yaml are absent. Do not call this green.
- Frontend full unit suite: exit 1, **91 passed / 1 failed** files, **652 passed / 1 failed** tests. Existing research.spec async selection failure; investigated at existing UI seam, no product change.
- Shared TypeScript build: exit 0. Frontend Vite production build: exit 0, 1104 modules; warnings about CSS @import order and large >500kB bundle. Build does not demonstrate private image assets exist.
- Backend Webpack: exit 2, `No cached ProjectGraph is available`; retry through actual npm backend workspace also exit 2, same blocker. Production declaration typecheck is separate, not substitute backend build.
- Full disposable migrations-backed integration: exit 0, **36 suites / 290 tests**, zero skipped. Harness used real migration chain, checked-in explicit building fixture, testcontainer-owned DBs and UUID schemas. Intentional failure-path logs (asset/socket failures) are passing tests, not hidden gate failures.

## Additional isolated proofs / corrections
- Fixed six frontend test fixtures only: toast duplicate info -> required error; complete CommodityDef nameShort; complete explored field DTO (`satisfies`, no unknown cast); full typed empty DashboardData defaults; Holonet test helper accepts existing optional tagged characters; Array.from NodeList without compiler/lib edits. No assertions removed. RED = original eight spec diagnostics; GREEN `green-fixture-types-retry`: exit 0; focused six files **48/48** tests, exit 0. An intermediate missing `};` in my Holonet test helper caused TS1131/transform failure; corrected and rerun, not concealed.
- `.workmux/types-base-overlay.cjs` reads original layer-cycle spec via Git and substitutes it in compiler host only. First probe omitted project references and produced irrelevant composite diagnostics; superseded. `red-layer-overlay-valid`: exit 2, **exactly four TS2554** constructor diagnostics; patched spec-inclusive build passes and layer focused regression passes. The accidentally recorded `base-layer-constructors` tsc-version pipeline is NOT verification and contributes no evidence.
- Ignored repository DI probe registers actual concrete dependency/repository tokens, never generic Repository/Object/Function. First config omitted ignored directory from roots and found no tests (NOT RED). Corrected `red-repository-overlay-valid`: exit 1, **two failed** tests; in-memory fs Git overlay restores only SpacecraftScanService/SpacecraftService, and Nest cannot resolve generic Repository slots. `green-repository-valid`: exit 0, **2/2**. No production source rollback or other checkout involved.
- `red-config-graph-overlay`: with entity enum fixes retained, restores only old `.ts` datasource config via in-memory Git reads. exit 1, concrete TypeORM `Entity metadata for LayerKnowledge#user was not found`; green config regression passes. This separately proves both config loading and correct relation target graph, rather than accepting an ESM load failure as sole graph proof.
- Research failure: original full file failed in both broad and focused runs at synchronous closest(button) query. A narrower one-test run happened to pass (known timing flake), so NOT claimed deterministic RED. Same intended assertion changed to awaited accessible button `Alternative Reaktortheorie (eine von)`; product source untouched. `green-research-run1`, `run2`, `run3`: each exit 0, 13/13 tests. `final-frontend-unit-full`: exit 0, 92/92 files, 653/653 tests. This provides timing-race evidence, not a claim of exhaustive flake elimination.
- Base-only game-data control: Git overlay restores the only changed entity imported by that suite; exit 1, **34 failed / 6 passed / 40 total**, same missing-data failures. Existing test explicitly assigns GAME_DATA_PATH to empty game-data/data and dereferences absent REBEL_FIGHTER_A_WING. Private data must be supplied locally by coordinator/user or an independently authorized fixture design agreed; neither copied from another checkout nor fabricated.

## First-pass final serial gate results — historical NOT-GREEN state
The prior complete run below predates authorization of local input/pin preservation. Current normal Nx/local-data outcomes are recorded in the follow-up section; old failures are retained for reproducibility.

| Gate / ledger ID | Exit | Result / limitation |
| --- | ---: | --- |
| `final-frontend-unit-full` | 0 | 92 passed files, 653 passed tests; zero skipped |
| `final-backend-spec-types` | 0 | Spec-inclusive backend project-reference declaration/type build |
| `final-frontend-spec-types` | 0 | Spec-inclusive frontend project-reference declaration/type build; original eight diagnostics resolved |
| `final-shared-build` | 0 | Shared TypeScript library build |
| `final-frontend-build` | 0 | Frontend Vite production build; CSS import-order and >500kB bundle warnings remain |
| `final-backend-production-types` | 0 | Backend application declaration/type build, NOT a Webpack build |
| `final-backend-build` | 2 | Actual npm backend workspace Webpack: `No cached ProjectGraph is available` |
| `final-nx-lint` | 1 | Nx fails pnpm graph parsing because npm installation lacks `node_modules/.modules.yaml` |
| `datasource-ts-mts-parity` | 0 | Sources identical after normalizing ESM `.js` relative import specifiers; NOT `.mts` runtime execution |
| `cli-datasource-disposable` | 0 | Actual `.ts` datasource initializes; 204 migrations applied, repeat 0, no pending migrations, `synchronize=false` |
| `final-changed-lint` | 0 | All 41 changed/new app paths checked: 25 ESLint warnings, zero errors; separately 39 no-cached-graph warnings; module boundaries skipped |
| `final-backend-units-repeat` | 1 | 209 passed suites, 1 failed, 1 skipped (211 total); 1944 passed tests, 34 failed, 1 skipped (1979 total); same missing-private-data failures |
| `integration-full` | 0 | 36 suites, 290 tests, zero skipped; complete migrations-backed disposable PostgreSQL run |
| `lint-direct` | 1 | Broad app/shared lint: 3 errors / 1500 warnings; separately 1198 graph-unavailable warnings; module boundaries skipped |

Disposable CLI replay used the existing harness global setup/teardown; both ambient URL variables were unset before launch, and the harness-created URL was passed to the datasource only inside the process. The datasource and harness were destroyed in `finally`. No shared/development database used. Successful replay is additional evidence beyond metadata-only regression and full integration, not schema-synchronization approval.

Duplicate migration datasource table metadata is confirmed for `faction_modifiers`, `factions`, `users`. Required relation targets pass and replay succeeds with synchronization disabled, but duplicate app/migration entity metadata remains an independent-review risk. Do not enable synchronization or infer complete app boot from this result. `.mts` runtime command remains unverified; source parity is the evidence available.

### Reproduction commands
Run in this isolated worktree after the recorded npm-only offline installation. Exact original invocations (including RED overlays and focus paths), exits, durations and logs are in `.workmux/gate-results.tsv`. Default backend tests require the compiler environment below; integration must unset both ambient DB URLs so the disposable harness owns the database.

```sh
# Spec-inclusive types, then builds, serially:
npx --no-install tsc --build apps/backend/tsconfig.json --emitDeclarationOnly
npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly
npx --no-install tsc --build packages/shared/tsconfig.lib.json
npx --no-install vite build --config apps/frontend/vite.config.mts
npx --no-install tsc --build apps/backend/tsconfig.app.json --emitDeclarationOnly
npm exec --offline --workspace=@org/backend -- webpack-cli build --node-env=production

# Full unit suites:
npx --no-install vitest run --config apps/frontend/vite.config.mts --maxWorkers=1
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand

# Broad lint (both currently red; direct lint skips graph checks):
npx --no-install eslint apps/backend apps/frontend packages/shared
npx --no-install nx run-many --target=lint --all --parallel=1 --skip-nx-cache

# Full real-migration integration on disposable PostgreSQL only:
env -u INTEGRATION_DATABASE_URL -u DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.integration.config.cts --runInBand

# Additional migration-config evidence (ignored local verification scripts):
node .workmux/verify-datasource-parity.cjs
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_PROJECT=apps/backend/tsconfig.app.json TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' node --require ts-node/register --require tsconfig-paths/register .workmux/verify-cli-disposable.cjs
```

The recorded runner also supplies `npm_config_offline=true NX_DAEMON=false NX_INTERACTIVE=false`. Do not interpret direct successful gates as Nx graph success. No test exclusions were added to reach these results.

## Final scope and snapshot integrity
Final `git diff --check`: exit 0. Index empty. All changed paths are under `apps/`; no protected tracker/map/package/lockfile/nx.json/STU paths changed. Tracked diff: **38 files, 387 insertions, 52 deletions**; three untracked app regression specs are additional to that stat. No commits; final HEAD remains the base.

31 snapshot-tracked paths, all retained:
```text
apps/backend/jest.config.cts
apps/backend/src/database/migration-tests/20261023-character-order.int-spec.ts
apps/backend/src/database/migrations/20261023110000-prepare-user-characters.ts
apps/backend/src/database/migrations/support/character-migration-history.ts
apps/backend/src/database/typeorm-migration.config.mts
apps/backend/src/database/typeorm-migration.config.ts
apps/backend/src/modules/alliance/alliance.module.ts
apps/backend/src/modules/auth/npc-account.service.spec.ts
apps/backend/src/modules/auth/npc-account.service.ts
apps/backend/src/modules/auth/user.entity.ts
apps/backend/src/modules/messaging/messaging.module.ts
apps/backend/src/modules/spacecraft/field-effect-consequence.spec.ts
apps/backend/src/modules/spacecraft/field-effect-consequence.ts
apps/backend/src/modules/spacecraft/spacecraft-boarding.service.spec.ts
apps/backend/src/modules/spacecraft/spacecraft-boarding.service.ts
apps/backend/src/modules/spacecraft/spacecraft-scan.service.ts
apps/backend/src/modules/spacecraft/spacecraft.module.ts
apps/backend/src/modules/spacecraft/spacecraft.service.ts
apps/backend/src/modules/starmap/entities/layer-knowledge.entity.ts
apps/backend/src/modules/starmap/layer-map-cycle.service.spec.ts
apps/backend/src/modules/tick/tick-admin.service.spec.ts
apps/backend/src/modules/tick/tick-admin.service.ts
apps/backend/src/modules/tick/tick.module.ts
apps/backend/src/modules/tick/wreck-decay.service.spec.ts
apps/backend/src/modules/tick/wreck-decay.service.ts
apps/backend/src/modules/tutorial/tutorial-definitions.ts
apps/backend/src/modules/tutorial/tutorial.module.ts
apps/backend/src/modules/tutorial/tutorial.service.spec.ts
apps/backend/src/modules/tutorial/tutorial.service.ts
apps/frontend/src/components/tutorial/useTutorial.spec.tsx
apps/frontend/src/components/tutorial/useTutorial.ts
```
The imported hook regression was strengthened with asynchronous response flushing as described above; snapshot originals were not altered.

Three new snapshot specs:
```text
apps/backend/src/database/typeorm-migration-config.spec.ts
apps/backend/src/modules/messaging/messaging.module.spec.ts
apps/backend/src/testing/app-module-graph.spec.ts
```
Seven additional tracked fixture/test-only paths beyond snapshot; six resolve the eight reproduced TypeScript diagnostics, one repairs the reproduced research selector timing race:
```text
apps/frontend/src/components/spacecraft/SpacecraftMessageBar.spec.tsx
apps/frontend/src/pages/colonies/components/PanelFabrication.spec.tsx
apps/frontend/src/pages/colonies/components/PanelTelescope.spec.tsx
apps/frontend/src/pages/dashboard/DashboardLowerSections.spec.tsx
apps/frontend/src/pages/holonet.spec.tsx
apps/frontend/src/pages/research.spec.tsx
apps/frontend/src/pages/tutorial-targets.spec.tsx
```
No additional product source correction beyond the preserved snapshot. No preserved group was removed; risks and verification limitations are explicitly recorded rather than automatically accepting them as fully verified.

Snapshot SHA-256 values rechecked unchanged at final scope audit:
```text
apps-tracked.patch: ab38e3bc0ee7122e0efc2137674658937d67570dff7c65e27eabf257534cb5cd
typeorm-migration-config.spec.ts: e9d4961e5b4da5980e0cd2d661a007df3ccb79dca500bd25687589df2730a8af
messaging.module.spec.ts: 5819a0f9d1c2a9096d1b2174011e01c0b3daea4c85f6662ce4cb9c714dad01f5
app-module-graph.spec.ts: 116ae5476d4d49b353ccc14c4909ad220f3ef8ba3d06d7a7bfb33af99410c7eb
```
Private submodule pins are uninitialized: game-data `0c195e180469abff0eb40b721ffe32f1985e61aa`, assets `38aa9340e4a2d553b02d9331dab37176729c6a56`. Node v24.22.1; npm 11.19.1. Cached local PostgreSQL 16 Alpine/Ryuk images used by the existing harness; no private submodule fetch or external data disclosure.

## Missing private YAML diagnostics
The backend unit logs emitted missing-file diagnostics for these 36 distinct paths, relative to `game-data/data/`. This is observed missing input, not an exhaustive game-data manifest. The conditional mining-field skip specifically requires the two SWU field/category/resource paths noted below.
```text
buildings/stu-building-functions.yaml
buildings/stu-building-upgrades.yaml
buildings/stu-buildings.yaml
buildings/stu-field-build.yaml
buildings/swu-field-build-categories.yaml
colony-classes/stu-colony-classes.yaml
colony-classes/swu-letter-resources.yaml
colony-social/stu-social-effects.yaml
combat/formulas.yaml
combat/weapon-shield-modifiers.yaml
commodities/stu-commodity-map.yaml
fabrication/stu-fabrication.yaml
fabrication/stu-module-stats.yaml
modules/cargo.yaml
modules/computer.yaml
modules/engines.yaml
modules/hull.yaml
modules/hyperdrive.yaml
modules/life-support.yaml
modules/sensors.yaml
modules/shields.yaml
modules/special.yaml
modules/tractor-beam.yaml
modules/weapons.yaml
research/imperials.yaml
research/rebels.yaml
ship-building/escape-pod-presentations.yaml
ship-building/ship-class-hangar.yaml
ship-building/ship-class-slots.yaml
ship-building/ship-classes.yaml
ship-building/stu-rump-crew.yaml
ship-building/stu-rump-module-rules.yaml
ship-building/stu-rump-specials.yaml
ship-building/stu-rump-stats.yaml
terraforming/stu-terraforming.yaml
torpedoes/stu-torpedoes.yaml
```

## Outstanding gates / coordinator decisions — historical first pass
The environmental decisions below were subsequently authorized by the follow-up user prompt. Current status supersedes this historical stopping point; see follow-up verification after this section.
1. **Private data:** provide the correct pinned game-data locally under an authorized procedure, then rerun all backend units and missing SWU fixture coverage. Assets also absent; successful frontend build does not prove runtime asset availability. Do not fabricate YAML, copy from another checkout, fetch privately, or weaken/skip failures without new authorization.
2. **npm/Nx:** decide whether to authorize the minimal existing npm pin `cli: { packageManager: 'npm' }` in `nx.json`. It was deliberately not imported or edited. Once authorized, rerun actual Nx graph/lint and actual backend Webpack build serially. No `.modules.yaml` fabrication or dependency-tool patching.
3. **Lint rule registration:** separately decide scoped correction of the missing `react-hooks/exhaustive-deps` rule registration. Three ColoniesPage references fail broad lint; changed-file lint success does not waive them. Recheck boundaries with a valid graph, not skipped checks.
4. **Independent review:** evaluate duplicate app/migration metadata, Nest-internal/static regression seams and missing full app boot/provider graph coverage; review `.mts` runtime if required. Existing ts-jest `isolatedModules` deprecation, CSS import-order, bundle size and lint warnings remain disclosed, not fixed by tooling edits.

FIRST-PASS STOP (historical): all app corrections left uncommitted with exact environmental blockers. No merge/push or shared database migration. The follow-up below continues only the specifically authorized local-pin/data preservation and normal serial verification.

## Follow-up local-only inputs and current evidence — 2026-11-09
- Imported exact `.workmux/preserved-local-inputs/existing-npm-pin.patch`; its only diff is three added `nx.json` lines establishing `cli.packageManager: npm`. SHA-256 `6455457e790c521a9dc22a59ce060d7ffae0c68e7010b68c30425d83bd9eba65`. Exact diff text and parsed JSON audited; no other tooling edits.
- Previously absent `game-data/data` is a local relative symlink to `../.workmux/preserved-local-inputs/game-data/data`. Coordinator manifest verified for **49 total files, 42 `.yaml` files** (also existing backup/Markdown/.DS_Store entries). No content created/edited, fetching or transfer. Local inventory hashes in `.workmux/local-input-integrity.json`; content not disclosed. This is **data-backed local validation**, not verification that the coordinator's local contents equal a committed private submodule revision. Gitlinks unchanged; no submodule initialized.
- Assets remain absent. Current unit/type/build gates required no download or asset modifications; successful build is not runtime asset validation.
- `followup-nx-graph`: exit 0, shared/frontend/backend discovered. `followup-nx-sync-check`: exit 0, workspace up to date. Every normal target uses `--skipSync` to prevent automatic tsconfig/package edits, `--parallel=1`, disabled local/remote caches and daemon. Sync is checked separately, not waived.
- Fresh graph differs from stale cached inspection: normal frontend `typecheck` is now `tsc --build --emitDeclarationOnly`, not the prior cached app-only command. Explicit forced backend/frontend spec-inclusive checks also ran.
- `followup-frontend-lint-config`: exit 0; effective frontend `react-hooks/exhaustive-deps` severity 1 (warn), `rules-of-hooks` 2 (error), module-boundaries 2 (error), plugins registered. Prior root-cwd lint selected root config without React hooks and produced wrong-seam missing-rule diagnostics. These are not stale suppressions and no source/rule edits were made.
- `followup-nx-lint`: exit 0; shared zero diagnostics, backend 1423 warnings, frontend 108 warnings; **1531 warnings, zero errors**, **zero cached-graph unavailable warnings**, module-boundaries active. Warnings not eliminated or hidden.
- `followup-nx-types`: exit 0 for all three normal targets and prerequisite shared build. `followup-backend-spec-types`, `followup-frontend-spec-types`: both exit 0 using `--force` declaration/type builds.
- `followup-backend-unit-full`: exit 0, **211/211 suites, 1979/1979 tests**, **zero skipped**. Previously skipped mining fixture coverage ran using existing categories/resources inputs. All previous 34 missing-data failures now pass without test/product changes.
- `followup-frontend-unit-full`: exit 0, **92/92 files, 653/653 tests**, **zero skipped**.
- `followup-nx-builds`: exit 0 for shared/frontend/backend, actual backend Webpack succeeds. Frontend 1104 transformed modules; CSS @import-order and >500kB bundle warnings remain. Existing ts-jest isolatedModules deprecation remains; intentional negative-path service logs in passing tests are not suppressed.

### Pre-commit review hold — historical finding, subsequently authorized for minimal correction
**CONFIRMED BLOCKER IN PRIOR CANDIDATE — incomplete Buoy repository injection repair.** Changed injection slots in `apps/backend/src/modules/spacecraft/spacecraft.service.ts:215` and `apps/backend/src/modules/spacecraft/spacecraft-scan.service.ts:71` now use real Buoy repositories. `apps/backend/src/app.module.ts:159-269` has an explicit datasource entity list with no Buoy and no autoLoadEntities. Module-level `forFeature` creates a provider but does not add metadata to this explicit root list. Calling a repository operation requires the missing metadata. Concrete affected call paths: field-context Buoy lookup at `spacecraft.service.ts:3405`, list at `:3230`, sector scanning at `spacecraft-scan.service.ts:119`.

Ignored `.workmux/app-datasource-buoy.spec.ts` obtains actual `TypeOrmModuleOptions` through the application module's nested dynamic core provider and Nest testing module, builds actual application metadata in memory with `synchronize=false`, then asks the Buoy repository for metadata. No connection/migration is made. `followup-app-buoy-metadata-valid`: **exit 1, one failed test**, explicitly logs `Application datasource registers Buoy: false`, then throws **`EntityMetadataNotFoundError: No metadata for "Buoy" was found.`** This is a candidate runtime-boundary failure, not an environment failure. The first probe (`followup-app-buoy-metadata`) looked only one module level deep and failed its probe setup assertion; it is **not** used as evidence. The corrected probe builds metadata successfully, then fails at the repository boundary itself.

No production correction added. The user restricted new product/architecture scope and required preserving all candidate paths. The concrete minimal option for coordinator review is explicit registration of the existing Buoy entity in the application root datasource together with an enduring regression at this boundary; this would add an app source/test path and requires scoped authorization. Do not enable autoLoadEntities globally, synchronize, undo injections, hide the probe or label normal gates sufficient. Existing mocked DI tests/import scanner miss this condition.

### Remaining refreshed results
- `followup-hook-lint-proof`: exit 0, actual frontend config confirms all three retained comments suppress active exhaustive-deps warnings. Removing only comments **in memory** exposes all three; source and effective rules remain unchanged. Prior root broad-lint errors are a configuration-seam mismatch, not an active-rule waiver. No lint defect correction warranted.
- `followup-backend-focused`: exit 0, **10 suites / 32 tests**, zero skipped.
- `followup-frontend-focused`: exit 0, **8 files / 64 tests**, zero skipped, includes research assertion and six typed fixtures/tutorial. Existing React `strokeDashoffset` NaN warning remains observed; no product change to eliminate it.
- `followup-integration-full`: exit 0, **36 suites / 290 tests**, zero skipped, through normal `backend:test-integration` Nx target with both ambient database URLs unset; harness-only PostgreSQL and real migrations. Intentional error-path asset/socket logs belong to passing tests.
- `followup-datasource-source-parity`: exit 0; `.ts`/`.mts` match after relative ESM `.js` import normalization. **`.mts` runtime remains unverified**.
- `followup-cli-datasource-disposable`: exit 0; actual `.ts` datasource initializes on fresh harness-owned PostgreSQL, applies **204 migrations**, repeat **0**, pending false, synchronize false; teardown in finally. Confirmed duplicate table metadata remains **faction_modifiers, factions, users**.
- `followup-final-sync-check`: exit 0, no pending synchronization changes.

### Explicit residual review risks
Duplicate app/migration entity metadata is compatible with the tested forward replay while `synchronize=false`; that does not validate migration generation/schema-diff SQL. The two User mappings are not identical, so generation or synchronization is not approved and may propose destructive column churn. Preserve this distinction.
The previous-calendar migration regression validates forward adoption and rollback of newly applied bridge/current migrations while preserving historical data; it does not establish rollback through the absent historical `AddUserCharacters20261023120000` implementation. That original-owner rollback remains a compatibility limitation, not a proven forward data-loss defect.
Full application initialization/provider instantiation, `.mts` runtime, runtime assets, full DTO validation and exhaustive research-flake elimination remain outside the demonstrated passing seams.

### Previous scope / commit disposition — historical Buoy review hold
All **42 paths** match the explicit allowlist: original 41 app candidate paths plus exact npm pin. **39 modified tracked files, 390 insertions / 52 deletions; three new untracked regression specs**. App candidate byte hashes unchanged since the normal gates; both snapshots/49-file manifest intact. `git diff --check` exit 0; index empty; no commits. HEAD/base remains `7e7143d80d155b312dca1ad0d6a5304c38d54571`.
Eight planned logical groups cover all paths exactly once; research correction remains a one-file separate group. Commit execution is held because the aggregate candidate has a concrete red metadata gate, even though normal requested gates pass. No group staged or committed. No imported `ee90beb6`, F3d/H1/I1c fix, tracker/map change, merge/push, shared DB migration, main-checkout access or unapproved tooling/data changes.

### Previous follow-up command ledger — historical pre-fix hold
At that stopping point `.workmux/gate-results.tsv` contained **70 exact executions, 19 follow-up commands**, with individual exits, millisecond durations and log paths. 17 follow-up commands pass; one invalid initial probe and the valid failing runtime probe are clearly distinguished. `.workmux/run-gate.cjs` batch status is not gate truth. All builds/typechecks/tests ran serially with offline npm, no Nx daemon/remote cache, one Nx task at a time and skipSync prevention; sync checks pass separately.

Normal follow-up target patterns:
```sh
npx --no-install nx show projects
npx --no-install nx sync:check
npx --no-install nx run-many --target=lint --projects=shared,frontend,backend --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
npx --no-install nx run-many --target=typecheck --projects=shared,frontend,backend --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
npx --no-install tsc --build apps/backend/tsconfig.json --emitDeclarationOnly --force
npx --no-install tsc --build apps/frontend/tsconfig.json --emitDeclarationOnly --force
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install nx run backend:test --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static --runInBand
npx --no-install nx run frontend:test --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static --args='--run --maxWorkers=1'
npx --no-install nx run-many --target=build --projects=shared,frontend,backend --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install nx run backend:test-integration --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static --args='--runInBand'
# Confirmed failing no-database repository metadata probe:
TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config .workmux/jest-app-datasource.config.cjs --runInBand --no-cache
```
Exact focused, effective-config, hook-in-memory and datasource replay commands/logs are in the ledger. Ignored `.workmux/followup-refresh.sh` preserves the serial reproduction sequence. Local data symlink is environmental input only, not staged.

PREVIOUS STOP (historical): environmental gates repaired, confirmed Buoy runtime blocker held commits until explicit user authorization. That authorization was subsequently provided; the minimal acceptance correction and final results follow below. No branch integrated.

## Buoy root metadata acceptance — 2026-11-09
User specifically authorizes existing Buoy explicit root registration and an enduring no-database runtime metadata regression. Existing relation dependencies were already registered: User, Spacecraft, SpaceLocation. No additional entity/architecture expansion required.
- Production delta: `app.module.ts` imports Buoy next to CargoItem and adds Buoy next to CargoItem in the explicit root datasource list. Exactly two added source lines; no option/synchronize/autoload changes.
- Permanent regression: extended existing `apps/backend/src/testing/app-module-graph.spec.ts`, already transformed by preserved ts-jest Jest rule. Extracts the application's actual nested TypeORM options provider, resolves it through a small Nest testing module with a config-only test input, constructs actual TypeORM entity metadata, accesses real Buoy repository metadata and checks table/target plus actual User/Spacecraft/SpaceLocation relation target metadata. A tiny DataSource subclass exposes protected metadata build; no repository mocks/static list assertion/connection/shared DB. `isInitialized=false` asserted.
- `buoy-permanent-red`: exit 1, **one failed / one passed**, with unpatched root `EntityMetadataNotFoundError: No metadata for "Buoy" was found`. Actual permanent seam RED before production edit, not setup/environment failure.
- `buoy-permanent-green`: exit 0, **2/2 tests** after the two-line root fix.
- `buoy-backend-types`: exit 0 normal backend Nx typecheck and two prerequisite tasks.
- `buoy-backend-lint`: exit 0, **1423 warnings / zero errors**, graph-boundary checks active. No comments/rules changed.
Final source SHA-256 / Git blob IDs:
```text
apps/backend/src/app.module.ts
  sha256 c36e50074b06c92192083ada91ebdc67c361349389926468f0506ebcc4dd428e
  git blob 9fbb3c78f41187ed8621ee348ff57e8be83395da
apps/backend/src/testing/app-module-graph.spec.ts
  sha256 bb9265c8b613179f39ee57333cac7c59836d2225ff887aca677f83bead887d1c
  git blob 85fee3cd6530d37f463a64e1d065066f42a45b9a
```
Scope is **43 paths**: all original 42 retained plus app.module.ts; no extra permanent file needed. All old app/nx candidate bytes unchanged except the authorized extension of app-module-graph.spec.ts; final full candidate hashes saved in `.workmux/final-candidate-integrity.json`. All nine frontend candidate files byte-identical to previous run: **653/653 full units**, **64/64 focused tests**, spec-inclusive types, frontend lint **108 warnings/zero errors**, frontend build success retained. Root metadata/backend test edits do not modify frontend/shared contracts. No frontend re-run claimed.
Resume audit after accidental tmux termination: actual ledger records confirm every queued post-Buoy command completed with exit 0 before the interruption. Terminal logs independently confirm focused 13/69, full units 211/1980, successful Webpack, integration 36/290, runtime probe 1/1 and up-to-date sync. Forced spec-inclusive typecheck is recorded exit 0 with an empty success log. No command was missing/failed/unrecorded, so no redundant rerun was performed. Final 43-path source hashes, nine frontend source hashes, original snapshots and all 49 local inputs were revalidated before committing. The background task's lost session-completion notification was not treated as a gate verdict. All commits and final acceptance results follow below.

## Final committed acceptance result — 2026-11-09

**All required current gates and permanent Buoy runtime metadata regression pass.**
Base: `7e7143d80d155b312dca1ad0d6a5304c38d54571`. Final source/HEAD: `14b860813b988165f8470c0c9d3b31e087f70aa2`. Eight focused local commits; worktree and index clean.
No merge/push, external transfer, main-checkout access, autoload/synchronize, private submodule fetch, tracker/feature integration or other tooling/data edits.

| Fresh backend acceptance command ID | Exit | Duration ms | Log |
| --- | ---: | ---: | --- |
| `buoy-permanent-green` | 0 | 5946 | `.workmux/gates/buoy-permanent-green.log` |
| `buoy-backend-types` | 0 | 17876 | `.workmux/gates/buoy-backend-types.log` |
| `buoy-backend-lint` | 0 | 17250 | `.workmux/gates/buoy-backend-lint.log` |
| `buoy-backend-focused` | 0 | 20356 | `.workmux/gates/buoy-backend-focused.log` |
| `buoy-backend-spec-types` | 0 | 13670 | `.workmux/gates/buoy-backend-spec-types.log` |
| `buoy-backend-unit-full` | 0 | 90625 | `.workmux/gates/buoy-backend-unit-full.log` |
| `buoy-backend-build` | 0 | 14121 | `.workmux/gates/buoy-backend-build.log` |
| `buoy-integration-full` | 0 | 389432 | `.workmux/gates/buoy-integration-full.log` |
| `buoy-runtime-probe-green` | 0 | 11130 | `.workmux/gates/buoy-runtime-probe-green.log` |
| `buoy-final-sync-check` | 0 | 7518 | `.workmux/gates/buoy-final-sync-check.log` |

Exact commands (serial, actual exits above):
```sh
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --no-cache --runTestsByPath apps/backend/src/testing/app-module-graph.spec.ts
npx --no-install nx run backend:typecheck --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
npx --no-install nx run backend:lint --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config apps/backend/jest.config.cts --runInBand --runTestsByPath apps/backend/src/testing/app-module-graph.spec.ts apps/backend/src/database/typeorm-migration-config.spec.ts apps/backend/src/modules/messaging/messaging.module.spec.ts apps/backend/src/modules/auth/npc-account.service.spec.ts apps/backend/src/modules/spacecraft/spacecraft-field.spec.ts apps/backend/src/modules/spacecraft/spacecraft-scan.service.spec.ts apps/backend/src/modules/spacecraft/spacecraft-core-controls.spec.ts apps/backend/src/modules/spacecraft/spacecraft-boarding.service.spec.ts apps/backend/src/modules/spacecraft/field-effect-consequence.spec.ts apps/backend/src/modules/tick/tick-admin.service.spec.ts apps/backend/src/modules/tick/wreck-decay.service.spec.ts apps/backend/src/modules/tutorial/tutorial.service.spec.ts apps/backend/src/modules/starmap/layer-map-cycle.service.spec.ts
npx --no-install tsc --build apps/backend/tsconfig.json --emitDeclarationOnly --force
npx --no-install nx run backend:test --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static --runInBand
npx --no-install nx run backend:build --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL npx --no-install nx run backend:test-integration --parallel=1 --skipSync --skip-nx-cache --skipRemoteCache --outputStyle=static --args='--runInBand'
env -u DATABASE_URL -u INTEGRATION_DATABASE_URL TS_NODE_COMPILER_OPTIONS='{"moduleResolution":"node10","module":"commonjs","customConditions":null}' npx --no-install jest --config .workmux/jest-app-datasource.config.cjs --runInBand --no-cache
npx --no-install nx sync:check
```

The full append-only gate ledger contains 81 executions, including historical failures and explicitly invalid probes. These are preserved, not deleted or counted as acceptance successes.

Observed fresh summaries:
- `buoy-backend-focused`: Test Suites: 13 passed, 13 total; Tests:       69 passed, 69 total
- `buoy-backend-unit-full`: Test Suites: 211 passed, 211 total; Tests:       1980 passed, 1980 total
- `buoy-integration-full`: Test Suites: 36 passed, 36 total; Tests:       290 passed, 290 total
- Fresh permanent and ignored acceptance probes pass; all recorded passing suites report no skipped tests. The previous missing-data mining conditional skip now runs with the authorized local inputs.
- Frontend retained byte-identical evidence: 92 files / 653 tests; 8 focused files / 64 tests; forced spec-inclusive types; lint 108 warnings / zero errors; Vite production build. Shared normal type/build/lint evidence retained; prerequisite shared builds also refreshed by backend targets. No unchanged-gate rerun falsely claimed.
- Backend lint 1423 warnings / zero errors, graph-boundary checks active with no graph-unavailable skips. Aggregate prior proper-cwd lint 1531 warnings / zero errors. No rule/suppression removals or disabled rules.
- Existing ts-jest isolatedModules deprecation, React NaN strokeDashoffset fixture warning, CSS import-order and >500kB bundle warnings retained. Passing intentional negative-path service/asset/socket error logs are not hidden failures.

### Focused local commit ledger

| SHA | Subject | Paths |
| --- | --- | ---: |
| `659dcc8389343c70c581a72fd9dc53b0e8c5ecd5` | fix(tooling): preserve existing npm pin for Nx gates | 1 |
| `6dd206ef3cbcbebc94ebc5de8b57d5ab833b8d4b` | fix(database): repair migration datasource relation metadata | 5 |
| `36d0bf40cfce2b8203878cdb3d4ce3ee174490c8` | fix(database): preserve historical character migration ownership | 3 |
| `95d06cd15eb008536674728c4beca72e2ad58a59` | fix(backend): repair module wiring and injectable dependencies | 23 |
| `347eb88568c4e2aa6c973ac2005bbda19fd2bcf0` | fix(auth): fit NPC supply username within column limit | 2 |
| `1e469840ec6eebadc7b56e4c3246a42acc24ef30` | fix(frontend): reject malformed tutorial navigation responses | 2 |
| `776df59716f640e9130155b11749a8f8f2b6e646` | test(frontend): repair typed baseline fixtures | 6 |
| `14b860813b988165f8470c0c9d3b31e087f70aa2` | test(research): await alternative detail action rendering | 1 |

Each commit ends with `Co-Authored-By: Claude Code <noreply@anthropic.com>`. Research async assertion correction is the final independent one-file commit for later conflict resolution. Provider consumers/registrations, root Buoy fix and permanent regression stay in the same backend logical repair commit.

### Scope, integrity and limitations

Final range contains exactly 43 authorized paths: previous 42 plus `app.module.ts`, with permanent regression in an already-imported testing file. No package/lockfile/other tooling/STU/tracker/map changes; exact three-line preserved npm pin is the only nx.json delta. Local data is a relative symlink to ignored coordinator snapshot; 49-file manifest and immutable original snapshots verified. Data-backed local validation, not proof of private submodule commit provenance. Assets absent but no current gate required a download or modification.
Final source SHA-256 hashes for every candidate path are in `.workmux/final-candidate-integrity.json`; root and regression SHA-256/Git blob IDs are recorded above. Commit SHA covers the actual final source, not merely a test log.
Actual application root metadata and Buoy/User/Spacecraft/SpaceLocation relation targets now pass without connecting. **This does not establish full Nest application boot/provider instantiation or end-to-end HTTP operation.**
Migration `.ts` actual datasource replay remains 204 then 0 migrations, pending false, synchronize false; full fresh disposable integration also passes after root-options correction. `.mts` source parity passed, but **`.mts` runtime unverified**. Duplicate migration/app metadata for users/factions/faction_modifiers remains a schema-generation/synchronization risk; no migration generation or synchronization approved. Historical previous-calendar owner rollback remains limited to demonstrated forward adoption/new-migration rollback, not absent owner implementation.
No ee90beb6, F3d/H1/I1c correction, tracker resolution or branch integration. Stop for independent review and serial integration. All required current acceptance gates green within these explicitly bounded seams; no broad application-boot/asset/schema-generation claim.

## Serial baseline integration into stu-parity — 2026-11-09

Independent gpt-6.1-sol review PASS for exact eight commits / 43 paths supplied by user; no blocking P0/P1/P2. Two nonblocking P3 notes (DI test titles and duplicate random formulas) deliberately not refactored.
User explicitly narrowed the prior worker main-checkout ban only for safe reviewed-range fast-forward and path-scoped original preservation. No other checkout/feature/tracker/tooling work authorized or performed.
Main checkout discovered via `git worktree list --porcelain`: `/Users/TMUNDIN/git/github.com/swuniverse/core` on `stu-parity`.
Before HEAD: `7e7143d80d155b312dca1ad0d6a5304c38d54571`. After HEAD: `14b860813b988165f8470c0c9d3b31e087f70aa2`. Ordinary `git merge --ff-only` of this exact SHA, automatic stash disabled; exit 0. Eight existing linear commits, no merge/squash/rebase/new commit.

### Original overlap preserved permanently

Named stash **`stu-parity-original-baseline-20261109`**, OID **`c46b537b8517893d741ce701ba14939d58663506`**. **35 paths: 32 tracked (31 original app files + nx.json) and 3 original untracked app regression specs.**
Before preservation: expected base HEAD, empty index, no unmerged/rename entries. Original tracked apps patch, exact npm pin patch and all three untracked regressions matched immutable local snapshots byte-for-byte. No concurrent content/index changes observed during pre/post checks.
Preservation used `git --literal-pathspecs stash push --include-untracked -m stu-parity-original-baseline-20261109 -- <exact 35 overlap paths>`. No unrelated tracker/brag path passed, staged or stashed. Stash captured immediately by unique tag/OID rather than shared-stack position.
Stash tracked diff matches original app and npm pin snapshots; untracked parent contains exactly the three regression files; all 35 preserved blobs match original hashes. Stash index parent matches base; no unrelated entries. Originals recoverable by OID; **do not automatically pop/drop**. New committed baseline supersedes original working bytes without silently discarding them.

Preserved tracked paths:
```text
apps/backend/jest.config.cts
apps/backend/src/database/migration-tests/20261023-character-order.int-spec.ts
apps/backend/src/database/migrations/20261023110000-prepare-user-characters.ts
apps/backend/src/database/migrations/support/character-migration-history.ts
apps/backend/src/database/typeorm-migration.config.mts
apps/backend/src/database/typeorm-migration.config.ts
apps/backend/src/modules/alliance/alliance.module.ts
apps/backend/src/modules/auth/npc-account.service.spec.ts
apps/backend/src/modules/auth/npc-account.service.ts
apps/backend/src/modules/auth/user.entity.ts
apps/backend/src/modules/messaging/messaging.module.ts
apps/backend/src/modules/spacecraft/field-effect-consequence.spec.ts
apps/backend/src/modules/spacecraft/field-effect-consequence.ts
apps/backend/src/modules/spacecraft/spacecraft-boarding.service.spec.ts
apps/backend/src/modules/spacecraft/spacecraft-boarding.service.ts
apps/backend/src/modules/spacecraft/spacecraft-scan.service.ts
apps/backend/src/modules/spacecraft/spacecraft.module.ts
apps/backend/src/modules/spacecraft/spacecraft.service.ts
apps/backend/src/modules/starmap/entities/layer-knowledge.entity.ts
apps/backend/src/modules/starmap/layer-map-cycle.service.spec.ts
apps/backend/src/modules/tick/tick-admin.service.spec.ts
apps/backend/src/modules/tick/tick-admin.service.ts
apps/backend/src/modules/tick/tick.module.ts
apps/backend/src/modules/tick/wreck-decay.service.spec.ts
apps/backend/src/modules/tick/wreck-decay.service.ts
apps/backend/src/modules/tutorial/tutorial-definitions.ts
apps/backend/src/modules/tutorial/tutorial.module.ts
apps/backend/src/modules/tutorial/tutorial.service.spec.ts
apps/backend/src/modules/tutorial/tutorial.service.ts
apps/frontend/src/components/tutorial/useTutorial.spec.tsx
apps/frontend/src/components/tutorial/useTutorial.ts
nx.json
```
Preserved original untracked regressions:
```text
apps/backend/src/database/typeorm-migration-config.spec.ts
apps/backend/src/modules/messaging/messaging.module.spec.ts
apps/backend/src/testing/app-module-graph.spec.ts
```
Pre-existing stash also remains intact: `baac46101477d1e2c0a6657bcdb1b4bc21daca5a`. Neither stash popped/dropped; no stash cleanup.

### Unrelated changes / integrated source integrity

**65 unrelated paths unchanged**, checked by SHA-256, file mode/symlink state and exact status: **10 tracked dirty + 55 untracked**. Includes **20 issue paths** (10 tracked + 10 untracked) and **45 untracked brag paths**. No issue/map/brag/STU/package/lockfile content edited or staged.
Before and after full status/hash inventories: `.workmux/serial-integration-before.json` and `.workmux/serial-integration-after.json`. The 43 reviewed candidate source paths now match main and committed reviewed blobs against `.workmux/final-candidate-integrity.json`; 8 originally clean candidate paths were also verified against base before FF. Main index empty; expected unrelated issue/brag dirt remains. Candidate worktree stays clean.
All worktrees and branches retained; no force/reset/checkout/clean/stash drop, cleanup, branch deletion or remote operation. Ordinary fast-forward details in `.workmux/serial-integration-ff.log`; retained stash identification in `.workmux/serial-integration-stash.json`.

### Exact verification performed — no duplicate full suites

Verified candidate range contains exactly 43 authorized paths and eight existing linear commits. Verified original overlapping files/snapshots; asserted before HEAD/index; saved unrelated status/content manifest; verified preserved stash tree and every original blob; asserted post-stash main dirt; FF exit 0; verified after HEAD/index/dirt; matched all 43 source hashes in candidate/main/reviewed Git blobs; checked existing/new stash OIDs retained.
Material environment comparison: Node v24.22.1 / npm 11.19.1; candidate/main versions match for Nx, Jest, ts-jest, SWC Jest, TypeScript, Vitest, Vite, TypeORM, Nest core and Nest TypeORM. Relevant package/lockfile/tsconfig/Jest/SWC/Vite config bytes match. All 49 main local-data input files match reviewed local snapshot. `.workmux/serial-integration-environment.json` records comparison without data-content disclosure.
**No material environment difference found; no sanity or exhaustive suites rerun, and no new full-suite success claimed.** Exact existing gate ledger remains `.workmux/gate-results.tsv` (81 executions). Reviewed acceptance evidence retained: backend 211 suites / 1980 tests, focused 13 / 69, integration 36 / 290, frontend 92 files / 653 tests, zero skipped; current required types/lint/build/sync and permanent Buoy metadata GREEN. Existing warnings and no full app-boot claim unchanged.
Migration generation/synchronization still excluded because duplicate users/factions/faction_modifiers metadata; migration replay accepted only synchronize=false. `.mts` source parity only, runtime unverified. No database operation in this integration phase.

STOP: reviewed baseline integrated into stu-parity only. **No push, no D3b/ee90beb6 or other feature integration, no tracker resolution.** Ready for coordinator-controlled next serial phase; do not start it automatically.

# Independent Sol prerequisite review — 2026-11-09

## Conclusion

**Both alleged pre-existing races: CONFIRMED.** Bounded stale-movement-write protection and a shared fleet mutation/relocation concurrency contract are technically necessary before unchanged existing operations can safely coexist with complete atomic wormhole relocation. Separate prerequisite children are a reasonable delivery boundary, not the only possible implementation structure.

This is a review of evidence and technical prerequisites, **not** K7a2 implementation acceptance, endpoint approval, or a repeat of K7a1's staged-core PASS. No wormhole operation exists in the reviewed candidate. Main's supplied baseline remains `c79ff89f`; this preserved review worktree remains at `ff16922a`.

## 1. Stale movement save after lock wait — CONFIRMED

**Production:** `apps/backend/src/modules/spacecraft/spacecraft-destruction.service.ts:126-137` opens its own transaction, locks/rereads the row, checks only missing/destroyed status, then calls `manager.save(ship)` on the earlier caller entity. It neither validates that entity's original state nor derives the movement from the freshly locked row.

**Real caller seam:** `spacecraft.service.ts:347-370` loads via the global repository without a transaction/lock; `navigate` and `flyGalaxy` retain their earlier movement snapshots. Their cost/position/save paths are `:2051-2074` and `:2220-2235`. `setCurrentLocation` at `:3086-3093` changes only the in-memory entity. A stale saver returning true also allows downstream signatures/effects (`:2075-2092`, `:2236-2255`).

**Diagnostic match:** copied `stale-movement-probe.cjs:77-100` reads an actual entity, sets an old-snapshot target/cost, simulates a separately locked relocation, and calls the real public persistence method. `:102-120` observes a PostgreSQL lock wait, commits relocation, verifies the production save returned true, then reloads persisted state. The log reports committed target **2 / EPS 71 / impulse true**, subsequently overwritten with **3 / EPS 70 / impulse false**, followed by the intended RED assertion at script `:128-129`.

**Limits:** relocation and the normal-movement-style entity changes are simulated; the diagnostic is not an end-to-end `navigate` or wormhole request. In particular its inactive impulse is not a claim that actual `navigate` leaves impulse inactive. The real persistence behavior and the caller's stale-read/whole-entity-save pattern suffice to verify the race. A waiting lock serializes the write, not its earlier validation.

## 2. Fleet join validated at old location, persisted after relocation — CONFIRMED

**Production:** `spacecraft.service.ts:2839-2865` globally reads fleet, ship, and leader; checks ship eligibility and colocation; then saves membership without a shared transaction, fleet lock, or post-wait revalidation. `requireFleet` at `:2953-2958` and `findOne` at `:347-370` perform ordinary reads. The `fleetId` foreign-key relation is `entities/spacecraft.entity.ts:251-256`.

**Diagnostic match:** copied `stale-fleet-probe.cjs:71-83` constructs real repositories plus the real `ShipClassService`; these cover the executed join/findOne path, including summary hydration (`spacecraft.service.ts:1537-1543,1566-1569`). Unused constructor dependencies are not exercised. Script `:88-100` locks the fleet and current member set `[leader]`, moves the leader, then invokes real `joinFleet`. After the observed write lock wait and relocation commit, `:119-133` reloads both membership and joiner from PostgreSQL.

The final log contains **leader: location 2, fleet 1; joiner: location 1, fleet 1**, and the colocation assertion fails. **Persisted joiner fleet ID 1 is decisive.** Returned `fleetId:null` is separately disclosed; the earlier returned-object assertion was faulty/inconclusive and is not an additional race finding.

The wait query filters spacecraft lock waits, not the precise blocker identity. Together with the controlled held fleet/current-member locks, FK relation, and final persisted state, it supports the claimed interleaving; no extra claim of traced lock identity is needed.

## What these races do—and do not—establish

They do **not** demonstrate a partial commit inside the simulated relocation transaction. They demonstrate stale operations that cannot be safely ordered after that commit: movement executes from an obsolete origin; join succeeds using obsolete colocation. Concurrent fleet changes remain permitted when freshly validated—there is no requirement to freeze a fleet permanently after passage.

A new endpoint's ship/fleet locks, endpoint-only advisory locks, or serializable transaction alone cannot make unchanged global writers repeat their old validation. Equivalent shared revalidation/CAS/transaction protocols could solve this; a particular lock mechanism or broad redesign is not mandated.

## Smallest safe separable prerequisite scope

### A. Movement stale-write protection

- Validate original authoritative movement state under lock (or an equivalent conditional-write token), or perform validation/computation/persistence in one supported transaction context. Guard origin and eligibility plus resources/runtime being read or written—not just destruction or a last-minute location assignment. Relevant membership assumptions must follow the fleet contract below.
- Adapt the implicated existing navigation callers; **changing only `saveUnlessDestroyed` is insufficient** where the same movement flows bypass it with direct member saves: `spacecraft.service.ts:2082-2084,2372-2380,2523-2527,2634-2640`.
- Define stale rejection separately enough to preserve existing missing/destroyed and combat-survivor behavior (`spacecraft-destruction.service.ts:140-142`). Stop stale steps before their effects; do not merely return false and continue effects for the stale leader.
- Regression seams: barrier-controlled committed relocation versus production stale saver; a real affected movement caller with no rejected-step signatures/discovery/effects; resource/runtime-only conflicts; valid nonstale movement and terminal-destruction behavior. Scope is these movement persistence paths, not every spacecraft writer or a fleet redesign.

### B. Fleet membership/leadership mutation protocol

- Apply a consistent transaction/lock order shared with relocation; reread membership, leadership, owner/eligibility, and relevant positions **after obtaining locks**. Use narrow writes so membership operations cannot restore stale position/resource state.
- Bound this to create/join/leave/dissolve/leader changes (`spacecraft.service.ts:2817-2888,2939-2950`) and the existing movement-induced departure at `:2804-2811`. Preserve existing partial/nonfixed ordinary-flight policy; do not reuse it as wormhole participant selection. Adjacent whole-fleet saves should avoid reverting protected leadership fields, without expanding into an all-service audit.
- Regression seams: real join waiting across committed relocation, checked via persisted state; join committed first must be included in relocation's authoritative participant set; concurrent leave/dissolve/leader change must serialize or reject without stale restoration; rollback and deterministic lock ordering. Only the **join** interleaving is demonstrated by the supplied DB probe; other methods are bounded protocol participants, not separately proven identical failures.

K7a2 then implements its own manager-bound arrival effects and commit-safe notifications. This review does not independently verify the worker report's other service-by-service adapter claims or prescribe a new outbox. Keep settled rules: complete fleet atomicity, entry own activation EPS only, free exit/travel, all parent arrival effects including mandatory K5c and repair cancellation.

## Technical work versus user decisions / triage

**No missing USER product or architecture decision is demonstrated.** The product rules are settled. Choosing bounded locking/revalidation and manager adapters is technical implementation work; creating explicit prerequisite dependencies is scope management, not a new tariff, eligibility restriction, or human-only architecture mandate.

The copied `issue.md:3,41` is the worker's **uncommitted** `ready-for-human` proposal—not user authorization. Under `docs/agents/triage-labels.md:9-10`, `ready-for-human` means human implementation. Once precise technical children/dependencies are defined, **`ready-for-agent` with explicit blocking dependencies is more accurate**, while remaining blocked and unaccepted until those dependencies and joint backend acceptance are satisfied. No child or tracker change was made here.

## Evidence / execution disclosure

Read the six supplied local inputs first. Compared only implicated local production/hydration/entity/database seams. Existing disposable migration evidence was sufficient; **no diagnostic rerun, DB connection, dependency reinstall, migration replay, test suite, typecheck/build/lint, or broad gate was run**.

Copied evidence: movement final run exit **1**; fleet initial returned-object assertion exit **1** but inconclusive; fleet final persisted-state run exit **1**, confirming the claimed split. Both scripts require ambient DB URLs unset, create their own PostgreSQL 16 containers, use actual `connectIntegrationDatabase` migrations (`testing/integration/database.ts:23-37`), and `synchronize:false` (`testing/integration/data-source.ts:116-126`), with cleanup in `finally`. These are supplied runs, not independently rerun results.

Read-only shell inspection through `npm exec --offline -- node -e '…'` exited **0**: verified cwd/HEAD/clean status, no `.codegraph/`, ignored report destination, and no baseline-to-HEAD differences in the implicated service/entity/harness files; located only relevant symbols. No CodeGraph/indexing, agents/workflows, external services/secrets, STU/other-checkout access, commits/merges/push, or source/tracker/config/package/map edits. Only this ignored report was written.

**Stop:** technical prerequisite boundary supported; no endpoint registration, merge, child creation, or issue resolution authorized/performed.

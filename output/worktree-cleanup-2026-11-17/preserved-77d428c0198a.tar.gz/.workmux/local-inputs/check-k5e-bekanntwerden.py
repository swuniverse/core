from pathlib import Path
import subprocess
import sys

path = 'docs/adr/0008-ebenenkenntnis-und-kartenzyklus.md'
if sys.argv[1:] == ['--baseline']:
    text = subprocess.check_output(
        ['git', 'show', '15425192e03bdc9407cf031247f8a8b855d23312:' + path],
        text=True,
    )
    missing = [
        marker for marker in ('## Bekanntwerden einer Ebene', 'LayerKnowledgeService.markKnown')
        if marker not in text
    ]
    for marker in missing:
        print(f'RED (expected missing requirement): {marker}')
    if len(missing) != 2:
        sys.exit(1)
    print('RED confirmed against original K5e implementation commit')
    sys.exit(0)

text = Path(path).read_text()
checks = {
    'successful starter-world onboarding uses markKnown': (
        'OnboardingService.claimHomeworld' in text
        and 'erfolgreiche Claim-Pfad' in text
        and 'LayerKnowledgeService.markKnown' in text
    ),
    'actual owned-ship arrival uses markKnown': (
        'eigenen bewegenden Schiffe' in text
        and 'Galaxieflug' in text
        and 'markKnown' in text
    ),
    'markKnown preserves EXPLORED idempotently': (
        '`EXPLORED` markierte Ebene' in text and 'idempotent' in text
    ),
    'map/sensor view and foreign ship do not grant knowledge': all(
        term in text for term in ('Karten- oder Sensoransicht', 'Ankunft eines fremden Schiffs')
    ),
    'failed or rolled-back movement does not grant knowledge': (
        'zurückgerollt, erreicht der Eintritts-Callback `markKnown` nicht' in text
    ),
    'movement and wormhole transaction boundaries are distinguished': all(
        term in text for term in (
            'Bewegungstransaktion', 'Passage-Transaktion', 'Transaktionsmanager'
        )
    ),
}
failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'MISSING'}: {name}")
if failed:
    sys.exit(1)
